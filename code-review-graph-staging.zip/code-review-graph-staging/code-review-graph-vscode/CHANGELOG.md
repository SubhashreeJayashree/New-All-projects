# Changelog

## 0.3.0 - 2026-09-18

### Changed
- Accepts Python backend schema v13, shipped by code-review-graph 2.3.9.
  Earlier builds accept v9 (0.2.2) or v6 (0.2.1, the last tagged release) and
  answer a migrated database with "Database was created with a newer version".
  code-review-graph 2.3.9 migrates the graph to v13 the first time any command
  opens it, so this build has to be installed alongside it.

## 0.2.2 - 2026-04-11

### Fixed
- Compatible with VS Code 1.115 / Electron 39 by updating the extension SQLite dependency stack.

## 0.2.1 — 2026-04-08

### Fixed
- Compatible with Python backend schema v6 (no extension-side schema changes in this release)

## 0.2.0 — 2026-03-20

### Added
- **Query Graph** command with 8 query patterns (callers_of, callees_of, imports_of, etc.)
- **Find Callees** command to trace all functions called by a target
- **Find Large Functions** command to identify oversized functions/classes
- **Compute Embeddings** command to generate vector embeddings
- **Watch Mode** command for continuous graph updates
- Cursor-aware resolution for blast radius and navigation commands
- Fuzzy fallback search when exact node matches fail
- SCM decorations for git-aware file status

### Changed
- Updated README with complete command table (13 commands)
- All 13 commands now documented

## 0.1.1 — 2026-03-17

### Fixed
- CLI path setting scoped to `machine` level (security fix)
- Secure nonce generation using `crypto.randomBytes()`

## 0.1.0 — 2026-03-17

Initial release.

- Code Graph tree view with file, class, function, type, and test nodes
- Interactive D3.js graph visualisation in a webview panel
- Blast radius analysis from cursor position
- Find callers and find tests commands
- Search across all graph nodes
- Review changes with git-aware impact analysis
- Auto-update graph on file save
- CLI auto-detection and guided installation
- Getting Started walkthrough
