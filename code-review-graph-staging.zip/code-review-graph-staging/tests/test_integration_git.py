"""Integration tests exercising git-dependent code with real temporary repos.

Tests cover:
- get_changed_files with real git history
- parse_git_diff_ranges with real diffs
- incremental_update detecting real file modifications
- base ref injection rejection
- wiki page path traversal protection
"""

from __future__ import annotations

import inspect
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from code_review_graph.changes import parse_git_diff_ranges
from code_review_graph.errors import ChangeDiscoveryError
from code_review_graph.graph import GraphStore
from code_review_graph.incremental import (
    _commit_object_exists,
    collect_all_files,
    discover_review_changes,
    full_build,
    get_all_tracked_files,
    get_changed_files,
    get_staged_and_unstaged,
    incremental_update,
    resolve_incremental_base,
    resolve_review_base,
)
from code_review_graph.tools._common import graph_provenance
from code_review_graph.tools.build import build_or_update_graph
from code_review_graph.tools.context import get_minimal_context
from code_review_graph.wiki import get_wiki_page


def _git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    """Run a git command inside *repo* and return the result."""
    return subprocess.run(
        ["git", *args],
        capture_output=True,
        text=True,
        cwd=str(repo),
        timeout=10,
    )


def _git_ok(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    """Run a git command and fail the test if it does not succeed."""
    result = _git(repo, *args)
    assert result.returncode == 0, (
        f"git {' '.join(args)} failed ({result.returncode}): {result.stderr.strip()}"
    )
    return result


@pytest.fixture()
def git_repo(tmp_path: Path) -> Path:
    """Create a real git repo with two commits.

    Commit 1 adds ``hello.py`` with a single function.
    Commit 2 modifies ``hello.py`` (adds a second function).
    """
    repo = tmp_path / "repo"
    repo.mkdir()

    _git(repo, "init")
    _git(repo, "config", "user.email", "test@test.com")
    _git(repo, "config", "user.name", "Test")

    # First commit
    py_file = repo / "hello.py"
    py_file.write_text("def greet():\n    return 'hello'\n")
    _git(repo, "add", "hello.py")
    _git(repo, "commit", "-m", "initial commit")

    # Second commit — modify the file
    py_file.write_text(
        "def greet():\n    return 'hello'\n\n"
        "def farewell():\n    return 'goodbye'\n"
    )
    _git(repo, "add", "hello.py")
    _git(repo, "commit", "-m", "add farewell function")

    return repo


# ------------------------------------------------------------------
# 1. get_changed_files with a real git repo
# ------------------------------------------------------------------


def test_get_changed_files_real_git(git_repo: Path) -> None:
    """get_changed_files should list hello.py as changed between HEAD~1..HEAD."""
    changed = get_changed_files(git_repo, base="HEAD~1")
    assert "hello.py" in changed


@pytest.fixture()
def git_repo_with_unicode_path(tmp_path: Path) -> Path:
    """Create a real repository with a committed non-ASCII Python path."""
    repo = tmp_path / "unicode-repo"
    repo.mkdir()
    assert _git(repo, "init").returncode == 0
    assert _git(repo, "config", "user.email", "test@test.com").returncode == 0
    assert _git(repo, "config", "user.name", "Test").returncode == 0
    (repo / "café.py").write_text("value = 1\n", encoding="utf-8")
    assert _git(repo, "add", "--", "café.py").returncode == 0
    assert _git(repo, "commit", "-m", "add unicode path").returncode == 0
    return repo


def test_get_changed_files_preserves_unicode_path(
    git_repo_with_unicode_path: Path,
) -> None:
    """Committed Git changes preserve a literal path on every platform."""
    source = git_repo_with_unicode_path / "café.py"
    source.write_text("value = 2\n", encoding="utf-8")
    assert _git(git_repo_with_unicode_path, "add", "--", "café.py").returncode == 0
    assert (
        _git(git_repo_with_unicode_path, "commit", "-m", "modify unicode path").returncode
        == 0
    )

    assert get_changed_files(git_repo_with_unicode_path, base="HEAD~1") == [
        "café.py"
    ]


def test_get_staged_and_unstaged_preserves_unicode_path(
    git_repo_with_unicode_path: Path,
) -> None:
    """Working-tree Git changes preserve a literal path on every platform."""
    source = git_repo_with_unicode_path / "café.py"
    source.write_text("value = 2\n", encoding="utf-8")

    assert get_staged_and_unstaged(git_repo_with_unicode_path) == ["café.py"]


def test_get_staged_and_unstaged_expands_new_untracked_directories(
    git_repo_with_unicode_path: Path,
) -> None:
    """A new directory reports its files, not an unusable directory placeholder."""
    nested = git_repo_with_unicode_path / "new" / "nested.py"
    nested.parent.mkdir()
    nested.write_text("value = 1\n", encoding="utf-8")

    assert get_staged_and_unstaged(git_repo_with_unicode_path) == [
        "new/nested.py",
    ]


def test_a_wholly_new_directory_reaches_every_review_tool(
    git_repo_with_unicode_path: Path,
) -> None:
    """Against real git: the case the scoped walk silently deleted.

    ``--untracked-files=normal`` is cheaper -- it does not stat below an
    untracked directory -- but git then reports that directory as one ``new/``
    record with no files in it. Discovery would have handed review tools an
    empty list and ``status: ok``. This test is the reason the walk stays at
    ``all``: a repository whose only change is a brand-new package must not
    review as a clean tree.
    """
    _git_ok(git_repo_with_unicode_path, "commit", "--allow-empty", "-m", "empty")
    nested = git_repo_with_unicode_path / "new" / "nested.py"
    nested.parent.mkdir()
    nested.write_text("value = 1\n", encoding="utf-8")

    # git itself collapses it; the fix is not to consume that collapsed view.
    collapsed = _git(
        git_repo_with_unicode_path,
        "status", "--porcelain", "--untracked-files=normal",
    ).stdout
    assert "new/\n" in collapsed and "nested.py" not in collapsed

    files, _ = discover_review_changes(git_repo_with_unicode_path, "HEAD~1")
    assert files == ["new/nested.py"]


def test_a_new_package_is_visible_to_every_review_tool(
    git_repo_with_unicode_path: Path,
) -> None:
    """The regression, checked where a user would actually meet it.

    A repository whose only change is an uncommitted new package, reviewed
    through the four MCP tools against real git. Checking
    ``get_staged_and_unstaged`` alone was not enough: the drop that erased
    these files lived one layer below the tools, and every tool's own test
    passed while every tool returned nothing.
    """
    from code_review_graph.incremental import full_build, get_db_path
    from code_review_graph.tools.query import get_impact_radius
    from code_review_graph.tools.review import (
        detect_changes_func,
        get_affected_flows_func,
        get_review_context,
    )

    repo = git_repo_with_unicode_path
    store = GraphStore(get_db_path(repo))
    try:
        full_build(repo, store)
    finally:
        store.close()
    # An empty commit makes `git diff HEAD~1` empty, which is the branch that
    # sends discovery to the working-tree walk.
    _git_ok(repo, "commit", "--allow-empty", "-m", "empty")
    (repo / "newfeature").mkdir()
    (repo / "newfeature" / "__init__.py").write_text("", encoding="utf-8")
    (repo / "newfeature" / "api.py").write_text(
        "def handler():\n    return 1\n", encoding="utf-8",
    )

    expected = {"newfeature/__init__.py", "newfeature/api.py"}
    assert expected <= set(discover_review_changes(repo, "HEAD~1")[0])

    for func in (detect_changes_func, get_review_context, get_impact_radius,
                 get_affected_flows_func):
        result = func(repo_root=str(repo))
        assert result["status"] == "ok", func.__name__
        summary = result.get("summary", "")
        assert "No changes detected" not in summary, func.__name__
        assert "No changed files detected" not in summary, func.__name__


def test_a_new_file_in_a_tracked_directory_reaches_discovery(
    git_repo_with_unicode_path: Path,
) -> None:
    """The commonest "I added a file" shape, end to end."""
    _git_ok(git_repo_with_unicode_path, "commit", "--allow-empty", "-m", "empty")
    (git_repo_with_unicode_path / "brand_new_module.py").write_text(
        "value = 1\n", encoding="utf-8",
    )

    files, _ = discover_review_changes(git_repo_with_unicode_path, "HEAD~1")
    assert files == ["brand_new_module.py"]


def test_discovery_reports_a_timeout_rather_than_a_clean_tree(
    git_repo_with_unicode_path: Path,
) -> None:
    """A zero budget is the cheapest way to exhaust one deterministically.

    Whatever the budget is, running out of it must never look like the
    all-clear a review gate acts on (#262).
    """
    with pytest.raises(ChangeDiscoveryError) as excinfo:
        with patch.dict(os.environ, {"CRG_DISCOVERY_TIMEOUT": "0"}):
            discover_review_changes(git_repo_with_unicode_path, "HEAD~1")

    assert "timed out" in str(excinfo.value)


def test_get_staged_and_unstaged_uses_rename_destination(
    git_repo_with_unicode_path: Path,
) -> None:
    """NUL porcelain returns only the destination record for a staged rename."""
    destination = "renamed café.py"
    assert (
        _git(
            git_repo_with_unicode_path,
            "mv",
            "--",
            "café.py",
            destination,
        ).returncode
        == 0
    )

    assert get_staged_and_unstaged(git_repo_with_unicode_path) == [destination]


@pytest.mark.skipif(
    sys.platform == "win32",
    reason="Windows filenames cannot contain '>' or newline characters",
)
def test_git_discovery_preserves_literal_separator_characters(
    git_repo_with_unicode_path: Path,
) -> None:
    """NUL output preserves arrows and newlines as filename characters."""
    names = ["path -> literal.py", "line\nbreak.py"]
    for name in names:
        (git_repo_with_unicode_path / name).write_text("value = 1\n")
    assert _git(git_repo_with_unicode_path, "add", "--", *names).returncode == 0
    assert (
        _git(git_repo_with_unicode_path, "commit", "-m", "add literal paths").returncode
        == 0
    )

    assert set(
        get_changed_files(git_repo_with_unicode_path, base="HEAD~1")
    ) == set(names)

    for name in names:
        (git_repo_with_unicode_path / name).write_text("value = 2\n")
    assert set(get_staged_and_unstaged(git_repo_with_unicode_path)) == set(names)


# ------------------------------------------------------------------
# 2. parse_git_diff_ranges with a real git repo
# ------------------------------------------------------------------


def test_parse_git_diff_ranges_real_git(git_repo: Path) -> None:
    """parse_git_diff_ranges should return non-empty line ranges for hello.py."""
    ranges = parse_git_diff_ranges(str(git_repo), base="HEAD~1")
    assert "hello.py" in ranges
    assert len(ranges["hello.py"]) > 0
    # Each entry is a (start, end) tuple with positive line numbers
    for start, end in ranges["hello.py"]:
        assert start >= 1
        assert end >= start


def test_review_base_excludes_commits_unique_to_base_branch(tmp_path: Path) -> None:
    """A branch review should compare from the common ancestor, not base tip."""
    repo = _init_repo(tmp_path)

    _git_ok(repo, "checkout", "-b", "feature")
    _commit_file(repo, "feature_only")

    _git_ok(repo, "checkout", "main")
    _commit_file(repo, "base_only")
    base_tip = _git_ok(repo, "rev-parse", "HEAD").stdout.strip()
    _git_ok(repo, "update-ref", "refs/remotes/origin/main", base_tip)
    _git_ok(repo, "tag", "base-release")
    _git_ok(repo, "checkout", "feature")

    # A two-dot diff against the current base tip wrongly attributes both
    # sides of the divergence to the feature branch.
    assert set(get_changed_files(repo, "main")) == {
        "base_only.py",
        "feature_only.py",
    }

    review_base = resolve_review_base(repo, "main")
    assert review_base == _git_ok(repo, "merge-base", "main", "HEAD").stdout.strip()
    assert resolve_review_base(repo, "origin/main") == review_base
    assert get_changed_files(repo, review_base) == ["feature_only.py"]
    assert set(parse_git_diff_ranges(str(repo), review_base)) == {"feature_only.py"}

    # A caller can still request an exact two-tip comparison with a commit ID.
    assert resolve_review_base(repo, base_tip) == base_tip
    assert resolve_review_base(repo, "base-release") == "base-release"
    assert resolve_review_base(repo, "HEAD~1") == "HEAD~1"


def test_review_base_falls_back_when_merge_base_is_unavailable(
    git_repo: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Shallow or incomplete history must retain the caller's original base."""
    real_run = subprocess.run

    def fail_merge_base(*args, **kwargs):
        command = args[0]
        if command[:2] == ["git", "merge-base"]:
            return subprocess.CompletedProcess(command, 1, stdout="", stderr="no ancestor")
        return real_run(*args, **kwargs)

    monkeypatch.setattr("code_review_graph.incremental.subprocess.run", fail_merge_base)

    branch = _git_ok(git_repo, "branch", "--show-current").stdout.strip()
    assert resolve_review_base(git_repo, branch) == branch


# ------------------------------------------------------------------
# 3. incremental_update detects real modifications
# ------------------------------------------------------------------


def test_incremental_update_real_git(git_repo: Path) -> None:
    """Full build then incremental update should detect the second commit."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    try:
        store = GraphStore(db_path)

        # Reset to first commit, do a full build
        _git(git_repo, "checkout", "HEAD~1", "--detach")
        full_build(git_repo, store)
        initial_nodes = store.get_stats().total_nodes
        assert initial_nodes > 0, "full_build should create at least one node"

        # Move back to tip (second commit) and do incremental update
        _git(git_repo, "checkout", "-")
        result = incremental_update(
            git_repo, store, changed_files=["hello.py"]
        )
        assert result["files_updated"] >= 1
        assert "hello.py" in result["changed_files"]

        # The graph should now contain more nodes (farewell function added)
        assert store.get_stats().total_nodes >= initial_nodes

        store.close()
    finally:
        Path(db_path).unlink(missing_ok=True)


# ------------------------------------------------------------------
# 4. base ref injection is rejected
# ------------------------------------------------------------------


def test_base_validation_rejects_injection(git_repo: Path) -> None:
    """Passing a malicious --flag as base should be rejected (empty list)."""
    result = get_changed_files(git_repo, base="--output=/tmp/evil")
    assert result == []


# ------------------------------------------------------------------
# 5. wiki page path traversal is blocked
# ------------------------------------------------------------------


@pytest.fixture()
def git_repo_with_submodule(tmp_path: Path) -> Path:
    """Create a parent repo containing a git submodule with a Python file."""
    # Create the "library" repo that will become a submodule
    lib_repo = tmp_path / "lib"
    lib_repo.mkdir()
    _git(lib_repo, "init")
    _git(lib_repo, "config", "user.email", "test@test.com")
    _git(lib_repo, "config", "user.name", "Test")
    (lib_repo / "util.py").write_text("def helper():\n    pass\n")
    _git(lib_repo, "add", "util.py")
    _git(lib_repo, "commit", "-m", "lib initial")

    # Create the parent repo and add lib as a submodule
    parent = tmp_path / "parent"
    parent.mkdir()
    _git(parent, "init")
    _git(parent, "config", "user.email", "test@test.com")
    _git(parent, "config", "user.name", "Test")
    (parent / "main.py").write_text("def main():\n    pass\n")
    _git(parent, "add", "main.py")
    _git(parent, "commit", "-m", "parent initial")
    _git(
        parent, "-c", "protocol.file.allow=always",
        "submodule", "add", str(lib_repo), "lib",
    )
    _git(parent, "commit", "-m", "add lib submodule")

    return parent


def test_get_all_tracked_files_without_recurse(
    git_repo_with_submodule: Path,
) -> None:
    """Without recurse_submodules, submodule files are NOT listed."""
    files = get_all_tracked_files(
        git_repo_with_submodule, recurse_submodules=False
    )
    assert "main.py" in files
    # Submodule entry appears as a gitlink, not as individual files
    assert not any(f.startswith("lib/") for f in files)


def test_get_all_tracked_files_with_recurse(
    git_repo_with_submodule: Path,
) -> None:
    """With recurse_submodules=True, submodule files ARE listed."""
    files = get_all_tracked_files(
        git_repo_with_submodule, recurse_submodules=True
    )
    assert "main.py" in files
    assert "lib/util.py" in files


def test_collect_all_files_with_recurse(
    git_repo_with_submodule: Path,
) -> None:
    """collect_all_files with recurse_submodules includes submodule code."""
    files = collect_all_files(
        git_repo_with_submodule, recurse_submodules=True
    )
    assert "main.py" in files
    assert "lib/util.py" in files


def test_full_build_with_recurse_submodules(
    git_repo_with_submodule: Path,
) -> None:
    """full_build with recurse_submodules parses submodule files."""
    db_path = git_repo_with_submodule / ".code-review-graph" / "graph.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    store = GraphStore(db_path)
    try:
        result = full_build(
            git_repo_with_submodule, store, recurse_submodules=True
        )
        assert result["files_parsed"] >= 2  # main.py + lib/util.py
        assert result["errors"] == []

        # Verify both parent and submodule nodes exist
        parent_nodes = store.get_nodes_by_file(
            str(git_repo_with_submodule / "main.py")
        )
        sub_nodes = store.get_nodes_by_file(
            str(git_repo_with_submodule / "lib" / "util.py")
        )
        assert len(parent_nodes) > 0
        assert len(sub_nodes) > 0
    finally:
        store.close()


def test_wiki_page_path_traversal_blocked(tmp_path: Path) -> None:
    """get_wiki_page must not serve files outside the wiki directory."""
    wiki_dir = tmp_path / "wiki"
    wiki_dir.mkdir()

    # Create a legitimate page
    (wiki_dir / "my-module.md").write_text("# My Module\n")

    # Attempt a path traversal — should return None
    result = get_wiki_page(str(wiki_dir), "../../etc/passwd")
    assert result is None


def test_incremental_rename_matches_a_fresh_full_rebuild(
    tmp_path: Path,
    monkeypatch,
) -> None:
    """A committed rename must not leave graph state behind at the old path."""
    monkeypatch.setenv("CRG_SERIAL_PARSE", "1")
    repo = tmp_path / "rename-repo"
    repo.mkdir()
    assert _git(repo, "init").returncode == 0
    assert _git(repo, "config", "user.email", "test@test.com").returncode == 0
    assert _git(repo, "config", "user.name", "Test").returncode == 0

    (repo / "a.py").write_text("def foo():\n    return 1\n", encoding="utf-8")
    assert _git(repo, "add", "--", "a.py").returncode == 0
    assert _git(repo, "commit", "-m", "add a.py").returncode == 0

    incremental_store = GraphStore(tmp_path / "incremental.db")
    full_store = None
    try:
        full_build(repo, incremental_store)
        assert incremental_store.get_nodes_by_file(str(repo / "a.py"))

        assert _git(repo, "mv", "--", "a.py", "b.py").returncode == 0
        assert _git(repo, "commit", "-m", "rename a.py to b.py").returncode == 0

        incremental_update(repo, incremental_store)

        full_store = GraphStore(tmp_path / "full.db")
        full_build(repo, full_store)

        assert set(incremental_store.get_all_files()) == set(
            full_store.get_all_files()
        )
        assert (
            incremental_store.get_stats().total_nodes
            == full_store.get_stats().total_nodes
        )
        assert (
            incremental_store.get_stats().total_edges
            == full_store.get_stats().total_edges
        )
    finally:
        incremental_store.close()
        if full_store is not None:
            full_store.close()


# ------------------------------------------------------------------
# 6. Auto-resolved incremental base (last-synced commit, not HEAD~1)
# ------------------------------------------------------------------


def _init_repo(tmp_path: Path) -> Path:
    """A git repo on branch ``main`` with one commit adding ``a.py``.

    ``init -b main`` pins the branch name so tests that switch branches do not
    depend on the host's ``init.defaultBranch`` (which may be ``master``).
    """
    repo = tmp_path / "repo"
    repo.mkdir()
    _git_ok(repo, "init", "-b", "main")
    _git_ok(repo, "config", "user.email", "test@test.com")
    _git_ok(repo, "config", "user.name", "Test")
    (repo / "a.py").write_text("def alpha():\n    return 1\n")
    _git_ok(repo, "add", ".")
    _git_ok(repo, "commit", "-m", "c0")
    return repo


def _commit_file(repo: Path, name: str) -> None:
    (repo / f"{name}.py").write_text(f"def {name}():\n    return 1\n")
    _git_ok(repo, "add", ".")
    _git_ok(repo, "commit", "-m", name)


def _graph_structure_snapshot(store: GraphStore) -> tuple[frozenset, frozenset]:
    """Return graph structure without timestamps or build metadata."""
    nodes = frozenset(
        (
            node.kind,
            node.qualified_name,
            node.file_path,
            node.line_start,
            node.line_end,
            node.language,
        )
        for node in store.get_all_nodes(exclude_files=False)
    )
    edges = frozenset(
        (
            edge.kind,
            edge.source_qualified,
            edge.target_qualified,
            edge.file_path,
            edge.line,
        )
        for edge in store.get_all_edges()
    )
    return nodes, edges


def test_automatic_update_after_empty_commit_refreshes_freshness(
    tmp_path: Path,
) -> None:
    repo = _init_repo(tmp_path)
    commit_a = _git_ok(repo, "rev-parse", "HEAD").stdout.strip()
    build_or_update_graph(full_rebuild=True, repo_root=str(repo), postprocess="none")
    graph_path = repo / ".code-review-graph" / "graph.db"

    with GraphStore(graph_path) as store:
        structure_at_a = _graph_structure_snapshot(store)
        assert store.get_metadata("git_head_sha") == commit_a

    _git_ok(repo, "commit", "--allow-empty", "-m", "empty commit")
    commit_b = _git_ok(repo, "rev-parse", "HEAD").stdout.strip()
    assert commit_b != commit_a

    result = build_or_update_graph(
        full_rebuild=False,
        repo_root=str(repo),
        base=None,
        postprocess="none",
    )
    assert result["build_type"] == "incremental"
    assert result["files_updated"] == 0

    with GraphStore(graph_path) as store:
        structure_at_b = _graph_structure_snapshot(store)
        stored_sha = store.get_metadata("git_head_sha")
    provenance = graph_provenance(str(repo))
    context = get_minimal_context(repo_root=str(repo))

    assert structure_at_b == structure_at_a
    assert (
        stored_sha,
        provenance and provenance.get("head_matches_build"),
        context["status"],
        context.get("reason"),
    ) == (commit_b, True, "ok", None)


def test_automatic_update_after_unsupported_file_commit_refreshes_freshness(
    tmp_path: Path,
) -> None:
    repo = _init_repo(tmp_path)
    unindexed = repo / "notes.crg-unsupported"
    unindexed.write_text("initial notes\n")
    _git_ok(repo, "add", unindexed.name)
    _git_ok(repo, "commit", "-m", "add unsupported notes")
    commit_a = _git_ok(repo, "rev-parse", "HEAD").stdout.strip()
    build_or_update_graph(full_rebuild=True, repo_root=str(repo), postprocess="none")
    graph_path = repo / ".code-review-graph" / "graph.db"

    with GraphStore(graph_path) as store:
        structure_at_a = _graph_structure_snapshot(store)

    unindexed.write_text("updated notes\n")
    _git_ok(repo, "add", unindexed.name)
    _git_ok(repo, "commit", "-m", "update unsupported notes")
    commit_b = _git_ok(repo, "rev-parse", "HEAD").stdout.strip()
    assert get_changed_files(repo, commit_a) == [unindexed.name]

    result = build_or_update_graph(
        full_rebuild=False,
        repo_root=str(repo),
        base=None,
        postprocess="none",
    )
    assert result["changed_files"] == [unindexed.name]
    assert result["files_updated"] == 0

    with GraphStore(graph_path) as store:
        structure_at_b = _graph_structure_snapshot(store)
        stored_sha = store.get_metadata("git_head_sha")
    provenance = graph_provenance(str(repo))

    assert structure_at_b == structure_at_a
    assert (
        stored_sha,
        provenance and provenance.get("head_matches_build"),
    ) == (commit_b, True)


def test_explicit_changed_files_update_records_head_when_files_stored(
    tmp_path: Path,
) -> None:
    repo = _init_repo(tmp_path)
    build_or_update_graph(full_rebuild=True, repo_root=str(repo), postprocess="none")

    (repo / "a.py").write_text("def alpha():\n    return 2\n")
    _git_ok(repo, "add", "a.py")
    _git_ok(repo, "commit", "-m", "change alpha")
    commit_b = _git_ok(repo, "rev-parse", "HEAD").stdout.strip()

    with GraphStore(repo / ".code-review-graph" / "graph.db") as store:
        result = incremental_update(repo, store, changed_files=["a.py"])
        stored_sha = store.get_metadata("git_head_sha")

    # Watch batches pass explicit files; once they store the change the graph
    # matches HEAD and must say so, or every query carries a stale caveat.
    assert result["files_updated"] == 1
    assert stored_sha == commit_b


def test_failed_automatic_update_does_not_claim_graph_is_current(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo = _init_repo(tmp_path)
    commit_a = _git_ok(repo, "rev-parse", "HEAD").stdout.strip()
    build_or_update_graph(full_rebuild=True, repo_root=str(repo), postprocess="none")

    (repo / "a.py").write_text("def alpha():\n    return 2\n")
    _git_ok(repo, "add", "a.py")
    _git_ok(repo, "commit", "-m", "change alpha")
    commit_b = _git_ok(repo, "rev-parse", "HEAD").stdout.strip()

    def fail_parse(*_args, **_kwargs):
        raise RuntimeError("forced parse failure")

    monkeypatch.setattr(
        "code_review_graph.incremental.CodeParser.parse_bytes",
        fail_parse,
    )
    result = build_or_update_graph(
        full_rebuild=False,
        repo_root=str(repo),
        base=None,
        postprocess="none",
    )

    with GraphStore(repo / ".code-review-graph" / "graph.db") as store:
        stored_sha = store.get_metadata("git_head_sha")

    # The failure is visible in status, errors and summary, but the anchor
    # still advances: freezing it would re-diff the same range on every later
    # update and never recover on its own.
    assert result["status"] == "partial"
    assert result["files_updated"] == 0
    assert result["errors"] == [{"file": "a.py", "error": "forced parse failure"}]
    assert stored_sha == commit_b
    assert stored_sha != commit_a
    assert "a.py" in result["summary"]
    assert "up to date" not in result["summary"].lower()


def test_commit_object_exists(tmp_path: Path) -> None:
    repo = _init_repo(tmp_path)
    head = _git(repo, "rev-parse", "HEAD").stdout.strip()
    assert _commit_object_exists(repo, head) is True
    assert _commit_object_exists(repo, "0" * 40) is False
    # Injection-shaped refs are rejected before ever reaching git.
    assert _commit_object_exists(repo, "--output=/tmp/evil") is False


def test_resolve_incremental_base(tmp_path: Path) -> None:
    repo = _init_repo(tmp_path)
    head = _git(repo, "rev-parse", "HEAD").stdout.strip()

    store = GraphStore(str(repo / "graph.db"))
    try:
        # Usable anchor -> the stored SHA.
        store.set_metadata("git_head_sha", head)
        assert resolve_incremental_base(repo, store) == head
        # Unreachable anchor (rewrite / shallow clone) -> None (full rebuild).
        store.set_metadata("git_head_sha", "0" * 40)
        assert resolve_incremental_base(repo, store) is None
    finally:
        store.close()

    # No anchor at all (fresh / legacy database) -> None.
    store2 = GraphStore(str(repo / "graph2.db"))
    try:
        assert resolve_incremental_base(repo, store2) is None
    finally:
        store2.close()


def test_resolve_incremental_base_non_git(tmp_path: Path) -> None:
    plain = tmp_path / "plain"
    plain.mkdir()
    store = GraphStore(str(plain / "graph.db"))
    try:
        # Non-git working copies keep the concrete "HEAD~1" default so the
        # SVN/plain change-discovery path never receives None.
        assert resolve_incremental_base(plain, store) == "HEAD~1"
    finally:
        store.close()


def test_update_auto_base_catches_commits_missed_by_head1(tmp_path: Path) -> None:
    """The headline bug: after several out-of-band commits, a default update
    must reconcile all of them, not only the newest."""
    repo = _init_repo(tmp_path)
    c0 = _git(repo, "rev-parse", "HEAD").stdout.strip()
    build_or_update_graph(full_rebuild=True, repo_root=str(repo), postprocess="none")

    for name in ("beta", "gamma", "delta"):
        _commit_file(repo, name)

    # Old behaviour, reproduced explicitly: HEAD~1 sees only the last commit.
    head1 = get_changed_files(repo, "HEAD~1")
    assert head1 == ["delta.py"]

    # New behaviour: auto base resolves to c0 and catches every commit since.
    res = build_or_update_graph(
        full_rebuild=False, repo_root=str(repo), base=None, postprocess="none"
    )
    assert res["base_resolved"] == c0
    assert set(res["changed_files"]) == {"beta.py", "gamma.py", "delta.py"}


def test_update_auto_base_across_divergent_branch_switch(tmp_path: Path) -> None:
    """Build on one branch, then switch to a divergent branch whose HEAD~1 is
    NOT the anchor. A fixed HEAD~1 base would miss the difference and leave the
    other branch's files stale; the resolved anchor reconciles it.
    """
    repo = _init_repo(tmp_path)  # main @ c0 with a.py

    # A sibling branch off c0 that adds its own file, then back to main.
    _git_ok(repo, "checkout", "-b", "sibling")
    _commit_file(repo, "sibling_only")
    _git_ok(repo, "checkout", "main")

    # Advance main by two commits and build the graph at main's tip.
    _commit_file(repo, "main_one")
    _commit_file(repo, "main_two")
    main_tip = _git_ok(repo, "rev-parse", "HEAD").stdout.strip()
    build_or_update_graph(full_rebuild=True, repo_root=str(repo), postprocess="none")

    # Switch to the divergent sibling. Its HEAD~1 is c0, not main's tip, so a
    # fixed-HEAD~1 update could never reconcile against where the graph is.
    _git_ok(repo, "checkout", "sibling")
    res = build_or_update_graph(
        full_rebuild=False, repo_root=str(repo), base=None, postprocess="none"
    )
    # The resolved base is the commit the graph was actually built at.
    assert res["base_resolved"] == main_tip
    assert res["build_type"] == "incremental"
    # The diff main_tip..sibling adds sibling's file and drops main's files.
    changed = set(res["changed_files"])
    assert {"sibling_only.py", "main_one.py", "main_two.py"} <= changed


def test_update_without_usable_anchor_falls_back_to_full_rebuild(
    tmp_path: Path,
) -> None:
    repo = _init_repo(tmp_path)
    build_or_update_graph(full_rebuild=True, repo_root=str(repo), postprocess="none")

    # Corrupt the anchor to an unreachable SHA (as a history rewrite would).
    from code_review_graph.incremental import get_db_path

    store = GraphStore(str(get_db_path(repo)))
    try:
        store.set_metadata("git_head_sha", "0" * 40)
    finally:
        store.close()

    _commit_file(repo, "epsilon")
    res = build_or_update_graph(
        full_rebuild=False, repo_root=str(repo), base=None, postprocess="none"
    )
    assert res["build_type"] == "full"
    assert res["base_resolved"] is None


def test_update_missing_graph_ignores_explicit_incremental_base(
    tmp_path: Path,
) -> None:
    repo = _init_repo(tmp_path)
    _commit_file(repo, "beta")

    res = build_or_update_graph(
        full_rebuild=False,
        repo_root=str(repo),
        base="HEAD~1",
        postprocess="none",
    )

    assert res["build_type"] == "full"
    assert res["base_resolved"] is None
    assert res["files_parsed"] == 2
    with GraphStore(repo / ".code-review-graph" / "graph.db") as store:
        assert store.get_nodes_by_file(str(repo / "a.py"))
        assert store.get_nodes_by_file(str(repo / "beta.py"))


def test_update_repairs_existing_empty_graph(
    tmp_path: Path,
) -> None:
    repo = _init_repo(tmp_path)
    graph_path = repo / ".code-review-graph" / "graph.db"
    with GraphStore(graph_path):
        pass
    _commit_file(repo, "beta")

    res = build_or_update_graph(
        full_rebuild=False,
        repo_root=str(repo),
        base="HEAD~1",
        postprocess="none",
    )

    assert res["build_type"] == "full"
    assert res["base_resolved"] is None
    assert res["files_parsed"] == 2
    with GraphStore(graph_path) as store:
        assert store.get_nodes_by_file(str(repo / "a.py"))
        assert store.get_nodes_by_file(str(repo / "beta.py"))


def test_status_then_update_builds_complete_queryable_graph(
    tmp_path: Path,
    monkeypatch,
    capsys,
) -> None:
    from code_review_graph import cli
    from code_review_graph.tools.query import query_graph

    repo = tmp_path / "queryable-repo"
    repo.mkdir()
    _git_ok(repo, "init", "-b", "main")
    _git_ok(repo, "config", "user.email", "test@test.com")
    _git_ok(repo, "config", "user.name", "Test")
    (repo / "provider.py").write_text(
        "def target():\n    return 1\n",
        encoding="utf-8",
    )
    (repo / "stable.py").write_text(
        "from provider import target\n\ndef stable():\n    return target()\n",
        encoding="utf-8",
    )
    recent = repo / "recent.py"
    recent.write_text(
        "from provider import target\n\ndef recent():\n    return target()\n",
        encoding="utf-8",
    )
    _git_ok(repo, "add", ".")
    _git_ok(repo, "commit", "-m", "initial callers")

    data_dir = tmp_path / "queryable-data"
    monkeypatch.setenv("CRG_DATA_DIR", str(data_dir))
    monkeypatch.setattr(
        sys,
        "argv",
        ["code-review-graph", "status", "--repo", str(repo)],
    )
    with pytest.raises(SystemExit) as exc_info:
        cli.main()
    assert exc_info.value.code == 1
    assert not data_dir.exists()
    capsys.readouterr()

    recent.write_text(
        "from provider import target\n\ndef recent():\n    return target() + 1\n",
        encoding="utf-8",
    )
    _git_ok(repo, "add", "recent.py")
    _git_ok(repo, "commit", "-m", "change recent caller")

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "code-review-graph",
            "update",
            "--repo",
            str(repo),
            "--base",
            "HEAD~1",
            "--skip-postprocess",
        ],
    )
    cli.main()

    assert "Full rebuild" in capsys.readouterr().out
    result = query_graph("callers_of", "target", repo_root=str(repo))
    assert result["status"] == "ok"
    assert {item["name"] for item in result["results"]} == {"recent", "stable"}


def test_update_explicit_base_bypasses_auto_resolution(tmp_path: Path) -> None:
    repo = _init_repo(tmp_path)
    build_or_update_graph(full_rebuild=True, repo_root=str(repo), postprocess="none")
    for name in ("beta", "gamma"):
        _commit_file(repo, name)

    # An explicit base is honoured verbatim and stays incremental.
    res = build_or_update_graph(
        full_rebuild=False, repo_root=str(repo), base="HEAD~1", postprocess="none"
    )
    assert res["build_type"] == "incremental"
    assert res["base_resolved"] == "HEAD~1"
    assert res["changed_files"] == ["gamma.py"]


def test_mcp_tool_base_defaults_to_none() -> None:
    """The MCP wrapper must default base to None so omitted-base calls reach
    the auto-resolution path instead of a hardcoded HEAD~1."""
    from code_review_graph.main import build_or_update_graph_tool

    # FastMCP may wrap the tool; the underlying callable is stored on ``.fn``.
    fn = getattr(build_or_update_graph_tool, "fn", build_or_update_graph_tool)
    assert inspect.signature(fn).parameters["base"].default is None


def test_cli_update_brief_default_base_does_not_crash(
    tmp_path: Path, capsys, monkeypatch
) -> None:
    """`update --brief` with no explicit --base must not crash. The base now
    defaults to None, which the brief impact path cannot pass to git directly;
    it has to reuse the resolved base."""
    from code_review_graph import cli

    repo = _init_repo(tmp_path)
    build_or_update_graph(full_rebuild=True, repo_root=str(repo), postprocess="none")
    _commit_file(repo, "brief_new")

    monkeypatch.setattr(
        sys,
        "argv",
        ["code-review-graph", "update", "--brief", "--repo", str(repo)],
    )
    cli.main()  # would raise AttributeError/TypeError on a None base before the fix

    out = capsys.readouterr().out
    # It ran the incremental update and the brief impact summary without error.
    assert "Incremental:" in out
    assert "changed file" in out


def test_update_auto_base_multi_commit_rename_matches_full_rebuild(
    tmp_path: Path,
    monkeypatch,
) -> None:
    """Three commits after the stored SHA converge exactly to a fresh graph.

    The commits deliberately split a module rename, its importer update, and a
    new importing file. A HEAD~1 update sees only the new file; the automatic
    stored-SHA base must reconcile all three commits and purge the old path.
    """
    monkeypatch.setenv("CRG_SERIAL_PARSE", "1")
    repo = tmp_path / "multi-commit-repo"
    repo.mkdir()
    _git_ok(repo, "init", "-b", "main")
    _git_ok(repo, "config", "user.email", "test@test.com")
    _git_ok(repo, "config", "user.name", "Test")

    package = repo / "pkg"
    package.mkdir()
    (package / "__init__.py").write_text("", encoding="utf-8")
    old_module = package / "service.py"
    old_module.write_text(
        "def provide():\n"
        "    return 'value'\n",
        encoding="utf-8",
    )
    importer = repo / "app.py"
    importer.write_text(
        "from pkg.service import provide\n\n"
        "def run():\n"
        "    return provide()\n",
        encoding="utf-8",
    )
    _git_ok(repo, "add", ".")
    _git_ok(repo, "commit", "-m", "initial graph state")
    stored_sha = _git_ok(repo, "rev-parse", "HEAD").stdout.strip()

    incremental_data = tmp_path / "incremental-data"
    monkeypatch.setenv("CRG_DATA_DIR", str(incremental_data))
    initial = build_or_update_graph(
        full_rebuild=True,
        repo_root=str(repo),
        postprocess="none",
    )
    assert initial["errors"] == []
    with GraphStore(incremental_data / "graph.db") as stored:
        assert stored.get_metadata("git_head_sha") == stored_sha
        assert stored.get_nodes_by_file(str(old_module))

    # Commit 1: rename the provider module.
    new_module = package / "core.py"
    _git_ok(repo, "mv", "pkg/service.py", "pkg/core.py")
    _git_ok(repo, "commit", "-m", "rename provider module")

    # Commit 2: update the existing importer.
    importer.write_text(
        "from pkg.core import provide\n\n"
        "def run():\n"
        "    return provide()\n",
        encoding="utf-8",
    )
    _git_ok(repo, "add", "app.py")
    _git_ok(repo, "commit", "-m", "update provider importer")

    # Commit 3: add another importing file.
    new_consumer = repo / "worker.py"
    new_consumer.write_text(
        "from pkg.core import provide\n\n"
        "def work():\n"
        "    return provide()\n",
        encoding="utf-8",
    )
    _git_ok(repo, "add", "worker.py")
    _git_ok(repo, "commit", "-m", "add provider worker")

    commits_since_graph = _git_ok(
        repo,
        "rev-list",
        "--count",
        f"{stored_sha}..HEAD",
    ).stdout.strip()
    assert commits_since_graph == "3"
    assert get_changed_files(repo, "HEAD~1") == ["worker.py"]

    updated = build_or_update_graph(
        full_rebuild=False,
        repo_root=str(repo),
        postprocess="none",
    )
    assert updated["build_type"] == "incremental"
    assert updated["base_resolved"] == stored_sha
    assert set(updated["changed_files"]) == {
        "app.py",
        "pkg/service.py",
        "pkg/core.py",
        "worker.py",
    }
    assert updated["errors"] == []

    def node_snapshot(store: GraphStore) -> set[tuple[object, ...]]:
        return {
            (
                node.kind,
                node.name,
                node.qualified_name,
                node.file_path,
                node.line_start,
                node.line_end,
                node.language,
                node.parent_name,
                node.params,
                node.return_type,
                node.is_test,
                node.file_hash,
                json.dumps(node.extra, sort_keys=True),
            )
            for node in store.get_all_nodes(exclude_files=False)
        }

    def edge_snapshot(store: GraphStore) -> set[tuple[object, ...]]:
        return {
            (
                edge.kind,
                edge.source_qualified,
                edge.target_qualified,
                edge.file_path,
                edge.line,
                json.dumps(edge.extra, sort_keys=True),
                edge.confidence,
                edge.confidence_tier,
            )
            for edge in store.get_all_edges()
        }

    with GraphStore(incremental_data / "graph.db") as incremental_store:
        assert incremental_store.get_nodes_by_file(str(old_module)) == []
        assert incremental_store.get_nodes_by_file(str(new_module))
        incremental_nodes = node_snapshot(incremental_store)
        incremental_edges = edge_snapshot(incremental_store)
        assert all(
            str(old_module) not in repr(edge)
            for edge in incremental_edges
        )

    fresh_data = tmp_path / "fresh-data"
    monkeypatch.setenv("CRG_DATA_DIR", str(fresh_data))
    fresh = build_or_update_graph(
        full_rebuild=True,
        repo_root=str(repo),
        postprocess="none",
    )
    assert fresh["errors"] == []

    with GraphStore(fresh_data / "graph.db") as fresh_store:
        assert incremental_nodes == node_snapshot(fresh_store)
        assert incremental_edges == edge_snapshot(fresh_store)
