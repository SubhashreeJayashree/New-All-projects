export type AssistantState = 'idle' | 'listening' | 'evaluating' | 'speaking' | 'blocked' | 'emergency_stopped';

export type LanguageCode = 'en' | 'hi' | 'ta' | 'es' | 'fr' | 'de' | 'ar';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'hayat' | 'system';
  text: string;
  timestamp: string;
  language?: LanguageCode;
  imageUrl?: string;
  system1Route?: string;
  system1Confidence?: number;
  durationMs?: number;
  adbAction?: string;
  modelTier?: 'Astra' | 'Sol' | 'Luna';
  taskCostUsd?: string;
}

export interface System1Decision {
  status: 'ALLOWED' | 'BLOCKED';
  route: string;
  confidence: number;
  urgency: number;
  complexity: number;
  isJailbreak: boolean;
  jailbreakProbability: number;
  requiresSystem2: boolean;
  durationMs: number;
  timestamp: string;
  // Video 6: GPT-6 Sol vs Astra vs Luna Multi-Tier Cost & Benchmark Telemetry
  selectedTier?: 'GPT-6 Sol (5x Cheaper)' | 'GPT-6 Astra (Max Effort)' | 'GPT-6 Luna (100x Cheaper)';
  tokenPriceRatio?: string;
  estimatedTaskPrice?: string;
  automationBenchScore?: string;
  biohighDefenseRate?: string;
}

export interface ADBCommandLog {
  id: string;
  command: string;
  result: string;
  status: 'SUCCESS' | 'FAILED';
  durationMs: number;
  timestamp: string;
}

export interface CallLogItem {
  id: string;
  contactName: string;
  phoneNumber: string;
  type: 'incoming' | 'outgoing' | 'missed';
  time: string;
  duration?: string;
}

export interface GoogleSearchResultItem {
  title: string;
  link: string;
  source: string;
  pubDate: string;
}

export interface YouTubeVideoResult {
  videoId: string;
  title: string;
}

export interface ItunesTrackResult {
  title: string;
  artist: string;
  album: string;
  artworkUrl: string;
  previewUrl: string;
}

export interface PhoneState {
  screen:
    | 'home'
    | 'whatsapp'
    | 'call'
    | 'call_log'
    | 'google'
    | 'youtube'
    | 'spotify'
    | 'jiosaavn'
    | 'gmail'
    | 'twitter'
    | 'instagram'
    | 'facebook'
    | 'telegram'
    | 'camera'
    | 'settings'
    | 'maps'
    | 'notes'
    | 'calculator'
    | 'smarthome'
    | 'translator'
    | 'locked';
  isAwake: boolean;
  battery: number;
  isCharging: boolean;
  activeCall?: {
    contactName: string;
    phoneNumber: string;
    durationSec: number;
    isActive: boolean;
    isRinging?: boolean;
  };
  callLogs: CallLogItem[];
  googleQuery?: string;
  isTypingGoogle?: boolean;
  googleResult?: {
    title: string;
    temperature?: string;
    condition?: string;
    snippet?: string;
    aiSummary?: string;
    items?: GoogleSearchResultItem[];
    wikiCard?: {
      title: string;
      extract: string;
      thumbnail?: string;
      url?: string;
    };
    relatedQueries?: string[];
  };
  whatsappChat?: {
    contact: string;
    phoneNumber?: string;
    messages: Array<{ from: 'me' | 'contact'; text: string; time: string }>;
    draftText?: string;
  };
  youtubeSong?: {
    platform?: 'youtube' | 'spotify' | 'jiosaavn';
    searchQuery?: string;
    title: string;
    artist: string;
    album?: string;
    artworkUrl?: string;
    previewUrl?: string;
    youtubeVideoId?: string;
    youtubeResults?: YouTubeVideoResult[];
    trackResults?: ItunesTrackResult[];
    isPlaying: boolean;
    adSkipped: boolean;
  };
  gmailState?: {
    inbox: Array<{
      id: string;
      from: string;
      email: string;
      subject: string;
      snippet: string;
      time: string;
      unread?: boolean;
    }>;
    compose?: {
      to: string;
      subject: string;
      body: string;
      status: 'typing' | 'ready' | 'sent';
    };
  };
  twitterState?: {
    trends: Array<{ tag: string; posts: string; category: string }>;
    feed: Array<{
      id: string;
      author: string;
      handle: string;
      text: string;
      time: string;
      likes: number;
      reposts: number;
    }>;
    draftTweet?: string;
  };
  instagramState?: {
    posts: Array<{
      id: string;
      user: string;
      caption: string;
      image: string;
      likes: number;
      time: string;
    }>;
    activeSearch?: string;
  };
  notesState?: {
    notes: Array<{
      id: string;
      title: string;
      content: string;
      time: string;
      category: 'Note' | 'Alarm' | 'Reminder';
    }>;
  };
  calculatorState?: {
    expression: string;
    result: string;
    history: Array<{ expr: string; res: string }>;
  };
  smartHomeState?: {
    devices: Array<{
      id: string;
      name: string;
      room: string;
      status: boolean;
      value?: string;
      type: 'light' | 'ac' | 'lock' | 'tv' | 'camera';
    }>;
  };
  translatorState?: {
    sourceText: string;
    targetLang: string;
    translatedText: string;
    pronunciation?: string;
  };
}

export interface SeismicEvent {
  id: string;
  location: string;
  lat: number;
  lng: number;
  magnitude: number;
  depthKm: number;
  timeAgo: string;
}

export interface CareerApplication {
  id: string;
  role: string;
  company: string;
  status: 'scraped' | 'tailored' | 'filling' | 'otp_required' | 'submitted';
  tailoredPoints: string[];
  submittedAt?: string;
  otpCode?: string;
}

export interface TelemetrySpan {
  id: string;
  name: string;
  service: string;
  durationMs: number;
  status: 'OK' | 'ERROR';
  timestamp: string;
  metadata?: Record<string, any>;
}
