import { LanguageCode } from '../types';

export class VoiceController {
  private recognition: any = null;
  private isListening = false;
  private isMuted = false;
  private isContinuous = true;
  private isPausedForSpeech = false;
  private currentLanguage: LanguageCode = 'en';
  private audioContext: AudioContext | null = null;
  private ringOscillator1: OscillatorNode | null = null;
  private ringOscillator2: OscillatorNode | null = null;
  private ringGain: GainNode | null = null;
  private ringInterval: any = null;
  private speechWatchdogTimer: any = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  private onResultCallback: ((text: string) => void) | null = null;
  private onInterimCallback: ((text: string) => void) | null = null;
  private onErrorCallback: ((err: any) => void) | null = null;
  private onStateChangeCallback: ((isListening: boolean) => void) | null = null;

  constructor() {
    this.initRecognition();
  }

  private initRecognition() {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        try {
          this.recognition = new SpeechRecognition();
          this.recognition.continuous = true;
          this.recognition.interimResults = true;
          this.recognition.maxAlternatives = 1;
          this.recognition.lang = 'en-US';
          this.setupRecognitionListeners();
        } catch (e) {
          console.warn('SpeechRecognition initialization error:', e);
        }
      }
    }
  }

  private setupRecognitionListeners() {
    if (!this.recognition) return;

    this.recognition.onstart = () => {
      this.isListening = true;
      if (this.onStateChangeCallback) this.onStateChangeCallback(true);
    };

    this.recognition.onresult = (event: any) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        const item = event.results[i];
        if (item.isFinal) {
          finalTranscript += item[0].transcript;
        } else {
          interimTranscript += item[0].transcript;
        }
      }

      const trimmedInterim = interimTranscript.trim();
      const trimmedFinal = finalTranscript.trim();

      if (trimmedInterim && this.onInterimCallback) {
        this.onInterimCallback(trimmedInterim);
      }

      if (trimmedFinal && this.onResultCallback && !this.isPausedForSpeech) {
        this.onResultCallback(trimmedFinal);
      }
    };

    this.recognition.onerror = (event: any) => {
      // 'no-speech' is normal silence interval
      if (event.error === 'no-speech') return;
      console.warn('Speech recognition event warning:', event.error);
      if (this.onErrorCallback) this.onErrorCallback(event.error);
    };

    this.recognition.onend = () => {
      this.isListening = false;
      if (this.onStateChangeCallback) this.onStateChangeCallback(false);

      // Auto-restart if in continuous hands-free mode and not paused for speech
      if (this.isContinuous && !this.isPausedForSpeech) {
        setTimeout(() => {
          if (this.isContinuous && !this.isListening && !this.isPausedForSpeech) {
            try {
              this.recognition?.start();
              this.isListening = true;
              if (this.onStateChangeCallback) this.onStateChangeCallback(true);
            } catch (e) {
              // ignore duplicate start attempts
            }
          }
        }, 400);
      }
    };
  }

  public getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioContext) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.audioContext = new AudioCtx();
      }
    }
    if (this.audioContext && this.audioContext.state === 'suspended') {
      this.audioContext.resume().catch((err) => console.warn('AudioContext resume failed:', err));
    }
    return this.audioContext;
  }

  // Play standard telephone ringing tone (440Hz + 480Hz US cadence: 2s on, 4s off)
  public playPhoneRinging() {
    this.stopPhoneRinging();
    if (this.isMuted) return;

    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const triggerBurst = () => {
        try {
          const osc1 = ctx.createOscillator();
          const osc2 = ctx.createOscillator();
          const gain = ctx.createGain();

          osc1.type = 'sine';
          osc2.type = 'sine';
          osc1.frequency.setValueAtTime(440, ctx.currentTime);
          osc2.frequency.setValueAtTime(480, ctx.currentTime);

          gain.gain.setValueAtTime(0, ctx.currentTime);
          gain.gain.linearRampToValueAtTime(0.08, ctx.currentTime + 0.1);
          gain.gain.setValueAtTime(0.08, ctx.currentTime + 1.8);
          gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 2.0);

          osc1.connect(gain);
          osc2.connect(gain);
          gain.connect(ctx.destination);

          osc1.start();
          osc2.start();
          osc1.stop(ctx.currentTime + 2.05);
          osc2.stop(ctx.currentTime + 2.05);
        } catch (e) {
          // ignore
        }
      };

      // Play immediate first ring
      triggerBurst();
      // Repeat every 3.5 seconds
      this.ringInterval = setInterval(triggerBurst, 3500);
    } catch (e) {
      console.warn('Phone ring tone failed:', e);
    }
  }

  public stopPhoneRinging() {
    if (this.ringInterval) {
      clearInterval(this.ringInterval);
      this.ringInterval = null;
    }
  }

  public playChime(type: 'start' | 'success' | 'alert' | 'whatsapp' = 'start') {
    if (this.isMuted) return;
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      if (type === 'start') {
        osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.1); // A5
      } else if (type === 'success') {
        osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
        osc.frequency.exponentialRampToValueAtTime(1046.5, ctx.currentTime + 0.12); // C6
      } else if (type === 'whatsapp') {
        // Crisp dual chime for WhatsApp dispatch
        osc.frequency.setValueAtTime(784, ctx.currentTime); // G5
        osc.frequency.exponentialRampToValueAtTime(1174.66, ctx.currentTime + 0.14); // D6
      } else {
        osc.frequency.setValueAtTime(320, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(220, ctx.currentTime + 0.15);
      }

      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.22);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.23);
    } catch (e) {
      console.warn('Audio chime playback failed:', e);
    }
  }

  public setLanguage(lang: LanguageCode) {
    this.currentLanguage = lang;
    if (this.recognition) {
      const langMap: Record<LanguageCode, string> = {
        en: 'en-US',
        hi: 'hi-IN',
        ta: 'ta-IN',
        es: 'es-ES',
        fr: 'fr-FR',
        de: 'de-DE',
        ar: 'ar-SA',
      };
      this.recognition.lang = langMap[lang] || 'en-US';
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (muted) {
      this.stopPhoneRinging();
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        try {
          window.speechSynthesis.cancel();
        } catch (e) {
          // ignore
        }
      }
    }
  }

  public async requestMicrophonePermission(): Promise<boolean> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      return false;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // Stop tracks immediately after granting permission
      stream.getTracks().forEach((track) => track.stop());
      return true;
    } catch (err) {
      console.warn('Microphone permission request error:', err);
      return false;
    }
  }

  public startListening(
    onResult: (text: string) => void,
    onInterim?: (text: string) => void,
    onError?: (err: any) => void,
    continuous = true
  ): boolean {
    if (!this.recognition) {
      if (onError) onError('Speech Recognition is not supported in this browser.');
      return false;
    }

    this.onResultCallback = onResult;
    this.onInterimCallback = onInterim || null;
    this.onErrorCallback = onError || null;
    this.isContinuous = continuous;

    try {
      this.playChime('start');
      this.recognition.start();
      this.isListening = true;
      return true;
    } catch (e) {
      // If already started, mark listening
      this.isListening = true;
      return true;
    }
  }

  public stopListening() {
    this.isContinuous = false;
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch (e) {
        // ignore
      }
      this.isListening = false;
    }
  }

  public speak(
    text: string,
    language: LanguageCode = 'en',
    onStart?: () => void,
    onEnd?: () => void
  ) {
    if (this.isMuted) {
      if (onStart) onStart();
      setTimeout(() => {
        if (onEnd) onEnd();
      }, 800);
      return;
    }

    this.playChime('success');

    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      if (onStart) onStart();
      setTimeout(() => {
        if (onEnd) onEnd();
      }, 1500);
      return;
    }

    try {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
      window.speechSynthesis.cancel();
    } catch (e) {
      // ignore
    }

    const cleanText = text
      .replace(/[*_~`#>]/g, '')
      .replace(/https?:\/\/\S+/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!cleanText) {
      if (onEnd) onEnd();
      return;
    }

    // Pause mic recognition callback while Hayat speaks
    this.isPausedForSpeech = true;

    // Safety Watchdog: SpeechSynthesisUtterance can get garbage collected or stall.
    // Ensure isPausedForSpeech is NEVER stuck permanently.
    if (this.speechWatchdogTimer) clearTimeout(this.speechWatchdogTimer);
    const estimatedDurationMs = Math.min(12000, Math.max(2500, cleanText.length * 90));
    this.speechWatchdogTimer = setTimeout(() => {
      this.isPausedForSpeech = false;
      if (onEnd) onEnd();
    }, estimatedDurationMs);

    setTimeout(() => {
      try {
        const utterance = new SpeechSynthesisUtterance(cleanText);
        // Retain reference on instance so GC does not swallow it
        this.currentUtterance = utterance;

        utterance.lang = 'en-US';
        utterance.rate = 1.05;
        utterance.pitch = 1.0;

        const availableVoices = window.speechSynthesis.getVoices();
        if (availableVoices && availableVoices.length > 0) {
          const match =
            availableVoices.find(
              (v) =>
                v.lang === 'en-US' &&
                (v.name.includes('Google') ||
                  v.name.includes('Natural') ||
                  v.name.includes('Samantha') ||
                  v.name.includes('Zira') ||
                  v.name.includes('Jenny'))
            ) ||
            availableVoices.find((v) => v.lang.startsWith('en')) ||
            availableVoices[0];
          if (match) utterance.voice = match;
        }

        utterance.onstart = () => {
          if (onStart) onStart();
        };

        const finishSpeech = () => {
          if (this.speechWatchdogTimer) {
            clearTimeout(this.speechWatchdogTimer);
            this.speechWatchdogTimer = null;
          }
          this.isPausedForSpeech = false;
          this.currentUtterance = null;
          if (onEnd) onEnd();
        };

        utterance.onend = finishSpeech;
        utterance.onerror = (err) => {
          console.warn('Speech synthesis error event:', err);
          finishSpeech();
        };

        window.speechSynthesis.speak(utterance);

        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }
      } catch (err) {
        console.warn('Speech synthesis speak execution failed:', err);
        this.isPausedForSpeech = false;
        if (onStart) onStart();
        setTimeout(() => {
          if (onEnd) onEnd();
        }, 1200);
      }
    }, 40);
  }
}
