export type RealtimeEventType =
  | 'init:state'
  | 'sys:metrics'
  | 'telemetry:span'
  | 'system1:decision'
  | 'adb:log'
  | 'music:playing'
  | 'google:results'
  | 'whatsapp:reply'
  | 'social:event'
  | 'chat:message'
  | 'phone:state_sync'
  | 'ws:status';

export interface RealtimeMessage<T = any> {
  type: RealtimeEventType;
  payload: T;
  timestamp: string;
}

type EventHandler = (payload: any, fullMessage: RealtimeMessage) => void;

class RealtimeSocketClient {
  private ws: WebSocket | null = null;
  private listeners: Map<RealtimeEventType | '*', Set<EventHandler>> = new Map();
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private reconnectAttempts = 0;
  private isConnected = false;
  private pendingQueue: Array<{ type: string; payload?: any }> = [];

  public connect() {
    if (typeof window === 'undefined') return;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws/realtime`;

    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.isConnected = true;
        this.reconnectAttempts = 0;
        this.emitLocal('ws:status', { connected: true, url: wsUrl });

        // Flush any queued messages buffered while disconnected
        while (this.pendingQueue.length > 0) {
          const item = this.pendingQueue.shift();
          if (item && this.ws?.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify(item));
          }
        }
      };

      this.ws.onmessage = (event) => {
        try {
          const msg: RealtimeMessage = JSON.parse(event.data);
          if (!msg || !msg.type) return;
          this.dispatch(msg);
        } catch {
          // Ignore malformed frames
        }
      };

      this.ws.onclose = () => {
        this.isConnected = false;
        this.emitLocal('ws:status', { connected: false });
        this.scheduleReconnect();
      };

      this.ws.onerror = () => {
        this.isConnected = false;
        this.emitLocal('ws:status', { connected: false });
      };
    } catch {
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    const delay = Math.min(5000, 800 * Math.pow(1.5, this.reconnectAttempts));
    this.reconnectAttempts++;
    this.reconnectTimer = setTimeout(() => {
      this.connect();
    }, delay);
  }

  private emitLocal(type: RealtimeEventType, payload: any) {
    this.dispatch({
      type,
      payload,
      timestamp: new Date().toISOString(),
    });
  }

  private dispatch(msg: RealtimeMessage) {
    const typeHandlers = this.listeners.get(msg.type);
    if (typeHandlers) {
      typeHandlers.forEach((handler) => handler(msg.payload, msg));
    }
    const wildcardHandlers = this.listeners.get('*');
    if (wildcardHandlers) {
      wildcardHandlers.forEach((handler) => handler(msg.payload, msg));
    }
  }

  public subscribe(type: RealtimeEventType | '*', handler: EventHandler): () => void {
    if (!this.listeners.has(type)) {
      this.listeners.set(type, new Set());
    }
    this.listeners.get(type)!.add(handler);
    this.connect();

    return () => {
      this.listeners.get(type)?.delete(handler);
    };
  }

  public send(type: string, payload?: any) {
    const msg = { type, payload, timestamp: new Date().toISOString() };
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(msg));
    } else {
      this.pendingQueue.push(msg);
      this.connect();
    }
  }

  public getConnectionStatus(): boolean {
    return this.isConnected;
  }
}

export const realtimeSocket = new RealtimeSocketClient();
