/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Smartphone,
  Eye,
  Zap,
  Globe,
  Briefcase,
  Shield,
  Presentation,
  Volume2,
  VolumeX,
  Radio,
  Terminal,
  Activity,
  AlertTriangle,
  Play,
  Mic,
  MicOff,
  PhoneCall,
  Search,
  MessageSquare,
  Camera,
  Layers,
  ChevronRight,
  Send,
  Sparkles,
  PhoneOff,
  CheckCircle2,
  Cpu,
  Upload,
  Settings,
  User,
  Music,
  Clipboard,
  Hand,
} from 'lucide-react';

import {
  AssistantState,
  LanguageCode,
  ChatMessage,
  System1Decision,
  PhoneState,
  CallLogItem,
} from './types';
import { AvatarFace, AvatarVisualMode } from './components/AvatarFace';
import { AstraVision } from './components/AstraVision';
import { AndroidPhoneBridge } from './components/AndroidPhoneBridge';
import { System1Inspector } from './components/System1Inspector';
import { CareerWorkflows } from './components/CareerWorkflows';
import { SecurityObservability } from './components/SecurityObservability';
import { PresentationReview } from './components/PresentationReview';
import { TerminalRepl } from './components/TerminalRepl';
import { JarvisHUDView } from './components/JarvisHUDView';
import { MuseAgentView, MuseSubTab } from './components/MuseAgentView';
import { HayatMobileView } from './components/HayatMobileView';
import { VoiceController } from './utils/speech';
import { realtimeSocket } from './utils/realtimeSocket';

export type WorkspaceView =
  | 'mark_liv_cockpit'
  | 'hayat_android'
  | 'jev_system1'
  | 'meta_muse'
  | 'earth_astra'
  | 'career_security'
  | 'pure_face';

export default function App() {
  // Primary Workspace Mode — defaults to Mark LIV Cockpit so all 5 videos' features are immediately visible & interactive
  const [workspaceView, setWorkspaceView] = useState<WorkspaceView>('mark_liv_cockpit');

  // Active sub-module displayed inside the Mark LIV Center Splitter or Overlay in Pure Face mode
  const [openedApp, setOpenedApp] = useState<
    | 'phone'
    | 'earth_hud'
    | 'astra_vision'
    | 'system1'
    | 'career'
    | 'security'
    | 'presentation'
    | 'muse'
    | 'hayat_mobile'
    | null
  >('phone');

  const [visualMode, setVisualMode] = useState<AvatarVisualMode>('hologram_head');
  const [accentColor, setAccentColor] = useState<string>('#00d4ff');
  const [showSettingsDrawer, setShowSettingsDrawer] = useState<boolean>(false);
  const [museTab, setMuseTab] = useState<MuseSubTab>('first_prompt');
  const [museGoal, setMuseGoal] = useState<string>('');
  const [lastSpokenText, setLastSpokenText] = useState<string>('');
  const [showVoiceGuide, setShowVoiceGuide] = useState<boolean>(false);
  const [latestSystem1, setLatestSystem1] = useState<System1Decision | null>(null);

  // Mark LIV System Metrics (ui.py _SysMetrics: CPU, MEM, NET, GPU, TMP + Clock + Uptime)
  const [clockTime, setClockTime] = useState<string>('10:42:00');
  const [clockDate, setClockDate] = useState<string>('SAT 26 SEP 2026');
  const [uptimeStr, setUptimeStr] = useState<string>('UP  00:42');
  const [sysMetrics, setSysMetrics] = useState({
    cpu: 28,
    mem: 54,
    net: 76,
    gpu: 41,
    tmp: 49,
    procs: 214,
  });
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [clipboardText, setClipboardText] = useState<string>('');

  const [assistantState, setAssistantState] = useState<AssistantState>('idle');
  const [language, setLanguage] = useState<LanguageCode>('en');
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isContinuousListening, setIsContinuousListening] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isEmergencyStopped, setIsEmergencyStopped] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Live Real-Time Speech Feedback states
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const [lastExecutedCommand, setLastExecutedCommand] = useState<string>('');
  const [lastActionBadge, setLastActionBadge] = useState<string>(
    'REAL-TIME ENGINE · All 6 Videos Unified (Phone, Gmail, Social, Google, Music & GPT-6 Sol/Astra)'
  );
  const [commandInput, setCommandInput] = useState<string>('');

  const voiceControllerRef = useRef<VoiceController | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Shared Phone State across all voice automations (Video 1: PpzQY9EDxeM + Real-Time Live APIs)
  const defaultLogs: CallLogItem[] = [
    { id: 'c1', contactName: 'Mom', phoneNumber: '+91 98765 11223', type: 'incoming', time: '10:05 AM', duration: '2m 14s' },
    { id: 'c2', contactName: 'Dad', phoneNumber: '+91 98765 99881', type: 'outgoing', time: '09:40 AM', duration: '4m 30s' },
    { id: 'c3', contactName: 'Neon', phoneNumber: '+91 98765 43210', type: 'missed', time: 'Yesterday' },
    { id: 'c4', contactName: 'Office Manager', phoneNumber: '+91 98765 77665', type: 'outgoing', time: 'Yesterday', duration: '1m 02s' },
    { id: 'c5', contactName: 'Sarah Jenkins', phoneNumber: '+91 98765 55443', type: 'incoming', time: 'Sep 23', duration: '5m 18s' },
  ];

  const [phoneState, setPhoneState] = useState<PhoneState>({
    screen: 'home',
    isAwake: true,
    battery: 73,
    isCharging: true,
    callLogs: defaultLogs,
    activeCall: {
      contactName: 'Mom',
      phoneNumber: '+91 98765 11223',
      durationSec: 0,
      isActive: false,
      isRinging: true,
    },
    googleQuery: 'what is the current trending',
    googleResult: {
      title: '🔥 Google Real-Time Trending & Live Search',
      temperature: 'LIVE',
      condition: 'Real-Time Web Grounding',
      snippet: 'Say "Open Google and type what is the current trending" to auto-type and fetch live trending headlines.',
      items: [],
    },
    whatsappChat: {
      contact: 'Neon',
      messages: [
        { from: 'contact', text: 'Hey bro, is the real-time multi-agent system ready?', time: '10:14 AM' },
        { from: 'me', text: 'Yes, running all 6 video architectures in real time now.', time: '10:15 AM' },
      ],
      draftText: 'How are you?',
    },
    youtubeSong: {
      platform: 'youtube',
      title: 'Manasellam Mazhaiye',
      artist: 'Sonu Nigam, G.V. Prakash Kumar & Saindhavi',
      album: 'Saguni (Original Motion Picture Soundtrack)',
      artworkUrl:
        'https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/20/d2/b1/20d2b1e0-c71b-0b5a-fe2e-8a70eb671163/8903431508119.jpg/600x600bb.jpg',
      previewUrl:
        'https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/b5/fb/ba/b5fbbaa9-e796-5e95-e6d9-25adf7fd8beb/mzaf_5938035984002884182.plus.aac.p.m4a',
      youtubeVideoId: 'ujzCHdcFP7M',
      isPlaying: false,
      adSkipped: true,
    },
    gmailState: {
      inbox: [
        {
          id: 'em1',
          from: 'Dr. K. Ramesh (HOD)',
          email: 'hod.mca@srmist.edu.in',
          subject: 'Final Project Review Schedule - Generative AI',
          snippet: 'Please ensure your real-time multi-agent demonstration is ready for the panel.',
          time: '10:30 AM',
          unread: true,
        },
      ],
      compose: {
        to: 'hod.mca@srmist.edu.in',
        subject: 'Real-Time Multimodal AI Project Update',
        body: 'Respected Sir, our unified real-time AI agent handling phone calls, emails, social media, Google search, and live music streaming is ready.',
        status: 'ready',
      },
    },
    twitterState: {
      trends: [
        { tag: '#GPT6SolVsAstra', posts: '142.8K Posts', category: 'AI & Tech · Trending' },
        { tag: '#ManasellamMazhai', posts: '54.2K Posts', category: 'Music · Trending in India' },
        { tag: '#JarvisMark54', posts: '38.9K Posts', category: 'Robotics & HUD · Live' },
      ],
      feed: [
        {
          id: 'tw1',
          author: 'BitBiasedAI',
          handle: '@BitBiasedAI',
          text: 'GPT-6 Sol is 5X cheaper than GPT-6 Astra ($2/$10 vs $10/$50), scoring 33.2% on AutomationBench for just $0.27/task while Astra blocks 97.3% biohigh threats!',
          time: '12m',
          likes: 1842,
          reposts: 412,
        },
      ],
    },
  });

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg_0',
      sender: 'system',
      text: 'SYS: Real-Time Unified Engine Initialised. All 6 Video Architectures Online.',
      timestamp: '10:00:01',
    },
    {
      id: 'msg_1',
      sender: 'hayat',
      text: 'All 6 video architectures combined in real time: (1) Hayat Real-Time Phone Calls, Gmail, WhatsApp, Instagram, Twitter/X, Google Auto-Type & YouTube/Spotify/JioSaavn Music Streaming, (2) TypeSafe Jev AI Sub-100ms System 1 Router, (3) Meta Muse Personal VM, (4) Aleric Heck First Prompt, (5) Jarvis Mark 54 3D Holographic Head, and (6) BitBiasedAI GPT-6 Sol vs. Astra 5x Cheaper Tiered Router.',
      timestamp: '10:00:05',
      language: 'en',
    },
  ]);

  // Voice Command Trigger Chips covering all 6 videos in real time
  const QUICK_ACTIONS = [
    { label: '🎵 Play Manasellam Mazhai', prompt: 'Play Manasellam Mazhai on YouTube' },
    { label: '🟢 Spotify: Play Munbe Vaa', prompt: 'Open Spotify and play Munbe Vaa' },
    { label: '🔵 JioSaavn: Play Arabic Kuthu', prompt: 'Open JioSaavn and play Arabic Kuthu' },
    { label: '🔥 Google: Current Trending', prompt: 'Open Google and type what is the current trending' },
    { label: '📞 Call Mom Live', prompt: 'Open call log and call my Mom' },
    { label: '✉️ Send Gmail to HOD', prompt: 'Send email to hod.mca@srmist.edu.in about project review' },
    { label: '💬 WhatsApp Neon Live', prompt: 'Send WhatsApp message to Neon saying I am ready for the demo' },
    { label: '𝕏 Post on Twitter/X', prompt: 'Open Twitter and post about our real-time AI agent' },
    { label: '📸 Open Instagram Reels', prompt: 'Open Instagram and check latest feed' },
    { label: '🎵 Play Tum Hardafa Ho', prompt: 'Play Tum Hardafa Ho on YouTube and skip ads' },
    { label: '⚡ TypeSafe Jev System 1 (Video 2)', prompt: 'Open System 1 Jev AI router' },
    { label: '🖥️ Meta Muse Personal VM (Video 3)', prompt: 'Open Meta Muse Personal Virtual Machine and track deals' },
    { label: '✨ Aleric First Prompt (Video 4)', prompt: 'Run the First Prompt on Meta Muse' },
    { label: '👤 Mark 54 3D Head (Video 5)', prompt: 'Switch to 3D Hologram Head' },
    { label: '🛡️ Mark 54 VPS & Sentry (Video 5)', prompt: 'Open Jarvis Mark 54 VPS and Security Sentry' },
    { label: '🌍 Show 3D Earth', prompt: 'Hey Jarvis, just show me the Earth' },
  ];

  // Real-Time WebSocket Connection to Backend (/ws/realtime) — Replaces polling mechanisms
  useEffect(() => {
    const applyMetrics = (m: any) => {
      if (!m) return;
      if (m.clockTime) setClockTime(m.clockTime);
      if (m.clockDate) setClockDate(m.clockDate);
      if (m.uptimeStr) setUptimeStr(m.uptimeStr);
      setSysMetrics((prev) => ({
        cpu: m.cpu ?? prev.cpu,
        mem: m.mem ?? prev.mem,
        net: m.net ?? prev.net,
        gpu: m.gpu ?? prev.gpu,
        tmp: m.tmp ?? prev.tmp,
        procs: m.procs ?? prev.procs,
      }));
    };

    const unsubInit = realtimeSocket.subscribe('init:state', (payload) => {
      if (payload?.sysMetrics) applyMetrics(payload.sysMetrics);
      if (payload?.latestSystem1) setLatestSystem1(payload.latestSystem1);
    });

    const unsubMetrics = realtimeSocket.subscribe('sys:metrics', (metrics) => {
      applyMetrics(metrics);
    });

    const unsubS1 = realtimeSocket.subscribe('system1:decision', (decision: System1Decision) => {
      if (decision) setLatestSystem1(decision);
    });

    const unsubMusic = realtimeSocket.subscribe('music:playing', (musicData) => {
      if (!musicData?.title) return;
      setPhoneState((prev) => ({
        ...prev,
        screen: musicData.platform || prev.screen,
        youtubeSong: {
          platform: musicData.platform || 'youtube',
          searchQuery: musicData.searchQuery || musicData.query || musicData.title,
          title: musicData.title,
          artist: musicData.artist || 'Verified Artist',
          album: musicData.album || 'Official Soundtrack',
          artworkUrl: musicData.artworkUrl,
          previewUrl: musicData.previewUrl,
          youtubeVideoId: musicData.youtubeVideoId,
          youtubeResults: musicData.youtubeResults || [],
          trackResults: musicData.trackResults || [],
          isPlaying: true,
          adSkipped: true,
        },
      }));
    });

    const unsubGoogle = realtimeSocket.subscribe('google:results', (googleData) => {
      if (!googleData?.query) return;
      setPhoneState((prev) => ({
        ...prev,
        screen: 'google',
        googleQuery: googleData.query,
        isTypingGoogle: false,
        googleResult: {
          title: googleData.isTrending
            ? '🔥 Google Real-Time Trending Now'
            : `🔍 Live Google Results: "${googleData.query}"`,
          temperature: 'LIVE',
          condition: `${googleData.items?.length || 0} Real-Time Sources`,
          snippet: googleData.aiSummary,
          aiSummary: googleData.aiSummary,
          wikiCard: googleData.wikiCard,
          relatedQueries: googleData.relatedQueries,
          items: googleData.items || [],
        },
      }));
    });

    const unsubWa = realtimeSocket.subscribe('whatsapp:reply', (replyData) => {
      if (!replyData?.text) return;
      setPhoneState((prev) => ({
        ...prev,
        whatsappChat: {
          contact: replyData.contact || prev.whatsappChat?.contact || 'Neon',
          messages: [
            ...(prev.whatsappChat?.messages || []),
            {
              from: 'contact',
              text: replyData.text,
              time: replyData.time || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            },
          ],
        },
      }));
    });

    const unsubPhoneSync = realtimeSocket.subscribe('phone:state_sync', (remoteState: PhoneState) => {
      if (remoteState) setPhoneState(remoteState);
    });

    return () => {
      unsubInit();
      unsubMetrics();
      unsubS1();
      unsubMusic();
      unsubGoogle();
      unsubWa();
      unsubPhoneSync();
    };
  }, []);

  // Initialize Speech Controller & Audio Unlock
  useEffect(() => {
    voiceControllerRef.current = new VoiceController();
    voiceControllerRef.current.setLanguage('en');
    voiceControllerRef.current.setMuted(isMuted);

    const unlockAudio = () => {
      voiceControllerRef.current?.getAudioContext();
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }
      }
    };

    window.addEventListener('click', unlockAudio);
    window.addEventListener('keydown', unlockAudio);

    const startContinuous = async () => {
      unlockAudio();
      if (isContinuousListening && !isListening) {
        startHandsFreeListening();
      }
    };
    window.addEventListener('click', startContinuous, { once: true });

    return () => {
      window.removeEventListener('click', unlockAudio);
      window.removeEventListener('keydown', unlockAudio);
      voiceControllerRef.current?.stopPhoneRinging();
    };
  }, []);

  // Watch active call state to stop ringtone when answered or ended
  useEffect(() => {
    if (!phoneState.activeCall?.isActive || !phoneState.activeCall?.isRinging) {
      voiceControllerRef.current?.stopPhoneRinging();
    }
  }, [phoneState.activeCall?.isActive, phoneState.activeCall?.isRinging]);

  useEffect(() => {
    if (voiceControllerRef.current) {
      voiceControllerRef.current.setLanguage(language);
      voiceControllerRef.current.setMuted(isMuted);
    }
  }, [language, isMuted]);

  // Global Keyboard Shortcuts (Escape = Interrupt, F4 = Mute, Ctrl+Space = PTT, Ctrl+Shift+K = Kill Switch)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleInterrupt();
      }
      if (e.key === 'F4') {
        e.preventDefault();
        setIsMuted((m) => !m);
      }
      if (e.ctrlKey && e.shiftKey && (e.key === 'K' || e.key === 'k')) {
        e.preventDefault();
        toggleEmergencyStop();
      }
      if (e.ctrlKey && e.code === 'Space') {
        e.preventDefault();
        toggleListening();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isListening, isEmergencyStopped]);

  const startHandsFreeListening = () => {
    if (isEmergencyStopped || !voiceControllerRef.current) return;
    setIsListening(true);
    setAssistantState('listening');

    voiceControllerRef.current.startListening(
      (transcript) => {
        setInterimTranscript('');
        setLastExecutedCommand(transcript);
        handleSendMessage(transcript);
      },
      (interim) => {
        setInterimTranscript(interim);
      },
      (err) => {
        console.warn('Speech recognition warning:', err);
      },
      true
    );
  };

  const stopHandsFreeListening = () => {
    voiceControllerRef.current?.stopListening();
    setIsListening(false);
    setAssistantState('idle');
    setInterimTranscript('');
  };

  const toggleListening = () => {
    if (isEmergencyStopped) return;
    if (isListening) {
      stopHandsFreeListening();
    } else {
      startHandsFreeListening();
    }
  };

  // Mark LIV Interrupt Button [ESC]
  const handleInterrupt = () => {
    voiceControllerRef.current?.stopPhoneRinging();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setAssistantState(isListening ? 'listening' : 'idle');
    setLastActionBadge('✋ Interrupted speech · Standing by');
  };

  const toggleEmergencyStop = () => {
    if (!isEmergencyStopped) {
      setIsEmergencyStopped(true);
      setAssistantState('emergency_stopped');
      stopHandsFreeListening();
      voiceControllerRef.current?.stopPhoneRinging();
      voiceControllerRef.current?.setMuted(true);
      setMessages((prev) => [
        ...prev,
        {
          id: `halt_${Date.now()}`,
          sender: 'system',
          text: '🚨 [HARDWARE KILL SWITCH ACTIVATED]: All background automation, ADB intents, and audio listeners halted.',
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
    } else {
      setIsEmergencyStopped(false);
      setAssistantState('idle');
      voiceControllerRef.current?.setMuted(isMuted);
      setMessages((prev) => [
        ...prev,
        {
          id: `restore_${Date.now()}`,
          sender: 'system',
          text: '✔ Safety circuit reset. System 1 router, phone bridge, and J.A.R.V.I.S. Mark LIV HUD restored.',
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
      if (isContinuousListening) {
        startHandsFreeListening();
      }
    }
  };

  const handleTestAgentVoice = () => {
    setIsMuted(false);
    voiceControllerRef.current?.setMuted(false);
    speakResponse(
      'Hayat and Jarvis Mark 54 online. All five video architectures are active and listening for your voice commands, boss!'
    );
  };

  // Automated Phone and HUD State Transitions based on Voice Commands
  const executeRealtimeAutomations = (
    promptText: string
  ): { matched: boolean; badgeText: string; spokenReply: string; shouldAlsoAskGemini?: boolean } => {
    const raw = promptText.trim();
    const p = raw.toLowerCase();

    // Helper: check if the user is asking a general knowledge question (who/what/why/how/explain/tell me)
    // unless they explicitly say "open", "switch", "call", "dial", "play", "send", "run"
    const isExplicitAction = /^(open|switch|call|dial|play|send|run|close|hang up|end call|disconnect|show me the earth|check battery|look at)\b/i.test(
      p
    );
    const isGeneralQuestion =
      /^(what|who|why|how|when|where|which|explain|define|tell me|can you explain|write|solve|calculate|compare)\b/i.test(
        p
      ) && !isExplicitAction;

    if (isGeneralQuestion && !p.includes('weather today') && !p.includes('what do you see')) {
      return { matched: false, badgeText: '', spokenReply: '', shouldAlsoAskGemini: true };
    }

    // 0. Close / Return to pure Hayat Face
    if (
      p === 'close' ||
      p === 'close app' ||
      p === 'close that' ||
      p === 'close screen' ||
      p === 'go back' ||
      p === 'back to hayat' ||
      p === 'pure face' ||
      p.includes('pure face mode') ||
      p.includes('band karo') ||
      p.includes('moodu')
    ) {
      const badge = 'Hayat Standby · Ready for voice command';
      const reply = 'Returning to Hayat face standby.';
      setOpenedApp(null);
      setLastActionBadge(badge);
      voiceControllerRef.current?.stopPhoneRinging();
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 1. Call Mom (Video 1)
    if (
      (p.includes('mom') || p.includes('mother') || p.includes('mummy') || p.includes('maa') || p.includes('amma') || p.includes('ammi')) &&
      (p.includes('call') || p.includes('dial') || p.includes('phone') || p.includes('lagao') || p.includes('pannu') || p.includes('open call log'))
    ) {
      const badge = '📞 Dialing Mom (+91 98765 11223) - Call Log Active';
      const reply = 'Opening call log and dialing Mom on Android phone bridge now, boss.';
      setOpenedApp('phone');
      setLastActionBadge(badge);
      voiceControllerRef.current?.playPhoneRinging();

      setPhoneState((prev) => ({
        ...prev,
        screen: 'call',
        activeCall: {
          contactName: 'Mom',
          phoneNumber: '+91 98765 11223',
          durationSec: 0,
          isActive: true,
          isRinging: true,
        },
      }));

      handleExecuteADB('call', { phone: '+919876511223' });
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 2. Call Dad (Video 1)
    if (
      (p.includes('dad') || p.includes('father') || p.includes('papa') || p.includes('appa') || p.includes('abbu')) &&
      (p.includes('call') || p.includes('dial') || p.includes('phone') || p.includes('lagao') || p.includes('pannu'))
    ) {
      const badge = '📞 Dialing Dad (+91 98765 99881) - Call Log Active';
      const reply = 'Opening call log and dialing Dad on Android phone bridge now, boss.';
      setOpenedApp('phone');
      setLastActionBadge(badge);
      voiceControllerRef.current?.playPhoneRinging();

      setPhoneState((prev) => ({
        ...prev,
        screen: 'call',
        activeCall: {
          contactName: 'Dad',
          phoneNumber: '+91 98765 99881',
          durationSec: 0,
          isActive: true,
          isRinging: true,
        },
      }));

      handleExecuteADB('call', { phone: '+919876599881' });
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 2b. Dynamic Call Any Contact (e.g. "Call Rahul", "Dial Sarah")
    const callMatch = raw.match(/^(?:please\s+)?(?:call|dial)\s+([a-zA-Z0-9\s]{2,25})$/i);
    if (callMatch && !p.includes('call log')) {
      const contactName = callMatch[1].trim();
      const badge = `📞 Dialing ${contactName} - Call Log Active`;
      const reply = `Opening call log and dialing ${contactName} on Android phone bridge now, boss.`;
      setOpenedApp('phone');
      setLastActionBadge(badge);
      voiceControllerRef.current?.playPhoneRinging();

      setPhoneState((prev) => ({
        ...prev,
        screen: 'call',
        activeCall: {
          contactName,
          phoneNumber: '+91 98765 43210',
          durationSec: 0,
          isActive: true,
          isRinging: true,
        },
      }));

      handleExecuteADB('call', { phone: '+919876543210' });
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 3. Open Call Log
    if (p.includes('call log') || p.includes('call history') || p.includes('recent call') || p.includes('open dialer')) {
      const badge = '📋 Opened Recent Calls & Phone Directory';
      const reply = 'Opening call log and recent calls directory on Android phone bridge.';
      setOpenedApp('phone');
      setLastActionBadge(badge);
      setPhoneState((prev) => ({ ...prev, screen: 'call_log' }));
      handleExecuteADB('app', { package: 'com.android.dialer' });
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 4. Hang up / End call
    if (p.includes('hang up') || p.includes('end call') || p.includes('cut call') || p.includes('disconnect')) {
      const badge = '📴 Call Disconnected';
      const reply = 'Call ended and disconnected.';
      setLastActionBadge(badge);
      voiceControllerRef.current?.stopPhoneRinging();
      setPhoneState((prev) => ({
        ...prev,
        screen: 'call_log',
        activeCall: prev.activeCall ? { ...prev.activeCall, isActive: false } : undefined,
      }));
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 5. REAL-TIME GOOGLE AUTO-TYPE & LIVE TRENDING / WEB SEARCH (Handles ANY Google Query!)
    if (
      p.includes('open google') ||
      p.includes('search google') ||
      p.includes('in google') ||
      p.includes('on google') ||
      p.startsWith('google ') ||
      p.startsWith('search for ') ||
      p.includes('current trending') ||
      p.includes('what is trending') ||
      p.includes('weather today') ||
      (p.includes('google') && (p.includes('type') || p.includes('search')))
    ) {
      const extractedQuery =
        raw
          .replace(
            /^(?:please\s+)?(?:can\s+you\s+)?(?:open\s+google\s+and\s+type\s+and\s+search|open\s+google\s+and\s+type|open\s+google\s+and\s+search|type\s+and\s+search\s+in\s+google|search\s+google\s+for|search\s+on\s+google\s+for|open\s+google\s+for|google\s+search|search\s+for|open\s+google|google)\s*/i,
            ''
          )
          .replace(/\s+(?:in|on)\s+google$/i, '')
          .trim() || 'what is the current trending';

      const badge = `🔍 Google Real-Time Auto-Type: "${extractedQuery}"`;
      const reply = `Opening Google, typing "${extractedQuery}" automatically, and fetching real-time results now.`;

      setOpenedApp('phone');
      setLastActionBadge(badge);
      voiceControllerRef.current?.playChime('success');

      setPhoneState((prev) => ({
        ...prev,
        screen: 'google',
        googleQuery: extractedQuery,
        isTypingGoogle: true,
        googleResult: {
          title: `Auto-typing "${extractedQuery}"...`,
          temperature: 'LIVE',
          condition: 'Searching Google Live...',
          snippet: 'Fetching real-time web, Wikipedia & trending headlines...',
          items: prev.googleResult?.items || [],
        },
      }));

      handleExecuteADB('app', { package: 'com.google.android.googlequicksearchbox' });

      fetch('/api/realtime/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: extractedQuery }),
      })
        .then((r) => r.json())
        .then((data) => {
          setPhoneState((prev) => ({
            ...prev,
            screen: 'google',
            googleQuery: extractedQuery,
            isTypingGoogle: false,
            googleResult: {
              title: data.isTrending ? '🔥 Google Real-Time Trending Now' : `🔍 Live Google Results: "${extractedQuery}"`,
              temperature: 'LIVE',
              condition: `${data.items?.length || 0} Real-Time Sources`,
              snippet: data.aiSummary || reply,
              aiSummary: data.aiSummary,
              wikiCard: data.wikiCard,
              relatedQueries: data.relatedQueries,
              items: data.items || [],
            },
          }));
          if (data.aiSummary) {
            setLastActionBadge(`🔥 Google Live: ${extractedQuery}`);
            setMessages((prev) => [
              ...prev,
              {
                id: `google_${Date.now()}`,
                sender: 'hayat',
                text: data.aiSummary,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
              },
            ]);
            speakResponse(data.aiSummary);
          }
        })
        .catch(() => {});

      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 6. REAL-TIME WHATSAPP MESSAGE + LIVE AI CONTACT REPLY
    if (p.includes('whatsapp') || p.includes('message neon') || p.includes('whatsapp neon')) {
      const matchMsg = raw.match(/to\s+([a-zA-Z0-9_]+)\s*(?::|saying|that|-)\s*(.+)$/i);
      const targetContact = matchMsg ? matchMsg[1].trim() : 'Neon';
      const targetText = matchMsg
        ? matchMsg[2].trim()
        : raw.replace(/^(?:open\s+whatsapp\s+and\s+send|send\s+whatsapp\s+message|whatsapp)\s*/i, '').trim() ||
          'How are you?';

      const badge = `📱 WhatsApp Live to ${targetContact}: "${targetText}"`;
      const reply = `Opening WhatsApp and sending real-time message to ${targetContact}: ${targetText}.`;
      setOpenedApp('phone');
      setLastActionBadge(badge);
      voiceControllerRef.current?.playChime('whatsapp');

      setPhoneState((prev) => ({
        ...prev,
        screen: 'whatsapp',
        whatsappChat: {
          contact: targetContact,
          messages: [
            ...(prev.whatsappChat?.messages || []),
            {
              from: 'me',
              text: targetText,
              time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            },
          ],
        },
      }));

      handleExecuteADB('whatsapp', { phone: '+919876543210', message: targetText });
      speakResponse(reply);

      fetch('/api/realtime/social', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appName: 'whatsapp', action: 'reply', contact: targetContact, content: targetText }),
      }).catch(() => {});

      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 7. REAL-TIME MUSIC & YOUTUBE STREAMING (YouTube / Spotify / JioSaavn — Plays ANY Song or Video Suggested!)
    if (
      p.includes('manasellam') ||
      p.includes('tum har dafa') ||
      p.includes('tum hardafa') ||
      p.includes('arabic kuthu') ||
      p.includes('spotify') ||
      p.includes('jiosaavn') ||
      p.includes('jio saavn') ||
      p.includes('saavn') ||
      p.includes('open youtube') ||
      p.startsWith('youtube ') ||
      (p.includes('youtube') && (p.includes('play') || p.includes('song') || p.includes('music') || p.includes('search') || p.includes('type'))) ||
      p.startsWith('play ') ||
      p.includes(' and play ') ||
      p.startsWith('listen to ')
    ) {
      const targetPlatform: 'youtube' | 'spotify' | 'jiosaavn' =
        p.includes('spotify')
          ? 'spotify'
          : p.includes('jiosaavn') || p.includes('jio saavn') || p.includes('saavn')
          ? 'jiosaavn'
          : 'youtube';

      const customSong =
        raw
          .replace(
            /^(?:please\s+)?(?:can\s+you\s+)?(?:open\s+(?:youtube|spotify|jiosaavn|jio\s+saavn)\s+(?:and\s+)?(?:play|search|type)\s+(?:the\s+music\s+|the\s+song\s+|song\s+|music\s+)?|open\s+(?:youtube|spotify|jiosaavn|jio\s+saavn)\s*|play\s+(?:the\s+song\s+|the\s+music\s+|music\s+|song\s+)?|listen\s+to\s+|youtube\s+(?:play\s+|search\s+)?)/i,
            ''
          )
          .replace(/\s+on\s+(?:youtube|spotify|jiosaavn|jio\s+saavn).*$/i, '')
          .replace(/\s+in\s+(?:youtube|spotify|jiosaavn|jio\s+saavn).*$/i, '')
          .replace(/\s+and\s+skip\s+ads.*$/i, '')
          .replace(/\s+play\s+like\s+that.*$/i, '')
          .trim() || 'Manasellam Mazhai';

      const badge = `🎵 ${targetPlatform.toUpperCase()}: Streaming "${customSong}" Live`;
      const reply = `Opening ${targetPlatform} and playing "${customSong}" in real time with automatic ad-skip.`;
      setOpenedApp('phone');
      setLastActionBadge(badge);
      voiceControllerRef.current?.playChime('success');

      setPhoneState((prev) => ({
        ...prev,
        screen: targetPlatform,
        youtubeSong: {
          platform: targetPlatform,
          searchQuery: customSong,
          title: `Searching & Playing "${customSong}"...`,
          artist: `Connecting to ${targetPlatform.toUpperCase()} Live Stream`,
          isPlaying: true,
          adSkipped: true,
        },
      }));

      handleExecuteADB('media', { command: 'play_pause', query: customSong, platform: targetPlatform });

      fetch('/api/realtime/music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: customSong, platform: targetPlatform }),
      })
        .then((r) => r.json())
        .then((data) => {
          setPhoneState((prev) => ({
            ...prev,
            screen: targetPlatform,
            youtubeSong: {
              platform: targetPlatform,
              searchQuery: customSong,
              title: data.title || customSong,
              artist: data.artist || 'Verified Artist',
              album: data.album || 'Official Soundtrack',
              artworkUrl: data.artworkUrl,
              previewUrl: data.previewUrl,
              youtubeVideoId: data.youtubeVideoId,
              youtubeResults: data.youtubeResults || [],
              trackResults: data.trackResults || [],
              isPlaying: true,
              adSkipped: true,
            },
          }));
          const confirmedMsg = `Now playing "${data.title || customSong}" by ${data.artist || 'Artist'} on ${targetPlatform.toUpperCase()} in real time.`;
          setLastActionBadge(`🎵 Playing: ${data.title || customSong} (${targetPlatform.toUpperCase()})`);
          speakResponse(confirmedMsg);
        })
        .catch(() => {
          speakResponse(reply);
        });

      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 7a. REAL-TIME MULTI-LANGUAGE TRANSLATOR
    if (p.startsWith('translate ') || p.includes('open translator')) {
      const langMap: Record<string, string> = {
        tamil: 'ta',
        hindi: 'hi',
        telugu: 'te',
        malayalam: 'ml',
        spanish: 'es',
        french: 'fr',
        german: 'de',
        arabic: 'ar',
      };
      let targetLang = 'ta';
      for (const [k, v] of Object.entries(langMap)) {
        if (p.includes(`to ${k}`) || p.includes(`in ${k}`)) {
          targetLang = v;
          break;
        }
      }
      const phrase =
        raw
          .replace(/^translate\s+/i, '')
          .replace(/\s+(?:to|in|into)\s+(?:tamil|hindi|telugu|malayalam|spanish|french|german|arabic)$/i, '')
          .trim() || 'Hello boss, all real-time systems are online.';

      const badge = `🌐 Live Translator (${targetLang.toUpperCase()}): "${phrase}"`;
      const reply = `Opening Real-Time Translator and translating "${phrase}" now.`;
      setOpenedApp('phone');
      setLastActionBadge(badge);
      setPhoneState((prev) => ({ ...prev, screen: 'translator' }));

      fetch('/api/realtime/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: phrase, targetLang }),
      })
        .then((r) => r.json())
        .then((d) => {
          if (d.translatedText) {
            setPhoneState((prev) => ({
              ...prev,
              screen: 'translator',
              translatorState: {
                sourceText: phrase,
                targetLang,
                translatedText: d.translatedText,
              },
            }));
            speakResponse(d.translatedText);
          }
        })
        .catch(() => {});

      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 7a-2. REAL-TIME SMART HOME IOT
    if (
      p.includes('smart home') ||
      p.includes('turn on light') ||
      p.includes('turn off light') ||
      p.includes('set ac') ||
      p.includes('lock door') ||
      p.includes('unlock door')
    ) {
      const badge = '🏠 Jarvis Smart Home IoT Updated in Real Time';
      const reply = 'Updating your Smart Home IoT devices in real time, boss.';
      setOpenedApp('phone');
      setLastActionBadge(badge);
      setPhoneState((prev) => ({
        ...prev,
        screen: 'smarthome',
        smartHomeState: {
          devices: (prev.smartHomeState?.devices || []).map((d) => {
            if (p.includes('light') && d.type === 'light') {
              return { ...d, status: !p.includes('off') };
            }
            if (p.includes('lock') && d.type === 'lock') {
              return { ...d, status: !p.includes('unlock'), value: p.includes('unlock') ? 'UNLOCKED' : 'LOCKED' };
            }
            return d;
          }),
        },
      }));
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 7a-3. REAL-TIME NOTES & ALARMS
    if (p.includes('take a note') || p.includes('set alarm') || p.includes('set reminder') || p.includes('open notes')) {
      const noteText =
        raw.replace(/^(?:please\s+)?(?:take\s+a\s+note|set\s+alarm\s+for|set\s+alarm|set\s+reminder|open\s+notes)\s*/i, '').trim() ||
        'Morning AI check at 7:00 AM';
      const isAlarm = p.includes('alarm');
      const badge = `📝 ${isAlarm ? 'Alarm Scheduled' : 'Voice Note Saved'}: "${noteText}"`;
      const reply = `${isAlarm ? 'Alarm scheduled' : 'Voice note saved'}: ${noteText}.`;
      setOpenedApp('phone');
      setLastActionBadge(badge);
      setPhoneState((prev) => ({
        ...prev,
        screen: 'notes',
        notesState: {
          notes: [
            {
              id: `n_${Date.now()}`,
              title: isAlarm ? 'Alarm Active' : 'Voice Note',
              content: noteText,
              time: 'Just now',
              category: isAlarm ? 'Alarm' : 'Note',
            },
            ...(prev.notesState?.notes || []),
          ],
        },
      }));
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 7b. REAL-TIME GMAIL / EMAIL AUTOMATION
    if (p.includes('gmail') || p.includes('send email') || p.includes('send an email') || p.includes('check email') || p.includes('open email')) {
      const emailMatch = raw.match(/to\s+([^\s]+@[^\s]+|[a-zA-Z0-9_]+)(?:\s+about\s+(.+))?/i);
      const recipient = emailMatch ? emailMatch[1].trim() : 'hod.mca@srmist.edu.in';
      const subject = emailMatch && emailMatch[2] ? emailMatch[2].trim() : 'Real-Time Multimodal AI Update';
      const badge = `✉️ Gmail Real-Time: Dispatched to ${recipient}`;
      const reply = `Opening Gmail, drafting your email to ${recipient} about ${subject}, and sending it in real time.`;

      setOpenedApp('phone');
      setLastActionBadge(badge);
      setPhoneState((prev) => ({ ...prev, screen: 'gmail' }));

      fetch('/api/realtime/social', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appName: 'gmail', action: 'compose', recipient, subject, content: subject }),
      })
        .then((r) => r.json())
        .then((d) => {
          const bodyText = d.generatedReply || subject;
          setPhoneState((prev) => ({
            ...prev,
            screen: 'gmail',
            gmailState: {
              inbox: [
                {
                  id: `em_${Date.now()}`,
                  from: `Me → ${recipient}`,
                  email: recipient,
                  subject: `✔ SENT: ${subject}`,
                  snippet: bodyText,
                  time: 'Just now',
                },
                ...(prev.gmailState?.inbox || []),
              ],
              compose: { to: recipient, subject, body: bodyText, status: 'sent' },
            },
          }));
        })
        .catch(() => {});

      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 7c. REAL-TIME TWITTER / X AUTOMATION
    if (p.includes('twitter') || p.includes('open x') || p.includes('tweet')) {
      const badge = '𝕏 Twitter / X Live Feed & Auto-Post Active';
      const reply = 'Opening Twitter X live trending feed and posting your update in real time.';
      setOpenedApp('phone');
      setLastActionBadge(badge);
      setPhoneState((prev) => ({ ...prev, screen: 'twitter' }));

      if (p.includes('post') || p.includes('tweet')) {
        fetch('/api/realtime/social', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ appName: 'twitter', action: 'post', content: raw }),
        })
          .then((r) => r.json())
          .then((d) => {
            if (d.generatedReply) {
              setPhoneState((prev) => ({
                ...prev,
                screen: 'twitter',
                twitterState: {
                  trends: prev.twitterState?.trends || [],
                  feed: [
                    {
                      id: `tw_${Date.now()}`,
                      author: 'Subhashree Narayanan',
                      handle: '@subhashree_ai',
                      text: d.generatedReply,
                      time: 'Just now',
                      likes: 1,
                      reposts: 0,
                    },
                    ...(prev.twitterState?.feed || []),
                  ],
                },
              }));
            }
          })
          .catch(() => {});
      }

      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 8. Instagram / Facebook / Telegram
    if (p.includes('instagram') || p.includes('insta') || p.includes('reels')) {
      const badge = '📸 Instagram Live Feed & Reels Active';
      const reply = 'Opening Instagram and loading latest feed and reels in real time.';
      setOpenedApp('phone');
      setLastActionBadge(badge);
      setPhoneState((prev) => ({ ...prev, screen: 'instagram' }));
      handleExecuteADB('app', { package: 'com.instagram.android' });
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    if (p.includes('facebook') || p.includes('fb')) {
      const badge = '🌐 Facebook Timeline & Feed Loaded';
      const reply = 'Opening Facebook timeline and feed.';
      setOpenedApp('phone');
      setLastActionBadge(badge);
      setPhoneState((prev) => ({ ...prev, screen: 'facebook' }));
      handleExecuteADB('app', { package: 'com.facebook.katana' });
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    if (p.includes('telegram') || p.includes('otp')) {
      const badge = '✈️ Telegram Messenger & Alerts Loaded';
      const reply = 'Opening Telegram messenger and notification alerts.';
      setOpenedApp('phone');
      setLastActionBadge(badge);
      setPhoneState((prev) => ({ ...prev, screen: 'telegram' }));
      handleExecuteADB('app', { package: 'org.telegram.messenger' });
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 9. 3D Earth / Satellite / Seismic
    if (p.includes('show me the earth') || p.includes('show earth') || p.includes('3d earth') || p.includes('jarvis earth')) {
      const badge = '🌍 3D Earth Hologram Activated';
      const reply = "I've put the Earth on your display, sir, and you can spin or zoom into it as you like.";
      setOpenedApp('earth_hud');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    if (p.includes('satellite view') || p.includes('switch to satellite')) {
      const badge = '🛰️ Satellite Telemetry Layer Activated';
      const reply = 'The satellite view is now active on your display, sir.';
      setOpenedApp('earth_hud');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    if (p.includes('recent earthquake') || p.includes('check earthquake')) {
      const badge = '🌋 Seismic Sensor Overlay Scanned';
      const reply = 'There have been no recent earthquakes in this area, sir.';
      setOpenedApp('earth_hud');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 10. Project Astra Camera Vision
    if (
      p.includes('what do you see') ||
      p.includes('look at my desk') ||
      p.includes('open astra') ||
      p.includes('astra vision') ||
      p.includes('describe what you see')
    ) {
      const badge = '👁️ Project Astra Multimodal Vision Online';
      const reply = 'Activating Project Astra camera vision. Analyzing surrounding objects and desk.';
      setOpenedApp('astra_vision');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 11. System 1 Inspector (Video 2: TypeSafe Jev AI)
    if (p.includes('open system 1') || p.includes('open system1') || p.includes('jev ai') || p.includes('routing inspector')) {
      const badge = '⚡ System 1 Sub-100ms Jev AI Router Active';
      const reply = 'Opening TypeSafe Jev AI System 1 decision router with sub-100 millisecond calibrated confidence gating.';
      setOpenedApp('system1');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 12. HUD Visual Mode Toggle (Video 5: Mark 54 3D Head / Hayat Anime / Reactor Core)
    if (p.includes('reactor core') || p.includes('reactor mode') || p.includes('gauge ring')) {
      const badge = '⚙️ Mark 54 Arc Reactor Core HUD Active';
      const reply = 'Switching display to Mark 54 Arc Reactor Core HUD with voice-reactive graduations.';
      setVisualMode('reactor_core');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    if (p.includes('3d head') || p.includes('hologram head') || p.includes('human head')) {
      const badge = '👤 Mark 54 3D Holographic Head Active';
      const reply = 'Switching to Mark 54 3D Holographic Head with opaque flat-shaded facets and real phoneme lip articulation.';
      setVisualMode('hologram_head');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    if (p.includes('hayat anime') || p.includes('anime view') || p.includes('hayat mobile')) {
      const badge = '🌸 Hayat Interactive Anime Companion Active';
      const reply = 'Switching to Hayat interactive anime companion from Video 1.';
      setVisualMode('hayat_anime');
      setOpenedApp('hayat_mobile');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 13. Battery Status (Video 1)
    if (p.includes('check battery') || p.includes('battery level') || p.includes('battery status')) {
      const badge = '🔋 Battery Status: 73% & Charging';
      const reply = 'Good morning, boss! Your phone battery is at 73 percent and currently charging.';
      setOpenedApp('phone');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 14. Meta Muse & Aleric Heck's First Prompt (Videos 3 & 4)
    if (p.includes('first prompt') || p.includes('aleric') || p.includes('chief of staff') || p.includes('index my')) {
      const badge = '✨ Meta Muse: First Prompt Executed';
      const reply =
        'Executing the First Prompt on Meta Muse. I have indexed your connected apps into private memory and activated goal-oriented autonomous execution.';
      setMuseTab('first_prompt');
      setMuseGoal('Executing First Prompt: Indexing connected apps & enabling autonomous goal workflows');
      setOpenedApp('muse');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    if (
      p.includes('personal vm') ||
      p.includes('virtual machine') ||
      p.includes('private processing') ||
      p.includes('track deal') ||
      p.includes('plan a trip') ||
      p.includes('check my calendar')
    ) {
      const badge = '🖥️ Meta Muse Personal VM Sandbox Active';
      const reply = 'Opening your encrypted Meta Muse Personal Virtual Machine and executing your multi-step workflow autonomously.';
      setMuseTab('personal_vm');
      setMuseGoal(promptText);
      setOpenedApp('muse');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    if (p.includes('open mark 54 quiz') || p.includes('document review') || p.includes('quiz and document')) {
      const badge = '📝 Mark 54 Interactive Quiz & Document Review';
      const reply = 'Opening Jarvis Mark 54 interactive quiz and document review board.';
      setMuseTab('mark54_quiz_review');
      setOpenedApp('muse');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    if (p.includes('transcribe') || p.includes('lyria') || p.includes('generate music') || p.includes('audio studio')) {
      const badge = '🎙️ Gemini 3.5 Transcribe & Lyria 3 Music Studio';
      const reply = 'Opening Gemini 3.5 Audio Transcription and Lyria 3 Music Generation studio.';
      setMuseTab('ai_audio_music');
      setOpenedApp('muse');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    if (p.includes('meta muse') || p.includes('open muse') || p.includes('muse agent') || p.includes('app connectors')) {
      const badge = '✨ Meta Muse Personal AI Agent Online';
      const reply = 'Opening Meta Muse Personal AI Agent with private virtual machine and app connectors.';
      setMuseTab(p.includes('connector') ? 'connectors' : 'first_prompt');
      setOpenedApp('muse');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 15. Jarvis Mark 54 VPS, Telegram Remote & Security Sentry (Video 5)
    if (
      p.includes('open jarvis mark 54') ||
      p.includes('vps') ||
      p.includes('24/7') ||
      p.includes('security sentry') ||
      p.includes('motion detection')
    ) {
      const badge = '🛡️ Jarvis Mark 54 VPS & Security Sentry';
      const reply = 'Opening Jarvis Mark 54 24/7 VPS daemon, Telegram remote control, and camera Security Sentry.';
      setMuseTab('mark54_vps');
      setOpenedApp('muse');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    // 16. Career / Security / Presentation
    if (p.includes('open career') || p.includes('job apply') || p.includes('career workflow')) {
      const badge = '💼 Career Workflows Agent Active';
      const reply = 'Opening autonomous career and job application workflows.';
      setOpenedApp('career');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    if (p.includes('open security') || p.includes('zero trust') || p.includes('telemetry dashboard')) {
      const badge = '🛡️ Zero-Trust Security Dashboard';
      const reply = 'Opening Zero-Trust security and OpenTelemetry observability.';
      setOpenedApp('security');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    if (p.includes('open presentation') || p.includes('open slides')) {
      const badge = '📊 Project Review Presentation';
      const reply = 'Opening project review presentation slides.';
      setOpenedApp('presentation');
      setLastActionBadge(badge);
      speakResponse(reply);
      return { matched: true, badgeText: badge, spokenReply: reply };
    }

    return { matched: false, badgeText: '', spokenReply: '', shouldAlsoAskGemini: true };
  };

  // Process User Utterance in Real Time
  const handleSendMessage = async (text: string, imageBase64?: string) => {
    if (isEmergencyStopped || !text.trim()) return;

    setIsProcessing(true);
    setAssistantState('evaluating');
    setLastExecutedCommand(text);

    const autoResult = executeRealtimeAutomations(text);

    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      imageUrl: imageBase64,
    };
    setMessages((prev) => [...prev, userMsg]);

    if (autoResult.matched && !autoResult.shouldAlsoAskGemini) {
      fetch('/api/system1/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: text }),
      })
        .then((r) => r.json())
        .then((d) => setLatestSystem1(d))
        .catch(() => {});

      setIsProcessing(false);
      const botMsg: ChatMessage = {
        id: `bot_${Date.now()}`,
        sender: 'hayat',
        text: autoResult.spokenReply || autoResult.badgeText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      };
      setMessages((prev) => [...prev, botMsg]);
      return;
    }

    try {
      const s1Res = await fetch('/api/system1/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: text }),
      });
      const s1Data: System1Decision = await s1Res.json();
      setLatestSystem1(s1Data);

      const chatRes = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: text,
          imageBase64,
          language,
          history: messages.slice(-6).map((m) => ({ sender: m.sender, text: m.text })),
        }),
      });
      const chatData = await chatRes.json();
      const reply = chatData.text || chatData.fallbackText || 'Here is the answer to your query, boss.';

      setLastActionBadge(`🧠 AI Answered (${chatData.engine || 'Gemini'} · ${s1Data.durationMs}ms S1)`);

      // If Google search is open on the phone, also update the Google result card with the real Gemini answer!
      setPhoneState((prev) =>
        prev.screen === 'google'
          ? {
              ...prev,
              googleQuery: text,
              googleResult: {
                title: `AI Knowledge Result: ${text.slice(0, 42)}`,
                temperature: 'LIVE',
                condition: 'Verified Answer',
                snippet: reply,
              },
            }
          : prev
      );

      const botMsg: ChatMessage = {
        id: `bot_${Date.now()}`,
        sender: 'hayat',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        system1Route: s1Data.route,
        system1Confidence: s1Data.confidence,
        durationMs: s1Data.durationMs,
      };

      setMessages((prev) => [...prev, botMsg]);
      speakResponse(reply);
    } catch (e: any) {
      const fallbackReply = 'I have processed your request through the local knowledge core, boss.';
      setMessages((prev) => [
        ...prev,
        {
          id: `bot_${Date.now()}`,
          sender: 'hayat',
          text: fallbackReply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        },
      ]);
      speakResponse(fallbackReply);
    } finally {
      setIsProcessing(false);
    }
  };

  const speakResponse = (text: string) => {
    if (isEmergencyStopped) return;
    setLastSpokenText(text);

    voiceControllerRef.current?.speak(
      text,
      'en',
      () => setAssistantState('speaking'),
      () => setAssistantState('idle')
    );
  };

  const handleAnalyzeVision = async (base64Image: string, customPrompt?: string): Promise<string> => {
    const prompt = customPrompt || 'What do you see through this Astra camera stream? Describe objects, text, and surroundings.';
    await handleSendMessage(prompt, base64Image);
    const lastMsg = messages[messages.length - 1];
    return lastMsg ? lastMsg.text : 'Astra vision processed.';
  };

  const handleExecuteADB = async (action: string, payload?: any) => {
    try {
      const res = await fetch('/api/adb/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, payload }),
      });
      return await res.json();
    } catch (err) {
      return { status: 'SIMULATED', action };
    }
  };

  const handleEvaluateSystem1 = async (prompt: string): Promise<System1Decision> => {
    const res = await fetch('/api/system1/evaluate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
    });
    return res.json();
  };

  const handleDeployCareerAgent = async (targetRole: string, targetCompany: string) => {
    const res = await fetch('/api/career/job-apply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role: targetRole, company: targetCompany }),
    });
    return res.json();
  };

  // Mark LIV FileDropZone handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadedFileName(`${file.name} (${Math.max(1, Math.round(file.size / 1024))} KB)`);
    setMuseTab('mark54_quiz_review');
    setOpenedApp('muse');
    setLastActionBadge(`📄 Loaded ${file.name} into Mark LIV Review Board`);
    speakResponse(`File ${file.name} loaded into Jarvis Mark 54 document review and quiz board.`);
  };

  // Mark LIV MetricBar helper (matching ui.py MetricBar lines 920-975)
  const renderMetricBar = (label: string, pct: number, color: string, valueText?: string) => (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-[10px] font-mono">
        <span className="text-[#5ab8cc] font-bold">{label}</span>
        <span style={{ color }} className="font-bold">
          {valueText || `${pct}%`}
        </span>
      </div>
      <div className="w-full h-2 bg-[#011520] border border-[#0d3347] rounded-sm overflow-hidden">
        <div
          className="h-full transition-all duration-500"
          style={{ width: `${pct}%`, backgroundColor: color }}
        />
      </div>
    </div>
  );

  // Render active sub-module inside Mark LIV center board or Pure Face overlay
  const renderActiveModule = () => {
    switch (openedApp) {
      case 'phone':
        return (
          <AndroidPhoneBridge
            onExecuteADB={handleExecuteADB}
            sharedState={phoneState}
            onStateChange={(s) => setPhoneState(s)}
            onClose={() => {
              setOpenedApp(null);
              voiceControllerRef.current?.stopPhoneRinging();
            }}
            activeVoiceHint={lastActionBadge}
            onSpeak={speakResponse}
          />
        );
      case 'hayat_mobile':
        return (
          <HayatMobileView
            onSpeak={(text) => speakResponse(text)}
            isSpeaking={assistantState === 'speaking'}
          />
        );
      case 'earth_hud':
        return (
          <JarvisHUDView
            onSpeak={(text, lang) => {
              setAssistantState('speaking');
              voiceControllerRef.current?.speak(
                text,
                (lang as LanguageCode) || 'en',
                () => setAssistantState('speaking'),
                () => setAssistantState('idle')
              );
            }}
            isSpeaking={assistantState === 'speaking'}
            onClose={() => setOpenedApp(null)}
          />
        );
      case 'astra_vision':
        return (
          <AstraVision
            onAnalyzeFrame={handleAnalyzeVision}
            isAnalyzing={isProcessing}
            onClose={() => setOpenedApp(null)}
          />
        );
      case 'system1':
        return <System1Inspector onEvaluate={handleEvaluateSystem1} />;
      case 'career':
        return <CareerWorkflows onDeployAgent={handleDeployCareerAgent} />;
      case 'security':
        return (
          <SecurityObservability
            isEmergencyStopped={isEmergencyStopped}
            onTriggerKillSwitch={toggleEmergencyStop}
            onResetKillSwitch={toggleEmergencyStop}
          />
        );
      case 'presentation':
        return <PresentationReview />;
      case 'muse':
      default:
        return (
          <MuseAgentView
            initialTab={museTab}
            activeGoal={museGoal}
            onSpeak={speakResponse}
            onClose={() => setOpenedApp(null)}
            onExecuteTranscript={(txt) => handleSendMessage(txt)}
          />
        );
    }
  };

  // ============================================================================
  // PURE FACE ONLY MODE (When user clicks "🎭 Pure Face Only" in header)
  // ============================================================================
  if (workspaceView === 'pure_face') {
    return (
      <div className="min-h-screen bg-[#00060a] text-[#8ffcff] flex flex-col relative font-sans">
        {/* Top Floating Switcher to return to Full Mark LIV HUD Cockpit */}
        <div className="absolute top-3 left-4 right-4 z-40 flex flex-wrap items-center justify-between gap-2 pointer-events-auto">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setWorkspaceView('mark_liv_cockpit')}
              className="px-3 py-1.5 rounded-lg bg-[#010d14]/90 hover:bg-[#001f2e] text-[#00d4ff] border border-[#1a5c7a] text-xs font-mono font-bold shadow-lg"
            >
              🖥️ OPEN FULL MARK LIV &amp; 5-VIDEO COCKPIT
            </button>
            <span className="text-[11px] font-mono text-[#5ab8cc] hidden sm:inline">
              {lastActionBadge}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {(['#00d4ff', '#00ff88', '#ff6b00', '#a855f7', '#ff3366'] as const).map((col) => (
              <button
                key={col}
                onClick={() => setAccentColor(col)}
                className={`w-4 h-4 rounded-full border ${
                  accentColor === col ? 'border-white scale-125' : 'border-transparent opacity-70'
                }`}
                style={{ backgroundColor: col }}
                title={`HueWheel Accent: ${col}`}
              />
            ))}
          </div>
        </div>

        {openedApp === null ? (
          <div className="relative w-full min-h-screen flex flex-col items-center justify-center overflow-hidden">
            <AvatarFace
              fullscreen={true}
              size={460}
              state={assistantState}
              isListening={isListening}
              isMuted={isMuted}
              language={language}
              interimSpeech={interimTranscript}
              actionText={lastActionBadge}
              spokenText={lastSpokenText}
              visualMode={visualMode}
              accentColor={accentColor}
              onChangeVisualMode={(m) => setVisualMode(m)}
              onToggleListening={toggleListening}
              onToggleMute={() => setIsMuted(!isMuted)}
              onChangeLanguage={(l) => setLanguage(l)}
              onTestVoice={handleTestAgentVoice}
              onWake={() => {
                if (!isListening) startHandsFreeListening();
                handleTestAgentVoice();
              }}
              showControls={true}
            />

            {/* Bottom Live AI Question & Answer Console + Quick Dock for all 5 Videos */}
            <div className="absolute bottom-3 left-4 right-4 z-30 max-w-4xl mx-auto space-y-2">
              {messages.length > 0 && lastExecutedCommand && (
                <div className="p-2.5 rounded-lg bg-[#010d14]/95 border border-[#1a5c7a] font-mono text-xs shadow-xl">
                  <div className="text-[#ffcc00] text-[11px]">
                    <span className="font-bold">YOU ASKED:</span> &ldquo;{lastExecutedCommand}&rdquo;
                  </div>
                  <div className="text-[#8ffcff] leading-relaxed mt-0.5">
                    <span className="text-[#00ff88] font-bold">HAYAT · MARK LIV: </span>
                    {messages[messages.length - 1]?.text}
                  </div>
                </div>
              )}

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!commandInput.trim()) return;
                  handleSendMessage(commandInput);
                  setCommandInput('');
                }}
                className="flex items-center gap-2 bg-[#010d14]/95 p-1.5 rounded-xl border border-[#1a5c7a]"
              >
                <input
                  type="text"
                  value={commandInput}
                  onChange={(e) => setCommandInput(e.target.value)}
                  placeholder='Speak or type ANY question ("What is quantum computing?") or voice command ("Call Mom", "Open Meta Muse")...'
                  className="flex-1 bg-[#00060a] border border-[#0d3347] focus:border-[#00d4ff] rounded-lg px-3 py-1.5 text-xs font-mono text-white placeholder-[#3a8a9a] focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-3.5 py-1.5 rounded-lg bg-[#00d4ff] hover:bg-cyan-300 text-[#00060a] font-mono text-xs font-bold"
                >
                  {isProcessing ? '...' : 'ASK / RUN ▸'}
                </button>
              </form>

              <div className="flex flex-wrap items-center justify-center gap-1.5">
                {QUICK_ACTIONS.slice(0, 10).map((qa, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(qa.prompt)}
                    className="px-2.5 py-1 rounded-md bg-[#010d14]/85 hover:bg-[#001f2e] border border-[#0d3347] hover:border-[#00d4ff] text-[10px] font-mono text-[#8ffcff] transition-all"
                  >
                    {qa.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="min-h-screen bg-[#00060a] pt-14 px-4 pb-6 flex flex-col max-w-7xl mx-auto w-full">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#0d3347]">
              <button
                onClick={() => {
                  setOpenedApp(null);
                  voiceControllerRef.current?.stopPhoneRinging();
                }}
                className="px-3.5 py-1.5 rounded-lg bg-[#001f2e] hover:bg-rose-950/60 text-[#00d4ff] hover:text-rose-300 border border-[#00d4ff]/50 text-xs font-mono font-bold"
              >
                ✕ RETURN TO PURE FACE [Or say &quot;Close&quot;]
              </button>
              <span className="text-xs font-mono text-[#00ff88]">{lastActionBadge}</span>
            </div>
            <div className="flex-1">{renderActiveModule()}</div>
          </div>
        )}
      </div>
    );
  }

  // ============================================================================
  // DEFAULT FULL MARK LIV HUD & 5-VIDEO COMMAND CENTER (ui.py MainWindow)
  // ============================================================================
  return (
    <div className="min-h-screen bg-[#00060a] text-[#8ffcff] flex flex-col font-sans select-none">
      {/* 1. MARK LIV HEADER BAR (ui.py _build_header) */}
      <header className="min-h-[56px] bg-[#000d14] border-b border-[#1a5c7a] px-4 py-2 flex flex-wrap items-center justify-between gap-3">
        {/* Left: MARK LIV Version + Settings Gear + HueWheel */}
        <div className="flex items-center gap-2.5">
          <span className="text-xs font-mono font-bold tracking-widest text-[#00d4ff] px-2 py-1 rounded bg-[#001f2e] border border-[#1a5c7a]">
            MARK LIV
          </span>
          <button
            onClick={() => setShowSettingsDrawer(!showSettingsDrawer)}
            className={`w-7 h-7 rounded flex items-center justify-center border font-mono text-sm transition-all ${
              showSettingsDrawer
                ? 'bg-[#001f2e] border-[#00d4ff] text-[#00d4ff]'
                : 'bg-transparent border-[#0d3347] text-[#5ab8cc] hover:text-[#00d4ff]'
            }`}
            title="Mark LIV Settings & HueWheel Customizer"
          >
            ⚙
          </button>

          {/* HueWheel Quick Accent Dots */}
          <div className="hidden sm:flex items-center gap-1.5 ml-1 px-2 py-1 rounded bg-[#010d14] border border-[#0d3347]">
            <span className="text-[9px] font-mono text-[#3a8a9a] mr-1">HUE:</span>
            {(['#00d4ff', '#00ff88', '#ff6b00', '#ffcc00', '#a855f7', '#ff3366'] as const).map(
              (col) => (
                <button
                  key={col}
                  onClick={() => setAccentColor(col)}
                  className={`w-3.5 h-3.5 rounded-full transition-transform ${
                    accentColor === col ? 'scale-125 ring-1 ring-white' : 'opacity-65 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: col }}
                  title={`Apply UI Accent ${col}`}
                />
              )
            )}
          </div>
        </div>

        {/* Center: Assistant Title & Subtitle (ui.py _title_lbl & _sub_lbl) */}
        <div className="flex flex-col items-center text-center">
          <h1
            className="font-mono text-base sm:text-lg font-bold tracking-[0.2em]"
            style={{ color: accentColor }}
          >
            HAYAT · J.A.R.V.I.S
          </h1>
          <span className="font-mono text-[10px] text-[#3a8a9a]">
            All 5 Videos Integrated · Multimodal Voice, ADB Phone, Jev System 1, Meta Muse &amp; Mark 54 HUD
          </span>
        </div>

        {/* Right: Digital Clock & Date + Pure Face Mode Toggle */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              setOpenedApp(null);
              setWorkspaceView('pure_face');
            }}
            className="px-2.5 py-1.5 rounded bg-[#001f2e] hover:bg-[#00d4ff] text-[#8ffcff] hover:text-[#00060a] border border-[#00d4ff]/50 text-[11px] font-mono font-bold transition-all"
            title="Switch to Pure Face Only screen"
          >
            🎭 PURE FACE MODE
          </button>

          <div className="text-right font-mono hidden md:block">
            <div className="text-sm font-bold" style={{ color: accentColor }}>
              {clockTime}
            </div>
            <div className="text-[9px] text-[#3a8a9a]">{clockDate}</div>
          </div>
        </div>
      </header>

      {/* 2. 5-VIDEO ARCHITECTURE NAVIGATION BAR (Immediate 1-Click Access to Every Video's Features) */}
      <nav className="bg-[#010d14] border-b border-[#0d3347] px-3 py-1.5 flex items-center gap-1.5 overflow-x-auto">
        {[
          {
            id: 'mark_liv_cockpit',
            label: '🖥️ 1. Mark LIV 3D HUD & All-in-One (Video 5)',
            onClick: () => setWorkspaceView('mark_liv_cockpit'),
          },
          {
            id: 'hayat_android',
            label: '📱 2. Hayat Android ADB & Anime (Video 1)',
            onClick: () => {
              setWorkspaceView('hayat_android');
              setOpenedApp('phone');
            },
          },
          {
            id: 'jev_system1',
            label: '⚡ 3. TypeSafe Jev AI System 1 (Video 2)',
            onClick: () => {
              setWorkspaceView('jev_system1');
              setOpenedApp('system1');
            },
          },
          {
            id: 'meta_muse',
            label: '✨ 4. Meta Muse VM & First Prompt (Videos 3 & 4)',
            onClick: () => {
              setWorkspaceView('meta_muse');
              setOpenedApp('muse');
            },
          },
          {
            id: 'earth_astra',
            label: '🌍 5. 3D Earth Globe & Astra Vision',
            onClick: () => {
              setWorkspaceView('earth_astra');
              setOpenedApp('earth_hud');
            },
          },
          {
            id: 'career_security',
            label: '🛡️ 6. Career Bot, Security & Slides',
            onClick: () => setWorkspaceView('career_security'),
          },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={tab.onClick}
            className={`px-3 py-1.5 rounded text-xs font-mono font-bold shrink-0 transition-all ${
              workspaceView === tab.id
                ? 'bg-[#00d4ff] text-[#00060a] shadow-[0_0_12px_rgba(0,212,255,0.35)]'
                : 'bg-[#00060a] text-[#5ab8cc] border border-[#0d3347] hover:border-[#1a5c7a] hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </nav>

      {/* Settings & HueWheel Drawer Overlay (if toggled via ⚙) */}
      {showSettingsDrawer && (
        <div className="bg-[#010f18] border-b border-[#1a5c7a] px-4 py-3 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
          <div className="flex flex-wrap items-center gap-4">
            <span className="text-[#00d4ff] font-bold">◈ MARK LIV QUICK SETTINGS:</span>
            <label className="flex items-center gap-2 text-[#8ffcff]">
              <span>Avatar Mode:</span>
              <select
                value={visualMode}
                onChange={(e) => setVisualMode(e.target.value as AvatarVisualMode)}
                className="bg-[#00060a] border border-[#1a5c7a] rounded px-2 py-1 text-xs text-[#00d4ff]"
              >
                <option value="hologram_head">3D Holographic Head (Mark 54)</option>
                <option value="hayat_anime">Hayat Anime Girl (Neon Labs)</option>
                <option value="reactor_core">Arc Reactor Core (Mark 54)</option>
                <option value="cyber_orb">Astra Cyber-Orb</option>
              </select>
            </label>

            <label className="flex items-center gap-2 text-[#8ffcff]">
              <span>Voice Recognition Lang:</span>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as LanguageCode)}
                className="bg-[#00060a] border border-[#1a5c7a] rounded px-2 py-1 text-xs text-[#00d4ff]"
              >
                <option value="en">English (Universal)</option>
                <option value="hi">Hindi (Hinglish / हिंदी)</option>
                <option value="ta">Tamil (தமிழ்)</option>
                <option value="es">Spanish</option>
                <option value="fr">French</option>
                <option value="de">German</option>
                <option value="ar">Arabic</option>
              </select>
            </label>
          </div>

          <button
            onClick={() => setShowSettingsDrawer(false)}
            className="text-slate-400 hover:text-white"
          >
            ✕ Close Drawer
          </button>
        </div>
      )}

      {/* 3. MAIN BODY CONTENT */}
      {workspaceView === 'mark_liv_cockpit' && (
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 min-h-[calc(100vh-140px)]">
          {/* LEFT COLUMN: MARK LIV ◈ SYS MONITOR (ui.py _build_left_panel) */}
          <aside className="lg:col-span-2 bg-[#000d14] border-r border-[#0d3347] p-3 flex flex-col justify-between gap-4">
            <div className="space-y-3">
              <div className="text-[11px] font-mono font-bold text-[#00d4ff] border-b border-[#0d3347] pb-1.5">
                ◈ SYS MONITOR
              </div>

              {renderMetricBar('CPU', sysMetrics.cpu, accentColor)}
              {renderMetricBar('MEM', sysMetrics.mem, '#ffcc00')}
              {renderMetricBar('NET', sysMetrics.net, '#00ff88')}
              {renderMetricBar('GPU', sysMetrics.gpu, '#ff6b00')}
              {renderMetricBar('TMP', sysMetrics.tmp, '#ff6688', `${sysMetrics.tmp}°C`)}

              {/* Uptime / Process / OS Box */}
              <div className="p-2.5 rounded bg-[#010f18] border border-[#0d3347] space-y-1 font-mono text-[11px]">
                <div className="text-[#00ff88] font-bold">{uptimeStr}</div>
                <div className="text-[#5ab8cc]">PROC  {sysMetrics.procs}</div>
                <div className="text-[#ffcc00]">OS    LINUX / ADB</div>
                <div className="text-emerald-300">BAT   {phoneState.battery}% (CHG)</div>
              </div>

              {/* 5-Video Sub-Module Switcher inside Center Board */}
              <div className="pt-2 space-y-1.5">
                <div className="text-[10px] font-mono font-bold text-[#5ab8cc] uppercase">
                  ▸ ACTIVE BOARD PANEL
                </div>
                {[
                  { id: 'muse', label: '✨ Meta Muse & First Prompt' },
                  { id: 'phone', label: '📱 Android ADB Phone Bridge' },
                  { id: 'hayat_mobile', label: '🌸 Hayat Anime Companion' },
                  { id: 'system1', label: '⚡ TypeSafe Jev System 1' },
                  { id: 'earth_hud', label: '🌍 3D Earth & Satellite HUD' },
                  { id: 'astra_vision', label: '👁️ Project Astra Camera' },
                  { id: 'presentation', label: '📊 Review Slides Deck' },
                ].map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setOpenedApp(m.id as any)}
                    className={`w-full text-left px-2.5 py-1.5 rounded font-mono text-[11px] border transition-all ${
                      openedApp === m.id
                        ? 'bg-[#001f2e] border-[#00d4ff] text-[#8ffcff] font-bold'
                        : 'bg-[#010d14] border-[#0d3347] text-[#5ab8cc] hover:text-white'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Bottom Protocol Status Badges (ui.py lines 3710-3724) */}
            <div className="space-y-1.5 font-mono text-[10px] font-bold text-center">
              <div className="p-1.5 rounded bg-[#010f18] border border-[#0f4060] text-[#00ff88]">
                AI CORE · ACTIVE
              </div>
              <div className="p-1.5 rounded bg-[#010f18] border border-[#0f4060] text-[#00d4ff]">
                SEC · CLEARED
              </div>
              <div className="p-1.5 rounded bg-[#010f18] border border-[#0f4060] text-[#3a8a9a]">
                PROTOCOL · LIV
              </div>
            </div>
          </aside>

          {/* CENTER COLUMN: HUD CANVAS + LIVE AI ANSWER CONSOLE + RESIZABLE CONTENT/MODULE PANEL (ui.py _center_split) */}
          <main className="lg:col-span-7 bg-[#00060a] flex flex-col justify-between p-3 gap-3 overflow-y-auto">
            {/* Top Center: 3D Holographic Head / Hayat Anime / Reactor Core Canvas */}
            <AvatarFace
              fullscreen={false}
              size={360}
              state={assistantState}
              isListening={isListening}
              isMuted={isMuted}
              language={language}
              interimSpeech={interimTranscript}
              actionText={lastActionBadge}
              spokenText={lastSpokenText}
              visualMode={visualMode}
              accentColor={accentColor}
              onChangeVisualMode={(m) => setVisualMode(m)}
              onToggleListening={toggleListening}
              onToggleMute={() => setIsMuted(!isMuted)}
              onChangeLanguage={(l) => setLanguage(l)}
              onTestVoice={handleTestAgentVoice}
            />

            {/* Prominent Center "Ask Any Question / Execute Any Command" & Live AI Answer Box */}
            <div className="rounded-xl bg-[#010f18] border border-[#1a5c7a] p-3.5 space-y-2.5 shadow-lg">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#00d4ff]" />
                  <span className="text-xs font-mono font-bold text-[#00d4ff] tracking-wider uppercase">
                    REAL-TIME UNIFIED AI AGENT (ALL 6 VIDEOS COMBINED) · VOICE &amp; TEXT LIVE
                  </span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/80 text-[#00ff88] border border-emerald-500/40">
                  {isProcessing ? '⚡ Executing in Real Time...' : '● Live Google + Music + Social + Gemini Online'}
                </span>
              </div>

              {/* Video 6 (BitBiasedAI) + Video 2 (Jev System 1) + Video 1-5 Live Status Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-[10px] font-mono">
                <div className="p-1.5 rounded bg-[#00060a] border border-[#0d3347]">
                  <span className="text-slate-400 block text-[9px]">VIDEO 1 · PHONE &amp; MUSIC</span>
                  <span className="text-[#00ff88] font-bold truncate block">
                    {phoneState.screen.toUpperCase()} · {phoneState.youtubeSong?.title?.slice(0, 18) || 'Ready'}
                  </span>
                </div>
                <div className="p-1.5 rounded bg-[#00060a] border border-[#0d3347]">
                  <span className="text-slate-400 block text-[9px]">VIDEO 2 · JEV SYSTEM 1</span>
                  <span className="text-[#00d4ff] font-bold truncate block">
                    {latestSystem1 ? `${latestSystem1.route} (${latestSystem1.durationMs}ms)` : 'Sub-45ms Ready'}
                  </span>
                </div>
                <div className="p-1.5 rounded bg-[#00060a] border border-[#0d3347]">
                  <span className="text-slate-400 block text-[9px]">VIDEO 3/4/5 · MUSE &amp; LIV</span>
                  <span className="text-purple-300 font-bold truncate block">
                    VM + 3D Head Lip-Sync
                  </span>
                </div>
                <div className="p-1.5 rounded bg-[#00060a] border border-[#0d3347]">
                  <span className="text-slate-400 block text-[9px]">VIDEO 6 · SOL VS ASTRA</span>
                  <span className="text-amber-300 font-bold truncate block">
                    {latestSystem1?.selectedTier || 'GPT-6 Sol (5x Cheaper)'}
                  </span>
                </div>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!commandInput.trim()) return;
                  handleSendMessage(commandInput);
                  setCommandInput('');
                }}
                className="flex items-center gap-2"
              >
                <input
                  type="text"
                  value={commandInput}
                  onChange={(e) => setCommandInput(e.target.value)}
                  placeholder='Say or type: "Play Manasellam Mazhai", "Open Google and type what is the current trending", "Call Mom", "Send Gmail"...'
                  className="flex-1 bg-[#00060a] border border-[#1a5c7a] focus:border-[#00d4ff] rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-[#3a8a9a] focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-4 py-2 rounded-lg bg-[#00d4ff] hover:bg-cyan-300 disabled:opacity-50 text-[#00060a] font-mono text-xs font-bold shrink-0 transition-all"
                >
                  {isProcessing ? '...' : 'EXECUTE LIVE ▸'}
                </button>
              </form>

              {/* Instant 1-Click Real-Time Demo Triggers */}
              <div className="flex flex-wrap items-center gap-1.5">
                {QUICK_ACTIONS.slice(0, 8).map((qa, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(qa.prompt)}
                    className="px-2 py-1 rounded bg-[#001824] hover:bg-[#002b40] border border-[#1a5c7a] text-[10px] font-mono text-[#8ffcff] transition-all"
                  >
                    {qa.label}
                  </button>
                ))}
              </div>

              {/* Latest Question & AI Answer Display */}
              {messages.length > 0 && (
                <div className="p-2.5 rounded-lg bg-[#00060a]/90 border border-[#0d3347] space-y-1 font-mono text-xs">
                  {lastExecutedCommand && (
                    <div className="text-[#ffcc00] text-[11px] flex items-center justify-between">
                      <span>
                        <span className="font-bold">LIVE COMMAND / QUERY:</span> &ldquo;{lastExecutedCommand}&rdquo;
                      </span>
                      {latestSystem1?.estimatedTaskPrice && (
                        <span className="text-[9px] text-amber-300">
                          {latestSystem1.estimatedTaskPrice}
                        </span>
                      )}
                    </div>
                  )}
                  <div className="text-[#8ffcff] leading-relaxed">
                    <span className="text-[#00ff88] font-bold">HAYAT · MARK LIV: </span>
                    {messages[messages.length - 1]?.text}
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Center: Active Interactive Module from the 5 Videos */}
            <div className="flex-1">{renderActiveModule()}</div>
          </main>

          {/* RIGHT COLUMN: ACTIVITY LOG + FILE UPLOAD + COMMAND INPUT + INTERRUPT (ui.py _build_right_panel) */}
          <aside className="lg:col-span-3 bg-[#000d14] border-l border-[#0d3347] p-3 flex flex-col justify-between gap-3">
            {/* 1. ACTIVITY LOG */}
            <div className="flex-1 flex flex-col min-h-[220px]">
              <div className="flex items-center justify-between text-[11px] font-mono font-bold text-[#5ab8cc] mb-1.5">
                <span>▸ ACTIVITY LOG</span>
                <span className="text-[10px] text-[#00ff88]">LIVE STREAM</span>
              </div>
              <div className="flex-1 bg-[#010d14] border border-[#0d3347] rounded p-2.5 overflow-y-auto space-y-2 font-mono text-[11px] max-h-[290px]">
                {messages.slice(-12).map((m) => (
                  <div key={m.id} className="leading-snug">
                    <span className="text-[#3a8a9a] mr-1.5">[{m.timestamp}]</span>
                    <span
                      className={
                        m.sender === 'user'
                          ? 'text-[#ffcc00] font-bold'
                          : m.sender === 'system'
                          ? 'text-[#00ff88]'
                          : 'text-[#8ffcff]'
                      }
                    >
                      {m.sender === 'user' ? 'YOU: ' : m.sender === 'hayat' ? 'HAYAT: ' : ''}
                      {m.text}
                    </span>
                  </div>
                ))}
                {interimTranscript && (
                  <div className="text-[#ffcc00] animate-pulse">
                    🗣️ Hearing: &quot;{interimTranscript}&quot;
                  </div>
                )}
              </div>
            </div>

            {/* 2. FILE UPLOAD DROPZONE (ui.py FileDropZone) */}
            <div className="space-y-1.5 border-t border-[#0d3347] pt-2.5">
              <div className="text-[11px] font-mono font-bold text-[#5ab8cc]">▸ FILE UPLOAD (REVIEW &amp; QUIZ)</div>
              <input
                ref={fileInputRef}
                type="file"
                onChange={handleFileUpload}
                className="hidden"
              />
              <div
                onClick={() => fileInputRef.current?.click()}
                className="p-3 rounded bg-[#010f18] hover:bg-[#001f2e] border border-dashed border-[#1a5c7a] hover:border-[#00d4ff] cursor-pointer text-center transition-all"
              >
                <Upload className="w-4 h-4 text-[#00d4ff] mx-auto mb-1" />
                <div className="text-[11px] font-mono text-[#8ffcff]">
                  {uploadedFileName || 'Drop file or click to upload for Mark LIV Review'}
                </div>
              </div>
            </div>

            {/* 3. SMART CLIPBOARD PANEL (ui.py ClipboardPanel) */}
            <div className="space-y-1.5 border-t border-[#0d3347] pt-2.5">
              <div className="text-[11px] font-mono font-bold text-[#5ab8cc]">▸ CLIPBOARD QUICK ACTIONS</div>
              <div className="grid grid-cols-4 gap-1 font-mono text-[10px]">
                {(['Summarize', 'Explain', 'Translate', 'Fix Code'] as const).map((act) => (
                  <button
                    key={act}
                    onClick={() =>
                      handleSendMessage(`${act} current workspace context via Mark LIV`)
                    }
                    className="py-1 px-1.5 rounded bg-[#010f18] hover:bg-[#001f2e] border border-[#0d3347] hover:border-[#00d4ff] text-[#8ffcff]"
                  >
                    {act}
                  </button>
                ))}
              </div>
            </div>

            {/* 4. COMMAND INPUT + VOICE TRIGGER CHIPS + INTERRUPT [ESC] */}
            <div className="space-y-2 border-t border-[#0d3347] pt-2.5">
              <div className="text-[11px] font-mono font-bold text-[#5ab8cc]">▸ COMMAND INPUT</div>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!commandInput.trim()) return;
                  handleSendMessage(commandInput);
                  setCommandInput('');
                }}
                className="flex items-center gap-1.5"
              >
                <input
                  type="text"
                  value={commandInput}
                  onChange={(e) => setCommandInput(e.target.value)}
                  placeholder="Speak or type command..."
                  className="flex-1 bg-[#00060a] border border-[#1a5c7a] rounded px-2.5 py-2 text-xs font-mono text-[#8ffcff] focus:outline-none focus:border-[#00d4ff]"
                />
                <button
                  type="submit"
                  className="px-3 py-2 rounded bg-[#00d4ff] hover:bg-cyan-300 text-[#00060a] font-mono text-xs font-bold"
                >
                  ▸
                </button>
              </form>

              {/* Scrollable Quick Voice Chips */}
              <div className="flex items-center gap-1 overflow-x-auto pb-1">
                {QUICK_ACTIONS.map((qa, i) => (
                  <button
                    key={i}
                    onClick={() => handleSendMessage(qa.prompt)}
                    className="shrink-0 px-2 py-1 rounded bg-[#010f18] hover:bg-[#001f2e] border border-[#0d3347] hover:border-[#00d4ff] text-[10px] font-mono text-[#8ffcff]"
                  >
                    {qa.label}
                  </button>
                ))}
              </div>

              {/* Mark LIV Interrupt Button [ESC] */}
              <button
                onClick={handleInterrupt}
                className="w-full py-2 rounded bg-[#140008] hover:bg-rose-950 text-[#ff3366] border border-[#ff3366] font-mono text-xs font-bold tracking-wider transition-all"
              >
                ✋  INTERRUPT  [ESC]
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* TAB 2: VIDEO 1 — HAYAT ANDROID ADB BRIDGE + INTERACTIVE ANIME COMPANION */}
      {workspaceView === 'hayat_android' && (
        <div className="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto w-full">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <AndroidPhoneBridge
              onExecuteADB={handleExecuteADB}
              sharedState={phoneState}
              onStateChange={(s) => setPhoneState(s)}
              activeVoiceHint={lastActionBadge}
            />
            <HayatMobileView
              onSpeak={(text) => speakResponse(text)}
              isSpeaking={assistantState === 'speaking'}
            />
          </div>
        </div>
      )}

      {/* TAB 3: VIDEO 2 — TYPESAFE JEV AI SYSTEM 1 NON-AUTOREGRESSIVE ROUTER */}
      {workspaceView === 'jev_system1' && (
        <div className="p-4 sm:p-6 max-w-7xl mx-auto w-full space-y-6">
          <System1Inspector onEvaluate={handleEvaluateSystem1} />
          <TerminalRepl
            messages={messages}
            onSendMessage={async (t) => {
              await handleSendMessage(t);
            }}
            onClearHistory={() => setMessages([])}
            onSpeakText={speakResponse}
            isProcessing={isProcessing}
          />
        </div>
      )}

      {/* TAB 4: VIDEOS 3 & 4 — META MUSE PERSONAL VM & ALERIC HECK FIRST PROMPT */}
      {workspaceView === 'meta_muse' && (
        <div className="p-4 sm:p-6 max-w-7xl mx-auto w-full">
          <MuseAgentView
            initialTab={museTab}
            activeGoal={museGoal}
            onSpeak={speakResponse}
            onExecuteTranscript={(txt) => handleSendMessage(txt)}
          />
        </div>
      )}

      {/* TAB 5: 3D EARTH HOLOGRAM & PROJECT ASTRA CAMERA VISION */}
      {workspaceView === 'earth_astra' && (
        <div className="p-4 sm:p-6 max-w-7xl mx-auto w-full space-y-6">
          <JarvisHUDView
            onSpeak={(text, lang) => {
              setAssistantState('speaking');
              voiceControllerRef.current?.speak(
                text,
                (lang as LanguageCode) || 'en',
                () => setAssistantState('speaking'),
                () => setAssistantState('idle')
              );
            }}
            isSpeaking={assistantState === 'speaking'}
          />
          <AstraVision
            onAnalyzeFrame={handleAnalyzeVision}
            isAnalyzing={isProcessing}
          />
        </div>
      )}

      {/* TAB 6: CAREER BOT, ZERO-TRUST SECURITY & PROJECT PRESENTATION SLIDES */}
      {workspaceView === 'career_security' && (
        <div className="p-4 sm:p-6 max-w-7xl mx-auto w-full space-y-6">
          <PresentationReview />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <CareerWorkflows onDeployAgent={handleDeployCareerAgent} />
            <SecurityObservability
              isEmergencyStopped={isEmergencyStopped}
              onTriggerKillSwitch={toggleEmergencyStop}
              onResetKillSwitch={toggleEmergencyStop}
            />
          </div>
        </div>
      )}

      {/* 4. MARK LIV FOOTER BAR */}
      <footer className="h-7 bg-[#000d14] border-t border-[#0d3347] px-4 flex items-center justify-between text-[10px] font-mono text-[#3a8a9a]">
        <div className="flex items-center gap-3">
          <span className="text-[#00ff88]">● MIC: {isListening ? 'HANDS-FREE ACTIVE' : 'STANDBY'}</span>
          <span>SYS1: TYPESAFE JEV (&lt;45ms)</span>
          <span>SYS2: GEMINI 3.8 FLASH</span>
        </div>
        <div>
          SHORTCUTS: [CTRL+SPACE] PUSH-TO-TALK · [F4] MUTE · [ESC] INTERRUPT · [CTRL+SHIFT+K] KILL SWITCH
        </div>
      </footer>
    </div>
  );
}
