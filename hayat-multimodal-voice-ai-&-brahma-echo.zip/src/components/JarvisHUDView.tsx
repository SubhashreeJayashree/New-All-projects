import React, { useState, useEffect, useRef } from 'react';
import {
  Globe,
  Satellite,
  Activity,
  RotateCw,
  ZoomIn,
  ZoomOut,
  Compass,
  Radio,
  Volume2,
  Mic,
  Maximize2,
  Wind,
  Thermometer,
  Shield,
  Layers,
  ChevronRight,
} from 'lucide-react';

interface JarvisHUDViewProps {
  onSpeak: (text: string, language?: string) => void;
  isSpeaking: boolean;
  onClose?: () => void;
}

export const JarvisHUDView: React.FC<JarvisHUDViewProps> = ({ onSpeak, isSpeaking, onClose }) => {
  const [viewState, setViewState] = useState<'globe' | 'satellite'>('globe');
  const [showEarthquakes, setShowEarthquakes] = useState(true);
  const [zoomLevel, setZoomLevel] = useState(1.0);
  const [autoSpin, setAutoSpin] = useState(true);
  const [activeSpeechText, setActiveSpeechText] = useState(
    "I've put the Earth on your display, sir, and you can spin or zoom into it as you like."
  );

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const yawRef = useRef(0.85); // centered on Americas as in Video 2
  const pitchRef = useRef(0.28);
  const isDraggingRef = useRef(false);
  const lastMousePosRef = useRef({ x: 0, y: 0 });

  // 1. Voice Command 1: "Hey Jarvis, just show me the Earth."
  const handleShowEarth = () => {
    setViewState('globe');
    setZoomLevel(1.0);
    const speech = "I've put the Earth on your display, sir, and you can spin or zoom into it as you like.";
    setActiveSpeechText(speech);
    onSpeak(speech, 'en');
  };

  // 2. Voice Command 2: "Alright Jarvis, just change the satellite view."
  const handleSatelliteView = () => {
    setViewState('satellite');
    setZoomLevel(1.35);
    const speech = 'The satellite view is now active, sir.';
    setActiveSpeechText(speech);
    onSpeak(speech, 'en');
  };

  // 3. Voice Command 3: "And also Jarvis, show the earthquakes that happened in this area."
  const handleShowEarthquakes = () => {
    setShowEarthquakes(true);
    const speech = 'There have been no recent earthquakes in this area, sir.';
    setActiveSpeechText(speech);
    onSpeak(speech, 'en');
  };

  // Canvas 3D Globe with Exact Video 2 Features (Trajectory Arc, Glowing Atmospheric Haze, Satellite Track)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const w = canvas.width;
      const h = canvas.height;
      const cx = w / 2;
      const cy = h / 2;
      const radius = 145 * zoomLevel;

      ctx.clearRect(0, 0, w, h);

      if (autoSpin && !isDraggingRef.current) {
        yawRef.current += 0.002;
      }

      const yaw = yawRef.current;
      const pitch = pitchRef.current;

      // Project 3D sphere coordinate
      const project = (latDeg: number, lngDeg: number, rOffset = 1.0) => {
        const phi = (latDeg * Math.PI) / 180;
        const theta = (lngDeg * Math.PI) / 180 + yaw;

        let x = Math.cos(phi) * Math.sin(theta);
        let y = -Math.sin(phi);
        let z = Math.cos(phi) * Math.cos(theta);

        const y2 = y * Math.cos(pitch) - z * Math.sin(pitch);
        const z2 = y * Math.sin(pitch) + z * Math.cos(pitch);

        return {
          px: cx + x * radius * rOffset,
          py: cy + y2 * radius * rOffset,
          visible: z2 > -0.05,
          z: z2,
        };
      };

      // 1. Atmosphere Cyan Glow (Matching Video 2)
      const atmoGrad = ctx.createRadialGradient(cx, cy, radius * 0.9, cx, cy, radius * 1.35);
      atmoGrad.addColorStop(
        0,
        viewState === 'satellite' ? 'rgba(56, 189, 248, 0.35)' : 'rgba(6, 182, 212, 0.4)'
      );
      atmoGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = atmoGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, radius * 1.35, 0, Math.PI * 2);
      ctx.fill();

      // 2. Planet Sphere Background
      const sphereGrad = ctx.createRadialGradient(
        cx - radius * 0.35,
        cy - radius * 0.35,
        radius * 0.1,
        cx,
        cy,
        radius
      );
      if (viewState === 'satellite') {
        sphereGrad.addColorStop(0, '#0c2238');
        sphereGrad.addColorStop(0.5, '#051221');
        sphereGrad.addColorStop(1, '#02070f');
      } else {
        sphereGrad.addColorStop(0, '#0284c7');
        sphereGrad.addColorStop(0.4, '#0369a1');
        sphereGrad.addColorStop(1, '#082f49');
      }

      ctx.fillStyle = sphereGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.fill();

      // Sharp Cyan Atmosphere Rim
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.stroke();

      // 3. Stylized North America & Continental Outlines (Centered on US as in Video 2)
      const northAmericaCoords = [
        { lat: 58, lng: -125 },
        { lat: 50, lng: -85 },
        { lat: 46, lng: -70 },
        { lat: 40, lng: -73 }, // New York
        { lat: 38, lng: -80 }, // West Virginia
        { lat: 30, lng: -82 }, // Florida
        { lat: 26, lng: -97 }, // Texas / Gulf
        { lat: 20, lng: -105 }, // Mexico
        { lat: 34, lng: -120 }, // California
        { lat: 48, lng: -124 }, // Washington
      ];

      ctx.fillStyle = viewState === 'satellite' ? 'rgba(34, 197, 94, 0.3)' : 'rgba(125, 211, 252, 0.45)';
      ctx.beginPath();
      let started = false;
      for (const pt of northAmericaCoords) {
        const pr = project(pt.lat, pt.lng);
        if (pr.visible) {
          if (!started) {
            ctx.moveTo(pr.px, pr.py);
            started = true;
          } else {
            ctx.lineTo(pr.px, pr.py);
          }
        }
      }
      if (started) {
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#e0f2fe';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }

      // South America outline
      const southAmericaCoords = [
        { lat: 10, lng: -75 },
        { lat: -5, lng: -35 },
        { lat: -23, lng: -43 },
        { lat: -54, lng: -68 },
        { lat: -18, lng: -70 },
      ];
      ctx.beginPath();
      started = false;
      for (const pt of southAmericaCoords) {
        const pr = project(pt.lat, pt.lng);
        if (pr.visible) {
          if (!started) {
            ctx.moveTo(pr.px, pr.py);
            started = true;
          } else {
            ctx.lineTo(pr.px, pr.py);
          }
        }
      }
      if (started) {
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }

      // 4. White Diagonal Trajectory Arc (Exact match to Video 2 crossing New York & Atlantic)
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2.2;
      ctx.setLineDash([8, 6]);
      ctx.beginPath();
      let firstArc = true;
      for (let lng = -160; lng <= 20; lng += 4) {
        // Curve formula crossing Americas
        const lat = 60 - (lng + 160) * 0.55;
        const pr = project(lat, lng, 1.05);
        if (pr.visible) {
          if (firstArc) {
            ctx.moveTo(pr.px, pr.py);
            firstArc = false;
          } else {
            ctx.lineTo(pr.px, pr.py);
          }
        }
      }
      ctx.stroke();
      ctx.setLineDash([]);

      // 5. Glowing City Pins (Orange Nodes as in Video 2)
      const pins = [
        { name: 'New York', lat: 40.71, lng: -74.0 },
        { name: 'West Virginia', lat: 38.59, lng: -80.45 },
        { name: 'California', lat: 36.77, lng: -119.41 },
        { name: 'Atlantic Node', lat: 18.0, lng: -45.0 },
        { name: 'Bogota', lat: 4.71, lng: -74.07 },
      ];

      for (const pin of pins) {
        const pr = project(pin.lat, pin.lng);
        if (pr.visible) {
          // Orange circular halo
          ctx.beginPath();
          ctx.arc(pr.px, pr.py, 7, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(249, 115, 22, 0.35)';
          ctx.fill();

          // Orange central dot
          ctx.beginPath();
          ctx.arc(pr.px, pr.py, 3.5, 0, Math.PI * 2);
          ctx.fillStyle = '#f97316';
          ctx.fill();

          // White text label
          ctx.fillStyle = '#ffffff';
          ctx.font = '10px monospace';
          ctx.fillText(pin.name, pr.px + 8, pr.py - 2);
        }
      }

      // 6. Orbital Satellite Rings (Surrounding Earth)
      const satTime = Date.now() * 0.001;
      ctx.strokeStyle = 'rgba(234, 179, 8, 0.4)';
      ctx.lineWidth = 1.2;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      for (let a = 0; a <= Math.PI * 2; a += 0.1) {
        const sx = cx + Math.cos(a) * (radius * 1.35);
        const sy = cy + Math.sin(a) * (radius * 0.55);
        if (a === 0) ctx.moveTo(sx, sy);
        else ctx.lineTo(sx, sy);
      }
      ctx.stroke();
      ctx.setLineDash([]);

      // Satellite Orbiter
      const satX = cx + Math.cos(satTime) * (radius * 1.35);
      const satY = cy + Math.sin(satTime) * (radius * 0.55);
      ctx.fillStyle = '#facc15';
      ctx.fillRect(satX - 3.5, satY - 3.5, 7, 7);

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [viewState, showEarthquakes, zoomLevel, autoSpin]);

  // Drag interaction
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    isDraggingRef.current = true;
    lastMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDraggingRef.current) return;
    const dx = e.clientX - lastMousePosRef.current.x;
    const dy = e.clientY - lastMousePosRef.current.y;

    yawRef.current += dx * 0.007;
    pitchRef.current = Math.max(-1.1, Math.min(1.1, pitchRef.current + dy * 0.007));

    lastMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  return (
    <div className="flex flex-col p-5 bg-[#050811] rounded-2xl border border-cyan-500/30 backdrop-blur-2xl shadow-2xl relative overflow-hidden">
      {/* Top Cockpit Telemetry Bar (Exact Video 2 Layout) */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-cyan-500/20 mb-4 font-mono text-xs text-cyan-300">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-cyan-400 animate-ping" />
          <span className="font-bold tracking-widest text-sm text-white">J.A.R.V.I.S. 1.5</span>
          <span className="text-slate-500">·</span>
          <span>22:40 UTC+02:00</span>
          <span className="text-slate-500">·</span>
          <span className="text-amber-400 font-semibold">United States</span>
        </div>

        <div className="flex items-center gap-3 text-[11px] text-slate-300">
          <span className="flex items-center gap-1">
            <Thermometer className="w-3.5 h-3.5 text-cyan-400" />
            16.4°C
          </span>
          <span className="flex items-center gap-1">
            <Wind className="w-3.5 h-3.5 text-cyan-400" />
            150 km/h Wind
          </span>
          <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
            {isSpeaking ? 'SPEAKING' : 'ONLINE'}
          </span>
          {onClose && (
            <button
              onClick={onClose}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-rose-500/30 text-slate-300 hover:text-rose-300 border border-slate-700 hover:border-rose-500/50 transition-colors text-xs font-semibold"
              title="Close view and return to Hayat face"
            >
              ✕ CLOSE
            </button>
          )}
        </div>
      </div>

      {/* Main 3D Canvas Screen */}
      <div className="relative w-full aspect-[16/9] min-h-[420px] bg-[#02040a] rounded-xl border border-cyan-500/30 overflow-hidden flex items-center justify-center shadow-inner">
        {/* Top-Right Location Card (Matching Video 2) */}
        <div className="absolute top-4 right-4 z-10 p-3 bg-slate-900/90 border border-cyan-500/40 rounded-xl text-xs font-mono text-slate-200 backdrop-blur shadow-2xl">
          <div className="text-cyan-400 font-bold text-sm mb-1">West Virginia</div>
          <div className="text-[10px] text-slate-400">18:40 UTC-04:00</div>
          <div className="text-[10px] text-emerald-400 mt-1">16.4°C · Wind 150 km/h</div>
          <div className="text-[9px] text-slate-500 mt-0.5">LAT: 38.59, LON: -80.45</div>
        </div>

        {/* Top-Left View Mode Tag */}
        <div className="absolute top-4 left-4 z-10 flex items-center gap-2">
          <span className="px-3 py-1 bg-slate-900/90 border border-cyan-500/50 rounded-lg text-xs font-mono font-bold text-cyan-300">
            MODE: {viewState.toUpperCase()}
          </span>
          {showEarthquakes && (
            <span className="px-2.5 py-1 bg-rose-500/20 border border-rose-500/40 rounded-lg text-xs font-mono text-rose-300">
              SEISMIC SCAN: ACTIVE
            </span>
          )}
        </div>

        {/* 3D Earth Canvas */}
        <canvas
          ref={canvasRef}
          width={640}
          height={420}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          className="cursor-grab active:cursor-grabbing max-w-full drop-shadow-2xl"
        />

        {/* Bottom Speech Subtitle (From Video 2) */}
        <div className="absolute bottom-4 left-4 right-4 z-10 flex items-center justify-between text-xs font-mono">
          <div className="p-2.5 bg-slate-900/90 border border-cyan-500/30 rounded-xl text-cyan-200 italic shadow">
            &quot;{activeSpeechText}&quot;
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-slate-900/80 rounded-lg border border-slate-800">
            <button
              onClick={() => setAutoSpin(!autoSpin)}
              title="Auto Spin"
              className={`p-1.5 rounded ${autoSpin ? 'text-cyan-400' : 'text-slate-500'}`}
            >
              <RotateCw className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel((z) => Math.max(0.8, z - 0.2))}
              title="Zoom Out"
              className="p-1.5 rounded text-slate-300 hover:text-white"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel((z) => Math.min(1.6, z + 0.2))}
              title="Zoom In"
              className="p-1.5 rounded text-slate-300 hover:text-white"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* BOTTOM COCKPIT: Glowing Audio Speakers & Video 2 Voice Triggers */}
      <div className="mt-5 pt-4 border-t border-cyan-500/20 flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Left Glowing Neon Orb Speaker (From Video 2 Desk) */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-14 h-14 rounded-full bg-slate-950 border-2 border-emerald-400 shadow-lg shadow-emerald-500/40 flex items-center justify-center relative">
            <div className="w-8 h-8 rounded-full bg-emerald-500/30 animate-ping absolute" />
            <div className="w-6 h-6 rounded-full bg-emerald-400 shadow-inner" />
          </div>
          <div className="font-mono text-xs">
            <span className="text-emerald-400 font-bold block">LEFT ACOUSTIC ORB</span>
            <span className="text-slate-500 text-[10px]">Neon Green Active</span>
          </div>
        </div>

        {/* Video 2 Interactive Voice Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-2.5">
          <button
            onClick={handleShowEarth}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-mono font-bold text-xs rounded-xl shadow-lg shadow-cyan-600/25 transition-all"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>&quot;Show me the Earth&quot;</span>
          </button>

          <button
            onClick={handleSatelliteView}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-mono font-bold text-xs rounded-xl shadow-lg shadow-amber-600/25 transition-all"
          >
            <Satellite className="w-3.5 h-3.5" />
            <span>&quot;Change to satellite view&quot;</span>
          </button>

          <button
            onClick={handleShowEarthquakes}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white font-mono font-bold text-xs rounded-xl shadow-lg shadow-rose-600/25 transition-all"
          >
            <Activity className="w-3.5 h-3.5" />
            <span>&quot;Show earthquakes here&quot;</span>
          </button>
        </div>

        {/* Right Glowing Neon Orb Speaker (From Video 2 Desk) */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="font-mono text-xs text-right">
            <span className="text-purple-400 font-bold block">RIGHT ACOUSTIC ORB</span>
            <span className="text-slate-500 text-[10px]">Neon Purple Active</span>
          </div>
          <div className="w-14 h-14 rounded-full bg-slate-950 border-2 border-purple-400 shadow-lg shadow-purple-500/40 flex items-center justify-center relative">
            <div className="w-8 h-8 rounded-full bg-purple-500/30 animate-ping absolute" />
            <div className="w-6 h-6 rounded-full bg-purple-400 shadow-inner" />
          </div>
        </div>
      </div>
    </div>
  );
};
