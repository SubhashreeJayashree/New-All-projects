import React, { useEffect, useRef } from 'react';
import { Mic, MicOff, Volume2, VolumeX, Radio, Sparkles, Cpu, User, Smile, Disc } from 'lucide-react';
import { AssistantState, LanguageCode } from '../types';
import { HEAD_MESH_DATA } from '../utils/headMeshData';

export type AvatarVisualMode = 'hologram_head' | 'hayat_anime' | 'reactor_core' | 'cyber_orb';

interface AvatarFaceProps {
  state: AssistantState;
  isListening: boolean;
  isMuted: boolean;
  language: LanguageCode;
  onToggleListening: () => void;
  onToggleMute: () => void;
  onChangeLanguage: (lang: LanguageCode) => void;
  onTestVoice: () => void;
  volumeLevel?: number; // 0 to 1
  fullscreen?: boolean;
  size?: number;
  interimSpeech?: string;
  actionText?: string;
  spokenText?: string;
  visualMode?: AvatarVisualMode;
  onChangeVisualMode?: (mode: AvatarVisualMode) => void;
  accentColor?: string;
  assistantName?: string;
  onWake?: () => void;
  showControls?: boolean;
}

// Parse hex color (#rrggbb) into [r, g, b]
function hexToRgb(hex: string): [number, number, number] {
  const clean = (hex || '#00d4ff').replace('#', '').trim();
  if (clean.length !== 6) return [0, 212, 255];
  const num = parseInt(clean, 16);
  if (Number.isNaN(num)) return [0, 212, 255];
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

// Mark LIV _blend(): pre-mix `col` at alpha `a` (0..255) onto `bg`, returning an OPAQUE rgb() string.
// This prevents back-facing or neck polygons from bleeding through the lit face surface.
function blendOpaque(
  bg: [number, number, number],
  col: [number, number, number],
  alpha255: number
): string {
  const f = Math.max(0, Math.min(1, alpha255 / 255));
  const r = Math.round(bg[0] + (col[0] - bg[0]) * f);
  const g = Math.round(bg[1] + (col[1] - bg[1]) * f);
  const b = Math.round(bg[2] + (col[2] - bg[2]) * f);
  return `rgb(${r},${g},${b})`;
}

function blendRgbTuple(
  bg: [number, number, number],
  col: [number, number, number],
  alpha255: number
): [number, number, number] {
  const f = Math.max(0, Math.min(1, alpha255 / 255));
  return [
    Math.round(bg[0] + (col[0] - bg[0]) * f),
    Math.round(bg[1] + (col[1] - bg[1]) * f),
    Math.round(bg[2] + (col[2] - bg[2]) * f),
  ];
}

// Language-free Unicode reduction to viseme targets (Mark LIV core/avatar.py style)
// Returns mouth (0..1 jaw open), wide (-1 rounded .. +1 spread), and brow (-0.4..1.2)
function computeVisemeAtTime(text: string, timeSec: number, isSpeaking: boolean, isListening: boolean) {
  if (!isSpeaking) {
    return {
      mouth: 0,
      wide: 0,
      brow: isListening ? 0.12 + Math.sin(timeSec * 1.8) * 0.05 : Math.sin(timeSec * 0.9) * 0.04,
      amp: isListening ? 0.22 + Math.abs(Math.sin(timeSec * 3.4)) * 0.18 : 0.04,
    };
  }

  const clean = (text || 'hayat and jarvis mark liv speaking response').toLowerCase();
  const charIdx = Math.floor(timeSec * 13.5) % Math.max(1, clean.length);
  const ch = clean[charIdx] || 'a';
  const osc = 0.68 + 0.32 * Math.sin(timeSec * 24);

  // Bilabial closures: m, b, p — mouth shuts completely mid-word
  if ('mbp'.includes(ch)) {
    return { mouth: 0.0, wide: 0.0, brow: 0.28, amp: 0.35 };
  }
  // Rounded vowels / glides: u, o, w, q -> negative wide (-0.85) purses lips forward
  if ('uowq'.includes(ch)) {
    return { mouth: 0.58 * osc, wide: -0.85 * osc, brow: 0.38, amp: 0.78 * osc };
  }
  // Spread front vowels / sibilants: i, e, y, s, z, c -> positive wide (+0.82) spreads corners
  if ('ieyszc'.includes(ch)) {
    return { mouth: 0.44 * osc, wide: 0.82 * osc, brow: 0.34, amp: 0.72 * osc };
  }
  // Open vowels: a, h, r, l, k, g
  if ('ahrlkg'.includes(ch)) {
    return { mouth: 0.88 * osc, wide: 0.18 * osc, brow: 0.52, amp: 0.92 * osc };
  }
  // Dental / labiodental: f, v, t, d, n
  if ('fvtdn'.includes(ch)) {
    return { mouth: 0.32 * osc, wide: 0.28 * osc, brow: 0.25, amp: 0.55 * osc };
  }
  // Space / pause between words
  return { mouth: 0.06, wide: 0.0, brow: 0.2, amp: 0.18 };
}

export const AvatarFace: React.FC<AvatarFaceProps> = ({
  state,
  isListening,
  isMuted,
  language,
  onToggleListening,
  onToggleMute,
  onChangeLanguage,
  onTestVoice,
  volumeLevel = 0.6,
  fullscreen = false,
  size = 460,
  interimSpeech = '',
  actionText = '',
  spokenText = '',
  visualMode = 'hologram_head',
  onChangeVisualMode,
  accentColor = '#00d4ff',
  assistantName = 'HAYAT · J.A.R.V.I.S',
  onWake,
  showControls = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pointerRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  const primaryRgb = hexToRgb(accentColor);

  // Mark LIV C palette colors
  const getStateMeta = () => {
    if (isMuted || state === 'blocked' || state === 'emergency_stopped') {
      return {
        mainHex: '#ff3366',
        mainRgb: [255, 51, 102] as [number, number, number],
        accHex: '#ff3366',
        accRgb: [255, 51, 102] as [number, number, number],
        statusText: state === 'emergency_stopped' ? '⊘  EMERGENCY HALT' : '⊘  MUTED',
        statusColor: '#ff3366',
      };
    }
    if (state === 'speaking') {
      return {
        mainHex: accentColor,
        mainRgb: primaryRgb,
        accHex: '#ff6b00', // Mark LIV C.ACC orange when speaking
        accRgb: [255, 107, 0] as [number, number, number],
        statusText: '●  SPEAKING',
        statusColor: '#ff6b00',
      };
    }
    if (state === 'evaluating') {
      return {
        mainHex: accentColor,
        mainRgb: primaryRgb,
        accHex: '#ffcc00', // Mark LIV C.ACC2 gold when thinking/processing
        accRgb: [255, 204, 0] as [number, number, number],
        statusText: '◈  PROCESSING',
        statusColor: '#ffcc00',
      };
    }
    if (state === 'listening' || isListening) {
      return {
        mainHex: accentColor,
        mainRgb: primaryRgb,
        accHex: '#ff6b00', // Keep warm amber iris accent while status is green
        accRgb: [255, 107, 0] as [number, number, number],
        statusText: '●  LISTENING',
        statusColor: '#00ff88',
      };
    }
    return {
      mainHex: accentColor,
      mainRgb: primaryRgb,
      accHex: '#ff6b00',
      accRgb: [255, 107, 0] as [number, number, number],
      statusText: '●  ONLINE · STANDBY',
      statusColor: accentColor,
    };
  };

  const { mainHex, mainRgb, accHex, accRgb, statusText, statusColor } = getStateMeta();

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const nx = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
    const ny = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    pointerRef.current = { x: nx * 0.22, y: ny * 0.14 };
  };

  // Exact Mark LIV + Hayat Canvas Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let t = 0;
    let sway = 0;

    // Extract MediaPipe + Mark LIV mesh arrays
    const {
      verts,
      normals,
      faces,
      edges,
      jaw,
      brow,
      lips,
      lip_centre,
      fade,
      face_group,
      landmarks,
      span,
    } = HEAD_MESH_DATA;

    const numVerts = verts.length;
    const numFaces = faces.length;
    const numEdges = edges.length;

    // Upper teeth strip anchor indices: concatenate(lips_in[10:], lips_in[:1])
    const lipsIn = landmarks.lips_in || [];
    const lipUp = lipsIn.length > 10 ? [...lipsIn.slice(10), lipsIn[0]] : [];
    const headSpan = span ? span[0] - span[1] : 2.322;

    const posedX = new Float32Array(numVerts);
    const posedY = new Float32Array(numVerts);
    const posedZ = new Float32Array(numVerts);
    const rotNormX = new Float32Array(numVerts);
    const rotNormY = new Float32Array(numVerts);
    const rotNormZ = new Float32Array(numVerts);
    const projX = new Float32Array(numVerts);
    const projY = new Float32Array(numVerts);

    // Smoothed state variables matching HoloAvatar in core/avatar.py
    let curMouth = 0;
    let curWide = 0;
    let curBrow = 0;
    let curEmph = 0;
    let curGlow = 0;
    let scanY = -1.6;
    let blink = 0;
    let nextBlinkAt = 2.8;
    let gazeX = 0;
    let gazeY = 0;
    let gazeTgtX = 0;
    let gazeTgtY = 0;
    let nextGazeAt = 0.5;

    const BG_RGB: [number, number, number] = [0, 6, 10]; // Mark LIV C.BG = #00060a
    const _CAM_D = 4.6;
    const _BROW_LIFT = 0.14;
    const JAW_PIVOT_Y = 0.06;
    const JAW_PIVOT_Z = -0.34;
    const JAW_MAX = 0.115;

    const render = () => {
      const dt = 0.025;
      t += dt;

      const W = canvas.width;
      const H = canvas.height;
      const cx = W / 2;
      const cy = H / 2;
      const fw = Math.min(W, H);

      // 1. Fill Mark LIV deep space background (#00060a) & subtle HUD dot grid
      ctx.fillStyle = '#00060a';
      ctx.fillRect(0, 0, W, H);

      ctx.fillStyle = `rgba(${mainRgb[0]}, ${mainRgb[1]}, ${mainRgb[2]}, 0.09)`;
      const gridStep = 26;
      for (let gx = 14; gx < W; gx += gridStep) {
        for (let gy = 14; gy < H; gy += gridStep) {
          ctx.fillRect(gx, gy, 1.2, 1.2);
        }
      }

      const isSpeaking = state === 'speaking' && !isMuted;
      const isLstn = (state === 'listening' || isListening) && !isMuted;
      const viseme = computeVisemeAtTime(
        spokenText || interimSpeech || actionText,
        t,
        isSpeaking,
        isLstn
      );

      // Smooth jaw opening, lip width, brow lift, and audio glow (core/avatar.py time constants)
      const mouthRate = viseme.mouth > curMouth ? 0.48 : isSpeaking ? 0.65 : 0.25;
      curMouth += (viseme.mouth - curMouth) * mouthRate;
      if (curMouth < 0.002) curMouth = 0;

      curWide += (viseme.wide - curWide) * 0.42;
      curBrow += (viseme.brow - curBrow) * 0.22;
      curEmph += (curMouth - curEmph) * (curMouth > curEmph ? 0.35 : 0.12);
      curGlow += ((isMuted ? 0 : viseme.amp) - curGlow) * 0.28;

      // Advance vertical energy scan sweep
      scanY += dt * (0.55 + 1.5 * curGlow);
      if (scanY > 1.35) scanY = -1.75;

      // Natural blinking
      if (blink > 0) {
        blink = Math.max(0, blink - dt * 8.5);
      } else if (t >= nextBlinkAt) {
        blink = 1.0;
        nextBlinkAt = t + 2.8 + Math.random() * 2.8;
      }

      // Saccadic eye gaze fixations
      if (t >= nextGazeAt) {
        const reach = isSpeaking ? 0.85 : 0.5;
        gazeTgtX = (Math.random() * 2 - 1) * reach;
        gazeTgtY = (Math.random() * 2 - 1) * reach * 0.55;
        nextGazeAt = t + (isSpeaking ? 0.55 + Math.random() * 1.4 : 1.2 + Math.random() * 2.2);
      }
      gazeX += (gazeTgtX + pointerRef.current.x * 1.8 - gazeX) * 0.3;
      gazeY += (gazeTgtY + pointerRef.current.y * 1.8 - gazeY) * 0.3;

      // Layout band matching Mark LIV HudCanvas.paintEvent
      const syStatus = cy + fw * 0.37;
      const bandTop = 10;
      const bandH = Math.max(60, syStatus - 10 - bandTop);

      // ====================================================================
      // MODE 1: MARK 54 3D HOLOGRAPHIC HUMAN HEAD (EXACT core/avatar.py)
      // ====================================================================
      if (visualMode === 'hologram_head') {
        const rHead = Math.min(fw * 0.355, bandH / (headSpan + 0.08));
        const headCy = bandTop + (bandH - headSpan * rHead) / 2 + rHead;

        // 1. Radial Aura behind head
        const ar = rHead * 1.95;
        const auraGrad = ctx.createRadialGradient(cx, headCy, 0, cx, headCy, ar);
        const a0 = (34 + 66 * curGlow) / 255;
        const a1 = (20 + 40 * curGlow) / 255;
        auraGrad.addColorStop(0, `rgba(${mainRgb[0]}, ${mainRgb[1]}, ${mainRgb[2]}, ${a0.toFixed(3)})`);
        auraGrad.addColorStop(0.38, `rgba(${mainRgb[0]}, ${mainRgb[1]}, ${mainRgb[2]}, ${a1.toFixed(3)})`);
        auraGrad.addColorStop(1, 'rgba(0, 6, 10, 0)');
        ctx.fillStyle = auraGrad;
        ctx.beginPath();
        ctx.arc(cx, headCy, ar, 0, Math.PI * 2);
        ctx.fill();

        // 2. Integrated head sway + syllable emphasis nod
        const speed = (isMuted ? 0.55 : 1.0) * (isSpeaking ? 1.25 : 1.0);
        sway += dt * speed;
        const yaw =
          0.26 * Math.sin(sway * 0.31) +
          0.09 * Math.sin(sway * 0.73 + 1.3) +
          0.018 * Math.sin(t * 1.7) * curEmph +
          pointerRef.current.x;
        const pitch =
          0.06 * Math.sin(sway * 0.23 + 0.7) +
          0.024 * Math.sin(sway * 0.61) -
          curEmph * 0.028 +
          pointerRef.current.y;

        const cyaw = Math.cos(yaw);
        const syaw = Math.sin(yaw);
        const cpitch = Math.cos(pitch);
        const spitch = Math.sin(pitch);

        // Rotation matrix m from core/avatar.py:
        // [ cy,       0,   sy      ]
        // [ sp*sy,   cp,  -sp*cy   ]
        // [-cp*sy,   sp,   cp*cy   ]
        const m00 = cyaw,
          m01 = 0,
          m02 = syaw;
        const m10 = spitch * syaw,
          m11 = cpitch,
          m12 = -spitch * cyaw;
        const m20 = -cpitch * syaw,
          m21 = spitch,
          m22 = cpitch * cyaw;

        const lc0 = lip_centre[0];
        const lc1 = lip_centre[1];

        // 3. Pose & project all 810 vertices
        for (let i = 0; i < numVerts; i++) {
          const v = verts[i];
          const n = normals[i];
          let vx = v[0];
          let vy = v[1];
          let vz = v[2];

          // Brow lift
          if (Math.abs(curBrow) > 0.004) {
            vy += brow[i] * (curBrow * _BROW_LIFT);
          }

          // Lip spread / rounding around lip_centre
          if (Math.abs(curWide) > 0.01 && curMouth > 0) {
            const k = lips[i] * (curWide * curMouth);
            vx += k * (vx - lc0) * 0.55;
            vy += k * (vy - lc1) * 0.3;
            vz -= k * 0.055;
          }

          // Real anatomical jaw hinge rotation around JAW_PIVOT (0, 0.06, -0.34)
          if (curMouth > 0.004 && jaw[i] > 0) {
            const ang = jaw[i] * (curMouth * JAW_MAX);
            const ca = Math.cos(ang);
            const sa = Math.sin(ang);
            const dy = vy - JAW_PIVOT_Y;
            const dz = vz - JAW_PIVOT_Z;
            vy = JAW_PIVOT_Y + dy * ca - dz * sa;
            vz = JAW_PIVOT_Z + dy * sa + dz * ca;
          }

          // Rotate vertex by m
          const rx = vx * m00 + vy * m01 + vz * m02;
          const ry = vx * m10 + vy * m11 + vz * m12;
          const rz = vx * m20 + vy * m21 + vz * m22;

          // Rotate normal by m
          const nx = n[0] * m00 + n[1] * m01 + n[2] * m02;
          const ny = n[0] * m10 + n[1] * m11 + n[2] * m12;
          const nz = n[0] * m20 + n[1] * m21 + n[2] * m22;

          posedX[i] = rx;
          posedY[i] = ry;
          posedZ[i] = rz;
          rotNormX[i] = nx;
          rotNormY[i] = ny;
          rotNormZ[i] = nz;

          const w = Math.max(0.35, _CAM_D - rz);
          const kProj = (_CAM_D / w) * rHead;
          projX[i] = cx + rx * kProj;
          projY[i] = headCy - ry * kProj;
        }

        // 4. _paint_surface(): Per-facet flat normals + Neck-first depth sort + Opaque blended fills
        const visibleTris: {
          fIdx: number;
          sortKey: number;
          bright: number;
        }[] = [];

        for (let f = 0; f < numFaces; f++) {
          const tri = faces[f];
          const a = tri[0];
          const b = tri[1];
          const c = tri[2];

          const ax = projX[a],
            ay = projY[a];
          const bx = projX[b],
            by = projY[b];
          const cxp = projX[c],
            cyp = projY[c];

          const area = Math.abs((bx - ax) * (cyp - ay) - (cxp - ax) * (by - ay));
          if (area <= 2.2) continue;

          // Flat facet normal: cross(verts[b] - verts[a], verts[c] - verts[a])
          const abx = posedX[b] - posedX[a];
          const aby = posedY[b] - posedY[a];
          const abz = posedZ[b] - posedZ[a];
          const acx = posedX[c] - posedX[a];
          const acy = posedY[c] - posedY[a];
          const acz = posedZ[c] - posedZ[a];

          let fnx = aby * acz - abz * acy;
          let fny = abz * acx - abx * acz;
          let fnz = abx * acy - aby * acx;
          const len = Math.hypot(fnx, fny, fnz) || 1e-9;
          fnx /= len;
          fny /= len;
          fnz /= len;

          // Orient outward by agreeing with sum of vertex normals
          const refX = rotNormX[a] + rotNormX[b] + rotNormX[c];
          const refY = rotNormY[a] + rotNormY[b] + rotNormY[c];
          const refZ = rotNormZ[a] + rotNormZ[b] + rotNormZ[c];
          if (fnx * refX + fny * refY + fnz * refZ < 0) {
            fnx = -fnx;
            fny = -fny;
            fnz = -fnz;
          }

          if (fnz <= 0.015) continue;

          // Rim term + high-left key light (core/avatar.py lines 526-531)
          const fres = Math.pow(Math.max(0, Math.min(2, 1.0 - fnz)), 1.7);
          const lam = Math.max(0, Math.min(1, fnx * -0.55 + fny * 0.5 + fnz * 0.52));
          const avgFade = (fade[a] + fade[b] + fade[c]) / 3.0;
          const bright =
            (0.26 + 0.2 * fres + 0.66 * Math.pow(lam, 1.05)) *
            avgFade *
            (0.88 + 0.24 * curGlow);

          const fz = (posedZ[a] + posedZ[b] + posedZ[c]) / 3.0;
          // Group neck facets (face_group=0) before head facets (face_group=1)
          const fg = face_group ? face_group[f] : 1;
          visibleTris.push({
            fIdx: f,
            sortKey: fg * 1000.0 + fz,
            bright: Math.max(0, Math.min(1, bright)),
          });
        }

        visibleTris.sort((t1, t2) => t1.sortKey - t2.sortKey);

        for (let k = 0; k < visibleTris.length; k++) {
          const item = visibleTris[k];
          const tri = faces[item.fIdx];
          const a = tri[0];
          const b = tri[1];
          const c = tri[2];

          const colStr = blendOpaque(BG_RGB, mainRgb, item.bright * 255);
          ctx.fillStyle = colStr;
          ctx.strokeStyle = colStr;
          ctx.lineWidth = 0.45;
          ctx.beginPath();
          ctx.moveTo(projX[a], projY[a]);
          ctx.lineTo(projX[b], projY[b]);
          ctx.lineTo(projX[c], projY[c]);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }

        // 5. _paint_wire(): Structure wireframe over lit skin with vertical energy sweep
        const skinRgb = blendRgbTuple(BG_RGB, mainRgb, 132);
        ctx.lineWidth = 0.9;
        for (let e = 0; e < numEdges; e++) {
          const pair = edges[e];
          const i0 = pair[0];
          const i1 = pair[1];

          const nz0 = rotNormZ[i0];
          const nz1 = rotNormZ[i1];
          if (nz0 <= -0.05 && nz1 <= -0.05) continue;

          const fres0 = Math.pow(Math.abs(1.0 - Math.abs(nz0)), 1.5);
          const fres1 = Math.pow(Math.abs(1.0 - Math.abs(nz1)), 1.5);
          const scan0 = 0.3 * Math.exp(-Math.pow((posedY[i0] - scanY) / 0.13, 2));
          const scan1 = 0.3 * Math.exp(-Math.pow((posedY[i1] - scanY) / 0.13, 2));

          const va0 = (nz0 > -0.05 ? 0.1 + 0.42 * fres0 + scan0 : 0) * fade[i0];
          const va1 = (nz1 > -0.05 ? 0.1 + 0.42 * fres1 + scan1 : 0) * fade[i1];
          const ea = 0.5 * (va0 + va1) * (0.8 + 0.45 * curGlow);
          if (ea <= 0.05) continue;

          ctx.strokeStyle = blendOpaque(skinRgb, mainRgb, Math.min(255, ea * 255 * 0.75));
          ctx.beginPath();
          ctx.moveTo(projX[i0], projY[i0]);
          ctx.lineTo(projX[i1], projY[i1]);
          ctx.stroke();
        }

        // 6. _paint_features(): Socket shadows, Amber Irises, Pupils, Brows, Mouth & Upper Teeth
        const faceFactor = Math.pow(Math.max(0, cyaw * cpitch), 2);
        const vis = 1.0 - blink;

        if (faceFactor > 0.02) {
          // Eyes
          for (const key of ['eye_l', 'eye_r'] as const) {
            const idxArr = landmarks[key];
            if (!idxArr || idxArr.length === 0) continue;

            let midY = 0;
            let minX = Infinity,
              maxX = -Infinity,
              minY = Infinity,
              maxY = -Infinity;
            for (let i = 0; i < idxArr.length; i++) {
              midY += projY[idxArr[i]];
            }
            midY /= idxArr.length;

            ctx.beginPath();
            for (let i = 0; i < idxArr.length; i++) {
              const vIdx = idxArr[i];
              const px = projX[vIdx];
              const py =
                vis < 0.999 ? midY + (projY[vIdx] - midY) * Math.max(0.04, vis) : projY[vIdx];
              if (px < minX) minX = px;
              if (px > maxX) maxX = px;
              if (py < minY) minY = py;
              if (py > maxY) maxY = py;
              if (i === 0) ctx.moveTo(px, py);
              else ctx.lineTo(px, py);
            }
            ctx.closePath();

            // Dark socket shadow
            ctx.fillStyle = blendOpaque(BG_RGB, mainRgb, 22);
            ctx.fill();

            // Lid outline
            ctx.strokeStyle = `rgba(${mainRgb[0]}, ${mainRgb[1]}, ${mainRgb[2]}, ${(0.82 * faceFactor).toFixed(3)})`;
            ctx.lineWidth = 1.3;
            ctx.stroke();

            // Glowing Amber/Orange Iris & Pupil (Mark LIV C.ACC)
            if (vis > 0.35) {
              const bw = maxX - minX;
              const bh = maxY - minY;
              const gx = (minX + maxX) * 0.5 + gazeX * bw * 0.16;
              const gy = (minY + maxY) * 0.5 + gazeY * bh * 0.2;
              const rad = Math.min(bh * 0.62, bw * 0.2);

              // Iris
              const irisAlpha = ((70 + 60 * curGlow) / 255) * faceFactor * vis;
              ctx.fillStyle = `rgba(${accRgb[0]}, ${accRgb[1]}, ${accRgb[2]}, ${irisAlpha.toFixed(3)})`;
              ctx.beginPath();
              ctx.ellipse(gx, gy, rad, rad * vis, 0, 0, Math.PI * 2);
              ctx.fill();

              // Bright Pupil
              const pupilAlpha = (245 / 255) * faceFactor * vis;
              ctx.fillStyle = `rgba(${accRgb[0]}, ${accRgb[1]}, ${accRgb[2]}, ${pupilAlpha.toFixed(3)})`;
              ctx.beginPath();
              ctx.ellipse(gx, gy, rad * 0.42, rad * 0.42 * vis, 0, 0, Math.PI * 2);
              ctx.fill();
            }
          }

          // Brows
          ctx.strokeStyle = `rgba(${mainRgb[0]}, ${mainRgb[1]}, ${mainRgb[2]}, ${(0.59 * faceFactor).toFixed(3)})`;
          ctx.lineWidth = 1.7;
          for (const key of ['brow_l', 'brow_r'] as const) {
            const idxArr = landmarks[key];
            if (!idxArr || idxArr.length === 0) continue;
            ctx.beginPath();
            for (let i = 0; i < idxArr.length; i++) {
              const vIdx = idxArr[i];
              if (i === 0) ctx.moveTo(projX[vIdx], projY[vIdx]);
              else ctx.lineTo(projX[vIdx], projY[vIdx]);
            }
            ctx.stroke();
          }

          // Mouth cavity, upper teeth strip, throat glow & lip rings
          if (lipsIn.length > 0) {
            let minLy = Infinity,
              maxLy = -Infinity;
            for (let i = 0; i < lipsIn.length; i++) {
              const py = projY[lipsIn[i]];
              if (py < minLy) minLy = py;
              if (py > maxLy) maxLy = py;
            }
            const openH = maxLy - minLy;

            if (curMouth > 0.02) {
              // Tinted mouth cavity
              ctx.fillStyle = blendOpaque(BG_RGB, mainRgb, 16 + 26 * curMouth);
              ctx.beginPath();
              for (let i = 0; i < lipsIn.length; i++) {
                const vIdx = lipsIn[i];
                if (i === 0) ctx.moveTo(projX[vIdx], projY[vIdx]);
                else ctx.lineTo(projX[vIdx], projY[vIdx]);
              }
              ctx.closePath();
              ctx.fill();

              // Upper teeth strip hanging from upper inner lip
              if (lipUp.length > 0) {
                const th = openH * 0.3;
                ctx.fillStyle = blendOpaque(BG_RGB, mainRgb, 150 + 60 * curMouth);
                ctx.beginPath();
                for (let i = 0; i < lipUp.length; i++) {
                  const vIdx = lipUp[i];
                  if (i === 0) ctx.moveTo(projX[vIdx], projY[vIdx]);
                  else ctx.lineTo(projX[vIdx], projY[vIdx]);
                }
                for (let i = lipUp.length - 1; i >= 0; i--) {
                  const vIdx = lipUp[i];
                  ctx.lineTo(projX[vIdx], projY[vIdx] + th);
                }
                ctx.closePath();
                ctx.fill();
              }

              // Warm pool at back of throat
              ctx.fillStyle = `rgba(${accRgb[0]}, ${accRgb[1]}, ${accRgb[2]}, ${((40 / 255) * curMouth * faceFactor).toFixed(3)})`;
              ctx.beginPath();
              for (let i = 0; i < lipsIn.length; i++) {
                const vIdx = lipsIn[i];
                if (i === 0) ctx.moveTo(projX[vIdx], projY[vIdx]);
                else ctx.lineTo(projX[vIdx], projY[vIdx]);
              }
              ctx.closePath();
              ctx.fill();
            }

            // Inner lip outline
            ctx.strokeStyle = `rgba(${mainRgb[0]}, ${mainRgb[1]}, ${mainRgb[2]}, ${(((150 + 70 * curMouth) / 255) * faceFactor).toFixed(3)})`;
            ctx.lineWidth = 1.3;
            ctx.beginPath();
            for (let i = 0; i < lipsIn.length; i++) {
              const vIdx = lipsIn[i];
              if (i === 0) ctx.moveTo(projX[vIdx], projY[vIdx]);
              else ctx.lineTo(projX[vIdx], projY[vIdx]);
            }
            ctx.closePath();
            ctx.stroke();
          }

          // Outer lip outline
          const lipsOut = landmarks.lips_out || [];
          if (lipsOut.length > 0) {
            ctx.strokeStyle = `rgba(${mainRgb[0]}, ${mainRgb[1]}, ${mainRgb[2]}, ${((110 / 255) * faceFactor).toFixed(3)})`;
            ctx.lineWidth = 1.1;
            ctx.beginPath();
            for (let i = 0; i < lipsOut.length; i++) {
              const vIdx = lipsOut[i];
              if (i === 0) ctx.moveTo(projX[vIdx], projY[vIdx]);
              else ctx.lineTo(projX[vIdx], projY[vIdx]);
            }
            ctx.closePath();
            ctx.stroke();
          }
        }
      }

      // ====================================================================
      // MODE 2: HAYAT INTERACTIVE ANIME COMPANION (VIDEO 1 - NEON LABS)
      // ====================================================================
      else if (visualMode === 'hayat_anime') {
        const s = fw / 380;
        const acy = bandTop + bandH * 0.48;
        const breath = Math.sin(t * 2.2) * 3 * s;

        // Ambient Pink-Cyan Aura
        const auraGrad = ctx.createRadialGradient(cx, acy, 20 * s, cx, acy, 155 * s);
        auraGrad.addColorStop(0, 'rgba(244, 114, 182, 0.28)');
        auraGrad.addColorStop(0.55, `rgba(${mainRgb[0]}, ${mainRgb[1]}, ${mainRgb[2]}, 0.16)`);
        auraGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = auraGrad;
        ctx.beginPath();
        ctx.arc(cx, acy, 155 * s, 0, Math.PI * 2);
        ctx.fill();

        // Back Dark Hair
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.ellipse(cx, acy + 16 * s + breath, 58 * s, 66 * s, 0, 0, Math.PI * 2);
        ctx.fill();

        // Shoulders / Cute Pink Top
        ctx.fillStyle = '#ec4899';
        ctx.beginPath();
        ctx.ellipse(cx, acy + 94 * s + breath, 62 * s, 42 * s, 0, 0, Math.PI * 2);
        ctx.fill();

        // Neck
        ctx.fillStyle = '#fde2d4';
        ctx.fillRect(cx - 12 * s, acy + 46 * s + breath, 24 * s, 28 * s);

        // Face / Head
        ctx.fillStyle = '#fde2d4';
        ctx.beginPath();
        ctx.ellipse(cx, acy + 18 * s + breath, 45 * s, 52 * s, 0, 0, Math.PI * 2);
        ctx.fill();

        // Soft Anime Blush Cheeks
        ctx.fillStyle = 'rgba(244, 114, 182, 0.42)';
        ctx.beginPath();
        ctx.ellipse(cx - 24 * s, acy + 28 * s + breath, 8.5 * s, 4.5 * s, 0, 0, Math.PI * 2);
        ctx.ellipse(cx + 24 * s, acy + 28 * s + breath, 8.5 * s, 4.5 * s, 0, 0, Math.PI * 2);
        ctx.fill();

        // Expressive Sparkly Anime Eyes
        const eyeY = acy + 14 * s + breath;
        if (blink < 0.5) {
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.ellipse(cx - 17 * s, eyeY, 10.5 * s, 12.5 * s, 0, 0, Math.PI * 2);
          ctx.ellipse(cx + 17 * s, eyeY, 10.5 * s, 12.5 * s, 0, 0, Math.PI * 2);
          ctx.fill();

          // Deep Indigo-Cyan Irises
          ctx.fillStyle = '#1e1b4b';
          ctx.beginPath();
          ctx.arc(cx - 17 * s + gazeX * 2.5, eyeY + 1 * s, 7.5 * s, 0, Math.PI * 2);
          ctx.arc(cx + 17 * s + gazeX * 2.5, eyeY + 1 * s, 7.5 * s, 0, Math.PI * 2);
          ctx.fill();

          // Specular sparkles
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(cx - 19.5 * s, eyeY - 2 * s, 3 * s, 0, Math.PI * 2);
          ctx.arc(cx + 14.5 * s, eyeY - 2 * s, 3 * s, 0, Math.PI * 2);
          ctx.arc(cx - 15 * s, eyeY + 3.5 * s, 1.5 * s, 0, Math.PI * 2);
          ctx.arc(cx + 19 * s, eyeY + 3.5 * s, 1.5 * s, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.strokeStyle = '#0f172a';
          ctx.lineWidth = 3 * s;
          ctx.beginPath();
          ctx.arc(cx - 17 * s, eyeY, 9 * s, Math.PI * 0.2, Math.PI * 0.8, true);
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(cx + 17 * s, eyeY, 9 * s, Math.PI * 0.2, Math.PI * 0.8, true);
          ctx.stroke();
        }

        // Lip-Sync Mouth
        const mouthY = acy + 42 * s + breath;
        const mh = isSpeaking ? (4 + curMouth * 12) * s : 3.5 * s;
        ctx.fillStyle = '#e11d48';
        ctx.beginPath();
        ctx.ellipse(cx, mouthY, 8.5 * s, mh, 0, 0, Math.PI * 2);
        ctx.fill();

        // Forehead Bangs & Side Strands
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.ellipse(cx - 46 * s, acy + 62 * s + breath, 14 * s, 44 * s, 0.18, 0, Math.PI * 2);
        ctx.ellipse(cx + 46 * s, acy + 62 * s + breath, 14 * s, 44 * s, -0.18, 0, Math.PI * 2);
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(cx - 40 * s, acy - 14 * s + breath);
        ctx.quadraticCurveTo(cx - 14 * s, acy + 6 * s + breath, cx - 6 * s, acy + 10 * s + breath);
        ctx.quadraticCurveTo(cx + 12 * s, acy + 6 * s + breath, cx + 40 * s, acy - 14 * s + breath);
        ctx.quadraticCurveTo(cx, acy - 36 * s + breath, cx - 40 * s, acy - 14 * s + breath);
        ctx.fill();

        // Waving Right Hand (Video 1)
        const waveAngle = Math.sin(t * 6.5) * 0.32;
        ctx.save();
        ctx.translate(cx + 56 * s, acy + 48 * s + breath);
        ctx.rotate(waveAngle);
        ctx.strokeStyle = '#fde2d4';
        ctx.lineWidth = 12 * s;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(14 * s, -30 * s);
        ctx.stroke();
        ctx.fillStyle = '#fde2d4';
        ctx.beginPath();
        ctx.arc(16 * s, -36 * s, 10.5 * s, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // ====================================================================
      // MODE 3: MARK 54 ARC REACTOR CORE (EXACT ui.py _paint_core)
      // ====================================================================
      else if (visualMode === 'reactor_core') {
        const r = Math.min(W * 0.44, bandH / 2.0);
        const coreCy = bandTop + bandH / 2.0;

        // 1. Ambient radial glow
        const coreGrad = ctx.createRadialGradient(cx, coreCy, 0, cx, coreCy, r * 1.15);
        coreGrad.addColorStop(0, `rgba(${mainRgb[0]}, ${mainRgb[1]}, ${mainRgb[2]}, ${(0.22 + 0.35 * curGlow).toFixed(3)})`);
        coreGrad.addColorStop(0.5, `rgba(${mainRgb[0]}, ${mainRgb[1]}, ${mainRgb[2]}, 0.08)`);
        coreGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = coreGrad;
        ctx.beginPath();
        ctx.arc(cx, coreCy, r * 1.15, 0, Math.PI * 2);
        ctx.fill();

        // 2. 72 Sparse Graduations (24 majors + 48 minors)
        for (let i = 0; i < 72; i++) {
          const a = (i * 5.0 * Math.PI) / 180;
          const ca = Math.cos(a);
          const sa = Math.sin(a);
          const isMajor = i % 3 === 0;
          const rIn = r * (isMajor ? 0.885 : 0.945);
          const rOut = r * 0.985;
          ctx.strokeStyle = blendOpaque(BG_RGB, mainRgb, (isMajor ? 0.42 : 0.18) * 255);
          ctx.lineWidth = isMajor ? 1.3 : 1.0;
          ctx.beginPath();
          ctx.moveTo(cx + ca * rIn, coreCy + sa * rIn);
          ctx.lineTo(cx + ca * rOut, coreCy + sa * rOut);
          ctx.stroke();
        }

        // 3. 5 Counter-Rotating Sweeping Arcs (exact ui.py lines 703-720)
        const rate = 1.0 + (state === 'evaluating' ? 1.9 : 0) + (isSpeaking ? 1.2 : 0);
        const arcSpecs: [number, number, number, number, [number, number, number], number, number][] = [
          [0.955, 118, 2, 1, accRgb, 0.75, 2.0],
          [0.845, 82, 3, -1, mainRgb, 0.38, 1.3],
          [0.76, 150, 1, 1, accRgb, 0.45, 1.6],
          [0.66, 64, 4, -1, mainRgb, 0.26, 1.1],
          [0.545, 128, 2, 1, mainRgb, 0.3, 1.2],
        ];

        for (let k = 0; k < arcSpecs.length; k++) {
          const [rr, spanDeg, count, dirn, colRgb, alpha, wid] = arcSpecs[k];
          const rad = r * rr;
          const baseDeg = (t * rate * (9 + k * 6) * dirn) % 360;
          ctx.strokeStyle = blendOpaque(BG_RGB, colRgb, alpha * 255);
          ctx.lineWidth = wid;
          for (let sgm = 0; sgm < count; sgm++) {
            const startRad = ((baseDeg + sgm * (360 / count)) * Math.PI) / 180;
            const endRad = startRad + (spanDeg * Math.PI) / 180;
            ctx.beginPath();
            ctx.arc(cx, coreCy, rad, startRad, endRad);
            ctx.stroke();
          }
        }

        // 4. 60 Voice Graduations ring
        const nSpikes = 60;
        const spikeRing = r * 0.415;
        const spikeCol = isSpeaking || isLstn ? accRgb : mainRgb;
        ctx.strokeStyle = blendOpaque(BG_RGB, spikeCol, (0.25 + 0.5 * curGlow) * 255);
        ctx.lineWidth = 1.6;
        for (let i = 0; i < nSpikes; i++) {
          const a = (i * (360 / nSpikes) * Math.PI) / 180;
          const ca = Math.cos(a);
          const sa = Math.sin(a);
          const wob = 0.5 + 0.5 * Math.sin(t * 2.3 + i * 0.42);
          const idle = 0.018 + 0.012 * Math.sin(t * 1.2 + i * 0.7);
          const h = r * (idle + (isSpeaking || isLstn ? curGlow * 0.2 * wob : 0));
          ctx.beginPath();
          ctx.moveTo(cx + ca * spikeRing, coreCy + sa * spikeRing);
          ctx.lineTo(cx + ca * (spikeRing + h), coreCy + sa * (spikeRing + h));
          ctx.stroke();
        }

        // 5. Inner Ring + Assistant Name
        const innerR = r * 0.355;
        ctx.strokeStyle = blendOpaque(BG_RGB, accRgb, (0.3 + 0.45 * curGlow) * 255);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(cx, coreCy, innerR, 0, Math.PI * 2);
        ctx.stroke();

        ctx.fillStyle = '#d8f8ff';
        ctx.font = `bold ${Math.max(10, Math.round(r * 0.085))}px "Courier New", monospace`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(assistantName, cx, coreCy);
      }

      // ====================================================================
      // MODE 4: ASTRA CYBER-ORB FACE
      // ====================================================================
      else {
        const s = fw / 400;
        const orbCy = bandTop + bandH / 2.0;
        for (let i = 0; i < 3; i++) {
          const radius = (86 + i * 26) * s + Math.sin(t * 2 + i) * (4 * s);
          ctx.beginPath();
          ctx.arc(cx, orbCy, radius, 0, Math.PI * 2);
          ctx.strokeStyle = i === 1 ? mainHex : `rgba(${mainRgb[0]}, ${mainRgb[1]}, ${mainRgb[2]}, 0.3)`;
          ctx.lineWidth = (i === 1 ? 2.4 : 1.2) * s;
          ctx.setLineDash(i === 0 ? [8 * s, 6 * s] : i === 2 ? [4 * s, 8 * s] : []);
          ctx.stroke();
        }
        ctx.setLineDash([]);

        const eyeY = orbCy - 16 * s;
        ctx.fillStyle = mainHex;
        if (blink < 0.5) {
          ctx.beginPath();
          ctx.arc(cx - 34 * s, eyeY, 8 * s, 0, Math.PI * 2);
          ctx.arc(cx + 34 * s, eyeY, 8 * s, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.strokeStyle = mainHex;
          ctx.lineWidth = 3 * s;
          ctx.beginPath();
          ctx.moveTo(cx - 42 * s, eyeY);
          ctx.lineTo(cx - 26 * s, eyeY);
          ctx.moveTo(cx + 26 * s, eyeY);
          ctx.lineTo(cx + 42 * s, eyeY);
          ctx.stroke();
        }

        const mh = isSpeaking ? (10 + curMouth * 22) * s : 5 * s;
        ctx.beginPath();
        ctx.ellipse(cx, orbCy + 28 * s, 24 * s, mh, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // ====================================================================
      // MARK LIV BOTTOM HUD STATUS LINE + 36-BAR WAVEFORM (ui.py lines 877-917)
      // ====================================================================
      ctx.fillStyle = statusColor;
      ctx.font = 'bold 12px "Courier New", monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      ctx.fillText(statusText, cx, syStatus);

      const wy = syStatus + 22;
      const N = 36;
      const bw = 7;
      const wx0 = (W - N * bw) / 2;
      const mid = (N - 1) / 2.0;

      for (let i = 0; i < N; i++) {
        if (isMuted) {
          ctx.fillStyle = '#ff3366';
          ctx.fillRect(wx0 + i * bw, wy + 18 - 2, bw - 1.5, 2);
        } else {
          const env = Math.pow(1.0 - Math.abs(i - mid) / mid, 0.7);
          const shimmer = 0.55 + 0.45 * Math.sin(t * 7.2 + i * 0.7);
          const idle = 3.0 + 2.0 * Math.sin(t * 3.6 + i * 0.6);
          const hgt = Math.max(2, Math.min(22, Math.round(idle + curGlow * 22.0 * env * shimmer)));
          if (curGlow > 0.05) {
            ctx.fillStyle = hgt > 11 ? mainHex : blendOpaque(BG_RGB, mainRgb, 150);
          } else {
            ctx.fillStyle = '#1a5c7a';
          }
          ctx.fillRect(wx0 + i * bw, wy + 20 - hgt, bw - 1.5, hgt);
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [
    state,
    mainHex,
    mainRgb,
    accHex,
    accRgb,
    statusText,
    statusColor,
    volumeLevel,
    size,
    visualMode,
    spokenText,
    interimSpeech,
    actionText,
    isListening,
    isMuted,
    assistantName,
  ]);

  // Mode Switcher Bar (Always visible so user can switch between 3D Head, Hayat Anime, Reactor Core, Cyber Orb)
  const ModeSwitcherPills = () =>
    onChangeVisualMode ? (
      <div
        onClick={(e) => e.stopPropagation()}
        className="flex flex-wrap items-center justify-center gap-1.5 z-20"
      >
        {(
          [
            { id: 'hologram_head', label: '3D Hologram Head (Mark 54)', icon: User },
            { id: 'hayat_anime', label: 'Hayat Anime Face', icon: Smile },
            { id: 'reactor_core', label: 'Arc Reactor Core', icon: Cpu },
            { id: 'cyber_orb', label: 'Astra Cyber Orb', icon: Disc },
          ] as const
        ).map((m) => {
          const Icon = m.icon;
          const active = visualMode === m.id;
          return (
            <button
              key={m.id}
              onClick={() => onChangeVisualMode(m.id)}
              className={`px-2.5 py-1 rounded-md text-[10px] font-mono font-bold flex items-center gap-1.5 border transition-all ${
                active
                  ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 shadow-[0_0_12px_rgba(0,212,255,0.3)]'
                  : 'bg-[#010d14]/90 border-[#0d3347] text-[#5ab8cc] hover:text-white hover:border-[#1a5c7a]'
              }`}
            >
              <Icon className="w-3 h-3" />
              <span>{m.label}</span>
            </button>
          );
        })}
      </div>
    ) : null;

  if (fullscreen) {
    return (
      <div
        onClick={onWake || onToggleListening}
        onMouseMove={handleMouseMove}
        className="relative w-full h-full min-h-[520px] flex flex-col items-center justify-between bg-[#00060a] select-none cursor-pointer overflow-hidden p-4"
        title="Tap anywhere or speak to Hayat / J.A.R.V.I.S"
      >
        {/* Top Mode Switcher Pills */}
        <div className="w-full flex items-center justify-between gap-2 z-20">
          <ModeSwitcherPills />
          {showControls && (
            <div onClick={(e) => e.stopPropagation()} className="flex items-center gap-2">
              <button
                onClick={onTestVoice}
                className="px-2.5 py-1 rounded-md bg-[#010d14] border border-[#1a5c7a] text-[10px] font-mono text-[#8ffcff] hover:bg-[#001f2e]"
              >
                🔊 TEST VOICE
              </button>
              <button
                onClick={onToggleMute}
                className={`p-1.5 rounded-md border ${
                  isMuted
                    ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                    : 'bg-[#010d14] border-[#0d3347] text-[#5ab8cc] hover:text-white'
                }`}
              >
                {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={onToggleListening}
                className={`px-2.5 py-1 rounded-md border text-[10px] font-mono font-bold flex items-center gap-1 ${
                  isListening
                    ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                    : 'bg-[#010d14] border-[#0d3347] text-[#5ab8cc]'
                }`}
              >
                {isListening ? <Mic className="w-3.5 h-3.5 animate-pulse" /> : <MicOff className="w-3.5 h-3.5" />}
                <span>{isListening ? 'MIC ON' : 'MIC OFF'}</span>
              </button>
            </div>
          )}
        </div>

        {/* Center 3D Holographic Face Canvas */}
        <div className="relative z-10 flex flex-col items-center justify-center my-auto">
          <canvas
            ref={canvasRef}
            width={size}
            height={size}
            style={{ width: `${size}px`, height: `${size}px`, maxWidth: '92vw', maxHeight: '68vh' }}
            className="transition-transform duration-300"
          />

          {/* Live Speech / Subtitle Feedback */}
          <div className="mt-1 min-h-[36px] flex flex-col items-center justify-center text-center max-w-xl px-4 z-20 pointer-events-none">
            {interimSpeech ? (
              <div className="px-3.5 py-1 rounded-full bg-cyan-950/80 border border-cyan-400/60 text-cyan-200 font-mono text-xs animate-pulse">
                🗣️ &ldquo;{interimSpeech}&rdquo;
              </div>
            ) : state === 'speaking' && spokenText ? (
              <div className="px-3.5 py-1 rounded-xl bg-[#010f18]/90 border border-[#1a5c7a] text-[#8ffcff] font-mono text-xs max-w-lg line-clamp-2">
                {spokenText}
              </div>
            ) : actionText ? (
              <div className="text-[11px] font-mono text-[#5ab8cc]">{actionText}</div>
            ) : null}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      onMouseMove={handleMouseMove}
      className="relative flex flex-col items-center justify-between p-3 bg-[#00060a] border border-[#0d3347] rounded-xl shadow-2xl overflow-hidden"
    >
      <div className="w-full flex flex-wrap items-center justify-between gap-2 z-10 mb-1">
        <ModeSwitcherPills />
        <div className="flex items-center gap-1.5">
          <button
            onClick={onTestVoice}
            className="px-2 py-1 rounded bg-[#010d14] border border-[#1a5c7a] text-[10px] font-mono text-[#8ffcff] hover:bg-[#001f2e]"
          >
            TEST VOICE
          </button>
          <button
            onClick={onToggleListening}
            className={`px-2.5 py-1 rounded font-mono text-[10px] font-bold flex items-center gap-1 ${
              isListening
                ? 'bg-emerald-500/20 border border-emerald-400 text-emerald-300'
                : 'bg-cyan-500 text-slate-950'
            }`}
          >
            {isListening ? <Mic className="w-3 h-3 animate-pulse" /> : <MicOff className="w-3 h-3" />}
            <span>{isListening ? 'LISTENING' : 'SPEAK'}</span>
          </button>
        </div>
      </div>

      <canvas
        ref={canvasRef}
        width={400}
        height={400}
        className="w-[320px] h-[320px] sm:w-[370px] sm:h-[370px] max-w-full"
      />
    </div>
  );
};
