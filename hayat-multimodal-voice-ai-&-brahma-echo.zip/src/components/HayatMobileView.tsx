import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Radio,
  Send,
  Sparkles,
  Phone,
  MessageSquare,
  Music,
  Play,
  Pause,
  SkipForward,
  Battery,
  Wifi,
  Search,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  Moon,
  Clock,
} from 'lucide-react';

interface HayatMobileViewProps {
  onSpeak: (text: string, language?: string) => void;
  isSpeaking: boolean;
}

export const HayatMobileView: React.FC<HayatMobileViewProps> = ({ onSpeak, isSpeaking }) => {
  const [currentScreen, setCurrentScreen] = useState<'avatar' | 'whatsapp' | 'youtube'>('avatar');
  const [isWaving, setIsWaving] = useState(true);
  const [isListening, setIsListening] = useState(false);
  const [batteryLevel, setBatteryLevel] = useState(73);
  const [lastSpeech, setLastSpeech] = useState<string>(
    'Hello! I am Hayat, your voice-first personal AI assistant.'
  );
  const [adSkipped, setAdSkipped] = useState(false);
  const [isPlayingSong, setIsPlayingSong] = useState(false);
  const [showMoonTransition, setShowMoonTransition] = useState(false);
  const [whatsappState, setWhatsappState] = useState<'idle' | 'drafted' | 'sent'>('idle');

  // SVG Anime Avatar Canvas
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Waving hand toggle effect
  useEffect(() => {
    const timer = setInterval(() => {
      setIsWaving((prev) => !prev);
    }, 2800);
    return () => clearInterval(timer);
  }, []);

  // Canvas-based interactive Anime Girl Avatar with lip-sync and waving arm
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let t = 0;

    const render = () => {
      t += 0.04;
      const w = canvas.width;
      const h = canvas.height;
      const cx = w / 2;
      const cy = h / 2 - 10;

      ctx.clearRect(0, 0, w, h);

      // 1. Ambient Background Aura
      const auraGrad = ctx.createRadialGradient(cx, cy, 30, cx, cy, 140);
      auraGrad.addColorStop(0, 'rgba(6, 182, 212, 0.25)');
      auraGrad.addColorStop(0.6, 'rgba(236, 72, 153, 0.15)');
      auraGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = auraGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, 140, 0, Math.PI * 2);
      ctx.fill();

      // 2. Subtle Body Breathing
      const breath = Math.sin(t * 2) * 2.5;

      // Shoulders / Torso (Cute stylish peach/pink top)
      ctx.fillStyle = '#f472b6'; // pink-400
      ctx.beginPath();
      ctx.ellipse(cx, cy + 90 + breath, 52, 38, 0, 0, Math.PI * 2);
      ctx.fill();

      // Collarbone & Neck
      ctx.fillStyle = '#fde2d4'; // fair anime skin tone
      ctx.beginPath();
      ctx.rect(cx - 10, cy + 50 + breath, 20, 24);
      ctx.fill();

      // 3. Head & Chin
      ctx.beginPath();
      ctx.ellipse(cx, cy + 26 + breath, 36, 42, 0, 0, Math.PI * 2);
      ctx.fill();

      // Soft Anime Blushing Cheeks
      ctx.fillStyle = 'rgba(244, 114, 182, 0.35)';
      ctx.beginPath();
      ctx.ellipse(cx - 20, cy + 33 + breath, 7, 4, 0, 0, Math.PI * 2);
      ctx.ellipse(cx + 20, cy + 33 + breath, 7, 4, 0, 0, Math.PI * 2);
      ctx.fill();

      // 4. Large Expressive Anime Eyes
      const blink = Math.sin(t * 0.9) > 0.96;
      const eyeY = cy + 22 + breath;

      if (!blink) {
        // Eye whites
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.ellipse(cx - 14, eyeY, 8.5, 10, 0, 0, Math.PI * 2);
        ctx.ellipse(cx + 14, eyeY, 8.5, 10, 0, 0, Math.PI * 2);
        ctx.fill();

        // Dark Sparkly Irises
        ctx.fillStyle = '#1e1b4b'; // deep purple-indigo
        ctx.beginPath();
        ctx.arc(cx - 14, eyeY + 1, 6, 0, Math.PI * 2);
        ctx.arc(cx + 14, eyeY + 1, 6, 0, Math.PI * 2);
        ctx.fill();

        // Eye Light Reflections
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(cx - 16, eyeY - 1, 2.5, 0, Math.PI * 2);
        ctx.arc(cx + 12, eyeY - 1, 2.5, 0, Math.PI * 2);
        ctx.arc(cx - 13, eyeY + 3, 1.2, 0, Math.PI * 2);
        ctx.arc(cx + 15, eyeY + 3, 1.2, 0, Math.PI * 2);
        ctx.fill();

        // Eyelashes
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.arc(cx - 14, eyeY - 6, 9, Math.PI * 1.1, Math.PI * 1.9);
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(cx + 14, eyeY - 6, 9, Math.PI * 1.1, Math.PI * 1.9);
        ctx.stroke();
      } else {
        // Closed happy eye slits
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(cx - 14, eyeY, 8, Math.PI * 0.2, Math.PI * 0.8, true);
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(cx + 14, eyeY, 8, Math.PI * 0.2, Math.PI * 0.8, true);
        ctx.stroke();
      }

      // 5. Reactive Lip-Sync Mouth
      const mouthY = cy + 45 + breath;
      let mouthHeight = 3;
      if (isSpeaking) {
        mouthHeight = 5 + Math.abs(Math.sin(t * 9)) * 9;
      }

      ctx.fillStyle = '#e11d48'; // ruby-red lip
      ctx.beginPath();
      ctx.ellipse(cx, mouthY, 7, mouthHeight, 0, 0, Math.PI * 2);
      ctx.fill();

      // Inner mouth contrast
      if (mouthHeight > 5) {
        ctx.fillStyle = '#4c0519';
        ctx.beginPath();
        ctx.ellipse(cx, mouthY, 4.5, mouthHeight - 2, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // 6. Cute Long Dark Anime Hair & Bangs
      ctx.fillStyle = '#0f172a'; // rich dark hair
      // Back hair
      ctx.beginPath();
      ctx.ellipse(cx, cy + 24 + breath, 46, 52, 0, 0, Math.PI * 2);
      ctx.fill();

      // Hair strands over shoulders
      ctx.beginPath();
      ctx.ellipse(cx - 38, cy + 68 + breath, 12, 38, 0.2, 0, Math.PI * 2);
      ctx.ellipse(cx + 38, cy + 68 + breath, 12, 38, -0.2, 0, Math.PI * 2);
      ctx.fill();

      // Forehead bangs
      ctx.beginPath();
      ctx.moveTo(cx - 32, cy - 4 + breath);
      ctx.quadraticCurveTo(cx - 12, cy + 12 + breath, cx - 6, cy + 16 + breath);
      ctx.quadraticCurveTo(cx + 10, cy + 12 + breath, cx + 32, cy - 4 + breath);
      ctx.quadraticCurveTo(cx, cy - 22 + breath, cx - 32, cy - 4 + breath);
      ctx.fill();

      // Hair highlight shine
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(cx, cy - 6 + breath, 36, Math.PI * 1.25, Math.PI * 1.75);
      ctx.stroke();

      // 7. Waving Right Hand (Matching Video 1)
      const waveAngle = Math.sin(t * 8) * 0.35;
      const handBaseX = cx + 46;
      const handBaseY = cy + 50 + breath;

      ctx.save();
      ctx.translate(handBaseX, handBaseY);
      ctx.rotate(waveAngle);

      // Arm
      ctx.strokeStyle = '#fde2d4';
      ctx.lineWidth = 10;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(12, -26);
      ctx.stroke();

      // Cute Palm & Waving Fingers
      ctx.fillStyle = '#fde2d4';
      ctx.beginPath();
      ctx.arc(14, -32, 9, 0, Math.PI * 2);
      ctx.fill();

      // Animated sparkle near waving hand
      ctx.fillStyle = '#38bdf8';
      const sparkY = -42 + Math.sin(t * 4) * 4;
      ctx.beginPath();
      ctx.arc(20, sparkY, 2.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [isSpeaking, isWaving]);

  // Command 1: WhatsApp Neon Message
  const triggerWhatsAppNeon = () => {
    // Show Full Moon Transition animation as shown in Video 1
    setShowMoonTransition(true);
    setTimeout(() => {
      setShowMoonTransition(false);
      setCurrentScreen('whatsapp');
      setWhatsappState('drafted');
      const text =
        "I have drafted the message 'How are you?' for Neon. Shall I dispatch it now, boss?";
      setLastSpeech(text);
      onSpeak(text, 'en');
    }, 700);
  };

  // Confirm WhatsApp Send
  const confirmWhatsAppSend = () => {
    setWhatsappState('sent');
    const text = 'Message dispatched to Neon successfully, boss.';
    setLastSpeech(text);
    onSpeak(text, 'en');
  };

  // Command 2: YouTube Tum Hardafa Ho Song with Ad Skip
  const triggerYouTubeSong = () => {
    setCurrentScreen('youtube');
    setIsPlayingSong(true);
    setAdSkipped(false);

    const speech =
      "Playing 'Tum Hardafa Ho' on YouTube Music now. I will automatically skip any ads for you, boss.";
    setLastSpeech(speech);
    onSpeak(speech, 'en');

    // Simulate auto-ad skip in 3.5 seconds
    setTimeout(() => {
      setAdSkipped(true);
    }, 3500);
  };

  // Command 3: Greeting / Battery readout
  const triggerGreeting = () => {
    setCurrentScreen('avatar');
    const speech = `Good morning, boss! I am listening. By the way, your phone battery is at ${batteryLevel}% right now.`;
    setLastSpeech(speech);
    onSpeak(speech, 'en');
  };

  // Command 4: Hayat Intro (English)
  const triggerIntro = () => {
    setCurrentScreen('avatar');
    const speech =
      'Greetings! I am Hayat, your personal AI assistant. I can automate your phone, answer your queries, and control your media.';
    setLastSpeech(speech);
    onSpeak(speech, 'en');
  };

  // Command 5: How are you
  const triggerKaisiHo = () => {
    setCurrentScreen('avatar');
    const speech =
      'I am operating at peak efficiency! How are you doing today? I am ready to help with your workflows.';
    setLastSpeech(speech);
    onSpeak(speech, 'en');
  };

  return (
    <div className="flex flex-col lg:flex-row items-center justify-center gap-6 p-4 sm:p-6 bg-[#07090e]/95 rounded-2xl border border-slate-800 shadow-2xl">
      {/* LEFT: Realistic Phone Mockup (Video 1 Recreated) */}
      <div className="w-[310px] sm:w-[330px] h-[640px] bg-slate-950 rounded-[48px] p-3 border-4 border-slate-700 shadow-2xl relative flex flex-col overflow-hidden shrink-0">
        {/* Dynamic Island / Speaker */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-4 bg-slate-900 rounded-full z-30 flex items-center justify-center">
          <div className="w-2.5 h-2.5 rounded-full bg-slate-950 mr-2" />
          <div className="w-1.5 h-1.5 rounded-full bg-pink-500/70 animate-pulse" />
        </div>

        {/* Inner Phone Screen */}
        <div className="w-full h-full bg-[#090d16] rounded-[38px] overflow-hidden flex flex-col relative text-slate-100">
          {/* Status Bar */}
          <div className="h-7 w-full flex items-center justify-between px-5 pt-1 text-[11px] font-mono z-20">
            <span className="font-semibold text-slate-200">10:42</span>
            <div className="flex items-center gap-1.5 text-slate-300">
              <Wifi className="w-3 h-3 text-cyan-400" />
              <span className="text-[10px]">5G</span>
              <span className="text-[10px]">{batteryLevel}%</span>
              <Battery className="w-3.5 h-3.5 text-emerald-400" />
            </div>
          </div>

          {/* Full Moon Video 1 Animated Transition Overlay */}
          {showMoonTransition && (
            <div className="absolute inset-0 bg-slate-950/90 z-40 flex items-center justify-center animate-fade-in">
              <div className="w-48 h-48 rounded-full bg-slate-200 shadow-2xl shadow-cyan-400/50 flex items-center justify-center overflow-hidden border-2 border-white/80 animate-spin-slow">
                <Moon className="w-32 h-32 text-slate-400 opacity-60" />
              </div>
            </div>
          )}

          {/* SCREEN 1: HAYAT VIRTUAL AVATAR (Default Assistant View) */}
          {currentScreen === 'avatar' && (
            <div className="flex-1 flex flex-col justify-between p-3 z-10">
              {/* Header Title */}
              <div className="text-center mt-2">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-pink-500/10 border border-pink-500/30 rounded-full text-[11px] font-mono text-pink-300 font-semibold shadow">
                  <Sparkles className="w-3 h-3 text-pink-400 animate-spin" />
                  <span>HAYAT · VIRTUAL ASSISTANT</span>
                </div>
                <div className="text-xs text-slate-400 mt-1 font-sans">
                  &quot;Good evening, boss!&quot;
                </div>
              </div>

              {/* Canvas Anime Character */}
              <div className="relative my-auto flex items-center justify-center">
                <canvas
                  ref={canvasRef}
                  width={280}
                  height={260}
                  className="w-[260px] h-[240px] drop-shadow-2xl"
                />
              </div>

              {/* Live Speech Bubble on Screen */}
              <div className="p-3 bg-slate-900/90 border border-slate-700/80 rounded-2xl text-[11px] text-pink-100 shadow-lg mb-2 relative">
                <div className="flex items-center gap-1.5 font-bold text-pink-400 mb-1 text-[10px] font-mono">
                  <span className="w-2 h-2 rounded-full bg-pink-400 animate-ping" />
                  HAYAT SPEAKING:
                </div>
                <p className="leading-snug italic font-sans">&quot;{lastSpeech}&quot;</p>
              </div>

              {/* Bottom Phone Action Bar */}
              <div className="flex items-center justify-between px-2 pb-2">
                <button
                  onClick={triggerGreeting}
                  title="Battery & Status"
                  className="flex flex-col items-center gap-1 text-[10px] text-slate-400 hover:text-white"
                >
                  <div className="w-9 h-9 rounded-xl bg-slate-800 flex items-center justify-center text-cyan-400">
                    <Battery className="w-4 h-4" />
                  </div>
                  <span>{batteryLevel}%</span>
                </button>

                {/* Central Red Record Button (Like in Video 1) */}
                <button
                  onClick={triggerGreeting}
                  className="w-12 h-12 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg shadow-rose-600/40 active:scale-95 transition-all"
                >
                  <Mic className="w-5 h-5 animate-pulse" />
                </button>

                <button
                  onClick={triggerYouTubeSong}
                  title="Play Tum Hardafa Ho"
                  className="flex flex-col items-center gap-1 text-[10px] text-slate-400 hover:text-white"
                >
                  <div className="w-9 h-9 rounded-xl bg-slate-800 flex items-center justify-center text-rose-400">
                    <Play className="w-4 h-4" />
                  </div>
                  <span>Music</span>
                </button>
              </div>
            </div>
          )}

          {/* SCREEN 2: WHATSAPP NEON MESSAGE (Video 1 Recreated) */}
          {currentScreen === 'whatsapp' && (
            <div className="flex-1 flex flex-col bg-[#0b141b] z-10 justify-between">
              {/* WhatsApp Header */}
              <div className="bg-[#1f2c34] p-3 flex items-center justify-between border-b border-slate-700/60">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center text-white font-bold text-xs">
                    N
                  </div>
                  <div>
                    <div className="font-semibold text-xs text-slate-100">Neon</div>
                    <div className="text-[9px] text-emerald-400">online</div>
                  </div>
                </div>
                <button
                  onClick={() => setCurrentScreen('avatar')}
                  className="text-[10px] text-slate-400 font-mono hover:text-white"
                >
                  ✕ CLOSE
                </button>
              </div>

              {/* Chat Messages */}
              <div className="flex-1 p-3 overflow-y-auto space-y-2 text-[11px]">
                <div className="max-w-[80%] bg-[#1f2c34] text-slate-200 p-2 rounded-xl rounded-bl-none">
                  Hey bro, is the project ready?
                  <span className="text-[8px] opacity-60 block text-right">10:14 AM</span>
                </div>

                {whatsappState !== 'idle' && (
                  <div className="max-w-[80%] ml-auto bg-[#005c4b] text-white p-2 rounded-xl rounded-br-none shadow">
                    How are you?
                    <span className="text-[8px] opacity-70 block text-right">
                      {whatsappState === 'sent' ? '10:15 AM · ✓✓' : 'Drafting...'}
                    </span>
                  </div>
                )}
              </div>

              {/* Hayat Confirmation Banner */}
              {whatsappState === 'drafted' && (
                <div className="p-3 bg-[#1f2c34] border-t border-emerald-500/40 text-xs">
                  <div className="text-pink-300 font-medium mb-2">
                    &quot;Shall I dispatch this message now, boss?&quot;
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={confirmWhatsAppSend}
                      className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg transition-colors"
                    >
                      Confirm &amp; Send Now
                    </button>
                    <button
                      onClick={() => setCurrentScreen('avatar')}
                      className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg text-xs"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              {whatsappState === 'sent' && (
                <div className="p-2.5 bg-emerald-950/60 border-t border-emerald-500/30 text-[11px] text-emerald-300 text-center font-mono">
                  Message dispatched to Neon successfully!
                </div>
              )}
            </div>
          )}

          {/* SCREEN 3: YOUTUBE SONG & AD SKIPPER (Video 1 Recreated) */}
          {currentScreen === 'youtube' && (
            <div className="flex-1 flex flex-col bg-slate-950 z-10 justify-between">
              {/* Header */}
              <div className="p-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs">
                <span className="font-bold text-rose-500">YouTube Music</span>
                <button onClick={() => setCurrentScreen('avatar')} className="text-slate-400 text-xs">
                  ✕ Close
                </button>
              </div>

              {/* Video Player */}
              <div className="p-3 space-y-3">
                <div className="w-full aspect-video bg-gradient-to-tr from-rose-950 to-slate-900 rounded-xl border border-slate-800 flex flex-col items-center justify-center relative overflow-hidden shadow-inner">
                  {/* Album Cover Art */}
                  <img
                    src="https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=500&q=80"
                    alt="Tum Hardafa Ho"
                    className="w-full h-full object-cover opacity-60"
                  />
                  <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center p-3 text-center">
                    <span className="text-sm font-bold text-white drop-shadow">
                      Tum Hardafa Ho (Slowed + Reverb)
                    </span>
                    <span className="text-[10px] text-slate-300 font-mono mt-0.5">
                      Lost Stories x Zaeden
                    </span>
                  </div>

                  {/* Ad Skipper Alert Overlay */}
                  {!adSkipped && (
                    <div className="absolute bottom-2 right-2 px-2.5 py-1 bg-amber-500 text-slate-950 rounded text-[10px] font-bold font-mono animate-bounce shadow">
                      Ad Playing · Auto Skipping in 3s...
                    </div>
                  )}

                  {adSkipped && (
                    <div className="absolute bottom-2 right-2 px-2 py-0.5 bg-emerald-500/90 text-white rounded text-[9px] font-mono">
                      ✔ Ad Skipped by Hayat
                    </div>
                  )}
                </div>

                {/* Song Meta */}
                <div>
                  <h4 className="font-bold text-xs text-white">Tum Hardafa Ho (Official Audio)</h4>
                  <p className="text-[10px] text-slate-400">Hayat Auto-Music Player</p>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-rose-500 h-full w-[45%]" />
                </div>
                <div className="flex justify-between text-[9px] font-mono text-slate-500">
                  <span>1:42</span>
                  <span>3:48</span>
                </div>

                {/* Playback Controls */}
                <div className="flex items-center justify-center gap-4">
                  <button
                    onClick={() => setIsPlayingSong(!isPlayingSong)}
                    className="w-10 h-10 rounded-full bg-white text-slate-950 flex items-center justify-center shadow-lg"
                  >
                    {isPlayingSong ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                  </button>
                </div>
              </div>

              {/* Bottom Assistant Note */}
              <div className="p-2.5 bg-slate-900 border-t border-slate-800 text-[10px] text-pink-300 text-center font-mono">
                Now playing on YouTube Music with auto ad-skip active!
              </div>
            </div>
          )}

          {/* Navigation Pill */}
          <div className="h-5 w-full flex items-center justify-center z-20 pb-1">
            <button
              onClick={() => setCurrentScreen('avatar')}
              className="w-24 h-1 bg-slate-500/80 rounded-full hover:bg-white transition-colors"
            />
          </div>
        </div>
      </div>

      {/* RIGHT: Video 1 Voice Command triggers & Interactive Deck */}
      <div className="flex-1 flex flex-col justify-between max-w-xl space-y-4">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-pink-400 animate-spin" />
              <h3 className="font-display font-bold text-base text-slate-100 uppercase tracking-wide">
                Hayat Virtual Voice Assistant (Mobile Edition)
              </h3>
            </div>
            <span className="text-xs font-mono text-cyan-400 font-semibold">
              VOICE ENGINE ACTIVE
            </span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed mb-4">
            Interactive virtual mobile assistant with animated waving avatar, natural voice speech,
            WhatsApp intent drafting with confirmation, and YouTube song player with automated ad-skipping.
            Understands multilingual spoken commands and responds in clear voice.
          </p>

          {/* Video 1 Exact Voice Scenarios */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
            {/* Scenario 1: WhatsApp Neon */}
            <div className="p-3.5 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-emerald-400 font-semibold">
                <span className="flex items-center gap-1">
                  <MessageSquare className="w-3.5 h-3.5" /> WHATSAPP NEON
                </span>
                <span className="text-[10px] text-slate-500">Video 1 Intent</span>
              </div>
              <p className="text-[11px] text-slate-300 italic">
                &quot;Send a WhatsApp message to Neon: How are you?&quot;
              </p>
              <button
                onClick={triggerWhatsAppNeon}
                className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-mono font-bold text-xs rounded transition-all shadow"
              >
                DRAFT WHATSAPP MESSAGE
              </button>
            </div>

            {/* Scenario 2: YouTube Tum Hardafa Ho */}
            <div className="p-3.5 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-rose-400 font-semibold">
                <span className="flex items-center gap-1">
                  <Music className="w-3.5 h-3.5" /> YOUTUBE &amp; AD-SKIP
                </span>
                <span className="text-[10px] text-slate-500">Video 1 Intent</span>
              </div>
              <p className="text-[11px] text-slate-300 italic">
                &quot;Play Tum Hardafa Ho on YouTube and skip ads.&quot;
              </p>
              <button
                onClick={triggerYouTubeSong}
                className="w-full py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-mono font-bold text-xs rounded transition-all shadow"
              >
                PLAY SONG &amp; SKIP ADS
              </button>
            </div>

            {/* Scenario 3: Battery & Status */}
            <div className="p-3.5 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-cyan-400 font-semibold">
                <span className="flex items-center gap-1">
                  <Battery className="w-3.5 h-3.5" /> BATTERY READOUT
                </span>
                <span className="text-[10px] text-slate-500">73%</span>
              </div>
              <p className="text-[11px] text-slate-300 italic">
                &quot;Good morning, Hayat! Check battery status.&quot;
              </p>
              <button
                onClick={triggerGreeting}
                className="w-full py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-mono font-bold text-xs rounded transition-all shadow"
              >
                CHECK BATTERY (73%)
              </button>
            </div>

            {/* Scenario 4: Meet Hayat Intro */}
            <div className="p-3.5 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-pink-400 font-semibold">
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> SYSTEM INTRODUCTION
                </span>
                <span className="text-[10px] text-slate-500">Video 1</span>
              </div>
              <p className="text-[11px] text-slate-300 italic">
                &quot;Introduce yourself to everyone.&quot;
              </p>
              <button
                onClick={triggerIntro}
                className="w-full py-1.5 bg-pink-600 hover:bg-pink-500 text-white font-mono font-bold text-xs rounded transition-all shadow"
              >
                PLAY INTRODUCTION
              </button>
            </div>
          </div>
        </div>

        {/* Live Audio Dialogue Box */}
        <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs">
          <div className="text-[10px] text-slate-500 mb-1 flex items-center justify-between">
            <span>LAST VOICE OUTPUT (ENGLISH):</span>
            <span className="text-pink-400">{isSpeaking ? 'SPEAKING NOW...' : 'STANDBY'}</span>
          </div>
          <p className="text-pink-200 font-sans italic text-xs leading-relaxed">&quot;{lastSpeech}&quot;</p>
        </div>
      </div>
    </div>
  );
};
