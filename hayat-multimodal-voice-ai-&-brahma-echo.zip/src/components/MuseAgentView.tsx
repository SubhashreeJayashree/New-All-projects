import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Shield,
  Globe,
  CheckCircle2,
  Terminal,
  Calendar,
  Mail,
  ShoppingBag,
  Cpu,
  Send,
  Eye,
  Lock,
  Play,
  Pause,
  Radio,
  Server,
  Smartphone,
  Camera,
  AlertTriangle,
  Layers,
  FileText,
  HelpCircle,
  Music,
  Mic,
  Square,
  Upload,
} from 'lucide-react';

export type MuseSubTab =
  | 'first_prompt'
  | 'personal_vm'
  | 'connectors'
  | 'mark54_vps'
  | 'mark54_quiz_review'
  | 'ai_audio_music';

interface MuseAgentViewProps {
  initialTab?: MuseSubTab;
  activeGoal?: string;
  onSpeak?: (text: string) => void;
  onClose?: () => void;
  onExecuteTranscript?: (text: string) => void;
}

export const MuseAgentView: React.FC<MuseAgentViewProps> = ({
  initialTab = 'first_prompt',
  activeGoal,
  onSpeak,
  onClose,
  onExecuteTranscript,
}) => {
  const [subTab, setSubTab] = useState<MuseSubTab>(initialTab);
  const [firstPromptExecuted, setFirstPromptExecuted] = useState<boolean>(true);
  const [vmStep, setVmStep] = useState<number>(3);
  const [sentryActive, setSentryActive] = useState<boolean>(true);
  const [approvalStatus, setApprovalStatus] = useState<'pending' | 'approved'>('pending');

  // Mark 54 Interactive Quiz state (from Mark-LIV ui.py show_quiz)
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);

  // Audio Transcription state (gemini-3.5-transcribe)
  const [isRecordingAudio, setIsRecordingAudio] = useState<boolean>(false);
  const [isTranscribing, setIsTranscribing] = useState<boolean>(false);
  const [transcribedText, setTranscribedText] = useState<string>('');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Lyria Music Generation state (lyria-3-clip-preview / lyria-3-pro-preview)
  const [musicPrompt, setMusicPrompt] = useState<string>(
    'Futuristic Jarvis Mark 54 holographic cockpit synthwave with warm sub-bass and crisp arpeggios'
  );
  const [musicMode, setMusicMode] = useState<'clip' | 'pro'>('clip');
  const [isGeneratingMusic, setIsGeneratingMusic] = useState<boolean>(false);
  const [generatedMusic, setGeneratedMusic] = useState<{
    model: string;
    description: string;
    audioDataUrl: string | null;
  } | null>(null);
  const [isPlayingSynth, setIsPlayingSynth] = useState<boolean>(false);
  const synthIntervalRef = useRef<any>(null);
  const synthCtxRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    if (initialTab) setSubTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    return () => {
      if (synthIntervalRef.current) clearInterval(synthIntervalRef.current);
      if (synthCtxRef.current) synthCtxRef.current.close().catch(() => {});
    };
  }, []);

  // Aleric Heck's "First Prompt You Should Use" for Meta Muse (Video 4: XK9GlQ5Btk0)
  const ALERIC_FIRST_PROMPT = `Act as my autonomous Chief of Staff and Personal AI Agent (Meta Muse).
1. MEMORY & CONTEXT: Index my connected apps (WhatsApp, Instagram, Facebook, Gmail, Google Calendar) to understand my schedule, preferences, key relationships, and active projects.
2. GOAL-ORIENTED EXECUTION: Do not wait for step-by-step micromanagement. When I state a goal, autonomously plan and execute the multi-step workflow inside my Private Personal Virtual Machine.
3. BOTTLENECK ELIMINATION: Identify my top 3 daily time-drains (inbox triage, scheduling, deal/flight tracking) and automate them in the background.
4. HUMAN-IN-THE-LOOP GATE: Pause and ask for my explicit voice approval ONLY before executing financial purchases or sending external messages.`;

  const runFirstPrompt = () => {
    setFirstPromptExecuted(true);
    setSubTab('first_prompt');
    onSpeak?.(
      'Executing the Meta Muse First Prompt. I have indexed your connected apps into private memory, configured your Personal Virtual Machine, and activated goal-oriented autonomous workflows.'
    );
  };

  // Mark 54 Interactive Quiz questions
  const QUIZ_QUESTIONS = [
    {
      q: '1. How does TypeSafe Jev AI (System 1) achieve sub-100ms routing latency?',
      options: [
        'Autoregressive chain-of-thought token generation',
        'Non-autoregressive single forward pass trained with RLCD (Noul, Choice, Score)',
        'Cloud database polling every 5 seconds',
      ],
      correct: 1,
    },
    {
      q: '2. Where does Meta Muse execute autonomous multi-step web & app workflows?',
      options: [
        'Inside an isolated, E2E encrypted Personal Virtual Machine (Private Processing)',
        'Public unencrypted browser cookies',
        'Manual copy-paste by the user',
      ],
      correct: 0,
    },
    {
      q: '3. How does Jarvis Mark 54 (Mark LIV) drive its 3D holographic head lip-sync?',
      options: [
        'Pre-rendered MP4 video loops',
        'Language-free phoneme/viseme schedule + MediaPipe 468-vertex canonical face & jaw pivot rig',
        'Static 2D PNG sprite swaps',
      ],
      correct: 1,
    },
  ];

  // Mark 54 Document Review findings (matching ui.py show_review severity: serious / caution / note)
  const REVIEW_FINDINGS = [
    {
      severity: 'serious',
      heading: 'Unapproved External Payment Intent Detected',
      detail: 'Autonomous shopping agent attempted checkout ($249.00) without human confirmation gate.',
      quote: 'dispatch_checkout(card_token, auto_confirm=True)',
      suggestion: 'Enforce Meta Muse Rule #4: Require explicit operator voice approval before payment execution.',
    },
    {
      severity: 'caution',
      heading: 'System 2 LLM Fallback Latency Spike (620ms)',
      detail: 'Routing simple ADB intents through autoregressive LLM adds 580ms unnecessary overhead.',
      quote: 'await ai.models.generateContent({ model: "gemini-3.8-flash", contents: "call mom" })',
      suggestion: 'Gate deterministic intents via System 1 Jev AI (>0.92 confidence) in <45ms.',
    },
    {
      severity: 'note',
      heading: 'Mark LIV 24/7 VPS & Telegram Bridge Verified',
      detail: 'Remote Telegram daemon (@HayatMark54Bot) and OpenCV Security Sentry heartbeat nominal.',
      quote: 'SYS: VPS daemon active. Uptime 99.98%.',
      suggestion: 'Keep wake-word and Telegram OTP forwarding active for headless tasks.',
    },
  ];

  // Start / Stop Microphone Recording for gemini-3.5-transcribe
  const toggleAudioRecording = async () => {
    if (isRecordingAudio) {
      mediaRecorderRef.current?.stop();
      setIsRecordingAudio(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(audioChunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = async () => {
          const base64 = reader.result as string;
          await runGeminiTranscribe(base64, blob.type || 'audio/webm');
        };
        reader.readAsDataURL(blob);
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecordingAudio(true);
    } catch (err) {
      // Fallback simulated recording if mic permission blocked in iframe
      await runGeminiTranscribe('data:audio/webm;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=', 'audio/webm');
    }
  };

  const runGeminiTranscribe = async (audioBase64: string, mimeType: string) => {
    setIsTranscribing(true);
    try {
      const res = await fetch('/api/gemini/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ audioBase64, mimeType }),
      });
      const data = await res.json();
      const text = data.transcript || 'Open call log and call my Mom';
      setTranscribedText(text);
      onSpeak?.(`Transcription complete via Gemini 3.5 Transcribe: ${text}`);
    } catch (e) {
      setTranscribedText('Open call log and call my Mom');
    } finally {
      setIsTranscribing(false);
    }
  };

  // Generate AI Music with lyria-3-clip-preview / lyria-3-pro-preview
  const handleGenerateMusic = async () => {
    setIsGeneratingMusic(true);
    try {
      const res = await fetch('/api/gemini/music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: musicPrompt, mode: musicMode }),
      });
      const data = await res.json();
      setGeneratedMusic({
        model: data.model || (musicMode === 'pro' ? 'lyria-3-pro-preview' : 'lyria-3-clip-preview'),
        description: data.description || `Generated music track for: "${musicPrompt}"`,
        audioDataUrl: data.audioDataUrl || null,
      });
      onSpeak?.(
        `Music track generated with ${
          musicMode === 'pro' ? 'Lyria 3 Pro' : 'Lyria 3 Clip'
        }. Starting playback now.`
      );
      if (!data.audioDataUrl) {
        startSynthPlayback();
      }
    } finally {
      setIsGeneratingMusic(false);
    }
  };

  const startSynthPlayback = () => {
    stopSynthPlayback();
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      synthCtxRef.current = ctx;
      setIsPlayingSynth(true);

      const notes = [220, 261.63, 329.63, 392.0, 440, 523.25, 392.0, 329.63];
      let step = 0;
      synthIntervalRef.current = setInterval(() => {
        if (ctx.state === 'suspended') ctx.resume();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = step % 2 === 0 ? 'sawtooth' : 'triangle';
        osc.frequency.setValueAtTime(notes[step % notes.length], ctx.currentTime);
        gain.gain.setValueAtTime(0.06, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.3);
        step++;
      }, 320);
    } catch (e) {
      // ignore
    }
  };

  const stopSynthPlayback = () => {
    if (synthIntervalRef.current) {
      clearInterval(synthIntervalRef.current);
      synthIntervalRef.current = null;
    }
    setIsPlayingSynth(false);
  };

  return (
    <div className="bg-[#010d14]/95 border border-[#1a5c7a] rounded-xl p-4 sm:p-5 shadow-2xl text-slate-100 space-y-5">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#0d3347]">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#001f2e] border border-[#00d4ff]/50 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-[#00d4ff]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-mono font-bold tracking-wider text-[#8ffcff]">
                META MUSE AGENT · ALERIC FIRST PROMPT · MARK LIV BOARD
              </h2>
              <span className="px-2 py-0.5 text-[10px] font-mono bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 rounded">
                PRIVATE VM ONLINE
              </span>
            </div>
            <p className="text-[11px] text-[#5ab8cc] font-mono">
              Videos 3, 4 &amp; 5: Meta Muse Personal VM · First Prompt · Mark 54 VPS, Quiz, Review &amp; Lyria/Transcribe Studio
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {[
            { id: 'first_prompt', label: '1. First Prompt (Aleric)' },
            { id: 'personal_vm', label: '2. Personal VM (Meta Muse)' },
            { id: 'connectors', label: '3. App Connectors' },
            { id: 'mark54_vps', label: '4. Mark 54 VPS & Sentry' },
            { id: 'mark54_quiz_review', label: '5. Mark 54 Quiz & Review' },
            { id: 'ai_audio_music', label: '6. Transcribe & Lyria Music' },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setSubTab(t.id as MuseSubTab)}
              className={`px-2.5 py-1.5 rounded text-[11px] font-mono transition-all ${
                subTab === t.id
                  ? 'bg-[#00d4ff] text-[#00060a] font-bold shadow-[0_0_10px_rgba(0,212,255,0.4)]'
                  : 'bg-[#000d14] text-[#5ab8cc] border border-[#0d3347] hover:border-[#00d4ff]/50 hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
          {onClose && (
            <button
              onClick={onClose}
              className="px-2.5 py-1.5 rounded bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-500/40 text-[11px] font-mono font-bold"
            >
              ✕ Close
            </button>
          )}
        </div>
      </div>

      {/* TAB 1: ALERIC HECK'S "FIRST PROMPT YOU SHOULD USE" ON META MUSE (Video 4: XK9GlQ5Btk0) */}
      {subTab === 'first_prompt' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-7 space-y-4">
            <div className="p-4 rounded-xl bg-[#000d14] border border-[#1a5c7a] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-[#00d4ff] uppercase flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  Video 4 (Aleric Heck): The First Prompt You Should Use on Meta Muse
                </span>
                <button
                  onClick={runFirstPrompt}
                  className="px-3 py-1 rounded bg-[#00d4ff] hover:bg-cyan-300 text-[#00060a] font-mono text-xs font-bold flex items-center gap-1 shadow"
                >
                  <Play className="w-3.5 h-3.5" />
                  EXECUTE FIRST PROMPT
                </button>
              </div>
              <pre className="p-3.5 rounded-lg bg-[#00060a] border border-[#0d3347] text-xs font-mono text-[#8ffcff] whitespace-pre-wrap leading-relaxed">
                {ALERIC_FIRST_PROMPT}
              </pre>
            </div>

            <div className="p-4 rounded-xl bg-[#000d14] border border-[#0d3347] space-y-3">
              <div className="text-xs font-mono font-bold text-[#00ff88] uppercase flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                Autonomous Chief-of-Staff Memory &amp; Bottleneck Setup Active
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-[#00060a] border border-[#0d3347]">
                  <div className="font-mono text-[#00d4ff] font-bold mb-1">1. UNIFIED MEMORY</div>
                  <p className="text-slate-300">
                    Indexed 1,420 WhatsApp threads, Instagram DMs, Calendar events &amp; emails inside Private Processing.
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-[#00060a] border border-[#0d3347]">
                  <div className="font-mono text-[#ffcc00] font-bold mb-1">2. GOAL AUTONOMY</div>
                  <p className="text-slate-300">
                    Eliminated prompt-by-prompt micromanagement; executes full multi-step goals in Personal VM.
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-[#00060a] border border-[#0d3347]">
                  <div className="font-mono text-[#ff6b00] font-bold mb-1">3. HUMAN GATE</div>
                  <p className="text-slate-300">
                    Pauses for explicit voice confirmation before financial checkouts or external dispatches.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 space-y-4">
            <div className="p-4 rounded-xl bg-[#000d14] border border-[#0d3347] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-white uppercase">
                  LIVE AUTONOMOUS WORKFLOWS
                </span>
                <span className="text-[11px] font-mono text-[#00ff88]">● 3 ACTIVE</span>
              </div>

              <div className="space-y-2.5 text-xs">
                <div className="p-3 rounded-lg bg-[#00060a] border border-[#0d3347] flex items-start gap-3">
                  <Calendar className="w-4 h-4 text-[#00d4ff] shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="font-semibold text-white">Calendar &amp; Inbox Triage</div>
                    <div className="text-slate-400">
                      Resolved 2 meeting conflicts &amp; prepared 4 priority replies.
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-[#00ff88]">DONE</span>
                </div>

                <div className="p-3 rounded-lg bg-[#00060a] border border-[#0d3347] flex items-start gap-3">
                  <ShoppingBag className="w-4 h-4 text-[#ffcc00] shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="font-semibold text-white">Autonomous Deal &amp; Flight Tracker</div>
                    <div className="text-slate-400">
                      Tracked 22% price drop on Sony WH-1000XM5 across 6 verified stores.
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-[#00d4ff]">READY</span>
                </div>

                <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[11px] text-amber-300 font-bold flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5" />
                      HUMAN-IN-THE-LOOP APPROVAL GATE
                    </span>
                    <span className="text-[10px] font-mono text-amber-400">
                      {approvalStatus === 'approved' ? 'APPROVED ✔' : 'AWAITING VOICE/CLICK'}
                    </span>
                  </div>
                  <p className="text-slate-300 text-xs">
                    {activeGoal || 'Confirm booking & dispatch itinerary to Neon on WhatsApp?'}
                  </p>
                  {approvalStatus === 'pending' ? (
                    <button
                      onClick={() => {
                        setApprovalStatus('approved');
                        onSpeak?.('Action approved and executed inside Meta Muse Personal Virtual Machine.');
                      }}
                      className="px-3 py-1.5 rounded bg-[#00ff88] hover:bg-emerald-400 text-[#00060a] font-mono text-xs font-bold"
                    >
                      ✓ Approve Action
                    </button>
                  ) : (
                    <div className="text-xs font-mono text-[#00ff88] font-semibold">
                      ✔ Approved &amp; dispatched inside Personal Virtual Machine.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: META MUSE PERSONAL VIRTUAL MACHINE (Video 3: ORNMTHvC45o) */}
      {subTab === 'personal_vm' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-8 p-4 rounded-xl bg-[#00060a] border border-[#1a5c7a] space-y-4">
            <div className="flex items-center justify-between border-b border-[#0d3347] pb-3">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <span className="ml-2 text-xs font-mono text-[#00d4ff] flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5" />
                  muse://personal-virtual-machine/autonomous-browser
                </span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#001f2e] text-[#8ffcff] border border-[#00d4ff]/40">
                PRIVATE PROCESSING ENCLAVE
              </span>
            </div>

            <div className="p-4 rounded-xl bg-[#010d14] border border-[#0d3347] space-y-3 font-mono text-xs">
              <div className="text-[#5ab8cc]">
                ACTIVE GOAL:{' '}
                <span className="text-white font-bold">
                  {activeGoal || 'Multi-Step Web Browsing, Price Comparison & Schedule Sync'}
                </span>
              </div>
              <div className="space-y-2">
                {[
                  'Spinning up hardware-isolated Personal Virtual Machine (Private Processing)...',
                  'Authenticating memory connectors: WhatsApp, Instagram, Google Calendar, Gmail...',
                  'Browsing live web sources, comparing flight/shopping deals & extracting schedule...',
                  'Synthesizing action plan and staging 1-click Human-in-the-Loop approval...',
                ].map((stepText, idx) => (
                  <div
                    key={idx}
                    onClick={() => setVmStep(idx)}
                    className={`p-2.5 rounded border flex items-center justify-between cursor-pointer ${
                      idx <= vmStep
                        ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200'
                        : 'bg-[#00060a] border-[#0d3347] text-slate-500'
                    }`}
                  >
                    <span>
                      [Step 0{idx + 1}] {stepText}
                    </span>
                    <span className="text-[#00ff88] font-bold">{idx <= vmStep ? '✔ COMPLETE' : 'PENDING'}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 p-4 rounded-xl bg-[#000d14] border border-[#0d3347] space-y-3 text-xs">
            <div className="font-mono font-bold text-[#00d4ff] uppercase flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Video 3 (Meta): Meet Muse Architecture
            </div>
            <p className="text-slate-300 leading-relaxed">
              Meta Muse runs inside your dedicated Personal Virtual Machine using Private Processing. It remembers your context across apps and completes complex multi-step tasks autonomously.
            </p>
            <div className="p-3 rounded-lg bg-[#00060a] border border-[#0d3347] space-y-1.5 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400">VM Isolation:</span>
                <span className="text-[#00ff88]">Confidential Compute</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Personal Memory:</span>
                <span className="text-[#00d4ff]">E2E Encrypted Graph</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Ray-Ban Meta Glasses:</span>
                <span className="text-[#00ff88]">Synced (Live Vision)</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CONNECTED APPS & MEMORY CONNECTORS */}
      {subTab === 'connectors' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
          {[
            { name: 'WhatsApp ADB Bridge', status: 'Connected · Real-time Messaging & Voice Call', color: 'text-[#00ff88]' },
            { name: 'Instagram & Facebook', status: 'Connected · Social Memory, Reels & DMs', color: 'text-pink-400' },
            { name: 'Google Calendar & Gmail', status: 'Connected · Autonomous Triage & Scheduling', color: 'text-[#00d4ff]' },
            { name: 'Ray-Ban Meta / Astra Glasses', status: 'Connected · Real-Time Camera Vision Stream', color: 'text-purple-400' },
            { name: 'Telegram Remote (@HayatMark54Bot)', status: 'Connected · Mark LIV 24/7 VPS Bot Bridge', color: 'text-sky-400' },
            { name: 'Autonomous Shopping & Deals', status: 'Connected · Price Drop & Flight Tracker', color: 'text-[#ffcc00]' },
          ].map((conn, i) => (
            <div key={i} className="p-4 rounded-xl bg-[#000d14] border border-[#0d3347] flex flex-col justify-between gap-2">
              <div className="flex items-center justify-between">
                <span className={`font-mono font-bold ${conn.color}`}>{conn.name}</span>
                <span className="w-2 h-2 rounded-full bg-[#00ff88]" />
              </div>
              <p className="text-slate-400">{conn.status}</p>
            </div>
          ))}
        </div>
      )}

      {/* TAB 4: JARVIS MARK 54 VPS 24/7, TELEGRAM REMOTE & SECURITY SENTRY (Video 5: mahfxobjr9g) */}
      {subTab === 'mark54_vps' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-[#000d14] border border-[#0d3347] space-y-2">
            <div className="font-mono font-bold text-[#00d4ff] flex items-center gap-2">
              <Server className="w-4 h-4" />
              24/7 VPS CLOUD DAEMON &amp; TELEGRAM REMOTE
            </div>
            <p className="text-slate-300">
              Jarvis Mark 54 runs 24/7 on a cloud VPS and accepts remote commands from Telegram even when your desktop is offline.
            </p>
            <div className="p-2.5 rounded bg-[#00060a] border border-[#0d3347] font-mono text-[11px] text-[#00ff88]">
              ● Telegram Bot: @HayatMark54Bot [CONNECTED · 24/7 VPS]
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#000d14] border border-[#0d3347] space-y-2">
            <div className="font-mono font-bold text-[#ffcc00] flex items-center gap-2">
              <Camera className="w-4 h-4" />
              MARK 54 CAMERA SECURITY SENTRY
            </div>
            <p className="text-slate-300">
              OpenCV + Gemini Live camera motion detection, presence awareness, and instant Telegram intrusion alerts.
            </p>
            <button
              onClick={() => {
                setSentryActive(!sentryActive);
                onSpeak?.(
                  !sentryActive
                    ? 'Mark 54 Security Sentry armed. Monitoring camera for motion and presence.'
                    : 'Security Sentry disarmed.'
                );
              }}
              className={`w-full py-2 rounded font-mono font-bold transition-all ${
                sentryActive
                  ? 'bg-emerald-500/20 border border-[#00ff88] text-[#00ff88]'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              {sentryActive ? '🛡️ SENTRY ARMED · MOTION LOCKED' : 'ARM SECURITY SENTRY'}
            </button>
          </div>

          <div className="p-4 rounded-xl bg-[#000d14] border border-[#0d3347] space-y-2">
            <div className="font-mono font-bold text-[#ff6b00] flex items-center gap-2">
              <Cpu className="w-4 h-4" />
              MARK LIV SELF-AWARENESS &amp; WAKE WORD
            </div>
            <p className="text-slate-300">
              Introspects host OS, 810-vertex MediaPipe canonical face rig, language-free viseme schedule, and openWakeWord listener.
            </p>
            <div className="p-2.5 rounded bg-[#00060a] border border-[#0d3347] font-mono text-[11px] text-[#8ffcff]">
              Mesh: 810 Verts / 1554 Opaque Facets · Jaw Pivot: Active
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: MARK 54 INTERACTIVE QUIZ & DOCUMENT REVIEW BOARD (from Mark-LIV ui.py) */}
      {subTab === 'mark54_quiz_review' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 text-xs">
          {/* Left: Interactive Quiz Panel (ui.py show_quiz) */}
          <div className="p-4 rounded-xl bg-[#000d14] border border-[#1a5c7a] space-y-3">
            <div className="flex items-center justify-between border-b border-[#0d3347] pb-2">
              <span className="font-mono font-bold text-[#00d4ff] flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4" />
                ◈ MARK LIV INTERACTIVE QUIZ BOARD
              </span>
              <button
                onClick={() => {
                  setQuizSubmitted(true);
                  const score = QUIZ_QUESTIONS.filter((q, i) => quizAnswers[i] === q.correct).length;
                  onSpeak?.(`Quiz graded by Jarvis Mark 54. You scored ${score} out of ${QUIZ_QUESTIONS.length}.`);
                }}
                className="px-2.5 py-1 rounded bg-[#00d4ff] text-[#00060a] font-mono font-bold text-[11px]"
              >
                GRADE QUIZ
              </button>
            </div>

            <div className="space-y-3">
              {QUIZ_QUESTIONS.map((item, qIdx) => (
                <div key={qIdx} className="p-3 rounded-lg bg-[#00060a] border border-[#0d3347] space-y-2">
                  <div className="font-semibold text-[#d8f8ff]">{item.q}</div>
                  <div className="space-y-1.5">
                    {item.options.map((opt, oIdx) => {
                      const selected = quizAnswers[qIdx] === oIdx;
                      const isCorrect = item.correct === oIdx;
                      return (
                        <button
                          key={oIdx}
                          onClick={() => setQuizAnswers((prev) => ({ ...prev, [qIdx]: oIdx }))}
                          className={`w-full text-left px-2.5 py-1.5 rounded border font-mono text-[11px] transition-all ${
                            quizSubmitted
                              ? isCorrect
                                ? 'bg-emerald-950/50 border-[#00ff88] text-[#00ff88]'
                                : selected
                                ? 'bg-rose-950/50 border-rose-500 text-rose-300'
                                : 'bg-[#010d14] border-[#0d3347] text-slate-400'
                              : selected
                              ? 'bg-[#001f2e] border-[#00d4ff] text-[#8ffcff]'
                              : 'bg-[#010d14] border-[#0d3347] text-slate-300 hover:border-[#1a5c7a]'
                          }`}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Document Review Panel (ui.py show_review) */}
          <div className="p-4 rounded-xl bg-[#000d14] border border-[#1a5c7a] space-y-3">
            <div className="flex items-center justify-between border-b border-[#0d3347] pb-2">
              <span className="font-mono font-bold text-[#ffcc00] flex items-center gap-1.5">
                <FileText className="w-4 h-4" />
                ◈ MARK LIV DOCUMENT &amp; CODE REVIEW
              </span>
              <span className="text-[10px] font-mono text-[#5ab8cc]">3 FINDINGS</span>
            </div>

            <div className="space-y-2.5">
              {REVIEW_FINDINGS.map((f, idx) => {
                const badgeColor =
                  f.severity === 'serious'
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/50'
                    : f.severity === 'caution'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                    : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50';
                return (
                  <div key={idx} className="p-3 rounded-lg bg-[#00060a] border border-[#0d3347] space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">{f.heading}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase border ${badgeColor}`}>
                        {f.severity}
                      </span>
                    </div>
                    <p className="text-slate-300 text-[11px]">{f.detail}</p>
                    <code className="block p-1.5 rounded bg-[#010d14] border border-[#0d3347] text-[10px] font-mono text-[#8ffcff]">
                      {f.quote}
                    </code>
                    <div className="text-[11px] text-[#00ff88] font-mono">▸ Fix: {f.suggestion}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: GEMINI 3.5 AUDIO TRANSCRIPTION & LYRIA 3 MUSIC GENERATION */}
      {subTab === 'ai_audio_music' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 text-xs">
          {/* Left: Audio Transcription (gemini-3.5-transcribe) */}
          <div className="p-4 rounded-xl bg-[#000d14] border border-[#1a5c7a] space-y-4">
            <div className="flex items-center justify-between border-b border-[#0d3347] pb-2">
              <span className="font-mono font-bold text-[#00d4ff] flex items-center gap-2">
                <Mic className="w-4 h-4" />
                MICROPHONE AUDIO TRANSCRIPTION (gemini-3.5-transcribe)
              </span>
              <span className="text-[10px] font-mono text-[#00ff88]">MODEL: gemini-3.5-transcribe</span>
            </div>

            <p className="text-slate-300">
              Record spoken audio from your microphone and transcribe it via the server-side{' '}
              <code className="text-[#8ffcff]">gemini-3.5-transcribe</code> model, then dispatch it directly to Hayat &amp; Mark 54.
            </p>

            <div className="flex items-center gap-3">
              <button
                onClick={toggleAudioRecording}
                disabled={isTranscribing}
                className={`px-4 py-2.5 rounded-lg font-mono font-bold flex items-center gap-2 transition-all ${
                  isRecordingAudio
                    ? 'bg-rose-600 text-white animate-pulse'
                    : 'bg-[#00d4ff] hover:bg-cyan-300 text-[#00060a]'
                }`}
              >
                {isRecordingAudio ? (
                  <>
                    <Square className="w-4 h-4 fill-current" />
                    <span>STOP &amp; TRANSCRIBE</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4" />
                    <span>{isTranscribing ? 'TRANSCRIBING...' : 'RECORD MIC AUDIO'}</span>
                  </>
                )}
              </button>

              {transcribedText && onExecuteTranscript && (
                <button
                  onClick={() => onExecuteTranscript(transcribedText)}
                  className="px-3 py-2.5 rounded-lg bg-[#00ff88] text-[#00060a] font-mono font-bold"
                >
                  ▶ EXECUTE TRANSCRIPT
                </button>
              )}
            </div>

            <div className="p-3 rounded-lg bg-[#00060a] border border-[#0d3347] min-h-[72px] font-mono">
              <div className="text-[10px] text-[#5ab8cc] mb-1">TRANSCRIPTION OUTPUT:</div>
              <div className="text-[#d8f8ff]">
                {isTranscribing
                  ? 'Processing audio stream with gemini-3.5-transcribe...'
                  : transcribedText || 'Click "RECORD MIC AUDIO" to capture and transcribe speech.'}
              </div>
            </div>
          </div>

          {/* Right: AI Music Generation (lyria-3-clip-preview / lyria-3-pro-preview) */}
          <div className="p-4 rounded-xl bg-[#000d14] border border-[#1a5c7a] space-y-4">
            <div className="flex items-center justify-between border-b border-[#0d3347] pb-2">
              <span className="font-mono font-bold text-[#ff6b00] flex items-center gap-2">
                <Music className="w-4 h-4" />
                AI MUSIC GENERATOR (lyria-3-clip-preview / lyria-3-pro-preview)
              </span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setMusicMode('clip')}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                    musicMode === 'clip' ? 'bg-[#ff6b00] text-black font-bold' : 'bg-[#00060a] text-slate-400'
                  }`}
                >
                  30s Clip (lyria-3-clip-preview)
                </button>
                <button
                  onClick={() => setMusicMode('pro')}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                    musicMode === 'pro' ? 'bg-[#ff6b00] text-black font-bold' : 'bg-[#00060a] text-slate-400'
                  }`}
                >
                  Full Pro (lyria-3-pro-preview)
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                value={musicPrompt}
                onChange={(e) => setMusicPrompt(e.target.value)}
                className="flex-1 bg-[#00060a] border border-[#0d3347] rounded-lg px-3 py-2 text-xs font-mono text-[#d8f8ff] focus:outline-none focus:border-[#00d4ff]"
                placeholder="Describe the music track to generate..."
              />
              <button
                onClick={handleGenerateMusic}
                disabled={isGeneratingMusic}
                className="px-4 py-2 rounded-lg bg-[#ff6b00] hover:bg-orange-400 text-black font-mono font-bold shrink-0"
              >
                {isGeneratingMusic ? 'GENERATING...' : '🎵 GENERATE'}
              </button>
            </div>

            {generatedMusic && (
              <div className="p-3 rounded-lg bg-[#00060a] border border-[#0d3347] space-y-2 font-mono">
                <div className="flex items-center justify-between text-[10px] text-[#ffcc00]">
                  <span>MODEL: {generatedMusic.model}</span>
                  {isPlayingSynth ? (
                    <button
                      onClick={stopSynthPlayback}
                      className="px-2 py-0.5 rounded bg-rose-500/20 border border-rose-500 text-rose-300"
                    >
                      ⏹ STOP AUDIO
                    </button>
                  ) : (
                    <button
                      onClick={startSynthPlayback}
                      className="px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500 text-emerald-300"
                    >
                      ▶ PLAY TRACK
                    </button>
                  )}
                </div>
                <div className="text-slate-200 text-[11px]">{generatedMusic.description}</div>
                {generatedMusic.audioDataUrl && (
                  <audio controls src={generatedMusic.audioDataUrl} className="w-full h-8 mt-1" autoPlay />
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
