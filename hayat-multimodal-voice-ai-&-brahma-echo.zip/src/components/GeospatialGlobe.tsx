import React, { useRef, useEffect, useState } from 'react';
import { Globe, Satellite, Activity, RotateCw, ZoomIn, ZoomOut, Compass, Navigation } from 'lucide-react';
import { SeismicEvent } from '../types';

interface GeospatialGlobeProps {
  onSpatialVoiceTrigger?: (action: string) => void;
}

export const GeospatialGlobe: React.FC<GeospatialGlobeProps> = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [viewMode, setViewMode] = useState<'globe' | 'satellite'>('globe');
  const [showEarthquakes, setShowEarthquakes] = useState<boolean>(true);
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [zoom, setZoom] = useState<number>(1.0);
  const [selectedEvent, setSelectedEvent] = useState<SeismicEvent | null>(null);

  // Rotation angles (pitch and yaw)
  const rotationRef = useRef({ pitch: 0.3, yaw: 0 });
  const isDraggingRef = useRef(false);
  const lastMousePosRef = useRef({ x: 0, y: 0 });

  // Seismic Earthquake Telemetry Events
  const seismicEvents: SeismicEvent[] = [
    {
      id: 'eq_1',
      location: 'New York / Offshore Atlantic',
      lat: 40.71,
      lng: -74.0,
      magnitude: 3.2,
      depthKm: 10.4,
      timeAgo: '42m ago',
    },
    {
      id: 'eq_2',
      location: 'San Francisco Fault Zone, CA',
      lat: 37.77,
      lng: -122.41,
      magnitude: 4.1,
      depthKm: 8.2,
      timeAgo: '1h 15m ago',
    },
    {
      id: 'eq_3',
      location: 'Tokyo Bay, Japan',
      lat: 35.67,
      lng: 139.65,
      magnitude: 5.3,
      depthKm: 32.0,
      timeAgo: '2h 04m ago',
    },
    {
      id: 'eq_4',
      location: 'Indian Ocean / Sunda Trench',
      lat: -3.09,
      lng: 101.44,
      magnitude: 4.8,
      depthKm: 24.5,
      timeAgo: '3h 30m ago',
    },
    {
      id: 'eq_5',
      location: 'Reykjanes Ridge, Iceland',
      lat: 63.85,
      lng: -22.43,
      magnitude: 3.7,
      depthKm: 6.0,
      timeAgo: '5h 10m ago',
    },
  ];

  // Canvas 3D Globe Rendering Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const w = canvas.width;
      const h = canvas.height;
      const cx = w / 2;
      const cy = h / 2;
      const radius = 135 * zoom;

      ctx.clearRect(0, 0, w, h);

      if (autoRotate && !isDraggingRef.current) {
        rotationRef.current.yaw += 0.005;
      }

      const yaw = rotationRef.current.yaw;
      const pitch = rotationRef.current.pitch;

      // 1. Atmosphere Glow Ring
      const atmoGrad = ctx.createRadialGradient(cx, cy, radius * 0.85, cx, cy, radius * 1.25);
      atmoGrad.addColorStop(
        0,
        viewMode === 'satellite' ? 'rgba(56, 189, 248, 0.25)' : 'rgba(6, 182, 212, 0.25)'
      );
      atmoGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = atmoGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, radius * 1.25, 0, Math.PI * 2);
      ctx.fill();

      // 2. Planet Sphere Background
      const sphereGrad = ctx.createRadialGradient(
        cx - radius * 0.35,
        cy - radius * 0.35,
        radius * 0.1,
        cx,
        cy,
        radius
      );
      if (viewMode === 'satellite') {
        sphereGrad.addColorStop(0, '#0a192f');
        sphereGrad.addColorStop(0.7, '#040d1a');
        sphereGrad.addColorStop(1, '#020610');
      } else {
        sphereGrad.addColorStop(0, '#0f172a');
        sphereGrad.addColorStop(0.7, '#090d16');
        sphereGrad.addColorStop(1, '#020617');
      }

      ctx.fillStyle = sphereGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.fill();

      // Outer border circle
      ctx.strokeStyle = viewMode === 'satellite' ? 'rgba(56, 189, 248, 0.4)' : 'rgba(6, 182, 212, 0.4)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Helper function to project lat/lng to 3D sphere coordinate
      const project = (latDeg: number, lngDeg: number) => {
        const phi = (latDeg * Math.PI) / 180;
        const theta = (lngDeg * Math.PI) / 180 + yaw;

        // 3D coordinates
        let x = Math.cos(phi) * Math.sin(theta);
        let y = -Math.sin(phi);
        let z = Math.cos(phi) * Math.cos(theta);

        // Rotate around pitch axis (X axis)
        const y2 = y * Math.cos(pitch) - z * Math.sin(pitch);
        const z2 = y * Math.sin(pitch) + z * Math.cos(pitch);

        return {
          px: cx + x * radius,
          py: cy + y2 * radius,
          visible: z2 > 0, // front hemisphere
          z: z2,
        };
      };

      // 3. Draw Latitude & Longitude Wireframe Grid
      ctx.lineWidth = 0.75;
      ctx.strokeStyle = viewMode === 'satellite' ? 'rgba(56, 189, 248, 0.15)' : 'rgba(6, 182, 212, 0.15)';

      // Latitude lines
      for (let lat = -60; lat <= 60; lat += 30) {
        ctx.beginPath();
        let first = true;
        for (let lng = -180; lng <= 180; lng += 10) {
          const pt = project(lat, lng);
          if (pt.visible) {
            if (first) {
              ctx.moveTo(pt.px, pt.py);
              first = false;
            } else {
              ctx.lineTo(pt.px, pt.py);
            }
          } else {
            first = true;
          }
        }
        ctx.stroke();
      }

      // Longitude lines
      for (let lng = 0; lng < 360; lng += 45) {
        ctx.beginPath();
        let first = true;
        for (let lat = -80; lat <= 80; lat += 10) {
          const pt = project(lat, lng);
          if (pt.visible) {
            if (first) {
              ctx.moveTo(pt.px, pt.py);
              first = false;
            } else {
              ctx.lineTo(pt.px, pt.py);
            }
          } else {
            first = true;
          }
        }
        ctx.stroke();
      }

      // 4. Stylized Landmass Clusters (sample world outline points)
      const landClusters = [
        // North America
        [ { lat: 50, lng: -120 }, { lat: 40, lng: -75 }, { lat: 30, lng: -90 }, { lat: 25, lng: -100 } ],
        // South America
        [ { lat: 5, lng: -60 }, { lat: -15, lng: -50 }, { lat: -35, lng: -65 } ],
        // Europe & Africa
        [ { lat: 55, lng: 15 }, { lat: 45, lng: 25 }, { lat: 10, lng: 20 }, { lat: -25, lng: 25 } ],
        // Asia & India
        [ { lat: 60, lng: 80 }, { lat: 35, lng: 105 }, { lat: 20, lng: 78 }, { lat: 10, lng: 105 } ],
        // Australia
        [ { lat: -20, lng: 135 }, { lat: -32, lng: 145 }, { lat: -30, lng: 120 } ],
      ];

      ctx.fillStyle = viewMode === 'satellite' ? 'rgba(56, 189, 248, 0.18)' : 'rgba(6, 182, 212, 0.18)';
      for (const cluster of landClusters) {
        ctx.beginPath();
        let started = false;
        for (const coord of cluster) {
          const p = project(coord.lat, coord.lng);
          if (p.visible) {
            if (!started) {
              ctx.moveTo(p.px, p.py);
              started = true;
            } else {
              ctx.lineTo(p.px, p.py);
            }
          }
        }
        if (started) {
          ctx.closePath();
          ctx.fill();
        }
      }

      // 5. Satellite Orbit Trails (if in satellite view)
      if (viewMode === 'satellite') {
        const satTime = Date.now() * 0.001;
        ctx.strokeStyle = 'rgba(234, 179, 8, 0.4)';
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        for (let a = 0; a <= Math.PI * 2; a += 0.1) {
          const sx = cx + Math.cos(a) * (radius * 1.28);
          const sy = cy + Math.sin(a) * (radius * 0.5) * Math.sin(satTime * 0.2);
          if (a === 0) ctx.moveTo(sx, sy);
          else ctx.lineTo(sx, sy);
        }
        ctx.stroke();
        ctx.setLineDash([]);

        // Satellite icons on orbit
        const satPos = {
          x: cx + Math.cos(satTime) * (radius * 1.28),
          y: cy + Math.sin(satTime) * (radius * 0.5) * Math.sin(satTime * 0.2),
        };
        ctx.fillStyle = '#facc15';
        ctx.fillRect(satPos.x - 3, satPos.y - 3, 6, 6);
      }

      // 6. Seismic / Earthquake telemetry pins
      if (showEarthquakes) {
        for (const eq of seismicEvents) {
          const pt = project(eq.lat, eq.lng);
          if (pt.visible) {
            const isSelected = selectedEvent?.id === eq.id;
            const pingRadius = 5 + eq.magnitude * 2;

            // Ping circle wave
            ctx.beginPath();
            ctx.arc(pt.px, pt.py, pingRadius, 0, Math.PI * 2);
            ctx.fillStyle = isSelected ? 'rgba(244, 63, 94, 0.4)' : 'rgba(244, 63, 94, 0.2)';
            ctx.fill();

            // Center red dot
            ctx.beginPath();
            ctx.arc(pt.px, pt.py, 3, 0, Math.PI * 2);
            ctx.fillStyle = '#f43f5e';
            ctx.fill();

            // Event label
            ctx.fillStyle = '#ffffff';
            ctx.font = '9px monospace';
            ctx.fillText(`M${eq.magnitude}`, pt.px + 6, pt.py - 4);
          }
        }
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [viewMode, showEarthquakes, autoRotate, zoom, selectedEvent]);

  // Mouse drag handlers for rotating globe
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    isDraggingRef.current = true;
    lastMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDraggingRef.current) return;
    const dx = e.clientX - lastMousePosRef.current.x;
    const dy = e.clientY - lastMousePosRef.current.y;

    rotationRef.current.yaw += dx * 0.008;
    rotationRef.current.pitch = Math.max(-1.2, Math.min(1.2, rotationRef.current.pitch + dy * 0.008));

    lastMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  // Click on canvas to select earthquake pin
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    // Cycle through earthquake telemetry
    const nextIdx = selectedEvent ? (seismicEvents.findIndex((ev) => ev.id === selectedEvent.id) + 1) % seismicEvents.length : 0;
    setSelectedEvent(seismicEvents[nextIdx]);
  };

  return (
    <div className="flex flex-col lg:flex-row gap-5 p-5 bg-[#0b0f19]/90 border border-slate-800 rounded-2xl backdrop-blur-xl shadow-2xl">
      {/* 3D Canvas Viewport */}
      <div className="relative flex-1 flex flex-col items-center justify-center min-h-[380px] bg-slate-950/80 rounded-xl border border-slate-800/80 overflow-hidden shadow-inner">
        {/* Controls Toolbar Overlay */}
        <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 p-1 bg-slate-900/85 backdrop-blur-md rounded-lg border border-slate-700/60 text-xs font-mono">
          <button
            onClick={() => setViewMode('globe')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-colors ${
              viewMode === 'globe' ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>3D GLOBE</span>
          </button>
          <button
            onClick={() => setViewMode('satellite')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-colors ${
              viewMode === 'satellite' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Satellite className="w-3.5 h-3.5" />
            <span>SATELLITE VIEW</span>
          </button>
        </div>

        {/* Top Right HUD telemetry status */}
        <div className="absolute top-3 right-3 z-10 flex items-center gap-2 text-[11px] font-mono text-slate-400">
          <span className="flex items-center gap-1 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            GEOSPATIAL ACTIVE
          </span>
        </div>

        {/* 3D Earth Canvas */}
        <canvas
          ref={canvasRef}
          width={420}
          height={380}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onClick={handleCanvasClick}
          className="cursor-grab active:cursor-grabbing max-w-full drop-shadow-2xl"
        />

        {/* Bottom Orbit / Zoom Controls */}
        <div className="absolute bottom-3 left-3 right-3 z-10 flex items-center justify-between text-xs font-mono text-slate-400">
          <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded-md border border-slate-800">
            <span>DRAG TO ROTATE GLOBE</span>
          </div>

          <div className="flex items-center gap-1 bg-slate-900/80 backdrop-blur p-1 rounded-md border border-slate-800">
            <button
              onClick={() => setAutoRotate(!autoRotate)}
              title="Toggle Auto Spin"
              className={`p-1.5 rounded hover:bg-slate-800 ${autoRotate ? 'text-cyan-400' : 'text-slate-500'}`}
            >
              <RotateCw className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoom((z) => Math.max(0.7, z - 0.15))}
              title="Zoom Out"
              className="p-1.5 rounded hover:bg-slate-800 text-slate-300"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoom((z) => Math.min(1.5, z + 0.15))}
              title="Zoom In"
              className="p-1.5 rounded hover:bg-slate-800 text-slate-300"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Right Sidebar: Seismic Event Feed & Voice Commands */}
      <div className="w-full lg:w-80 flex flex-col justify-between space-y-4">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-rose-400 animate-pulse" />
              <h4 className="font-display font-bold text-xs text-slate-100 tracking-wider uppercase">
                Seismic Activity Telemetry
              </h4>
            </div>
            <button
              onClick={() => setShowEarthquakes(!showEarthquakes)}
              className={`text-[10px] font-mono px-2 py-0.5 rounded border transition-colors ${
                showEarthquakes
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {showEarthquakes ? 'OVERLAY: ON' : 'OVERLAY: OFF'}
            </button>
          </div>

          <p className="text-xs text-slate-400 mb-3">
            Real-time planetary tremor events mapped directly onto 3D coordinate sphere (USGS protocol).
          </p>

          {/* List of earthquakes */}
          <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
            {seismicEvents.map((eq) => (
              <div
                key={eq.id}
                onClick={() => setSelectedEvent(eq)}
                className={`p-2.5 rounded-xl border text-xs transition-all cursor-pointer ${
                  selectedEvent?.id === eq.id
                    ? 'bg-rose-500/15 border-rose-500/60 shadow-lg'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-200">{eq.location}</span>
                  <span className="font-mono font-bold text-rose-400 px-1.5 py-0.5 bg-rose-500/10 rounded">
                    M {eq.magnitude}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[10px] font-mono text-slate-500">
                  <span>Depth: {eq.depthKm} km</span>
                  <span>{eq.timeAgo}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Voice Trigger Examples Box */}
        <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl text-xs">
          <div className="flex items-center gap-1.5 text-cyan-400 font-mono font-semibold mb-1.5">
            <Compass className="w-3.5 h-3.5" />
            <span>JARVIS HUD SPATIAL TRIGGERS</span>
          </div>
          <div className="space-y-1 text-[11px] font-mono text-slate-400">
            <div>&quot;Show me the Earth&quot; → 3D Globe Mode</div>
            <div>&quot;Change to satellite view&quot; → Orbital Satellites</div>
            <div>&quot;Show earthquakes in this area&quot; → Seismic Feed</div>
          </div>
        </div>
      </div>
    </div>
  );
};
