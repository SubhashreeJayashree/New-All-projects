import React, { useState, useEffect } from 'react';
import { Shield, ShieldAlert, KeyRound, Lock, Eye, EyeOff, Activity, RefreshCw, AlertTriangle, Radio } from 'lucide-react';
import { TelemetrySpan } from '../types';
import { realtimeSocket } from '../utils/realtimeSocket';

interface SecurityObservabilityProps {
  isEmergencyStopped: boolean;
  onTriggerKillSwitch: () => void;
  onResetKillSwitch: () => void;
}

export const SecurityObservability: React.FC<SecurityObservabilityProps> = ({
  isEmergencyStopped,
  onTriggerKillSwitch,
  onResetKillSwitch,
}) => {
  const [rawText, setRawText] = useState(
    'Please contact recruiter at hr@deepmind.com or call +91-9876543210 using API token sk-98fbc18820394857283.'
  );
  const [sanitizedText, setSanitizedText] = useState('');
  const [vaultTokens, setVaultTokens] = useState<Record<string, string>>({});
  const [showVaultSecrets, setShowVaultSecrets] = useState(false);
  const [spans, setSpans] = useState<TelemetrySpan[]>([]);
  const [isLoadingSpans, setIsLoadingSpans] = useState(false);
  const [wsConnected, setWsConnected] = useState<boolean>(realtimeSocket.getConnectionStatus());

  // Local PII Sanitization demo
  useEffect(() => {
    let clean = rawText;
    const vault: Record<string, string> = {};

    // Email matching
    const emailMatches = clean.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g) || [];
    emailMatches.forEach((m, i) => {
      const token = `<__MASKED_EMAIL_${i}__>`;
      vault[token] = m;
      clean = clean.replace(m, token);
    });

    // Phone matching
    const phoneMatches = clean.match(/\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/g) || [];
    phoneMatches.forEach((m, i) => {
      const token = `<__MASKED_PHONE_${i}__>`;
      vault[token] = m;
      clean = clean.replace(m, token);
    });

    // API Key matching
    const keyMatches = clean.match(/\b(?:sk-|api_)[a-zA-Z0-9]{15,}\b/g) || [];
    keyMatches.forEach((m, i) => {
      const token = `<__MASKED_APIKEY_${i}__>`;
      vault[token] = m;
      clean = clean.replace(m, token);
    });

    setSanitizedText(clean);
    setVaultTokens(vault);
  }, [rawText]);

  // Request state sync over WebSocket (or initial HTTP fallback if socket is still handshaking)
  const fetchSpans = async () => {
    setIsLoadingSpans(true);
    try {
      realtimeSocket.send('state:sync_request');
      const res = await fetch('/api/telemetry/spans');
      const data = await res.json();
      if (data.spans) setSpans(data.spans);
    } catch (e) {
      console.warn('Could not fetch spans');
    } finally {
      setIsLoadingSpans(false);
    }
  };

  // Real-Time WebSocket Subscription (Replaces polling interval)
  useEffect(() => {
    fetchSpans();

    const unsubInit = realtimeSocket.subscribe('init:state', (payload) => {
      if (Array.isArray(payload?.spans)) {
        setSpans(payload.spans);
      }
      setWsConnected(true);
    });

    const unsubSpan = realtimeSocket.subscribe('telemetry:span', (newSpan: TelemetrySpan) => {
      if (!newSpan || !newSpan.id) return;
      setSpans((prev) => {
        if (prev.some((s) => s.id === newSpan.id)) return prev;
        return [newSpan, ...prev.slice(0, 49)];
      });
    });

    const unsubStatus = realtimeSocket.subscribe('ws:status', (status) => {
      setWsConnected(!!status?.connected);
    });

    return () => {
      unsubInit();
      unsubSpan();
      unsubStatus();
    };
  }, []);

  return (
    <div className="flex flex-col gap-6 p-5 bg-[#0b0f19]/90 border border-slate-800 rounded-2xl backdrop-blur-xl shadow-2xl">
      {/* SECTION 1: Hardware Emergency Kill Switch Banner */}
      <div
        className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row items-center justify-between gap-4 ${
          isEmergencyStopped
            ? 'bg-rose-950/40 border-rose-500 hologram-glow-rose'
            : 'bg-slate-900/60 border-slate-800'
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
              isEmergencyStopped
                ? 'bg-rose-600 text-white animate-pulse'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-display font-bold text-sm text-slate-100 uppercase tracking-wide">
                Hardware Emergency Kill Switch (Safety Intercept)
              </h4>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                Hotkey: Ctrl + Shift + K
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {isEmergencyStopped
                ? 'EMERGENCY HALT TRIGGERED: All background subprocesses, ADB drivers, and web scrapers terminated.'
                : 'Zero-trust circuit breaker online. Instantly freezes all active execution loops and releases local ports.'}
            </p>
          </div>
        </div>

        <div>
          {isEmergencyStopped ? (
            <button
              onClick={onResetKillSwitch}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-mono font-bold text-xs rounded-xl shadow-lg transition-all"
            >
              RESTORE NORMAL OPERATION
            </button>
          ) : (
            <button
              onClick={onTriggerKillSwitch}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-mono font-bold text-xs rounded-xl shadow-lg shadow-rose-600/30 active:scale-95 transition-all"
            >
              TRIGGER EMERGENCY STOP
            </button>
          )}
        </div>
      </div>

      {/* SECTION 2: Local Zero-Trust PII Scrubbing Middleware */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-semibold text-emerald-400 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" /> LOCAL PII SCRUBBING MIDDLEWARE
            </span>
            <span className="text-[10px] font-mono text-slate-500">PRE-EGRESS MASKING</span>
          </div>
          <p className="text-xs text-slate-400">
            Automatically scrubs emails, phone numbers, and keys before payloads hit external LLM APIs.
          </p>

          <div>
            <label className="text-[10px] font-mono text-slate-400 block mb-1">INPUT TEXT (WITH SENSITIVE PII):</label>
            <textarea
              rows={3}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 font-mono outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="text-[10px] font-mono text-emerald-400 block mb-1">
              SANITIZED PAYLOAD DISPATCHED TO CLOUD:
            </label>
            <div className="p-2.5 bg-slate-900/80 border border-emerald-500/30 rounded-lg text-xs font-mono text-emerald-300 break-all select-all">
              {sanitizedText}
            </div>
          </div>
        </div>

        {/* Local Encrypted Token Vault */}
        <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-semibold text-cyan-400 flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5" /> LOCAL ENCRYPTED VAULT TOKENS
            </span>
            <button
              onClick={() => setShowVaultSecrets(!showVaultSecrets)}
              className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
            >
              {showVaultSecrets ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span className="text-[10px] font-mono">{showVaultSecrets ? 'HIDE SECRETS' : 'REVEAL'}</span>
            </button>
          </div>
          <p className="text-xs text-slate-400">
            Isolated local memory store that restores raw credentials on response delivery without exposure to external models.
          </p>

          <div className="space-y-2 max-h-48 overflow-y-auto">
            {Object.keys(vaultTokens).length === 0 ? (
              <div className="text-xs font-mono text-slate-500 py-6 text-center">
                No sensitive entities detected in input text.
              </div>
            ) : (
              Object.entries(vaultTokens).map(([token, secret]) => (
                <div key={token} className="p-2 bg-slate-900 rounded border border-slate-800 text-xs font-mono flex items-center justify-between">
                  <span className="text-cyan-300 font-semibold">{token}</span>
                  <span className="text-slate-400">
                    {showVaultSecrets ? secret : '••••••••••••••••'}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* SECTION 3: OpenTelemetry Distributed Trace Waterfalls */}
      <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-cyan-400" />
            <h4 className="font-display font-bold text-xs text-slate-100 uppercase tracking-wide">
              OpenTelemetry Latency Waterfall &amp; Distributed Traces
            </h4>
          </div>
          <button
            onClick={fetchSpans}
            disabled={isLoadingSpans}
            className="flex items-center gap-1 text-[11px] font-mono text-slate-400 hover:text-cyan-300"
          >
            <RefreshCw className={`w-3 h-3 ${isLoadingSpans ? 'animate-spin' : ''}`} />
            <span>REFRESH TRACES</span>
          </button>
        </div>

        <div className="space-y-2 max-h-60 overflow-y-auto">
          {spans.length === 0 ? (
            <div className="text-xs font-mono text-slate-500 text-center py-4">
              Awaiting live agent task traces...
            </div>
          ) : (
            spans.map((span) => {
              const maxDuration = 300;
              const barWidth = Math.min(100, Math.max(5, (span.durationMs / maxDuration) * 100));
              return (
                <div key={span.id} className="p-2 bg-slate-900/70 rounded-lg border border-slate-800/80 text-xs font-mono">
                  <div className="flex items-center justify-between mb-1 text-[11px]">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-200">{span.name}</span>
                      <span className="text-slate-500 text-[10px]">[{span.service}]</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={span.status === 'OK' ? 'text-emerald-400' : 'text-rose-400'}>
                        {span.durationMs}ms
                      </span>
                    </div>
                  </div>
                  <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        span.service.includes('jev')
                          ? 'bg-amber-400'
                          : span.service.includes('gemini')
                          ? 'bg-cyan-400'
                          : 'bg-emerald-400'
                      }`}
                      style={{ width: `${barWidth}%` }}
                    />
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
