import React, { useState } from 'react';
import { Presentation, ChevronLeft, ChevronRight, Maximize2, Minimize2, FileText, CheckCircle2, User, School, Sparkles, BookOpen } from 'lucide-react';

export const PresentationReview: React.FC = () => {
  const [activeDeck, setActiveDeck] = useState<'technical' | 'product'>('technical');
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [showNotes, setShowNotes] = useState(true);

  // Deck 1: Technical & Academic Review
  const TECHNICAL_SLIDES = [
    {
      id: 1,
      tag: 'SLIDE 01 · TITLE & AUTHOR DETAILS',
      title: 'Brahma Echo (Ultron v3) & Hayat Multimodal AI',
      subtitle: 'An Autonomous Multi-Agent Desktop Ecosystem & 24/7 Cloud Execution Engine',
      author: 'Subhashree Narayanan',
      affiliation: 'Master of Computer Applications (MCA - Generative AI) · SRM Institute of Science and Technology, Trichy Campus',
      content: (
        <div className="space-y-4 text-slate-200">
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
            <div className="text-cyan-400 font-mono text-xs font-semibold">CORE RESEARCH PILLARS:</div>
            <ul className="list-disc list-inside space-y-1 text-xs text-slate-300">
              <li>Dual-Brain Architecture: Sub-100ms TypeSafe Jev AI (System 1) + Gemini 3.8 Flash (System 2).</li>
              <li>Astra-Inspired Real-Time Multimodal Computer Vision with low-latency object spatial awareness.</li>
              <li>Deep Android Device Automation via Android Debug Bridge (ADB) telephony, media, and intents.</li>
              <li>Zero-Trust Governance with Local PII Masking, OpenTelemetry Traces, and Hardware Kill Switch.</li>
            </ul>
          </div>
        </div>
      ),
      speakerNotes:
        'Good morning/afternoon, sir. Today I am presenting our work on Brahma Echo and the Hayat Multimodal Voice Assistant. Our objective is bridging sub-100ms deterministic decision routers with generative reasoning and host hardware control.',
    },
    {
      id: 2,
      tag: 'SLIDE 02 · SYSTEM ARCHITECTURE',
      title: 'Hybrid Multi-Agent & Dual-Brain Topology',
      subtitle: 'Coordinated execution across Supervisor, Sub-Agents, and Hardware Bridges',
      content: (
        <div className="space-y-3 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl">
              <span className="font-mono font-bold text-amber-400 block mb-1">01. SYSTEM 1 ROUTER</span>
              <p className="text-slate-300">
                TypeSafe Jev AI running non-autoregressive parallel questions (Noul, Choice, Score) in under 100ms with calibrated confidence gating (&gt; 0.92).
              </p>
            </div>
            <div className="p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-xl">
              <span className="font-mono font-bold text-cyan-400 block mb-1">02. SYSTEM 2 REASONING</span>
              <p className="text-slate-300">
                Google Gemini 3.8 Flash multimodal engine for continuous conversational memory, visual scene inspection, and deep research synthesis.
              </p>
            </div>
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl">
              <span className="font-mono font-bold text-emerald-400 block mb-1">03. HARDWARE & ADB</span>
              <p className="text-slate-300">
                Native Android Debug Bridge (ADB) intent dispatcher for WhatsApp messaging, phone calls, media keys, and 3D geospatial telemetry.
              </p>
            </div>
          </div>
        </div>
      ),
      speakerNotes:
        'In this slide, I highlight our primary innovation: instead of routing every user utterance through an expensive, high-latency LLM, System 1 parses intent in 40ms, directly triggering device code when confidence exceeds 92%.',
    },
    {
      id: 3,
      tag: 'SLIDE 03 · VERIFICATION MATRIX',
      title: 'Functional Verification & Module Breakdown',
      subtitle: 'Empirical benchmark results across core execution modules',
      content: (
        <div className="overflow-x-auto text-xs font-mono">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2 px-3">Module Name</th>
                <th className="py-2 px-3">Engine Used</th>
                <th className="py-2 px-3">Measured Latency</th>
                <th className="py-2 px-3">Test Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-2 px-3 font-semibold text-amber-400">System 1 Router</td>
                <td className="py-2 px-3">TypeSafe Jev AI (RLCD)</td>
                <td className="py-2 px-3">44.2 ms</td>
                <td className="py-2 px-3 text-emerald-400 font-bold">✔ Verified (Zero Hallucination)</td>
              </tr>
              <tr>
                <td className="py-2 px-3 font-semibold text-cyan-400">Astra Vision Pipeline</td>
                <td className="py-2 px-3">OpenCV + Gemini Multimodal</td>
                <td className="py-2 px-3">480 ms</td>
                <td className="py-2 px-3 text-emerald-400 font-bold">✔ Verified (Real-time Spatial)</td>
              </tr>
              <tr>
                <td className="py-2 px-3 font-semibold text-emerald-400">ADB Phone Bridge</td>
                <td className="py-2 px-3">Subprocess Daemon (USB)</td>
                <td className="py-2 px-3">18 ms</td>
                <td className="py-2 px-3 text-emerald-400 font-bold">✔ Verified (WhatsApp/Telephony)</td>
              </tr>
              <tr>
                <td className="py-2 px-3 font-semibold text-purple-400">PII Scrubber Vault</td>
                <td className="py-2 px-3">Local Micro-NER &amp; Regex</td>
                <td className="py-2 px-3">1.2 ms</td>
                <td className="py-2 px-3 text-emerald-400 font-bold">✔ Verified (Zero Data Leak)</td>
              </tr>
            </tbody>
          </table>
        </div>
      ),
      speakerNotes:
        'This matrix summarizes our empirical verification benchmarks. Notice the System 1 decision latency is only 44 milliseconds, enabling instantaneous conversational transitions.',
    },
    {
      id: 4,
      tag: 'SLIDE 04 · SECURITY & ZERO-TRUST',
      title: 'Zero-Trust Governance & Self-Healing Logic',
      subtitle: 'Human-in-the-loop permission gates, stack-trace interception, and audit trails',
      content: (
        <div className="space-y-3 text-xs">
          <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
            <h5 className="font-semibold text-slate-200">Key Security &amp; Observability Capabilities:</h5>
            <ul className="list-disc list-inside space-y-1 text-slate-300">
              <li><strong>Local PII Sanitization Vault:</strong> Sensitive data (email, telephone, API secrets) are anonymized before any cloud transmission and restored only on return delivery.</li>
              <li><strong>Global Hardware Kill Switch:</strong> Physical keyboard binding [Ctrl + Shift + K] triggers immediate termination of all subprocesses and background threads.</li>
              <li><strong>Self-Healing Runtime Subsystem:</strong> Intercepts stack traces and runtime exceptions, generating autonomous patches to source files locally.</li>
            </ul>
          </div>
        </div>
      ),
      speakerNotes:
        'Security is a core focus. We ensure user privacy through local client-side token masking and give the operator absolute control via an instant hardware kill switch.',
    },
    {
      id: 5,
      tag: 'SLIDE 05 · CONCLUSION & FUTURE ROADMAP',
      title: 'Academic Contributions & Frontier Roadmap',
      subtitle: 'Summary of project impact and future scalability vectors',
      content: (
        <div className="space-y-3 text-xs text-slate-300">
          <div className="p-3 bg-cyan-950/20 border border-cyan-500/30 rounded-xl">
            <span className="font-mono font-bold text-cyan-400 block mb-1">CORE CONTRIBUTIONS:</span>
            <p>
              Unified cross-platform architecture connecting sub-100ms System 1 routers, Gemini 3.8 Flash multimodal vision, Android ADB phone automation, and 3D geospatial holographic HUDs under a single autonomous desktop assistant.
            </p>
          </div>
          <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl">
            <span className="font-mono font-bold text-amber-400 block mb-1">ROADMAP:</span>
            <p>
              1. Local offline Small Language Model (SLM) fallback via Ollama.<br />
              2. Peer-to-peer decentralized multi-agent swarm mesh synchronization.<br />
              3. OS-level vision mouse coordinate grounding for legacy applications.
            </p>
          </div>
        </div>
      ),
      speakerNotes:
        'To conclude, Brahma Echo establishes a new standard for local-first, low-latency multimodal assistants. Thank you, sir. I am now open to your questions and live demonstration requests.',
    },
  ];

  // Deck 2: Product & Feature Showcase
  const PRODUCT_SLIDES = [
    {
      id: 1,
      tag: 'SLIDE 01 · PRODUCT SHOWCASE',
      title: 'Hayat: Your Voice-First Multimodal AI Companion',
      subtitle: 'Inspired by Google Project Astra, Powered by Gemini & Jev AI',
      content: (
        <div className="space-y-4 text-slate-200">
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
            <div className="text-cyan-400 font-mono text-xs font-semibold">MEET HAYAT (حياة):</div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Hayat is a warm, ultra-responsive multimodal AI assistant that listens through microphone streams,
              observes surroundings via webcam vision, automates your Android smartphone via ADB, and speaks fluently
              in English, Hindi, and Tamil.
            </p>
          </div>
        </div>
      ),
      speakerNotes:
        'Good day! This deck showcases the product experience of Hayat. Unlike text chatbots, Hayat is voice-first and multimodal, designed to live on your workstation.',
    },
    {
      id: 2,
      tag: 'SLIDE 02 · PROBLEM VS SOLUTION',
      title: 'Fragmented Tools vs. Unified Control Center',
      subtitle: 'Why existing assistants fail and how Hayat solves context switching',
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 bg-rose-950/20 border border-rose-500/30 rounded-xl space-y-2">
            <span className="font-mono font-bold text-rose-400 block">THE PROBLEM:</span>
            <p className="text-slate-300">
              Users constantly context-switch between messaging apps, phone screens, code editors, and AI chatbots.
              Traditional AI assistants lack local hardware execution power and suffer from multi-second conversation lag.
            </p>
          </div>
          <div className="p-4 bg-emerald-950/20 border border-emerald-500/30 rounded-xl space-y-2">
            <span className="font-mono font-bold text-emerald-400 block">THE HAYAT SOLUTION:</span>
            <p className="text-slate-300">
              A single unified desktop control center with low-latency audio REPL, live webcam vision, automated WhatsApp messaging, direct phone dialing, and 3D geospatial intelligence.
            </p>
          </div>
        </div>
      ),
      speakerNotes:
        'Most users waste hours jumping between windows. With Hayat, a simple voice utterance automatically triggers a WhatsApp message, dials a contact, or visually debugs a screen error.',
    },
    {
      id: 3,
      tag: 'SLIDE 03 · STANDOUT UX FEATURES',
      title: 'Multimodal Astra Vision & Interactive Face Avatar',
      subtitle: 'Real-time eye tracking, audio lip-syncing, and spatial computer vision',
      content: (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
            <span className="font-mono font-bold text-cyan-400 block">ASTRA VISION</span>
            <p className="text-slate-300">Real-time object recognition, text OCR, and spatial locating via continuous camera frames.</p>
          </div>
          <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
            <span className="font-mono font-bold text-violet-400 block">LIP-SYNC AVATAR</span>
            <p className="text-slate-300">Synchronized visual avatar mouth animations matching spoken words with audio wave pulses.</p>
          </div>
          <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
            <span className="font-mono font-bold text-amber-400 block">PUSH-TO-TALK</span>
            <p className="text-slate-300">Global [Ctrl + Space] shortcut for controlled voice ingestion and ambient noise suppression.</p>
          </div>
        </div>
      ),
      speakerNotes:
        'Here we demonstrate the sensory presence of Hayat: the animated digital face lip-syncs dynamically to spoken speech, and the Astra vision module tracks objects in the user workspace.',
    },
    {
      id: 4,
      tag: 'SLIDE 04 · PHONE & CLOUD AUTOMATION',
      title: 'Android Hardware Bridge & Autonomous Tasks',
      subtitle: 'WhatsApp intent dispatching, telephony dialer, and career agent',
      content: (
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2 text-xs text-slate-300">
          <div className="font-mono font-bold text-emerald-400">ANDROID ADB BRIDGE IN ACTION:</div>
          <ul className="list-disc list-inside space-y-1">
            <li><strong>WhatsApp:</strong> Automatic URI intent launch + keystroke injection (`KEYCODE_ENTER = 66`).</li>
            <li><strong>Telephony:</strong> Immediate direct dialing via `android.intent.action.CALL`.</li>
            <li><strong>Media:</strong> Remote Spotify/YouTube playback control (`KEYCODE_MEDIA_PLAY_PAUSE = 85`).</li>
            <li><strong>Autonomous Muse AI:</strong> Headless job application auto-filling with mobile 2FA OTP forwarder.</li>
          </ul>
        </div>
      ),
      speakerNotes:
        'This slide showcases the practical utility of our Android bridge. Through standard ADB intents, Hayat controls the physical smartphone without needing proprietary cloud connectors.',
    },
    {
      id: 5,
      tag: 'SLIDE 05 · FEATURE COMPARISON',
      title: 'Platform Comparison Matrix',
      subtitle: 'Benchmarking Hayat against Web Chatbots and Script Automations',
      content: (
        <div className="overflow-x-auto text-xs font-mono">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2 px-2">Capability</th>
                <th className="py-2 px-2">Web Chatbots (ChatGPT)</th>
                <th className="py-2 px-2">Python Scripts</th>
                <th className="py-2 px-2 text-cyan-400">Hayat &amp; Brahma Echo</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-2 px-2">Sub-100ms Decision Routing</td>
                <td className="py-2 px-2 text-rose-400">❌ (2500ms+)</td>
                <td className="py-2 px-2 text-amber-400">⚠️ (Hardcoded)</td>
                <td className="py-2 px-2 text-emerald-400 font-bold">✔ Yes (Jev AI 44ms)</td>
              </tr>
              <tr>
                <td className="py-2 px-2">Real-time Webcam Vision</td>
                <td className="py-2 px-2 text-amber-400">⚠️ (Slow upload)</td>
                <td className="py-2 px-2 text-rose-400">❌ No</td>
                <td className="py-2 px-2 text-emerald-400 font-bold">✔ Yes (Astra Stream)</td>
              </tr>
              <tr>
                <td className="py-2 px-2">Android ADB Automation</td>
                <td className="py-2 px-2 text-rose-400">❌ No</td>
                <td className="py-2 px-2 text-amber-400">⚠️ (CLI only)</td>
                <td className="py-2 px-2 text-emerald-400 font-bold">✔ Yes (Intents + Media)</td>
              </tr>
              <tr>
                <td className="py-2 px-2">3D Holographic Globe HUD</td>
                <td className="py-2 px-2 text-rose-400">❌ No</td>
                <td className="py-2 px-2 text-rose-400">❌ No</td>
                <td className="py-2 px-2 text-emerald-400 font-bold">✔ Yes (Earthquakes/Orbit)</td>
              </tr>
              <tr>
                <td className="py-2 px-2">Local PII Masking Vault</td>
                <td className="py-2 px-2 text-rose-400">❌ No</td>
                <td className="py-2 px-2 text-rose-400">❌ No</td>
                <td className="py-2 px-2 text-emerald-400 font-bold">✔ Yes (Zero Leakage)</td>
              </tr>
            </tbody>
          </table>
        </div>
      ),
      speakerNotes:
        'This matrix clearly illustrates the architectural leap: unlike isolated web chatbots or fragile scripts, Hayat delivers a complete, cohesive, multi-sensory workstation environment.',
    },
  ];

  const currentSlides = activeDeck === 'technical' ? TECHNICAL_SLIDES : PRODUCT_SLIDES;
  const currentSlide = currentSlides[currentSlideIndex];

  const handleNext = () => {
    setCurrentSlideIndex((prev) => (prev + 1) % currentSlides.length);
  };

  const handlePrev = () => {
    setCurrentSlideIndex((prev) => (prev - 1 + currentSlides.length) % currentSlides.length);
  };

  return (
    <div
      className={`flex flex-col bg-[#0b0f19]/95 border border-slate-800 rounded-2xl backdrop-blur-xl shadow-2xl overflow-hidden transition-all ${
        isFullScreen ? 'fixed inset-4 z-50 p-6' : 'p-5'
      }`}
    >
      {/* Top Deck Switcher & Presentation Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pb-3 border-b border-slate-800 mb-4">
        <div className="flex items-center gap-2">
          <Presentation className="w-5 h-5 text-cyan-400" />
          <h3 className="font-display font-bold text-base text-slate-100 uppercase tracking-wide">
            Project Review Presentation Studio
          </h3>
        </div>

        {/* Deck Toggle Buttons */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs font-mono">
            <button
              onClick={() => {
                setActiveDeck('technical');
                setCurrentSlideIndex(0);
              }}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeDeck === 'technical'
                  ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              DECK 1: TECHNICAL REVIEW
            </button>
            <button
              onClick={() => {
                setActiveDeck('product');
                setCurrentSlideIndex(0);
              }}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeDeck === 'product'
                  ? 'bg-purple-500/20 text-purple-300 font-bold border border-purple-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              DECK 2: PRODUCT SHOWCASE
            </button>
          </div>

          <button
            onClick={() => setIsFullScreen(!isFullScreen)}
            title={isFullScreen ? 'Exit Full Screen' : 'Full Screen'}
            className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
          >
            {isFullScreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Slide Canvas */}
      <div className="flex-1 bg-gradient-to-b from-[#0f172a]/90 to-[#070b14] border border-slate-800 rounded-xl p-6 sm:p-8 flex flex-col justify-between shadow-inner relative overflow-hidden">
        {/* Slide Header */}
        <div className="border-b border-slate-800/80 pb-4 mb-4">
          <div className="text-[11px] font-mono text-cyan-400 tracking-widest uppercase mb-1">
            {currentSlide.tag}
          </div>
          <h2 className="font-display font-extrabold text-xl sm:text-2xl text-slate-100 tracking-tight">
            {currentSlide.title}
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 font-sans">{currentSlide.subtitle}</p>
        </div>

        {/* Slide Body Content */}
        <div className="flex-1 my-2 overflow-y-auto">{currentSlide.content}</div>

        {/* Slide Footer / Affiliation */}
        <div className="pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-[11px] font-mono text-slate-500 gap-2">
          <span>Presenter: Subhashree Narayanan · MCA GenAI · SRMIST Trichy</span>
          <span>Slide {currentSlideIndex + 1} of {currentSlides.length}</span>
        </div>
      </div>

      {/* Navigation Controls & Presenter Speaker Notes */}
      <div className="mt-4 pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Thumbnails dot navigator */}
        <div className="flex items-center gap-1.5">
          {currentSlides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentSlideIndex(idx)}
              className={`h-2 rounded-full transition-all ${
                currentSlideIndex === idx ? 'w-8 bg-cyan-400' : 'w-2 bg-slate-700 hover:bg-slate-500'
              }`}
            />
          ))}
        </div>

        {/* Prev / Next Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowNotes(!showNotes)}
            className={`text-xs font-mono px-3 py-1.5 rounded-lg border transition-colors ${
              showNotes ? 'bg-amber-500/15 border-amber-500/40 text-amber-300' : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
          >
            {showNotes ? 'HIDE SPEAKER NOTES' : 'SPEAKER NOTES FOR GUIDE'}
          </button>

          <button
            onClick={handlePrev}
            className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-mono border border-slate-700 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>PREV</span>
          </button>
          <button
            onClick={handleNext}
            className="flex items-center gap-1 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded-lg text-xs font-mono transition-colors"
          >
            <span>NEXT</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Speaker Notes Drawer */}
      {showNotes && (
        <div className="mt-3 p-3 bg-amber-950/20 border border-amber-500/30 rounded-xl text-xs">
          <div className="flex items-center gap-1.5 font-mono font-semibold text-amber-400 mb-1">
            <BookOpen className="w-3.5 h-3.5" />
            <span>EXPLANATION SCRIPT FOR GUIDE / EXAMINER:</span>
          </div>
          <p className="text-slate-300 italic leading-relaxed font-sans">{currentSlide.speakerNotes}</p>
        </div>
      )}
    </div>
  );
};
