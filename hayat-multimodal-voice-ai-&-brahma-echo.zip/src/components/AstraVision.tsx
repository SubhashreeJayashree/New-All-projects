import React, { useState, useRef, useEffect } from 'react';
import { Camera, RefreshCw, Eye, Share2, AlertCircle, Scan, CheckCircle2, Crosshair } from 'lucide-react';

interface AstraVisionProps {
  onAnalyzeFrame: (base64Image: string, promptText?: string) => Promise<string>;
  isAnalyzing: boolean;
  onClose?: () => void;
}

export const AstraVision: React.FC<AstraVisionProps> = ({ onAnalyzeFrame, isAnalyzing, onClose }) => {
  const [useLiveCam, setUseLiveCam] = useState(false);
  const [selectedDemoScene, setSelectedDemoScene] = useState<number>(0);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [visionAnalysis, setVisionAnalysis] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [detectedObjects, setDetectedObjects] = useState<Array<{ name: string; box: [number, number, number, number]; confidence: number }>>([]);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Pre-loaded realistic Astra test scenarios with synthetic high-resolution image data
  const DEMO_SCENES = [
    {
      id: 0,
      title: 'Dev Workspace & Android Phone',
      description: 'Dual monitor, Android phone connected via USB, mechanical keyboard, coffee mug.',
      imageUrl: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80',
      mockObjects: [
        { name: 'Android Device (ADB Connected)', box: [55, 30, 85, 55], confidence: 0.98 },
        { name: 'Display Monitor', box: [15, 10, 55, 75], confidence: 0.99 },
        { name: 'Coffee Cup', box: [65, 75, 88, 92], confidence: 0.94 },
      ],
      defaultPrompt: 'What do you see on my desk and check if my phone is ready?',
    },
    {
      id: 1,
      title: 'Code Bug & Terminal Stack Trace',
      description: 'Python runtime exception intercepted in developer editor.',
      imageUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80',
      mockObjects: [
        { name: 'TypeError Stack Trace', box: [25, 20, 60, 80], confidence: 0.97 },
        { name: 'Python Module (test_action.py)', box: [10, 15, 30, 50], confidence: 0.96 },
      ],
      defaultPrompt: 'Analyze this code error on my screen and tell me how to fix it.',
    },
    {
      id: 2,
      title: 'Misplaced Keys & Essentials (Astra Finder)',
      description: 'Spatial memory query to locate mislaid house keys and wallet.',
      imageUrl: 'https://images.unsplash.com/photo-1582139329536-e7284fece509?auto=format&fit=crop&w=800&q=80',
      mockObjects: [
        { name: 'House Key Ring', box: [40, 35, 68, 62], confidence: 0.99 },
        { name: 'Leather Cardholder', box: [45, 65, 75, 88], confidence: 0.95 },
      ],
      defaultPrompt: 'Where did I leave my keys? Can you spot them in this room?',
    },
  ];

  // Webcam stream management
  useEffect(() => {
    let stream: MediaStream | null = null;

    if (useLiveCam) {
      navigator.mediaDevices
        ?.getUserMedia({ video: { width: { ideal: 1280 }, height: { ideal: 720 } } })
        .then((s) => {
          stream = s;
          if (videoRef.current) {
            videoRef.current.srcObject = s;
            videoRef.current.play();
          }
          setErrorMsg(null);
        })
        .catch((err) => {
          console.warn('Camera permission denied or unavailable:', err);
          setErrorMsg('Camera access is restricted or unsupported in this view. Using Astra visual simulation.');
          setUseLiveCam(false);
        });
    } else {
      if (videoRef.current && videoRef.current.srcObject) {
        const s = videoRef.current.srcObject as MediaStream;
        s.getTracks().forEach((track) => track.stop());
        videoRef.current.srcObject = null;
      }
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [useLiveCam]);

  // Capture frame from webcam video
  const captureLiveFrame = (): string | null => {
    if (!videoRef.current || !canvasRef.current) return null;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.85);
  };

  // Convert image URL to Base64 for demo scenes
  const getDemoBase64 = async (url: string): Promise<string> => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(blob);
      });
    } catch (e) {
      // Return a reliable fallback 1x1 colored pixel or data uri
      return 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=';
    }
  };

  const handleInspect = async (customPrompt?: string) => {
    setErrorMsg(null);
    let imgData: string | null = null;

    if (useLiveCam) {
      imgData = captureLiveFrame();
    } else {
      const current = DEMO_SCENES[selectedDemoScene];
      imgData = await getDemoBase64(current.imageUrl);
      setDetectedObjects(current.mockObjects as any);
    }

    if (!imgData) {
      setErrorMsg('Failed to acquire vision frame.');
      return;
    }

    setCapturedImage(imgData);
    const prompt = customPrompt || (useLiveCam ? 'What do you see in this live webcam feed? Describe objects and environment.' : DEMO_SCENES[selectedDemoScene].defaultPrompt);

    try {
      const analysis = await onAnalyzeFrame(imgData, prompt);
      setVisionAnalysis(analysis);
    } catch (e: any) {
      setErrorMsg(e?.message || 'Error executing Astra vision analysis.');
    }
  };

  return (
    <div className="flex flex-col bg-[#0b0f19]/90 border border-slate-800 rounded-2xl p-5 backdrop-blur-xl shadow-2xl relative overflow-hidden">
      {/* Hidden canvas for video frame extraction */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800/80 mb-4">
        <div className="flex items-center gap-2">
          <Scan className="w-5 h-5 text-cyan-400 animate-pulse" />
          <h2 className="font-display font-bold text-base tracking-wide text-slate-100 uppercase">
            Project Astra Vision Pipeline
          </h2>
        </div>

        {/* Live cam / Simulated toggle & Close */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setUseLiveCam(!useLiveCam)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono transition-all ${
              useLiveCam
                ? 'bg-cyan-500/20 border border-cyan-500/50 text-cyan-300 font-semibold'
                : 'bg-slate-800/70 border border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            {useLiveCam ? 'WEBCAM: ACTIVE' : 'USE WEBCAM'}
          </button>

          {onClose && (
            <button
              onClick={onClose}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/30 text-slate-300 hover:text-rose-300 border border-slate-700 hover:border-rose-500/50 transition-colors text-xs font-semibold font-mono"
              title="Close Astra Vision and return to Hayat face"
            >
              ✕ CLOSE
            </button>
          )}
        </div>
      </div>

      {/* Error alert */}
      {errorMsg && (
        <div className="mb-4 flex items-center gap-2 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Viewport Frame */}
      <div className="relative w-full aspect-video bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center group shadow-inner">
        {useLiveCam ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
        ) : (
          <img
            src={DEMO_SCENES[selectedDemoScene].imageUrl}
            alt={DEMO_SCENES[selectedDemoScene].title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        )}

        {/* Cybernetic HUD Overlay Grid */}
        <div className="absolute inset-0 pointer-events-none border border-cyan-500/20 rounded-xl scanline-bg" />

        {/* Viewport Corners */}
        <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-cyan-400 pointer-events-none" />
        <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-cyan-400 pointer-events-none" />
        <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-cyan-400 pointer-events-none" />
        <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-cyan-400 pointer-events-none" />

        {/* Center Target Reticle */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-40">
          <Crosshair className="w-12 h-12 text-cyan-400 stroke-1 animate-spin-slow" />
        </div>

        {/* Detected Objects Bounding Boxes (Astra style) */}
        {!useLiveCam &&
          DEMO_SCENES[selectedDemoScene].mockObjects.map((obj, i) => (
            <div
              key={i}
              className="absolute border border-cyan-400/80 bg-cyan-500/10 rounded pointer-events-none transition-all duration-300"
              style={{
                top: `${obj.box[0]}%`,
                left: `${obj.box[1]}%`,
                height: `${obj.box[2] - obj.box[0]}%`,
                width: `${obj.box[3] - obj.box[1]}%`,
              }}
            >
              <span className="absolute -top-5 left-0 px-1.5 py-0.5 bg-slate-900/90 border border-cyan-500/60 rounded text-[9px] font-mono text-cyan-300 font-semibold tracking-wider whitespace-nowrap shadow">
                {obj.name} ({Math.round(obj.confidence * 100)}%)
              </span>
            </div>
          ))}

        {/* Status Tag in Viewport */}
        <div className="absolute bottom-3 left-3 flex items-center gap-2 px-2.5 py-1 bg-slate-900/85 backdrop-blur-md rounded-md border border-slate-700/80 text-[11px] font-mono text-slate-300 pointer-events-none">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span>FPS: 30 · RES: 1280x720 · ASTRA STREAM</span>
        </div>

        {/* Analyzing Spinner Overlay */}
        {isAnalyzing && (
          <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm flex flex-col items-center justify-center gap-3 z-20">
            <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
            <span className="text-xs font-mono font-medium text-cyan-300 tracking-wider">
              ANALYZING ASTRA SPATIAL VISION...
            </span>
          </div>
        )}
      </div>

      {/* Preset Astra Scenes Selector (when not using live webcam) */}
      {!useLiveCam && (
        <div className="flex items-center gap-2 mt-3 overflow-x-auto pb-1">
          {DEMO_SCENES.map((scene) => (
            <button
              key={scene.id}
              onClick={() => {
                setSelectedDemoScene(scene.id);
                setVisionAnalysis('');
              }}
              className={`shrink-0 px-3 py-1.5 rounded-lg text-xs font-mono transition-all text-left ${
                selectedDemoScene === scene.id
                  ? 'bg-cyan-500/15 border border-cyan-500/50 text-cyan-300'
                  : 'bg-slate-900/60 border border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="font-semibold">{scene.title}</div>
            </button>
          ))}
        </div>
      )}

      {/* Vision Inspection Trigger Bar */}
      <div className="flex items-center gap-3 mt-4">
        <button
          onClick={() => handleInspect()}
          disabled={isAnalyzing}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-mono font-bold text-xs tracking-wider rounded-xl shadow-lg shadow-cyan-500/20 active:scale-[0.98] transition-all disabled:opacity-50"
        >
          <Eye className="w-4 h-4" />
          <span>INSPECT ASTRA FRAME NOW</span>
        </button>

        <button
          onClick={() => handleInspect('Read any text visible in this frame')}
          disabled={isAnalyzing}
          title="OCR: Read visible text"
          className="px-3.5 py-2.5 bg-slate-800/80 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-mono border border-slate-700 transition-colors"
        >
          OCR TEXT
        </button>
      </div>

      {/* Real-time Vision Output Box */}
      {visionAnalysis && (
        <div className="mt-4 p-3.5 bg-cyan-950/20 border border-cyan-500/30 rounded-xl">
          <div className="flex items-center gap-1.5 text-xs font-mono font-semibold text-cyan-400 mb-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>ASTRA MULTIMODAL OBSERVATION</span>
          </div>
          <p className="text-xs text-slate-200 leading-relaxed font-sans">{visionAnalysis}</p>
        </div>
      )}
    </div>
  );
};
