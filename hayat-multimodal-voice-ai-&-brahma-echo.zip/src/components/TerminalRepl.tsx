import React, { useState, useRef, useEffect } from 'react';
import { Terminal, Send, Trash2, Sparkles, ChevronRight, CornerDownLeft, Volume2 } from 'lucide-react';
import { ChatMessage } from '../types';

interface TerminalReplProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => Promise<void>;
  onClearHistory: () => void;
  onSpeakText?: (text: string) => void;
  isProcessing: boolean;
}

export const TerminalRepl: React.FC<TerminalReplProps> = ({
  messages,
  onSendMessage,
  onClearHistory,
  onSpeakText,
  isProcessing,
}) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const QUICK_PROMPTS = [
    { label: '👁️ What do you see?', text: 'Look at my desk and describe what you see through Astra vision' },
    { label: '📱 WhatsApp Neon', text: 'Send a WhatsApp message to Neon: How are you?' },
    { label: '🎵 Play Tum Hardafa Ho', text: 'Play Tum Hardafa Ho on YouTube and skip ads' },
    { label: '🌍 Show 3D Earth', text: 'Hey Jarvis, just show me the Earth' },
    { label: '📡 Satellite View', text: 'Alright Jarvis, just change to satellite view' },
    { label: '🌋 Scan Earthquakes', text: 'Show the earthquakes that happened in this area' },
    { label: '🔋 Check Battery', text: 'Check device battery and system vitals' },
    { label: '💼 Career Bot', text: 'Apply for AI Engineer role at Google DeepMind with my resume' },
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isProcessing) return;
    const txt = inputText.trim();
    setInputText('');
    onSendMessage(txt);
  };

  return (
    <div className="flex flex-col h-[520px] bg-[#0b0f19]/90 border border-slate-800 rounded-2xl backdrop-blur-xl shadow-2xl overflow-hidden font-mono text-xs">
      {/* Shell Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-900/90 border-b border-slate-800 shrink-0">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span className="font-bold text-slate-200 tracking-wider text-[11px] uppercase">
            Hayat &amp; Brahma Echo Interactive REPL Hub
          </span>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-[10px] text-slate-500 hidden sm:inline">
            SYSTEM 1 (GREEN) · SYSTEM 2 (CYAN) · ADB (YELLOW)
          </span>
          <button
            onClick={onClearHistory}
            title="Clear Terminal Output"
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Quick Prompts Bar */}
      <div className="px-4 py-2 bg-slate-950/60 border-b border-slate-800/80 flex items-center gap-1.5 overflow-x-auto shrink-0">
        <span className="text-[10px] text-slate-500 uppercase tracking-widest shrink-0 mr-1 font-semibold">
          QUICK TRIGGER:
        </span>
        {QUICK_PROMPTS.map((qp, idx) => (
          <button
            key={idx}
            onClick={() => onSendMessage(qp.text)}
            className="shrink-0 px-2.5 py-1 bg-slate-900/80 border border-slate-800 hover:border-slate-700 rounded text-[11px] text-slate-300 hover:text-cyan-300 transition-all active:scale-95"
          >
            {qp.label}
          </button>
        ))}
      </div>

      {/* Message Output Terminal Stream */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 font-mono text-xs select-text">
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          const isSystem = msg.sender === 'system';

          if (isSystem) {
            return (
              <div key={msg.id} className="text-slate-500 italic text-[11px] border-l-2 border-slate-700 pl-2 my-1">
                [{msg.timestamp}] {msg.text}
              </div>
            );
          }

          return (
            <div
              key={msg.id}
              className={`p-3 rounded-xl border ${
                isUser
                  ? 'bg-slate-900/60 border-slate-800 ml-4'
                  : 'bg-cyan-950/20 border-cyan-500/30 mr-4'
              }`}
            >
              {/* Header meta */}
              <div className="flex items-center justify-between text-[10px] text-slate-500 mb-1">
                <span className={isUser ? 'text-amber-400 font-bold' : 'text-cyan-400 font-bold'}>
                  {isUser ? 'YOU (OPERATOR)' : 'HAYAT ASTRA AI (حياة)'}
                </span>
                <div className="flex items-center gap-2">
                  {!isUser && onSpeakText && (
                    <button
                      onClick={() => onSpeakText(msg.text)}
                      title="Read response aloud"
                      className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-bold px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30"
                    >
                      <Volume2 className="w-3 h-3" />
                      <span>SPEAK</span>
                    </button>
                  )}
                  {msg.system1Route && (
                    <span className="text-emerald-400">
                      SYS1: {msg.system1Route} ({msg.durationMs}ms)
                    </span>
                  )}
                  <span>{msg.timestamp}</span>
                </div>
              </div>

              {/* Text content */}
              <div className={`leading-relaxed text-xs ${isUser ? 'text-slate-200' : 'text-cyan-100'}`}>
                {msg.text}
              </div>

              {/* ADB action tag if applicable */}
              {msg.adbAction && (
                <div className="mt-2 inline-block px-2 py-0.5 bg-yellow-500/10 border border-yellow-500/30 rounded text-[10px] text-yellow-300 font-bold">
                  ADB INTENT: {msg.adbAction}
                </div>
              )}
            </div>
          );
        })}

        {isProcessing && (
          <div className="flex items-center gap-2 text-cyan-400 text-xs italic animate-pulse">
            <ChevronRight className="w-3.5 h-3.5" />
            <span>Hayat is processing multimodal speech and intent...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Box */}
      <form onSubmit={handleSubmit} className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2 shrink-0">
        <span className="text-emerald-400 font-bold pl-1">&gt;</span>
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Speak or type command (e.g. 'What do you see?', 'Send WhatsApp to Sarah', 'Play music')..."
          disabled={isProcessing}
          className="flex-1 bg-transparent text-slate-100 outline-none text-xs placeholder:text-slate-600 font-mono"
        />
        <button
          type="submit"
          disabled={!inputText.trim() || isProcessing}
          className="p-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold disabled:opacity-30 transition-all shrink-0"
        >
          <CornerDownLeft className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
