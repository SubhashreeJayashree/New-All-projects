import React, { useState } from 'react';
import { Briefcase, Send, CheckCircle2, ShieldCheck, FileText, Code2, Download, Copy, Sparkles, RefreshCw, KeyRound } from 'lucide-react';
import { CareerApplication } from '../types';

interface CareerWorkflowsProps {
  onDeployAgent: (role: string, company: string) => Promise<any>;
}

export const CareerWorkflows: React.FC<CareerWorkflowsProps> = ({ onDeployAgent }) => {
  const [role, setRole] = useState('AI Software Engineer');
  const [company, setCompany] = useState('Google DeepMind');
  const [isRunning, setIsRunning] = useState(false);
  const [activeStepIndex, setActiveStepIndex] = useState(0);
  const [otpInput, setOtpInput] = useState('');
  const [otpVerified, setOtpVerified] = useState(false);
  const [copiedLatex, setCopiedLatex] = useState(false);

  const [applicationData, setApplicationData] = useState<any>({
    status: 'READY',
    tailoredBulletPoints: [
      'Spearheaded multimodal voice assistant with Project Astra real-time vision and sub-100ms System 1 router.',
      'Engineered Android ADB automation bridge for WhatsApp intent messaging, telephony, and media control.',
      'Architected zero-trust PII sanitization and OpenTelemetry observability traces.',
    ],
    applicant: 'Subhashree Narayanan',
    email: 'nsubhashree853@gmail.com',
  });

  const STEPS = [
    { title: 'Job Scoping & Filtering', desc: 'Scrape role requirements and skills from portal' },
    { title: 'Graph RAG Alignment', desc: 'Match user candidate projects with vector store' },
    { title: 'Dynamic Resume Tailoring', desc: 'Synthesize custom quantified bullet points via Gemini' },
    { title: 'Headless Form Autofill', desc: 'Populate candidate details in Playwright browser' },
    { title: 'Human 2FA Verification', desc: 'Confirm OTP code sent to Telegram / Mobile' },
  ];

  const handleStartApplication = async () => {
    setIsRunning(true);
    setActiveStepIndex(0);
    setOtpVerified(false);

    try {
      // Step 1
      setActiveStepIndex(1);
      await new Promise((r) => setTimeout(r, 600));

      // Step 2
      setActiveStepIndex(2);
      await new Promise((r) => setTimeout(r, 700));

      // Step 3 (Call server API)
      const res = await onDeployAgent(role, company);
      setApplicationData(res);
      setActiveStepIndex(3);
      await new Promise((r) => setTimeout(r, 600));

      // Step 4: OTP Verification
      setActiveStepIndex(4);
    } finally {
      setIsRunning(false);
    }
  };

  const handleConfirmOtp = () => {
    if (otpInput.trim() === '849201' || otpInput.trim().length >= 4) {
      setOtpVerified(true);
      setActiveStepIndex(5);
    }
  };

  const sampleLatexCode = `\\documentclass[11pt,a4paper]{article}
\\usepackage[utf8]{inputenc}
\\usepackage[margin=0.75in]{geometry}
\\usepackage{hyperref}

\\begin{document}
\\begin{center}
    {\\Huge \\textbf{${applicationData.applicant || 'Subhashree Narayanan'}}}\\
    \\vspace{2mm}
    ${applicationData.email || 'nsubhashree853@gmail.com'} | +91-9876543210 | SRMIST Trichy
\\end{center}

\\section*{Target Role: ${role} @ ${company}}
\\section*{Core Competencies & Key Innovations}
\\begin{itemize}
${applicationData.tailoredBulletPoints
  .map((p: string) => `    \\item ${p}`)
  .join('\n')}
\\end{itemize}

\\section*{Autonomous Platform Architecture}
\\textbf{Hayat & Brahma Echo Engine} -- Autonomous Multimodal Voice AI paired with Project Astra Vision, TypeSafe Jev AI System 1 Decision Router (<100ms), and Android Debug Bridge hardware automation.
\\end{document}`;

  const handleCopyLatex = () => {
    navigator.clipboard.writeText(sampleLatexCode);
    setCopiedLatex(true);
    setTimeout(() => setCopiedLatex(false), 2000);
  };

  return (
    <div className="flex flex-col p-5 bg-[#0b0f19]/90 border border-slate-800 rounded-2xl backdrop-blur-xl shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
        <div className="flex items-center gap-2">
          <Briefcase className="w-5 h-5 text-indigo-400" />
          <h3 className="font-display font-bold text-base text-slate-100 uppercase tracking-wide">
            Autonomous Career &amp; Task Pipeline (Muse AI Style)
          </h3>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-indigo-500/10 border border-indigo-500/30 rounded-lg text-xs font-mono text-indigo-300">
          <Sparkles className="w-3.5 h-3.5" />
          <span>BACKGROUND VM WORKER</span>
        </div>
      </div>

      <p className="text-xs text-slate-400 mb-4 leading-relaxed">
        Executes multi-step career tasks autonomously: searches job postings, tailors resume bullet points via
        Gemini 3.8 Flash, fills application forms in isolated headless browsers, and forwards 2FA OTPs to your phone.
      </p>

      {/* Target Role & Company inputs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
        <div>
          <label className="block text-[11px] font-mono text-slate-400 mb-1">TARGET ROLE</label>
          <input
            type="text"
            value={role}
            onChange={(e) => setRole(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-indigo-500"
          />
        </div>
        <div>
          <label className="block text-[11px] font-mono text-slate-400 mb-1">TARGET ORGANIZATION</label>
          <input
            type="text"
            value={company}
            onChange={(e) => setCompany(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Launch Button */}
      <button
        onClick={handleStartApplication}
        disabled={isRunning}
        className="w-full py-2.5 px-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-mono font-bold text-xs tracking-wider rounded-xl shadow-lg shadow-indigo-600/20 active:scale-[0.99] transition-all flex items-center justify-center gap-2 disabled:opacity-50 mb-6"
      >
        {isRunning ? (
          <>
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span>DISPATCHING AUTONOMOUS JOB AGENT...</span>
          </>
        ) : (
          <>
            <Send className="w-4 h-4" />
            <span>EXECUTE AUTONOMOUS JOB APPLICATION</span>
          </>
        )}
      </button>

      {/* Step-by-Step Progress Stepper */}
      <div className="space-y-3 mb-6">
        <h4 className="text-xs font-mono text-slate-400 font-semibold uppercase tracking-wider">
          Execution Lifecycle Stepper
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
          {STEPS.map((s, idx) => {
            const isCompleted = activeStepIndex > idx + 1;
            const isCurrent = activeStepIndex === idx + 1;
            return (
              <div
                key={idx}
                className={`p-2.5 rounded-xl border text-xs transition-all ${
                  isCompleted
                    ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
                    : isCurrent
                    ? 'bg-indigo-500/15 border-indigo-500/60 text-indigo-300 animate-pulse'
                    : 'bg-slate-900/40 border-slate-800 text-slate-500'
                }`}
              >
                <div className="flex items-center gap-1.5 font-mono font-bold text-[11px] mb-1">
                  <span>0{idx + 1}.</span>
                  <span>{s.title}</span>
                </div>
                <p className="text-[10px] opacity-80 leading-snug">{s.desc}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* OTP Forwarder Banner (If Step 4/5 is reached) */}
      {activeStepIndex >= 4 && !otpVerified && (
        <div className="p-4 bg-amber-500/10 border border-amber-500/40 rounded-xl mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center shrink-0">
              <KeyRound className="w-5 h-5 text-amber-400 animate-bounce" />
            </div>
            <div>
              <div className="font-semibold text-xs text-amber-300">
                2FA OTP Verification Required (Forwarded to Mobile)
              </div>
              <p className="text-[11px] text-slate-300 mt-0.5">
                Simulated authentication token pushed to your Telegram device: <strong className="text-white font-mono">849201</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <input
              type="text"
              value={otpInput}
              onChange={(e) => setOtpInput(e.target.value)}
              placeholder="Enter 849201"
              className="bg-slate-950 border border-amber-500/60 rounded px-3 py-1.5 text-xs font-mono text-white outline-none w-32"
            />
            <button
              onClick={handleConfirmOtp}
              className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-mono font-bold text-xs rounded transition-colors"
            >
              CONFIRM OTP
            </button>
          </div>
        </div>
      )}

      {otpVerified && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl mb-6 flex items-center gap-2 text-xs text-emerald-300">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Application successfully submitted! Receipt logged into persistent audit ledger.</span>
        </div>
      )}

      {/* LaTeX Resume Synthesizer & Code Previewer */}
      <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950">
        <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 text-xs font-mono text-slate-300">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            <span>DYNAMIC LATEX RESUME SYNTHESIZER (TAILORED ARTIFACT)</span>
          </div>
          <button
            onClick={handleCopyLatex}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 transition-colors"
          >
            {copiedLatex ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedLatex ? 'COPIED TEX' : 'COPY TEX'}</span>
          </button>
        </div>

        <pre className="p-4 text-[11px] font-mono text-slate-300 overflow-x-auto max-h-52 leading-relaxed selection:bg-cyan-500/30">
          {sampleLatexCode}
        </pre>
      </div>
    </div>
  );
};
