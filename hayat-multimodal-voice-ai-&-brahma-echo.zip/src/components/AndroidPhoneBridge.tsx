import React, { useState, useEffect, useRef } from 'react';
import {
  Smartphone,
  Phone,
  MessageSquare,
  Music,
  Play,
  Pause,
  Battery,
  Wifi,
  Send,
  PhoneCall,
  PhoneOff,
  Compass,
  Search,
  Camera,
  Share2,
  Heart,
  MessageCircle,
  ChevronLeft,
  Mail,
  Sparkles,
  ExternalLink,
  Radio,
  Calculator,
  FileText,
  Home,
  Globe,
  Tv,
  Lock,
  Sun,
  Wind,
} from 'lucide-react';
import { PhoneState, ADBCommandLog, CallLogItem } from '../types';
import { realtimeSocket } from '../utils/realtimeSocket';

interface AndroidPhoneBridgeProps {
  onExecuteADB: (action: string, payload?: any) => Promise<any>;
  sharedState?: PhoneState;
  onStateChange?: (state: PhoneState) => void;
  onClose?: () => void;
  activeVoiceHint?: string;
  onSpeak?: (text: string) => void;
}

export const AndroidPhoneBridge: React.FC<AndroidPhoneBridgeProps> = ({
  onExecuteADB,
  sharedState,
  onStateChange,
  onClose,
  activeVoiceHint,
  onSpeak,
}) => {
  const defaultLogs: CallLogItem[] = [
    { id: 'c1', contactName: 'Mom', phoneNumber: '+91 98765 11223', type: 'incoming', time: '10:05 AM', duration: '2m 14s' },
    { id: 'c2', contactName: 'Dad', phoneNumber: '+91 98765 99881', type: 'outgoing', time: '09:40 AM', duration: '4m 30s' },
    { id: 'c3', contactName: 'Neon', phoneNumber: '+91 98765 43210', type: 'missed', time: 'Yesterday' },
    { id: 'c4', contactName: 'Office Manager', phoneNumber: '+91 98765 77665', type: 'outgoing', time: 'Yesterday', duration: '1m 02s' },
    { id: 'c5', contactName: 'Sarah Jenkins', phoneNumber: '+91 98765 55443', type: 'incoming', time: 'Sep 23', duration: '5m 18s' },
  ];

  const [localState, setLocalState] = useState<PhoneState>({
    screen: 'home',
    isAwake: true,
    battery: 73,
    isCharging: true,
    callLogs: defaultLogs,
    activeCall: {
      contactName: 'Mom',
      phoneNumber: '+91 98765 11223',
      durationSec: 0,
      isActive: false,
      isRinging: true,
    },
    googleQuery: 'what is the current trending',
    googleResult: {
      title: 'Live Google Trending & Search',
      temperature: 'LIVE',
      condition: 'Real-Time Web Grounding',
      snippet: 'Ask or type any query to auto-type and fetch live Google Trending & News results.',
      items: [],
      relatedQueries: [
        'what is the current trending',
        'latest AI agent breakthroughs',
        'weather in Chennai today',
        'top Tamil songs 2026',
      ],
    },
    whatsappChat: {
      contact: 'Neon',
      phoneNumber: '+919876543210',
      messages: [
        { from: 'contact', text: 'Hey bro, is the real-time multi-agent system ready?', time: '10:14 AM' },
        { from: 'me', text: 'Yes, running all 6 video architectures in real time now.', time: '10:15 AM' },
      ],
      draftText: '',
    },
    youtubeSong: {
      platform: 'youtube',
      searchQuery: 'Manasellam Mazhai',
      title: 'Manasellam Mazhaiye',
      artist: 'Sonu Nigam, G.V. Prakash Kumar & Saindhavi',
      album: 'Saguni (Original Motion Picture Soundtrack)',
      artworkUrl:
        'https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/20/d2/b1/20d2b1e0-c71b-0b5a-fe2e-8a70eb671163/8903431508119.jpg/600x600bb.jpg',
      previewUrl:
        'https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/b5/fb/ba/b5fbbaa9-e796-5e95-e6d9-25adf7fd8beb/mzaf_5938035984002884182.plus.aac.p.m4a',
      youtubeVideoId: 'ujzCHdcFP7M',
      youtubeResults: [
        { videoId: 'ujzCHdcFP7M', title: 'Manasellam Mazhaiye Official Video Song | Saguni | Karthi | Pranitha' },
      ],
      isPlaying: false,
      adSkipped: true,
    },
    gmailState: {
      inbox: [
        {
          id: 'em1',
          from: 'Dr. K. Ramesh (HOD)',
          email: 'hod.mca@srmist.edu.in',
          subject: 'Final Project Review Schedule - Generative AI',
          snippet: 'Please ensure your real-time multi-agent demonstration is ready for the panel.',
          time: '10:30 AM',
          unread: true,
        },
        {
          id: 'em2',
          from: 'GitHub Actions',
          email: 'noreply@github.com',
          subject: '[Jarvis-Mark-LIV] Build & VPS Daemon Verified',
          snippet: 'All 6 video architectures passed continuous integration checks.',
          time: '09:15 AM',
        },
      ],
      compose: {
        to: 'hod.mca@srmist.edu.in',
        subject: 'Real-Time Multimodal AI Project Ready',
        body: 'Respected Sir, our unified real-time AI agent handling phone calls, emails, social media, Google search, and live music streaming is ready for demonstration.',
        status: 'ready',
      },
    },
    twitterState: {
      trends: [
        { tag: '#GPT6SolVsAstra', posts: '142.8K Posts', category: 'AI & Tech · Trending' },
        { tag: '#ManasellamMazhai', posts: '54.2K Posts', category: 'Music · Trending in India' },
        { tag: '#JarvisMark54', posts: '38.9K Posts', category: 'Robotics & HUD · Live' },
        { tag: '#MetaMuseVM', posts: '29.1K Posts', category: 'Autonomous Agents' },
      ],
      feed: [
        {
          id: 'tw1',
          author: 'BitBiasedAI',
          handle: '@BitBiasedAI',
          text: 'GPT-6 Sol is 5X cheaper than GPT-6 Astra ($2/$10 vs $10/$50), scoring 33.2% on AutomationBench for just $0.27/task while Astra blocks 97.3% biohigh threats!',
          time: '12m',
          likes: 1842,
          reposts: 412,
        },
        {
          id: 'tw2',
          author: 'Neon Labs AI',
          handle: '@neon_labs_ai',
          text: 'Hayat real-time voice phone bridge now controls Calls, Gmail, WhatsApp, Instagram, YouTube, Spotify & JioSaavn hands-free!',
          time: '28m',
          likes: 920,
          reposts: 185,
        },
      ],
    },
    notesState: {
      notes: [
        {
          id: 'n1',
          title: 'Alarm Set: 06:30 AM',
          content: 'Morning workout & AI Agent server check',
          time: 'Active',
          category: 'Alarm',
        },
        {
          id: 'n2',
          title: 'Project Demo Checklist',
          content: 'Test YouTube any-song playback, Google auto-type trending search, WhatsApp live reply, and 3D Earth HUD.',
          time: 'Today',
          category: 'Note',
        },
      ],
    },
    calculatorState: {
      expression: '193 * 5',
      result: '965',
      history: [
        { expr: '193 * 5 (System 1 Speedup)', res: '965' },
        { expr: '10 / 2 (Astra vs Sol Ratio)', res: '5' },
      ],
    },
    smartHomeState: {
      devices: [
        { id: 'd1', name: 'Living Room Lights', room: 'Living Room', status: true, value: '100% Warm', type: 'light' },
        { id: 'd2', name: 'Smart AC Climate', room: 'Master Bedroom', status: true, value: '22°C Cool', type: 'ac' },
        { id: 'd3', name: 'Front Door Biometric Lock', room: 'Entrance', status: true, value: 'LOCKED', type: 'lock' },
        { id: 'd4', name: 'OLED Home Theater TV', room: 'Media Room', status: true, value: 'YouTube 4K', type: 'tv' },
      ],
    },
    translatorState: {
      sourceText: 'Hello boss, I can open YouTube and play any song or search Google in real time.',
      targetLang: 'ta',
      translatedText: 'வணக்கம் பாஸ், நான் யூடியூப்பைத் திறந்து எந்தப் பாடலையும் இயக்கலாம் அல்லது நிகழ்நேரத்தில் கூகிளில் தேடலாம்.',
    },
  });

  const phoneState = sharedState || localState;
  const updateState = (updater: (prev: PhoneState) => PhoneState) => {
    const next = updater(phoneState);
    setLocalState(next);
    if (onStateChange) onStateChange(next);
  };

  const [isExecuting, setIsExecuting] = useState(false);
  const [typedGoogleText, setTypedGoogleText] = useState(phoneState.googleQuery || '');
  const [customSongInput, setCustomSongInput] = useState('');
  const [customWhatsAppText, setCustomWhatsAppText] = useState('');
  const [customDialName, setCustomDialName] = useState('');
  const [customDialNumber, setCustomDialNumber] = useState('+91 98765 11223');
  const [customTweetInput, setCustomTweetInput] = useState('');
  const [customNoteInput, setCustomNoteInput] = useState('');
  const [customCalcInput, setCustomCalcInput] = useState('');
  const [translateInput, setTranslateInput] = useState('');
  const [translateLang, setTranslateLang] = useState('ta');
  const [showYoutubeEmbed, setShowYoutubeEmbed] = useState(true);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const [logs, setLogs] = useState<ADBCommandLog[]>([
    {
      id: 'log_1',
      command: 'adb devices -l',
      result: '9A251FFAZ0019C device product:hayat_bridge model:Pixel_9_Pro (Real-Time Connected)',
      status: 'SUCCESS',
      durationMs: 12,
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);

  const addLog = (cmd: string, res: string, duration: number, id?: string) => {
    const newLog: ADBCommandLog = {
      id: id || `log_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      command: cmd,
      result: res,
      status: 'SUCCESS',
      durationMs: duration,
      timestamp: new Date().toLocaleTimeString(),
    };
    setLogs((prev) => {
      if (prev.some((l) => l.id === newLog.id)) return prev;
      return [newLog, ...prev.slice(0, 18)];
    });
  };

  // Subscribe to real-time WebSocket stream for ADB logs and WhatsApp replies
  useEffect(() => {
    const unsubInit = realtimeSocket.subscribe('init:state', (payload) => {
      if (Array.isArray(payload?.adbLogs) && payload.adbLogs.length > 0) {
        setLogs(payload.adbLogs);
      }
    });

    const unsubAdb = realtimeSocket.subscribe('adb:log', (entry) => {
      if (entry && entry.command) {
        addLog(entry.command, entry.result, entry.durationMs || 12, entry.id);
      }
    });

    const unsubWa = realtimeSocket.subscribe('whatsapp:reply', (replyPayload) => {
      if (!replyPayload?.text) return;
      updateState((prev) => ({
        ...prev,
        whatsappChat: {
          contact: replyPayload.contact || prev.whatsappChat?.contact || 'Neon',
          messages: [
            ...(prev.whatsappChat?.messages || []),
            {
              from: 'contact',
              text: replyPayload.text,
              time: replyPayload.time || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            },
          ],
        },
      }));
    });

    const unsubTrans = realtimeSocket.subscribe('translator:result', (tPayload) => {
      if (!tPayload?.translatedText) return;
      updateState((prev) => ({
        ...prev,
        translatorState: {
          sourceText: tPayload.sourceText,
          targetLang: tPayload.targetLang,
          translatedText: tPayload.translatedText,
        },
      }));
    });

    return () => {
      unsubInit();
      unsubAdb();
      unsubWa();
      unsubTrans();
    };
  }, []);

  // Real-time character-by-character auto-typing animation whenever googleQuery changes!
  useEffect(() => {
    const targetQuery = phoneState.googleQuery || '';
    if (!targetQuery) return;
    setTypedGoogleText('');
    let idx = 0;
    const interval = setInterval(() => {
      idx++;
      setTypedGoogleText(targetQuery.slice(0, idx));
      if (idx >= targetQuery.length) {
        clearInterval(interval);
      }
    }, 28);
    return () => clearInterval(interval);
  }, [phoneState.googleQuery]);

  // Auto-play HTML5 audio stream whenever previewUrl or youtubeSong changes and isPlaying is true
  useEffect(() => {
    if (audioRef.current && phoneState.youtubeSong?.previewUrl) {
      if (phoneState.youtubeSong.isPlaying) {
        if (audioRef.current.src !== phoneState.youtubeSong.previewUrl) {
          audioRef.current.src = phoneState.youtubeSong.previewUrl;
        }
        audioRef.current.play().catch(() => {
          // Handled by user click or YouTube embed
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [phoneState.youtubeSong?.previewUrl, phoneState.youtubeSong?.isPlaying, phoneState.youtubeSong?.title]);

  // Call timer simulation
  useEffect(() => {
    let timer: any;
    if (phoneState.activeCall?.isActive) {
      timer = setInterval(() => {
        updateState((prev) => ({
          ...prev,
          activeCall: prev.activeCall
            ? {
                ...prev.activeCall,
                durationSec: prev.activeCall.durationSec + 1,
                isRinging: prev.activeCall.durationSec < 2,
              }
            : undefined,
        }));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [phoneState.activeCall?.isActive]);

  // 1. REAL-TIME PHONE CALL
  const triggerCallContact = async (name: string, number: string) => {
    setIsExecuting(true);
    try {
      const res = await onExecuteADB('call', { phone: number });
      addLog(
        res.adbCommand || `adb shell am start -a android.intent.action.CALL -d tel:${number}`,
        res.result || `Dialing ${name}`,
        res.durationMs || 24
      );

      updateState((prev) => ({
        ...prev,
        screen: 'call',
        activeCall: {
          contactName: name,
          phoneNumber: number,
          durationSec: 0,
          isActive: true,
          isRinging: true,
        },
      }));
      onSpeak?.(`Calling ${name} at ${number} in real time.`);
    } finally {
      setIsExecuting(false);
    }
  };

  // 2. REAL-TIME GOOGLE AUTO-TYPE & LIVE WEB SEARCH
  const triggerGoogleSearch = async (query = 'what is the current trending') => {
    const cleanQ = query.trim() || 'what is the current trending';
    setIsExecuting(true);
    updateState((prev) => ({
      ...prev,
      screen: 'google',
      googleQuery: cleanQ,
      isTypingGoogle: true,
      googleResult: {
        title: `Auto-Typing in Google: "${cleanQ}"...`,
        temperature: 'LIVE',
        condition: 'Auto-typing & fetching real-time web results...',
        snippet: 'Connecting to Google Live News, Wikipedia & Search Grounding...',
        items: prev.googleResult?.items || [],
        wikiCard: prev.googleResult?.wikiCard,
        relatedQueries: prev.googleResult?.relatedQueries,
      },
    }));

    try {
      const adbCmd = `adb shell input text "${cleanQ.replace(/\s+/g, '%s')}" && adb shell input keyevent 66`;
      const r = await fetch('/api/realtime/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: cleanQ }),
      });
      const data = await r.json();
      addLog(
        adbCmd,
        `Fetched ${data.items?.length || 0} live Google results in ${data.durationMs || 180}ms`,
        data.durationMs || 180
      );

      updateState((prev) => ({
        ...prev,
        screen: 'google',
        googleQuery: cleanQ,
        isTypingGoogle: false,
        googleResult: {
          title: data.isTrending ? '🔥 Google Real-Time Trending Now' : `🔍 Live Google Results: "${cleanQ}"`,
          temperature: 'LIVE',
          condition: `${data.items?.length || 0} Real-Time Web Sources`,
          snippet: data.aiSummary,
          aiSummary: data.aiSummary,
          wikiCard: data.wikiCard,
          relatedQueries: data.relatedQueries,
          items: data.items || [],
        },
      }));
      if (data.aiSummary) {
        onSpeak?.(data.aiSummary);
      }
    } catch (e) {
      updateState((prev) => ({ ...prev, isTypingGoogle: false }));
    } finally {
      setIsExecuting(false);
    }
  };

  // 3. REAL-TIME MUSIC STREAMING (YouTube / Spotify / JioSaavn — Plays ANY Song Suggested!)
  const triggerPlayMusic = async (
    songQuery: string,
    platform: 'youtube' | 'spotify' | 'jiosaavn' = 'youtube'
  ) => {
    const cleanQuery = songQuery.trim() || 'Manasellam Mazhai';
    setIsExecuting(true);
    updateState((prev) => ({
      ...prev,
      screen: platform,
      youtubeSong: {
        ...(prev.youtubeSong || { title: cleanQuery, artist: 'Searching...', isPlaying: true, adSkipped: true }),
        platform,
        searchQuery: cleanQuery,
        title: `Searching & Auto-Playing "${cleanQuery}"...`,
        artist: `Connecting to ${platform.toUpperCase()} Live Stream...`,
        isPlaying: true,
        adSkipped: true,
      },
    }));

    try {
      const r = await fetch('/api/realtime/music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: cleanQuery, platform }),
      });
      const data = await r.json();

      const adbCmd = `adb shell am start -a android.media.action.MEDIA_PLAY_FROM_SEARCH -e query "${cleanQuery}"`;
      addLog(
        adbCmd,
        `Streaming "${data.title}" by ${data.artist} on ${platform.toUpperCase()} (Ad-Skip Active)`,
        data.durationMs || 210
      );

      updateState((prev) => ({
        ...prev,
        screen: platform,
        youtubeSong: {
          platform,
          searchQuery: cleanQuery,
          title: data.title || cleanQuery,
          artist: data.artist || 'Verified Artist',
          album: data.album || 'Official Audio',
          artworkUrl: data.artworkUrl,
          previewUrl: data.previewUrl,
          youtubeVideoId: data.youtubeVideoId,
          youtubeResults: data.youtubeResults || [],
          trackResults: data.trackResults || [],
          isPlaying: true,
          adSkipped: true,
        },
      }));

      onSpeak?.(`Playing ${data.title || cleanQuery} by ${data.artist || 'artist'} on ${platform} in real time.`);
    } finally {
      setIsExecuting(false);
    }
  };

  // 4. REAL-TIME WHATSAPP WITH LIVE AI CONTACT REPLY
  const triggerWhatsApp = async (contact = 'Neon', message = 'How are you?') => {
    if (!message.trim()) return;
    setIsExecuting(true);
    try {
      const res = await onExecuteADB('whatsapp', { phone: '+919876543210', message });
      addLog(res.adbCommand, res.result, res.durationMs);

      const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      updateState((prev) => ({
        ...prev,
        screen: 'whatsapp',
        whatsappChat: {
          contact,
          messages: [
            ...(prev.whatsappChat?.messages || []),
            { from: 'me', text: message, time: nowTime },
          ],
        },
      }));

      await fetch('/api/realtime/social', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appName: 'whatsapp', action: 'reply', contact, content: message }),
      });
    } finally {
      setIsExecuting(false);
    }
  };

  // 5. REAL-TIME GMAIL COMPOSE & SEND
  const triggerSendEmail = async (to: string, subject: string, bodyPrompt: string) => {
    setIsExecuting(true);
    try {
      const socialRes = await fetch('/api/realtime/social', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appName: 'gmail',
          action: 'compose',
          recipient: to,
          subject,
          content: bodyPrompt,
        }),
      });
      const socialData = await socialRes.json();
      const draftedBody = socialData.generatedReply || bodyPrompt;

      addLog(
        `adb shell am start -a android.intent.action.SENDTO -d mailto:${to}`,
        `Dispatched real-time email to ${to}: "${subject}"`,
        socialData.durationMs || 190
      );

      updateState((prev) => ({
        ...prev,
        screen: 'gmail',
        gmailState: {
          inbox: [
            {
              id: `sent_${Date.now()}`,
              from: `Me → ${to}`,
              email: to,
              subject: `✔ SENT: ${subject}`,
              snippet: draftedBody,
              time: 'Just now',
              unread: false,
            },
            ...(prev.gmailState?.inbox || []),
          ],
          compose: {
            to,
            subject,
            body: draftedBody,
            status: 'sent',
          },
        },
      }));
      onSpeak?.(`Email sent to ${to} with subject ${subject}.`);
    } finally {
      setIsExecuting(false);
    }
  };

  // 6. REAL-TIME TWITTER / X POST
  const triggerPostTweet = async (tweetTopic: string) => {
    setIsExecuting(true);
    try {
      const socialRes = await fetch('/api/realtime/social', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appName: 'twitter',
          action: 'post',
          content: tweetTopic,
        }),
      });
      const socialData = await socialRes.json();
      const text = socialData.generatedReply || tweetTopic;

      addLog(
        `adb shell am start -a android.intent.action.SEND -t text/plain -e android.intent.extra.TEXT "${text.slice(0, 40)}..."`,
        'Published live post to X / Twitter timeline',
        socialData.durationMs || 165
      );

      updateState((prev) => ({
        ...prev,
        screen: 'twitter',
        twitterState: {
          trends: prev.twitterState?.trends || [],
          feed: [
            {
              id: `tw_${Date.now()}`,
              author: 'Subhashree Narayanan',
              handle: '@subhashree_ai',
              text,
              time: 'Just now',
              likes: 1,
              reposts: 0,
            },
            ...(prev.twitterState?.feed || []),
          ],
        },
      }));
      onSpeak?.('Posted your update to Twitter X in real time.');
    } finally {
      setIsExecuting(false);
    }
  };

  // 7. REAL-TIME TRANSLATOR
  const triggerTranslate = async (textToTranslate: string, targetLangCode = translateLang) => {
    const clean = textToTranslate.trim();
    if (!clean) return;
    setIsExecuting(true);
    try {
      const r = await fetch('/api/realtime/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: clean, targetLang: targetLangCode }),
      });
      const d = await r.json();
      updateState((prev) => ({
        ...prev,
        screen: 'translator',
        translatorState: {
          sourceText: clean,
          targetLang: targetLangCode,
          translatedText: d.translatedText || clean,
        },
      }));
      onSpeak?.(d.translatedText || clean);
    } finally {
      setIsExecuting(false);
    }
  };

  // 8. REAL-TIME CALCULATOR EVALUATION
  const evaluateCalculation = (expr: string) => {
    const clean = expr.replace(/[^0-9+\-*/().%\s]/g, '').trim();
    if (!clean) return;
    try {
      // Safe math evaluation
      const val = Function(`"use strict"; return (${clean})`)();
      const resStr = String(Number(val.toFixed(6)));
      updateState((prev) => ({
        ...prev,
        screen: 'calculator',
        calculatorState: {
          expression: clean,
          result: resStr,
          history: [{ expr: clean, res: resStr }, ...(prev.calculatorState?.history || []).slice(0, 8)],
        },
      }));
      onSpeak?.(`${clean} equals ${resStr}`);
    } catch {
      updateState((prev) => ({
        ...prev,
        screen: 'calculator',
        calculatorState: {
          expression: expr,
          result: 'Invalid Expression',
          history: prev.calculatorState?.history || [],
        },
      }));
    }
  };

  const isMusicScreen =
    phoneState.screen === 'youtube' || phoneState.screen === 'spotify' || phoneState.screen === 'jiosaavn';

  return (
    <div className="flex flex-col gap-4 p-4 bg-[#060d14]/95 border border-[#1a5c7a] rounded-2xl backdrop-blur-xl shadow-2xl">
      {/* Hidden HTML5 Audio Player for instant real-time song playback */}
      <audio ref={audioRef} className="hidden" preload="auto" />

      {/* Top Navigation & Status Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-[#0d3347]">
        <div className="flex items-center gap-2.5">
          <div className="w-2.5 h-2.5 rounded-full bg-[#00ff88] animate-ping" />
          <span className="font-mono font-bold text-xs sm:text-sm text-[#8ffcff] flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-[#00ff88]" />
            REAL-TIME YOUTUBE, GOOGLE AUTO-TYPE, PHONE, EMAIL, SOCIAL &amp; IOT ENGINE
          </span>
          {activeVoiceHint && (
            <span className="hidden md:inline-block px-2.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-500/40 text-[10px] font-mono text-cyan-300">
              {activeVoiceHint}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          {phoneState.screen !== 'home' && (
            <button
              onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}
              className="px-2.5 py-1 rounded-lg bg-[#011622] hover:bg-[#022b42] text-[#00d4ff] border border-[#1a5c7a] text-[10px] font-mono font-bold"
            >
              ⌂ PHONE HOME (16 APPS)
            </button>
          )}
          {onClose && (
            <button
              onClick={onClose}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-rose-500/20 text-slate-300 hover:text-rose-300 border border-slate-700 text-[10px] font-mono font-semibold"
            >
              ✕ MINIMIZE
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-col xl:flex-row gap-5">
        {/* LEFT: Realistic Interactive Android Smartphone (16 Real-Time Apps) */}
        <div className="flex flex-col items-center justify-center shrink-0 mx-auto">
          <div className="w-[315px] sm:w-[335px] h-[650px] bg-slate-950 rounded-[42px] p-3 border-4 border-[#1a5c7a] shadow-[0_0_35px_rgba(0,212,255,0.18)] relative flex flex-col overflow-hidden">
            {/* Top Speaker / Dynamic Island */}
            <div className="absolute top-4 left-1/2 -translate-x-1/2 w-24 h-4 bg-slate-900 rounded-full z-30 flex items-center justify-center">
              <div className="w-2 h-2 rounded-full bg-slate-950 mr-2" />
              <div className="w-1.5 h-1.5 rounded-full bg-[#00ff88]" />
            </div>

            {/* Screen Content Container */}
            <div className="w-full h-full bg-[#080d16] rounded-[32px] overflow-hidden flex flex-col relative text-slate-100 text-xs">
              {/* Status Bar */}
              <div className="h-7 w-full flex items-center justify-between px-5 pt-1 text-[10px] font-mono z-20 bg-slate-950/60">
                <span className="font-bold text-[#00d4ff]">
                  {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
                <div className="flex items-center gap-1.5 text-slate-300">
                  <Wifi className="w-3 h-3 text-[#00d4ff]" />
                  <span className="text-[9px] text-[#00ff88] font-bold">5G LIVE</span>
                  <span className="text-[9px]">{phoneState.battery}%</span>
                  <Battery className="w-3.5 h-3.5 text-[#00ff88]" />
                </div>
              </div>

              {/* SCREEN 1: HOME SCREEN WITH 16 REAL-TIME APPS */}
              {phoneState.screen === 'home' && (
                <div className="flex-1 flex flex-col justify-between p-3.5 z-10">
                  <div className="mt-1 flex flex-col items-center">
                    <span className="text-2xl font-display font-bold text-white tracking-tight">
                      {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <span className="text-[9px] text-[#00d4ff] font-mono">
                      REAL-TIME ADB OS · 16 LIVE APPS READY
                    </span>

                    {/* Live Google Search Bar on Home Screen */}
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        triggerGoogleSearch(typedGoogleText || 'what is the current trending');
                      }}
                      className="w-full mt-2 px-3 py-1.5 bg-slate-900/95 border border-[#1a5c7a] rounded-full flex items-center gap-2 text-slate-300 shadow-lg"
                    >
                      <Search className="w-3.5 h-3.5 text-[#00d4ff] shrink-0" />
                      <input
                        type="text"
                        value={typedGoogleText}
                        onChange={(e) => setTypedGoogleText(e.target.value)}
                        placeholder="Google auto-type & live search..."
                        className="bg-transparent text-[10px] text-white outline-none flex-1 font-sans"
                      />
                    </form>
                  </div>

                  {/* 16 Real-Time App Icons Grid */}
                  <div className="grid grid-cols-4 gap-y-2.5 gap-x-1.5 my-auto">
                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'call_log' }))}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-blue-600 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <Phone className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">Phone Calls</span>
                    </button>

                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'gmail' }))}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-red-600 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <Mail className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">Gmail</span>
                    </button>

                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'whatsapp' }))}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-emerald-600 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <MessageSquare className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">WhatsApp</span>
                    </button>

                    <button
                      onClick={() => triggerGoogleSearch('what is the current trending')}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-white flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <span className="text-sm font-extrabold bg-gradient-to-r from-blue-600 via-red-500 to-amber-500 bg-clip-text text-transparent">
                          G
                        </span>
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">Google Live</span>
                    </button>

                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'youtube' }))}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-rose-600 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <Play className="w-4 h-4 text-white fill-white" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">YouTube</span>
                    </button>

                    <button
                      onClick={() =>
                        updateState((p) => ({
                          ...p,
                          screen: 'spotify',
                          youtubeSong: p.youtubeSong ? { ...p.youtubeSong, platform: 'spotify' } : undefined,
                        }))
                      }
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-[#1db954] flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <Music className="w-4 h-4 text-slate-950" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">Spotify</span>
                    </button>

                    <button
                      onClick={() =>
                        updateState((p) => ({
                          ...p,
                          screen: 'jiosaavn',
                          youtubeSong: p.youtubeSong ? { ...p.youtubeSong, platform: 'jiosaavn' } : undefined,
                        }))
                      }
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-teal-500 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <Radio className="w-4 h-4 text-slate-950" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">JioSaavn</span>
                    </button>

                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'instagram' }))}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <Camera className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">Instagram</span>
                    </button>

                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'twitter' }))}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-slate-900 border border-slate-700 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <span className="text-xs font-extrabold text-white">𝕏</span>
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">Twitter / X</span>
                    </button>

                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'notes' }))}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-amber-500 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <FileText className="w-4 h-4 text-slate-950" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">Notes/Alarm</span>
                    </button>

                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'calculator' }))}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <Calculator className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">Calculator</span>
                    </button>

                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'smarthome' }))}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-cyan-600 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <Home className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">Smart Home</span>
                    </button>

                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'translator' }))}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-purple-600 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <Globe className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">Translator</span>
                    </button>

                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'telegram' }))}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-sky-500 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <Send className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">Telegram</span>
                    </button>

                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'facebook' }))}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-blue-700 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <Share2 className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">Facebook</span>
                    </button>

                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'maps' }))}
                      className="flex flex-col items-center gap-1 group"
                    >
                      <div className="w-10 h-10 rounded-2xl bg-emerald-700 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        <Compass className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-[8px] text-slate-200 font-medium">Maps Live</span>
                    </button>
                  </div>

                  {/* Now Playing Mini Bar on Home Screen */}
                  {phoneState.youtubeSong && (
                    <div
                      onClick={() => updateState((p) => ({ ...p, screen: p.youtubeSong?.platform || 'youtube' }))}
                      className="p-2 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between cursor-pointer hover:border-[#00d4ff]"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <img
                          src={
                            phoneState.youtubeSong.artworkUrl ||
                            'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=100&q=80'
                          }
                          alt="Art"
                          className="w-8 h-8 rounded-lg object-cover shrink-0"
                        />
                        <div className="truncate">
                          <div className="text-[10px] font-bold text-white truncate">{phoneState.youtubeSong.title}</div>
                          <div className="text-[9px] text-[#00d4ff] truncate">{phoneState.youtubeSong.artist}</div>
                        </div>
                      </div>
                      <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 shrink-0">
                        {phoneState.youtubeSong.isPlaying ? '▶ PLAYING' : 'PAUSED'}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* SCREEN 2: CALL LOG & CUSTOM LIVE DIALER */}
              {phoneState.screen === 'call_log' && (
                <div className="flex-1 flex flex-col bg-[#0b0f19] z-10">
                  <div className="p-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <button onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}>
                        <ChevronLeft className="w-4 h-4 text-slate-300" />
                      </button>
                      <span className="font-bold text-xs">Real-Time Phone Dialer &amp; Logs</span>
                    </div>
                  </div>

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      triggerCallContact(customDialName || 'Contact', customDialNumber || '+91 98765 11223');
                    }}
                    className="p-2 bg-slate-900/60 border-b border-slate-800 space-y-1.5"
                  >
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        value={customDialName}
                        onChange={(e) => setCustomDialName(e.target.value)}
                        placeholder="Contact Name (e.g. Karthik)"
                        className="w-1/2 bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 text-[10px] text-white"
                      />
                      <input
                        type="text"
                        value={customDialNumber}
                        onChange={(e) => setCustomDialNumber(e.target.value)}
                        placeholder="+91 98765..."
                        className="w-1/2 bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 text-[10px] text-white font-mono"
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] flex items-center justify-center gap-1.5"
                    >
                      <PhoneCall className="w-3 h-3" /> DIAL NOW IN REAL TIME
                    </button>
                  </form>

                  <div className="flex-1 p-2 overflow-y-auto space-y-1.5">
                    {phoneState.callLogs.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => triggerCallContact(item.contactName, item.phoneNumber)}
                        className="p-2.5 bg-slate-900/80 hover:bg-blue-950/40 border border-slate-800 rounded-xl flex items-center justify-between cursor-pointer transition-all"
                      >
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-blue-600/30 border border-blue-500/40 text-blue-300 flex items-center justify-center font-bold text-xs">
                            {item.contactName[0]}
                          </div>
                          <div>
                            <div className="font-semibold text-xs text-slate-100">{item.contactName}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{item.phoneNumber}</div>
                          </div>
                        </div>
                        <div className="w-7 h-7 rounded-full bg-emerald-600 flex items-center justify-center text-white">
                          <PhoneCall className="w-3.5 h-3.5" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* SCREEN 3: ACTIVE PHONE CALL SCREEN */}
              {phoneState.screen === 'call' && (
                <div className="flex-1 flex flex-col items-center justify-between p-6 bg-gradient-to-b from-slate-900 via-blue-950 to-slate-950 z-10">
                  <div className="text-center mt-6">
                    <div className="w-20 h-20 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center mx-auto mb-3 shadow-xl animate-pulse">
                      <Phone className="w-10 h-10 text-emerald-300" />
                    </div>
                    <h3 className="font-bold text-base text-white">{phoneState.activeCall?.contactName}</h3>
                    <p className="text-xs text-cyan-300 font-mono mt-0.5">{phoneState.activeCall?.phoneNumber}</p>
                    <p className="text-xs text-[#00ff88] font-mono mt-3 font-bold">
                      {phoneState.activeCall?.isRinging
                        ? '📡 Ringing via ADB Telephony Bridge...'
                        : `🟢 Connected Live (00:${(phoneState.activeCall?.durationSec || 0).toString().padStart(2, '0')})`}
                    </p>
                  </div>

                  <div className="flex flex-col items-center gap-3 w-full mb-4">
                    <a
                      href={`tel:${phoneState.activeCall?.phoneNumber?.replace(/\s+/g, '') || '+919876511223'}`}
                      className="px-3 py-1.5 rounded-lg bg-blue-600/30 border border-blue-400/50 text-[10px] font-mono text-blue-200 hover:bg-blue-600/50"
                    >
                      📲 Trigger Hardware Carrier Dialer (tel:)
                    </a>
                    <button
                      onClick={() =>
                        updateState((p) => ({
                          ...p,
                          screen: 'call_log',
                          activeCall: p.activeCall ? { ...p.activeCall, isActive: false } : undefined,
                        }))
                      }
                      className="w-14 h-14 rounded-full bg-rose-600 flex items-center justify-center text-white shadow-xl hover:bg-rose-500"
                    >
                      <PhoneOff className="w-6 h-6" />
                    </button>
                  </div>
                </div>
              )}

              {/* SCREEN 4: REAL-TIME GOOGLE SEARCH & LIVE TRENDING */}
              {phoneState.screen === 'google' && (
                <div className="flex-1 flex flex-col bg-slate-950 z-10 justify-between">
                  <div className="p-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                    <span className="font-bold text-xs flex items-center gap-1">
                      <span className="text-blue-400">G</span>
                      <span className="text-red-400">o</span>
                      <span className="text-amber-400">o</span>
                      <span className="text-blue-400">g</span>
                      <span className="text-emerald-400">l</span>
                      <span className="text-red-400">e</span>
                      <span className="text-slate-300 font-mono text-[10px] ml-1.5">AUTO-TYPE &amp; SEARCH</span>
                    </span>
                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}
                      className="text-[10px] text-slate-400 hover:text-white"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="p-2.5 space-y-2 flex-1 overflow-y-auto">
                    {/* Auto-Typing Google Search Bar */}
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        triggerGoogleSearch(typedGoogleText);
                      }}
                      className="flex items-center gap-1.5 p-2 bg-slate-900 border-2 border-[#00d4ff] rounded-xl text-xs shadow"
                    >
                      <Search className="w-3.5 h-3.5 text-[#00d4ff] shrink-0" />
                      <input
                        type="text"
                        value={typedGoogleText}
                        onChange={(e) => setTypedGoogleText(e.target.value)}
                        placeholder="Type or speak any Google query..."
                        className="bg-transparent text-white outline-none flex-1 text-[11px] font-mono"
                      />
                      <button
                        type="submit"
                        className="px-2 py-0.5 rounded bg-[#00d4ff] text-slate-950 font-bold text-[9px] font-mono"
                      >
                        SEARCH
                      </button>
                    </form>

                    {/* AI Overview Card */}
                    {phoneState.googleResult?.snippet && (
                      <div className="p-2.5 bg-gradient-to-br from-cyan-950/80 to-slate-900 border border-cyan-500/40 rounded-xl space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono text-[#00ff88] font-bold flex items-center gap-1">
                            <Sparkles className="w-3 h-3" /> {phoneState.googleResult.title || 'AI REAL-TIME OVERVIEW'}
                          </span>
                          <span className="text-[8px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                            LIVE
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-100 leading-relaxed">
                          {phoneState.googleResult.snippet}
                        </p>
                      </div>
                    )}

                    {/* Wikipedia Knowledge Graph Card if present */}
                    {phoneState.googleResult?.wikiCard && (
                      <div className="p-2 bg-slate-900 border border-purple-500/40 rounded-xl flex gap-2 items-start">
                        {phoneState.googleResult.wikiCard.thumbnail && (
                          <img
                            src={phoneState.googleResult.wikiCard.thumbnail}
                            alt={phoneState.googleResult.wikiCard.title}
                            className="w-12 h-12 rounded-lg object-cover shrink-0"
                          />
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="text-[10px] font-bold text-purple-300">
                            📚 {phoneState.googleResult.wikiCard.title}
                          </div>
                          <p className="text-[9px] text-slate-300 line-clamp-3 mt-0.5">
                            {phoneState.googleResult.wikiCard.extract}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Real-Time Trending / News Items from Google RSS */}
                    {phoneState.googleResult?.items && phoneState.googleResult.items.length > 0 && (
                      <div className="space-y-1.5">
                        <div className="text-[9px] font-mono text-amber-300 uppercase tracking-wider font-bold">
                          🔥 Live Google Web Results ({phoneState.googleResult.items.length})
                        </div>
                        {phoneState.googleResult.items.map((item, idx) => (
                          <a
                            key={idx}
                            href={item.link}
                            target="_blank"
                            rel="noreferrer"
                            className="block p-2 rounded-lg bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 transition-all"
                          >
                            <div className="flex items-center justify-between text-[8px] text-cyan-400 font-mono mb-0.5">
                              <span>{item.source}</span>
                              <span>{item.pubDate.slice(0, 16)}</span>
                            </div>
                            <div className="text-[10px] font-semibold text-slate-100 leading-snug line-clamp-2">
                              {item.title}
                            </div>
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* SCREEN 5: UNIFIED REAL-TIME MUSIC STREAMING (YouTube / Spotify / JioSaavn) */}
              {isMusicScreen && (
                <div className="flex-1 flex flex-col bg-[#070b12] z-10 justify-between">
                  {/* Platform Switcher Header */}
                  <div className="p-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() =>
                          updateState((p) => ({
                            ...p,
                            screen: 'youtube',
                            youtubeSong: p.youtubeSong ? { ...p.youtubeSong, platform: 'youtube' } : undefined,
                          }))
                        }
                        className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold ${
                          phoneState.screen === 'youtube' ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        YouTube
                      </button>
                      <button
                        onClick={() =>
                          updateState((p) => ({
                            ...p,
                            screen: 'spotify',
                            youtubeSong: p.youtubeSong ? { ...p.youtubeSong, platform: 'spotify' } : undefined,
                          }))
                        }
                        className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold ${
                          phoneState.screen === 'spotify' ? 'bg-[#1db954] text-slate-950' : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        Spotify
                      </button>
                      <button
                        onClick={() =>
                          updateState((p) => ({
                            ...p,
                            screen: 'jiosaavn',
                            youtubeSong: p.youtubeSong ? { ...p.youtubeSong, platform: 'jiosaavn' } : undefined,
                          }))
                        }
                        className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold ${
                          phoneState.screen === 'jiosaavn' ? 'bg-teal-400 text-slate-950' : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        JioSaavn
                      </button>
                    </div>
                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}
                      className="text-[10px] text-slate-400"
                    >
                      ✕
                    </button>
                  </div>

                  {/* Search Any Song Bar */}
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!customSongInput.trim()) return;
                      triggerPlayMusic(customSongInput, phoneState.screen as 'youtube' | 'spotify' | 'jiosaavn');
                      setCustomSongInput('');
                    }}
                    className="px-2.5 pt-2 flex items-center gap-1.5"
                  >
                    <input
                      type="text"
                      value={customSongInput}
                      onChange={(e) => setCustomSongInput(e.target.value)}
                      placeholder="Type any song to play now..."
                      className="flex-1 bg-slate-900 border border-slate-700 focus:border-[#00d4ff] rounded-lg px-2.5 py-1.5 text-[10px] text-white outline-none"
                    />
                    <button
                      type="submit"
                      className="px-2.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-mono text-[9px] font-bold shrink-0"
                    >
                      ▶ PLAY
                    </button>
                  </form>

                  {/* Active Player Visual + Real Embedded YouTube or High-Res Artwork */}
                  <div className="p-2.5 space-y-2 flex-1 overflow-y-auto flex flex-col justify-between">
                    {phoneState.screen === 'youtube' &&
                    phoneState.youtubeSong?.youtubeVideoId &&
                    showYoutubeEmbed ? (
                      <div className="w-full aspect-video rounded-xl overflow-hidden border border-slate-800 bg-black relative">
                        <iframe
                          key={phoneState.youtubeSong.youtubeVideoId}
                          src={`https://www.youtube.com/embed/${phoneState.youtubeSong.youtubeVideoId}?autoplay=1&rel=0`}
                          title={phoneState.youtubeSong.title}
                          className="w-full h-full"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                        />
                      </div>
                    ) : (
                      <div className="w-full aspect-video rounded-xl overflow-hidden border border-slate-800 relative flex items-center justify-center bg-slate-900">
                        <img
                          src={
                            phoneState.youtubeSong?.artworkUrl ||
                            'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=600&q=80'
                          }
                          alt={phoneState.youtubeSong?.title}
                          className="w-full h-full object-cover opacity-80"
                        />
                        <div className="absolute bottom-2 right-2 px-2 py-0.5 bg-emerald-500/90 text-slate-950 font-bold rounded text-[8px] font-mono">
                          ✔ Auto Ad-Skipped
                        </div>
                      </div>
                    )}

                    {/* Song Metadata */}
                    <div className="space-y-0.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-mono uppercase tracking-wider text-[#00ff88]">
                          ● {phoneState.screen.toUpperCase()} LIVE STREAM
                        </span>
                        {phoneState.youtubeSong?.youtubeVideoId && (
                          <button
                            onClick={() => setShowYoutubeEmbed(!showYoutubeEmbed)}
                            className="text-[9px] font-mono text-cyan-400 underline"
                          >
                            {showYoutubeEmbed ? 'Artwork Mode' : 'Video Mode'}
                          </button>
                        )}
                      </div>
                      <h4 className="font-bold text-xs text-white truncate">
                        {phoneState.youtubeSong?.title || 'Manasellam Mazhaiye'}
                      </h4>
                      <p className="text-[10px] text-slate-300 truncate">
                        {phoneState.youtubeSong?.artist || 'Sonu Nigam, G.V. Prakash Kumar & Saindhavi'}
                      </p>
                    </div>

                    {/* Direct HTML5 Audio Stream Controls */}
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                      <button
                        onClick={() => {
                          const nextPlay = !phoneState.youtubeSong?.isPlaying;
                          updateState((p) => ({
                            ...p,
                            youtubeSong: p.youtubeSong ? { ...p.youtubeSong, isPlaying: nextPlay } : undefined,
                          }));
                          if (audioRef.current) {
                            if (nextPlay) audioRef.current.play().catch(() => {});
                            else audioRef.current.pause();
                          }
                        }}
                        className="px-2.5 py-1.5 rounded-lg bg-[#00ff88] text-slate-950 font-mono font-bold text-[10px] flex items-center gap-1"
                      >
                        {phoneState.youtubeSong?.isPlaying ? (
                          <>
                            <Pause className="w-3 h-3 fill-slate-950" /> PAUSE
                          </>
                        ) : (
                          <>
                            <Play className="w-3 h-3 fill-slate-950" /> PLAY AUDIO
                          </>
                        )}
                      </button>

                      {/* Alternative YouTube video switcher */}
                      {phoneState.youtubeSong?.youtubeResults && phoneState.youtubeSong.youtubeResults.length > 1 && (
                        <div className="flex items-center gap-1">
                          {phoneState.youtubeSong.youtubeResults.slice(0, 3).map((v, i) => (
                            <button
                              key={v.videoId}
                              onClick={() =>
                                updateState((p) => ({
                                  ...p,
                                  youtubeSong: p.youtubeSong
                                    ? { ...p.youtubeSong, youtubeVideoId: v.videoId, title: v.title }
                                    : undefined,
                                }))
                              }
                              className={`px-1.5 py-1 rounded text-[8px] font-mono ${
                                phoneState.youtubeSong?.youtubeVideoId === v.videoId
                                  ? 'bg-rose-600 text-white font-bold'
                                  : 'bg-slate-800 text-slate-300'
                              }`}
                            >
                              Vid #{i + 1}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* SCREEN 6: REAL-TIME GMAIL CLIENT */}
              {phoneState.screen === 'gmail' && (
                <div className="flex-1 flex flex-col bg-slate-950 z-10 justify-between">
                  <div className="p-2.5 bg-red-950/80 border-b border-red-800/60 flex items-center justify-between">
                    <span className="font-bold text-xs text-white flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-red-400" /> Gmail Real-Time Client
                    </span>
                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}
                      className="text-[10px] text-slate-300"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="p-2.5 flex-1 overflow-y-auto space-y-2">
                    <div className="p-2 rounded-xl bg-slate-900 border border-red-500/30 space-y-1.5">
                      <div className="text-[9px] font-mono text-red-300 font-bold">
                        ✉️ AI AUTO-COMPOSE &amp; DISPATCH EMAIL
                      </div>
                      <input
                        type="text"
                        value={phoneState.gmailState?.compose?.to || ''}
                        onChange={(e) =>
                          updateState((p) => ({
                            ...p,
                            gmailState: {
                              inbox: p.gmailState?.inbox || [],
                              compose: {
                                to: e.target.value,
                                subject: p.gmailState?.compose?.subject || 'Project Update',
                                body: p.gmailState?.compose?.body || '',
                                status: 'typing',
                              },
                            },
                          }))
                        }
                        placeholder="Recipient email..."
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-[10px] text-white"
                      />
                      <input
                        type="text"
                        value={phoneState.gmailState?.compose?.subject || ''}
                        onChange={(e) =>
                          updateState((p) => ({
                            ...p,
                            gmailState: {
                              inbox: p.gmailState?.inbox || [],
                              compose: {
                                to: p.gmailState?.compose?.to || 'hod.mca@srmist.edu.in',
                                subject: e.target.value,
                                body: p.gmailState?.compose?.body || '',
                                status: 'typing',
                              },
                            },
                          }))
                        }
                        placeholder="Subject..."
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-[10px] text-white"
                      />
                      <button
                        onClick={() =>
                          triggerSendEmail(
                            phoneState.gmailState?.compose?.to || 'hod.mca@srmist.edu.in',
                            phoneState.gmailState?.compose?.subject || 'Project Update',
                            phoneState.gmailState?.compose?.body || 'Project status update'
                          )
                        }
                        className="w-full py-1 rounded bg-red-600 hover:bg-red-500 text-white font-bold text-[10px]"
                      >
                        🚀 AI DRAFT &amp; SEND NOW
                      </button>
                    </div>

                    <div className="space-y-1.5">
                      {(phoneState.gmailState?.inbox || []).map((em) => (
                        <div key={em.id} className="p-2 rounded-xl bg-slate-900/90 border border-slate-800 space-y-0.5">
                          <div className="flex items-center justify-between text-[9px] font-mono text-slate-400">
                            <span className="text-white font-bold">{em.from}</span>
                            <span>{em.time}</span>
                          </div>
                          <div className="text-[10px] font-semibold text-red-300">{em.subject}</div>
                          <p className="text-[9px] text-slate-300 line-clamp-2">{em.snippet}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* SCREEN 7: REAL-TIME TWITTER / X */}
              {phoneState.screen === 'twitter' && (
                <div className="flex-1 flex flex-col bg-black z-10 justify-between">
                  <div className="p-2.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
                    <span className="font-bold text-xs text-white flex items-center gap-1.5">
                      <span className="text-sm">𝕏</span> Live Feed &amp; Trending
                    </span>
                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}
                      className="text-[10px] text-slate-400"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="p-2.5 flex-1 overflow-y-auto space-y-2.5">
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!customTweetInput.trim()) return;
                        triggerPostTweet(customTweetInput);
                        setCustomTweetInput('');
                      }}
                      className="flex gap-1.5"
                    >
                      <input
                        type="text"
                        value={customTweetInput}
                        onChange={(e) => setCustomTweetInput(e.target.value)}
                        placeholder="Topic to AI-post on X..."
                        className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-[10px] text-white"
                      />
                      <button
                        type="submit"
                        className="px-2.5 py-1 rounded-lg bg-sky-500 text-white font-bold text-[10px]"
                      >
                        Post
                      </button>
                    </form>

                    <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
                      <div className="text-[9px] font-mono text-sky-400 font-bold">TRENDING ON 𝕏 NOW</div>
                      {(phoneState.twitterState?.trends || []).map((t, i) => (
                        <div key={i} className="flex items-center justify-between text-[10px]">
                          <span className="font-bold text-white">{t.tag}</span>
                          <span className="text-[9px] text-slate-400 font-mono">{t.posts}</span>
                        </div>
                      ))}
                    </div>

                    <div className="space-y-1.5">
                      {(phoneState.twitterState?.feed || []).map((post) => (
                        <div key={post.id} className="p-2 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
                          <div className="flex items-center justify-between text-[9px]">
                            <span className="font-bold text-white">
                              {post.author} <span className="text-slate-400 font-normal">{post.handle}</span>
                            </span>
                            <span className="text-slate-500">{post.time}</span>
                          </div>
                          <p className="text-[10px] text-slate-200 leading-snug">{post.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* SCREEN 8: WHATSAPP LIVE CHAT */}
              {phoneState.screen === 'whatsapp' && (
                <div className="flex-1 flex flex-col bg-[#0b141b] z-10 justify-between">
                  <div className="bg-[#1f2c34] p-2.5 flex items-center justify-between border-b border-slate-700/60">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-emerald-600 flex items-center justify-center font-bold text-xs">
                        {(phoneState.whatsappChat?.contact || 'N')[0]}
                      </div>
                      <div>
                        <div className="font-semibold text-xs text-white">
                          {phoneState.whatsappChat?.contact || 'Neon'}
                        </div>
                        <div className="text-[9px] text-emerald-400">online · real-time AI reply active</div>
                      </div>
                    </div>
                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}
                      className="text-[10px] text-slate-400"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="flex-1 p-2.5 overflow-y-auto space-y-2 text-[11px]">
                    {phoneState.whatsappChat?.messages.map((m, i) => (
                      <div
                        key={i}
                        className={`max-w-[85%] p-2 rounded-xl text-[10px] ${
                          m.from === 'me'
                            ? 'ml-auto bg-[#005c4b] text-white rounded-br-none'
                            : 'bg-[#1f2c34] text-slate-200 rounded-bl-none'
                        }`}
                      >
                        <p>{m.text}</p>
                        <span className="text-[8px] opacity-70 block text-right mt-0.5">{m.time}</span>
                      </div>
                    ))}
                  </div>

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!customWhatsAppText.trim()) return;
                      triggerWhatsApp(phoneState.whatsappChat?.contact || 'Neon', customWhatsAppText);
                      setCustomWhatsAppText('');
                    }}
                    className="p-2 bg-[#1f2c34] flex items-center gap-1.5"
                  >
                    <input
                      type="text"
                      value={customWhatsAppText}
                      onChange={(e) => setCustomWhatsAppText(e.target.value)}
                      placeholder="Type live WhatsApp message..."
                      className="flex-1 bg-[#2a3942] rounded-full px-3 py-1.5 text-[10px] text-white outline-none"
                    />
                    <button
                      type="submit"
                      className="w-7 h-7 rounded-full bg-emerald-500 flex items-center justify-center text-slate-950 font-bold"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </form>
                </div>
              )}

              {/* SCREEN 9: INSTAGRAM */}
              {phoneState.screen === 'instagram' && (
                <div className="flex-1 flex flex-col bg-slate-950 z-10 justify-between">
                  <div className="p-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs">
                    <span className="font-bold bg-gradient-to-r from-amber-400 via-rose-400 to-purple-500 bg-clip-text text-transparent">
                      Instagram Live Feed &amp; Reels
                    </span>
                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}
                      className="text-[10px] text-slate-400"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="p-2.5 flex-1 overflow-y-auto space-y-2.5">
                    <div className="flex items-center gap-2 pb-2 border-b border-slate-800 overflow-x-auto">
                      {['Mom', 'Neon', 'Astra', 'Sol_AI', 'Muse'].map((n, i) => (
                        <div key={i} className="flex flex-col items-center gap-1 shrink-0">
                          <div className="w-9 h-9 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 to-rose-500">
                            <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center font-bold text-[10px]">
                              {n[0]}
                            </div>
                          </div>
                          <span className="text-[8px] text-slate-400">{n}</span>
                        </div>
                      ))}
                    </div>

                    <div className="p-2 bg-slate-900 rounded-xl space-y-1.5 border border-slate-800">
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="font-bold text-white">neon_labs_ai</span>
                        <span className="text-[8px] text-emerald-400 font-mono">LIVE REEL</span>
                      </div>
                      <img
                        src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=400&q=80"
                        alt="Instagram post"
                        className="w-full h-28 object-cover rounded-lg"
                      />
                      <div className="flex items-center gap-3 text-slate-300 pt-1">
                        <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
                        <MessageCircle className="w-4 h-4" />
                        <Share2 className="w-4 h-4" />
                      </div>
                      <p className="text-[10px] text-slate-300">
                        <strong>neon_labs_ai</strong> Real-time voice control across all 6 video architectures! 🚀
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* SCREEN 10: NOTES & ALARMS */}
              {phoneState.screen === 'notes' && (
                <div className="flex-1 flex flex-col bg-slate-950 z-10 justify-between">
                  <div className="p-2.5 bg-amber-950/60 border-b border-amber-700/40 flex items-center justify-between">
                    <span className="font-bold text-xs text-amber-300 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5" /> Voice Notes, Alarms &amp; Reminders
                    </span>
                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}
                      className="text-[10px] text-slate-400"
                    >
                      ✕
                    </button>
                  </div>
                  <div className="p-2.5 flex-1 overflow-y-auto space-y-2">
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!customNoteInput.trim()) return;
                        const text = customNoteInput.trim();
                        updateState((p) => ({
                          ...p,
                          notesState: {
                            notes: [
                              {
                                id: `n_${Date.now()}`,
                                title: text.toLowerCase().includes('alarm') ? 'Alarm Scheduled' : 'Voice Note Saved',
                                content: text,
                                time: 'Just now',
                                category: text.toLowerCase().includes('alarm') ? 'Alarm' : 'Note',
                              },
                              ...(p.notesState?.notes || []),
                            ],
                          },
                        }));
                        onSpeak?.(`Saved to your notes: ${text}`);
                        setCustomNoteInput('');
                      }}
                      className="flex gap-1.5"
                    >
                      <input
                        type="text"
                        value={customNoteInput}
                        onChange={(e) => setCustomNoteInput(e.target.value)}
                        placeholder="Add note, alarm, or reminder..."
                        className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-[10px] text-white"
                      />
                      <button
                        type="submit"
                        className="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 font-bold text-[10px]"
                      >
                        Save
                      </button>
                    </form>

                    {(phoneState.notesState?.notes || []).map((n) => (
                      <div key={n.id} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 space-y-0.5">
                        <div className="flex items-center justify-between text-[9px] font-mono">
                          <span className="text-amber-400 font-bold">{n.title}</span>
                          <span className="text-slate-400">{n.time}</span>
                        </div>
                        <p className="text-[10px] text-slate-200">{n.content}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* SCREEN 11: LIVE CALCULATOR */}
              {phoneState.screen === 'calculator' && (
                <div className="flex-1 flex flex-col bg-slate-950 z-10 justify-between">
                  <div className="p-2.5 bg-indigo-950/70 border-b border-indigo-700/40 flex items-center justify-between">
                    <span className="font-bold text-xs text-indigo-300 flex items-center gap-1.5">
                      <Calculator className="w-3.5 h-3.5" /> Real-Time Scientific Calculator
                    </span>
                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}
                      className="text-[10px] text-slate-400"
                    >
                      ✕
                    </button>
                  </div>
                  <div className="p-3 flex-1 flex flex-col justify-between space-y-2">
                    <div className="p-3 rounded-xl bg-slate-900 border border-indigo-500/40 text-right">
                      <div className="text-[10px] font-mono text-slate-400">
                        {phoneState.calculatorState?.expression || '0'}
                      </div>
                      <div className="text-xl font-mono font-bold text-[#00ff88] mt-1">
                        = {phoneState.calculatorState?.result || '0'}
                      </div>
                    </div>

                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        evaluateCalculation(customCalcInput);
                        setCustomCalcInput('');
                      }}
                      className="flex gap-1.5"
                    >
                      <input
                        type="text"
                        value={customCalcInput}
                        onChange={(e) => setCustomCalcInput(e.target.value)}
                        placeholder="e.g. (1450 * 12) + 500"
                        className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                      />
                      <button
                        type="submit"
                        className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white font-bold text-xs"
                      >
                        =
                      </button>
                    </form>

                    <div className="grid grid-cols-4 gap-1.5">
                      {['7', '8', '9', '/', '4', '5', '6', '*', '1', '2', '3', '-', '0', '.', 'C', '+'].map((btn) => (
                        <button
                          key={btn}
                          onClick={() => {
                            if (btn === 'C') setCustomCalcInput('');
                            else setCustomCalcInput((p) => p + btn);
                          }}
                          className="py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 font-mono text-xs font-bold text-white"
                        >
                          {btn}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* SCREEN 12: SMART HOME IOT */}
              {phoneState.screen === 'smarthome' && (
                <div className="flex-1 flex flex-col bg-slate-950 z-10 justify-between">
                  <div className="p-2.5 bg-cyan-950/70 border-b border-cyan-700/40 flex items-center justify-between">
                    <span className="font-bold text-xs text-cyan-300 flex items-center gap-1.5">
                      <Home className="w-3.5 h-3.5" /> Jarvis Smart Home IoT Bridge
                    </span>
                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}
                      className="text-[10px] text-slate-400"
                    >
                      ✕
                    </button>
                  </div>
                  <div className="p-2.5 flex-1 overflow-y-auto space-y-2">
                    {(phoneState.smartHomeState?.devices || []).map((dev) => (
                      <div
                        key={dev.id}
                        onClick={() => {
                          updateState((p) => ({
                            ...p,
                            smartHomeState: {
                              devices: (p.smartHomeState?.devices || []).map((d) =>
                                d.id === dev.id ? { ...d, status: !d.status } : d
                              ),
                            },
                          }));
                          onSpeak?.(`${dev.name} turned ${!dev.status ? 'on' : 'off'}.`);
                        }}
                        className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                          dev.status
                            ? 'bg-cyan-950/40 border-cyan-500/50 text-white'
                            : 'bg-slate-900/60 border-slate-800 text-slate-400'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          {dev.type === 'light' && <Sun className="w-4 h-4 text-amber-400" />}
                          {dev.type === 'ac' && <Wind className="w-4 h-4 text-cyan-400" />}
                          {dev.type === 'lock' && <Lock className="w-4 h-4 text-emerald-400" />}
                          {dev.type === 'tv' && <Tv className="w-4 h-4 text-rose-400" />}
                          <div>
                            <div className="text-[11px] font-bold">{dev.name}</div>
                            <div className="text-[9px] text-slate-400">
                              {dev.room} · {dev.value}
                            </div>
                          </div>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold ${
                            dev.status ? 'bg-[#00ff88] text-slate-950' : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {dev.status ? 'ON' : 'OFF'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* SCREEN 13: REAL-TIME MULTI-LANGUAGE TRANSLATOR */}
              {phoneState.screen === 'translator' && (
                <div className="flex-1 flex flex-col bg-slate-950 z-10 justify-between">
                  <div className="p-2.5 bg-purple-950/70 border-b border-purple-700/40 flex items-center justify-between">
                    <span className="font-bold text-xs text-purple-300 flex items-center gap-1.5">
                      <Globe className="w-3.5 h-3.5" /> Real-Time Voice Translator
                    </span>
                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}
                      className="text-[10px] text-slate-400"
                    >
                      ✕
                    </button>
                  </div>
                  <div className="p-2.5 flex-1 overflow-y-auto space-y-2.5">
                    <div className="flex gap-1 flex-wrap">
                      {[
                        { code: 'ta', name: 'Tamil' },
                        { code: 'hi', name: 'Hindi' },
                        { code: 'te', name: 'Telugu' },
                        { code: 'es', name: 'Spanish' },
                        { code: 'fr', name: 'French' },
                        { code: 'ar', name: 'Arabic' },
                      ].map((l) => (
                        <button
                          key={l.code}
                          onClick={() => {
                            setTranslateLang(l.code);
                            triggerTranslate(
                              translateInput ||
                                phoneState.translatorState?.sourceText ||
                                'Hello boss, all systems are online.',
                              l.code
                            );
                          }}
                          className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold ${
                            translateLang === l.code
                              ? 'bg-purple-500 text-white'
                              : 'bg-slate-900 text-slate-300 border border-slate-800'
                          }`}
                        >
                          {l.name}
                        </button>
                      ))}
                    </div>

                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        triggerTranslate(translateInput, translateLang);
                      }}
                      className="space-y-1.5"
                    >
                      <input
                        type="text"
                        value={translateInput}
                        onChange={(e) => setTranslateInput(e.target.value)}
                        placeholder="Type any phrase to translate live..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-[10px] text-white"
                      />
                      <button
                        type="submit"
                        className="w-full py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold text-[10px]"
                      >
                        🌐 TRANSLATE IN REAL TIME
                      </button>
                    </form>

                    {phoneState.translatorState && (
                      <div className="p-2.5 rounded-xl bg-slate-900 border border-purple-500/40 space-y-1.5">
                        <div className="text-[9px] font-mono text-slate-400">
                          SOURCE: &ldquo;{phoneState.translatorState.sourceText}&rdquo;
                        </div>
                        <div className="text-xs font-bold text-[#00ff88] leading-relaxed">
                          {phoneState.translatorState.translatedText}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* SCREEN 14: FACEBOOK / TELEGRAM / MAPS */}
              {(phoneState.screen === 'facebook' ||
                phoneState.screen === 'telegram' ||
                phoneState.screen === 'maps') && (
                <div className="flex-1 flex flex-col bg-slate-950 z-10 justify-between">
                  <div className="p-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs">
                    <span className="font-bold text-cyan-300 uppercase">{phoneState.screen} Live</span>
                    <button
                      onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}
                      className="text-[10px] text-slate-400"
                    >
                      ✕
                    </button>
                  </div>
                  <div className="p-3 flex-1 overflow-y-auto space-y-2 text-xs">
                    <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
                      <span className="font-bold text-white">Real-Time {phoneState.screen.toUpperCase()} Bridge</span>
                      <p className="text-[10px] text-slate-300">
                        Connected to live ADB &amp; Telegram Bot daemon. OTP token: <strong className="text-emerald-400">849201</strong>
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Bottom Home Pill */}
              <div className="h-5 w-full flex items-center justify-center z-20 pb-1 bg-slate-950">
                <button
                  onClick={() => updateState((p) => ({ ...p, screen: 'home' }))}
                  className="w-24 h-1 bg-slate-500/80 rounded-full hover:bg-[#00d4ff] transition-colors"
                />
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT: REAL-TIME WIDESCREEN YOUTUBE THEATER, LIVE GOOGLE AUTO-TYPE BROWSER & COMMAND DECK */}
        <div className="flex-1 flex flex-col justify-between space-y-3 min-w-0">
          {/* 1. Real-Time Music Streaming & Widescreen YouTube Theater (Plays ANY Song!) */}
          <div className="p-3.5 rounded-xl bg-[#02121c] border-2 border-rose-500/50 space-y-2.5 shadow-lg">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-mono font-bold text-rose-400 flex items-center gap-1.5">
                <Music className="w-4 h-4" /> REAL-TIME YOUTUBE, SPOTIFY &amp; JIOSAAVN — PLAY ANY SONG OR VIDEO!
              </span>
              <span className="text-[10px] font-mono text-[#00ff88] font-bold">
                ● Live Video + Direct Audio Stream Active
              </span>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!customSongInput.trim()) return;
                triggerPlayMusic(customSongInput, 'youtube');
                setCustomSongInput('');
              }}
              className="flex flex-wrap sm:flex-nowrap gap-1.5"
            >
              <input
                type="text"
                value={customSongInput}
                onChange={(e) => setCustomSongInput(e.target.value)}
                placeholder='Type ANY song (e.g. "Manasellam Mazhai", "Arabic Kuthu", "Tum Hardafa Ho", "Believer")...'
                className="flex-1 bg-[#00060a] border border-slate-700 focus:border-rose-400 rounded-lg px-3 py-2 text-xs text-white outline-none font-mono"
              />
              <button
                type="submit"
                className="px-3 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-mono text-[10px] font-bold cursor-pointer"
              >
                ▶ Play on YouTube
              </button>
              <button
                type="button"
                onClick={() => triggerPlayMusic(customSongInput || 'Manasellam Mazhai', 'spotify')}
                className="px-2.5 py-2 rounded-lg bg-[#1db954] hover:bg-emerald-400 text-slate-950 font-mono text-[10px] font-bold cursor-pointer"
              >
                ▶ Spotify
              </button>
              <button
                type="button"
                onClick={() => triggerPlayMusic(customSongInput || 'Manasellam Mazhai', 'jiosaavn')}
                className="px-2.5 py-2 rounded-lg bg-teal-400 hover:bg-teal-300 text-slate-950 font-mono text-[10px] font-bold cursor-pointer"
              >
                ▶ JioSaavn
              </button>
            </form>

            {/* Quick Song Presets */}
            <div className="flex flex-wrap gap-1.5">
              {[
                { label: '🎵 Manasellam Mazhai', q: 'Manasellam Mazhai', p: 'youtube' as const },
                { label: '🔥 Arabic Kuthu (Halamithi Habibo)', q: 'Arabic Kuthu', p: 'youtube' as const },
                { label: '🎵 Tum Hardafa Ho', q: 'Tum Hardafa Ho', p: 'youtube' as const },
                { label: '🎶 Munbe Vaa', q: 'Munbe Vaa', p: 'youtube' as const },
                { label: '🎶 Rowdy Baby', q: 'Rowdy Baby', p: 'youtube' as const },
                { label: '🟢 Spotify: Kesariya', q: 'Kesariya', p: 'spotify' as const },
                { label: '🔵 JioSaavn: Chaleya', q: 'Chaleya', p: 'jiosaavn' as const },
              ].map((s, idx) => (
                <button
                  key={idx}
                  onClick={() => triggerPlayMusic(s.q, s.p)}
                  className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-rose-950/60 border border-slate-700 hover:border-rose-500/50 text-[10px] font-mono text-slate-200 cursor-pointer transition-all"
                >
                  {s.label}
                </button>
              ))}
            </div>

            {/* Widescreen Active YouTube Video & Multi-Result Switcher */}
            {phoneState.youtubeSong && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-1">
                <div className="md:col-span-7 rounded-xl overflow-hidden border border-slate-800 bg-black aspect-video relative">
                  {phoneState.youtubeSong.youtubeVideoId ? (
                    <iframe
                      key={`wide_${phoneState.youtubeSong.youtubeVideoId}`}
                      src={`https://www.youtube.com/embed/${phoneState.youtubeSong.youtubeVideoId}?autoplay=1&rel=0`}
                      title={phoneState.youtubeSong.title}
                      className="w-full h-full"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  ) : (
                    <img
                      src={phoneState.youtubeSong.artworkUrl}
                      alt={phoneState.youtubeSong.title}
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>

                <div className="md:col-span-5 flex flex-col justify-between bg-slate-950/90 border border-slate-800 rounded-xl p-2.5 space-y-2">
                  <div>
                    <div className="text-[9px] font-mono text-[#00ff88] font-bold uppercase">
                      ▶ NOW STREAMING ON {(phoneState.youtubeSong.platform || 'youtube').toUpperCase()}
                    </div>
                    <div className="text-xs font-bold text-white line-clamp-1 mt-0.5">
                      {phoneState.youtubeSong.title}
                    </div>
                    <div className="text-[10px] text-cyan-300 line-clamp-1">{phoneState.youtubeSong.artist}</div>
                  </div>

                  {/* Clickable Top YouTube Results for the current song */}
                  {phoneState.youtubeSong.youtubeResults && phoneState.youtubeSong.youtubeResults.length > 0 && (
                    <div className="space-y-1 max-h-28 overflow-y-auto pr-1">
                      <div className="text-[9px] font-mono text-slate-400">
                        MATCHING YOUTUBE VIDEOS (CLICK TO SWITCH):
                      </div>
                      {phoneState.youtubeSong.youtubeResults.map((yt, idx) => (
                        <button
                          key={yt.videoId}
                          onClick={() =>
                            updateState((p) => ({
                              ...p,
                              screen: 'youtube',
                              youtubeSong: p.youtubeSong
                                ? {
                                    ...p.youtubeSong,
                                    youtubeVideoId: yt.videoId,
                                    title: yt.title,
                                    isPlaying: true,
                                  }
                                : undefined,
                            }))
                          }
                          className={`w-full text-left px-2 py-1 rounded text-[9px] font-mono truncate flex items-center gap-1.5 ${
                            phoneState.youtubeSong?.youtubeVideoId === yt.videoId
                              ? 'bg-rose-600/30 border border-rose-500/60 text-white font-bold'
                              : 'bg-slate-900 hover:bg-slate-800 text-slate-300'
                          }`}
                        >
                          <span className="text-rose-400">#{idx + 1}</span>
                          <span className="truncate">{yt.title}</span>
                        </button>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-800">
                    <button
                      onClick={() => {
                        const nextPlay = !phoneState.youtubeSong?.isPlaying;
                        updateState((p) => ({
                          ...p,
                          youtubeSong: p.youtubeSong ? { ...p.youtubeSong, isPlaying: nextPlay } : undefined,
                        }));
                        if (audioRef.current) {
                          if (nextPlay) audioRef.current.play().catch(() => {});
                          else audioRef.current.pause();
                        }
                      }}
                      className="px-2.5 py-1 rounded bg-[#00ff88] text-slate-950 font-mono font-bold text-[10px]"
                    >
                      {phoneState.youtubeSong.isPlaying ? '⏸ Pause Audio' : '▶ Play Audio'}
                    </button>
                    {phoneState.youtubeSong.youtubeVideoId && (
                      <a
                        href={`https://www.youtube.com/watch?v=${phoneState.youtubeSong.youtubeVideoId}`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[10px] font-mono text-cyan-300 hover:underline flex items-center gap-1"
                      >
                        YouTube Direct <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 2. Real-Time Google Auto-Type & Live Search Browser (Searches ANYTHING You Say!) */}
          <div className="p-3.5 rounded-xl bg-[#02121c] border-2 border-cyan-500/50 space-y-2.5 shadow-lg">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-mono font-bold text-[#00d4ff] flex items-center gap-1.5">
                <Search className="w-4 h-4" /> REAL-TIME GOOGLE AUTO-TYPE &amp; LIVE SEARCH ENGINE
              </span>
              <span className="text-[10px] font-mono text-amber-300">
                ● Auto-Types &amp; Searches Anything You Say
              </span>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                triggerGoogleSearch(typedGoogleText || 'what is the current trending');
              }}
              className="flex flex-wrap sm:flex-nowrap gap-1.5"
            >
              <div className="flex-1 flex items-center gap-2 bg-[#00060a] border border-cyan-500/60 rounded-lg px-3 py-2">
                <span className="text-xs font-bold text-blue-400">G</span>
                <input
                  type="text"
                  value={typedGoogleText}
                  onChange={(e) => setTypedGoogleText(e.target.value)}
                  placeholder="Type anything or say 'Open Google and type...'"
                  className="flex-1 bg-transparent text-xs text-white outline-none font-mono"
                />
                {phoneState.isTypingGoogle && (
                  <span className="text-[10px] font-mono text-[#00ff88] animate-pulse">AUTO-TYPING...</span>
                )}
              </div>
              <button
                type="submit"
                className="px-3.5 py-2 rounded-lg bg-[#00d4ff] hover:bg-cyan-300 text-slate-950 font-mono text-[10px] font-bold cursor-pointer"
              >
                🔍 Auto-Type &amp; Search Google
              </button>
            </form>

            <div className="flex flex-wrap gap-1.5">
              {[
                'what is the current trending',
                'latest AI agent and GPT-6 Sol news',
                'weather in Chennai today',
                'who is the CEO of Google',
                'ISRO space mission updates',
                'Bitcoin and stock market today',
              ].map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => triggerGoogleSearch(q)}
                  className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-cyan-950/60 border border-slate-700 hover:border-cyan-400/50 text-[10px] font-mono text-cyan-200 cursor-pointer"
                >
                  🔍 &ldquo;{q}&rdquo;
                </button>
              ))}
            </div>

            {/* Live Google Search Result Preview right in the Widescreen Deck */}
            {phoneState.googleResult?.snippet && (
              <div className="p-2.5 rounded-xl bg-slate-950/90 border border-cyan-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold text-[#00ff88]">
                    {phoneState.googleResult.title}
                  </span>
                  <span className="text-[9px] font-mono text-cyan-400">{phoneState.googleResult.condition}</span>
                </div>
                <p className="text-xs text-slate-100 leading-relaxed">{phoneState.googleResult.snippet}</p>
                {phoneState.googleResult.items && phoneState.googleResult.items.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                    {phoneState.googleResult.items.slice(0, 4).map((it, i) => (
                      <a
                        key={i}
                        href={it.link}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] text-slate-200 truncate block"
                      >
                        <span className="text-cyan-400 font-mono text-[9px] mr-1.5">[{it.source}]</span>
                        {it.title}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* 3. Real-Time Phone Calls, Gmail, WhatsApp, Social, Calculator, Notes, Smart Home & Translator */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              onClick={() => triggerCallContact('Mom', '+91 98765 11223')}
              className="p-2 bg-slate-900 hover:bg-blue-950/40 border border-slate-800 hover:border-blue-500/40 rounded-xl text-left cursor-pointer"
            >
              <div className="text-[10px] font-mono text-blue-400 font-bold flex items-center gap-1">
                <PhoneCall className="w-3 h-3" /> CALL MOM
              </div>
              <p className="text-[9px] text-slate-400 mt-0.5">&ldquo;Call my Mom&rdquo;</p>
            </button>

            <button
              onClick={() =>
                triggerSendEmail(
                  'hod.mca@srmist.edu.in',
                  'Real-Time Multimodal Agent Ready',
                  'Our unified 6-video real-time AI project is live.'
                )
              }
              className="p-2 bg-slate-900 hover:bg-red-950/40 border border-slate-800 hover:border-red-500/40 rounded-xl text-left cursor-pointer"
            >
              <div className="text-[10px] font-mono text-red-400 font-bold flex items-center gap-1">
                <Mail className="w-3 h-3" /> SEND GMAIL
              </div>
              <p className="text-[9px] text-slate-400 mt-0.5">&ldquo;Send email&rdquo;</p>
            </button>

            <button
              onClick={() => triggerWhatsApp('Neon', 'Hey Neon! Are you ready for the live demo?')}
              className="p-2 bg-slate-900 hover:bg-emerald-950/40 border border-slate-800 hover:border-emerald-500/40 rounded-xl text-left cursor-pointer"
            >
              <div className="text-[10px] font-mono text-emerald-400 font-bold flex items-center gap-1">
                <MessageSquare className="w-3 h-3" /> WHATSAPP
              </div>
              <p className="text-[9px] text-slate-400 mt-0.5">Live AI Reply</p>
            </button>

            <button
              onClick={() => triggerPostTweet('Launching our unified 6-video Real-Time AI Agent!')}
              className="p-2 bg-slate-900 hover:bg-sky-950/40 border border-slate-800 hover:border-sky-500/40 rounded-xl text-left cursor-pointer"
            >
              <div className="text-[10px] font-mono text-sky-400 font-bold flex items-center gap-1">
                <span>𝕏</span> POST TWEET
              </div>
              <p className="text-[9px] text-slate-400 mt-0.5">&ldquo;Post on Twitter&rdquo;</p>
            </button>

            <button
              onClick={() => updateState((p) => ({ ...p, screen: 'smarthome' }))}
              className="p-2 bg-slate-900 hover:bg-cyan-950/40 border border-slate-800 hover:border-cyan-500/40 rounded-xl text-left cursor-pointer"
            >
              <div className="text-[10px] font-mono text-cyan-400 font-bold flex items-center gap-1">
                <Home className="w-3 h-3" /> SMART HOME
              </div>
              <p className="text-[9px] text-slate-400 mt-0.5">Lights, AC &amp; Lock</p>
            </button>

            <button
              onClick={() => updateState((p) => ({ ...p, screen: 'translator' }))}
              className="p-2 bg-slate-900 hover:bg-purple-950/40 border border-slate-800 hover:border-purple-500/40 rounded-xl text-left cursor-pointer"
            >
              <div className="text-[10px] font-mono text-purple-400 font-bold flex items-center gap-1">
                <Globe className="w-3 h-3" /> TRANSLATOR
              </div>
              <p className="text-[9px] text-slate-400 mt-0.5">Tamil, Hindi &amp; More</p>
            </button>

            <button
              onClick={() => updateState((p) => ({ ...p, screen: 'calculator' }))}
              className="p-2 bg-slate-900 hover:bg-indigo-950/40 border border-slate-800 hover:border-indigo-500/40 rounded-xl text-left cursor-pointer"
            >
              <div className="text-[10px] font-mono text-indigo-400 font-bold flex items-center gap-1">
                <Calculator className="w-3 h-3" /> CALCULATOR
              </div>
              <p className="text-[9px] text-slate-400 mt-0.5">Live Math Engine</p>
            </button>

            <button
              onClick={() => updateState((p) => ({ ...p, screen: 'notes' }))}
              className="p-2 bg-slate-900 hover:bg-amber-950/40 border border-slate-800 hover:border-amber-500/40 rounded-xl text-left cursor-pointer"
            >
              <div className="text-[10px] font-mono text-amber-400 font-bold flex items-center gap-1">
                <FileText className="w-3 h-3" /> NOTES / ALARM
              </div>
              <p className="text-[9px] text-slate-400 mt-0.5">Voice Reminders</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
