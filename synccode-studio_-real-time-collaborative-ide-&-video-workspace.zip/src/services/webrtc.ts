import { socketService } from './socket';

export interface PeerConnectionMeta {
  userId: string;
  pc: RTCPeerConnection;
  stream: MediaStream;
  candidateQueue?: RTCIceCandidateInit[];
}

const ICE_SERVERS: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
  ],
};

type StreamChangeCallback = (remoteStreams: Map<string, MediaStream>) => void;
type SpeakingCallback = (isSpeaking: boolean, volume: number) => void;

class WebRTCManager {
  public localStream: MediaStream | null = null;
  public screenStream: MediaStream | null = null;
  public peerConnections = new Map<string, PeerConnectionMeta>();
  public remoteStreams = new Map<string, MediaStream>();

  private onStreamChange: StreamChangeCallback | null = null;
  private onSpeakingChange: SpeakingCallback | null = null;
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private animationFrameId: number | null = null;
  private isVirtualMedia: boolean = false;
  private myUserId: string = '';

  public isAudioEnabled = true;
  public isVideoEnabled = true;
  public isScreenSharing = false;

  public init(myUserId: string, onStreamChange: StreamChangeCallback, onSpeakingChange?: SpeakingCallback) {
    this.myUserId = myUserId;
    this.onStreamChange = onStreamChange;
    this.onSpeakingChange = onSpeakingChange || null;

    // Listen to signaling messages from socket
    socketService.on('webrtc-signal', (data) => {
      this.handleIncomingSignal(data);
    });
  }

  public async startLocalMedia(): Promise<MediaStream> {
    try {
      // Attempt real user media
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 360 }, frameRate: { ideal: 24 } },
        audio: true,
      });
      this.localStream = stream;
      this.isVirtualMedia = false;
      this.setupAudioAnalysis(stream);
      return stream;
    } catch (err) {
      console.warn('Real webcam/mic not available or denied. Initializing simulated virtual video track:', err);
      // Graceful fallback: create virtual canvas video track + silent audio track
      this.localStream = this.createVirtualStream();
      this.isVirtualMedia = true;
      return this.localStream;
    }
  }

  private createVirtualStream(): MediaStream {
    const canvas = document.createElement('canvas');
    canvas.width = 320;
    canvas.height = 240;
    const ctx = canvas.getContext('2d')!;

    let frame = 0;
    const draw = () => {
      frame++;
      // Background gradient
      const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      grad.addColorStop(0, '#1e1b4b');
      grad.addColorStop(1, '#0f172a');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // User avatar silhouette simulation
      ctx.fillStyle = '#6366f1';
      ctx.beginPath();
      ctx.arc(160, 95, 38, 0, Math.PI * 2);
      ctx.fill();

      ctx.beginPath();
      ctx.arc(160, 200, 65, Math.PI, 0, false);
      ctx.fill();

      // Subtle pulse
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.font = '12px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('SyncCode Live Feed', 160, 165);

      if (this.isVirtualMedia) {
        requestAnimationFrame(draw);
      }
    };
    draw();

    const videoStream = canvas.captureStream(24);
    const videoTrack = videoStream.getVideoTracks()[0];

    // Create a dummy audio track using AudioContext
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const dst = audioCtx.createMediaStreamDestination();
      const gain = audioCtx.createGain();
      gain.gain.value = 0.0001; // virtually silent
      osc.connect(gain);
      gain.connect(dst);
      osc.start();
      const audioTrack = dst.stream.getAudioTracks()[0];
      return new MediaStream([videoTrack, audioTrack]);
    } catch {
      return new MediaStream([videoTrack]);
    }
  }

  private setupAudioAnalysis(stream: MediaStream) {
    try {
      const audioTracks = stream.getAudioTracks();
      if (audioTracks.length === 0) return;

      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = this.audioContext.createMediaStreamSource(stream);
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 256;
      source.connect(this.analyser);

      const bufferLength = this.analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      let lastSpeaking = false;
      const checkVolume = () => {
        if (!this.analyser) return;
        this.analyser.getByteFrequencyData(dataArray);

        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const avg = sum / bufferLength;
        const isSpeaking = this.isAudioEnabled && avg > 18;

        if (this.onSpeakingChange) {
          this.onSpeakingChange(isSpeaking, avg);
        }

        if (isSpeaking !== lastSpeaking) {
          lastSpeaking = isSpeaking;
          socketService.sendWebRTCState({
            isAudioOn: this.isAudioEnabled,
            isVideoOn: this.isVideoEnabled,
            isScreenSharing: this.isScreenSharing,
            isSpeaking,
          });
        }

        this.animationFrameId = requestAnimationFrame(checkVolume);
      };
      checkVolume();
    } catch (e) {
      console.warn('AudioContext analysis not initialized:', e);
    }
  }

  // Create an RTCPeerConnection for a remote peer and initiate offer
  public async callUser(targetUserId: string) {
    const existing = this.peerConnections.get(targetUserId);
    if (existing && existing.pc.signalingState !== 'closed') {
      // Peer connection already active or negotiating
      return;
    }

    const pc = this.createPeerConnection(targetUserId);

    try {
      if (pc.signalingState !== 'stable') {
        return;
      }
      const offer = await pc.createOffer();
      if (pc.signalingState !== 'stable') {
        return;
      }
      await pc.setLocalDescription(offer);

      socketService.sendWebRTCSignal(targetUserId, {
        type: 'offer',
        sdp: pc.localDescription,
      });
    } catch (err) {
      console.warn(`Failed to create offer for ${targetUserId}:`, err);
    }
  }

  private createPeerConnection(targetUserId: string): RTCPeerConnection {
    // If previous connection exists, close cleanly first
    const existing = this.peerConnections.get(targetUserId);
    if (existing) {
      try {
        existing.pc.close();
      } catch (e) {}
    }

    const pc = new RTCPeerConnection(ICE_SERVERS);

    // Add local tracks
    const activeStream = this.screenStream || this.localStream;
    if (activeStream) {
      activeStream.getTracks().forEach((track) => {
        try {
          pc.addTrack(track, activeStream);
        } catch (e) {}
      });
    }

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        socketService.sendWebRTCSignal(targetUserId, {
          type: 'candidate',
          candidate: event.candidate,
        });
      }
    };

    pc.ontrack = (event) => {
      if (event.streams && event.streams[0]) {
        const stream = event.streams[0];
        this.remoteStreams.set(targetUserId, stream);
        if (this.onStreamChange) {
          this.onStreamChange(new Map(this.remoteStreams));
        }
      }
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed' || pc.connectionState === 'closed') {
        this.removePeer(targetUserId);
      }
    };

    const meta: PeerConnectionMeta = {
      userId: targetUserId,
      pc,
      stream: new MediaStream(),
      candidateQueue: [],
    };
    this.peerConnections.set(targetUserId, meta);
    return pc;
  }

  private async handleIncomingSignal(data: { targetUserId: string; senderId: string; signal: any }) {
    const { senderId, signal } = data;
    if (!signal) return;

    let pcMeta = this.peerConnections.get(senderId);

    if (signal.type === 'offer') {
      const isPolite = this.myUserId < senderId;
      let pc = pcMeta?.pc;

      // Handle glare (simultaneous offers)
      if (pc && pc.signalingState !== 'stable') {
        if (!isPolite) {
          console.warn(`[WebRTC] Glare collision: impolite peer ${this.myUserId} ignoring offer from ${senderId}`);
          return;
        }
        if (pc.signalingState === 'have-local-offer') {
          try {
            await pc.setRemoteDescription({ type: 'rollback' });
          } catch (e) {
            console.warn('[WebRTC] Rollback error:', e);
          }
        }
      }

      if (!pc || pc.signalingState === 'closed') {
        pc = this.createPeerConnection(senderId);
        pcMeta = this.peerConnections.get(senderId)!;
      }

      try {
        await pc.setRemoteDescription(new RTCSessionDescription(signal.sdp));

        // Flush queued candidates
        if (pcMeta?.candidateQueue && pcMeta.candidateQueue.length > 0) {
          for (const cand of pcMeta.candidateQueue) {
            try {
              await pc.addIceCandidate(new RTCIceCandidate(cand));
            } catch (e) {}
          }
          pcMeta.candidateQueue = [];
        }

        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);

        socketService.sendWebRTCSignal(senderId, {
          type: 'answer',
          sdp: pc.localDescription,
        });
      } catch (err) {
        console.warn(`[WebRTC] Failed to process offer from ${senderId}:`, err);
      }
    } else if (signal.type === 'answer') {
      if (pcMeta) {
        // STRICT GUARD: Only apply answer if in 'have-local-offer' state
        if (pcMeta.pc.signalingState === 'have-local-offer') {
          try {
            await pcMeta.pc.setRemoteDescription(new RTCSessionDescription(signal.sdp));

            // Flush queued candidates
            if (pcMeta.candidateQueue && pcMeta.candidateQueue.length > 0) {
              for (const cand of pcMeta.candidateQueue) {
                try {
                  await pcMeta.pc.addIceCandidate(new RTCIceCandidate(cand));
                } catch (e) {}
              }
              pcMeta.candidateQueue = [];
            }
          } catch (err) {
            console.warn(`[WebRTC] Failed to set remote answer:`, err);
          }
        } else {
          // If signalingState is 'stable' or anything other than have-local-offer, skip cleanly without error
          console.warn(`[WebRTC] Ignored remote answer from ${senderId} because state is '${pcMeta.pc.signalingState}' (expected 'have-local-offer')`);
        }
      }
    } else if (signal.type === 'candidate') {
      if (pcMeta && signal.candidate) {
        // Only add candidate if remote description has already been set
        if (pcMeta.pc.remoteDescription && pcMeta.pc.remoteDescription.type) {
          try {
            await pcMeta.pc.addIceCandidate(new RTCIceCandidate(signal.candidate));
          } catch (e) {
            console.warn('[WebRTC] Error adding ICE candidate:', e);
          }
        } else {
          pcMeta.candidateQueue = pcMeta.candidateQueue || [];
          pcMeta.candidateQueue.push(signal.candidate);
        }
      }
    }
  }

  public removePeer(userId: string) {
    const pcMeta = this.peerConnections.get(userId);
    if (pcMeta) {
      pcMeta.pc.close();
      this.peerConnections.delete(userId);
    }
    this.remoteStreams.delete(userId);
    if (this.onStreamChange) {
      this.onStreamChange(new Map(this.remoteStreams));
    }
  }

  public toggleAudio(): boolean {
    if (this.localStream) {
      const audioTracks = this.localStream.getAudioTracks();
      if (audioTracks.length > 0) {
        this.isAudioEnabled = !audioTracks[0].enabled;
        audioTracks.forEach((t) => (t.enabled = this.isAudioEnabled));
      } else {
        this.isAudioEnabled = !this.isAudioEnabled;
      }
    } else {
      this.isAudioEnabled = !this.isAudioEnabled;
    }

    socketService.sendWebRTCState({
      isAudioOn: this.isAudioEnabled,
      isVideoOn: this.isVideoEnabled,
      isScreenSharing: this.isScreenSharing,
    });
    return this.isAudioEnabled;
  }

  public toggleVideo(): boolean {
    if (this.localStream) {
      const videoTracks = this.localStream.getVideoTracks();
      if (videoTracks.length > 0) {
        this.isVideoEnabled = !videoTracks[0].enabled;
        videoTracks.forEach((t) => (t.enabled = this.isVideoEnabled));
      } else {
        this.isVideoEnabled = !this.isVideoEnabled;
      }
    } else {
      this.isVideoEnabled = !this.isVideoEnabled;
    }

    socketService.sendWebRTCState({
      isAudioOn: this.isAudioEnabled,
      isVideoOn: this.isVideoEnabled,
      isScreenSharing: this.isScreenSharing,
    });
    return this.isVideoEnabled;
  }

  public async toggleScreenShare(): Promise<boolean> {
    if (this.isScreenSharing) {
      // Stop screenshare, switch back to camera
      if (this.screenStream) {
        this.screenStream.getTracks().forEach((t) => t.stop());
        this.screenStream = null;
      }
      this.isScreenSharing = false;

      // Replace track on all peer connections
      if (this.localStream) {
        const camVideoTrack = this.localStream.getVideoTracks()[0];
        if (camVideoTrack) {
          this.peerConnections.forEach((meta) => {
            const sender = meta.pc.getSenders().find((s) => s.track && s.track.kind === 'video');
            if (sender) sender.replaceTrack(camVideoTrack);
          });
        }
      }
    } else {
      try {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true,
        });
        this.screenStream = screenStream;
        this.isScreenSharing = true;

        const screenVideoTrack = screenStream.getVideoTracks()[0];

        screenVideoTrack.onended = () => {
          this.toggleScreenShare();
        };

        // Replace video track on all peer connections
        this.peerConnections.forEach((meta) => {
          const sender = meta.pc.getSenders().find((s) => s.track && s.track.kind === 'video');
          if (sender) sender.replaceTrack(screenVideoTrack);
        });
      } catch (err) {
        console.warn('Screen share canceled or denied:', err);
        this.isScreenSharing = false;
      }
    }

    socketService.sendWebRTCState({
      isAudioOn: this.isAudioEnabled,
      isVideoOn: this.isVideoEnabled,
      isScreenSharing: this.isScreenSharing,
    });
    return this.isScreenSharing;
  }

  public cleanup() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }
    if (this.localStream) {
      this.localStream.getTracks().forEach((t) => t.stop());
      this.localStream = null;
    }
    if (this.screenStream) {
      this.screenStream.getTracks().forEach((t) => t.stop());
      this.screenStream = null;
    }
    this.peerConnections.forEach((meta) => meta.pc.close());
    this.peerConnections.clear();
    this.remoteStreams.clear();
  }
}

export const webrtcManager = new WebRTCManager();
