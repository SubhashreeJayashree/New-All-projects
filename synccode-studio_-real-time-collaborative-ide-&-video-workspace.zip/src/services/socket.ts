import { User, CodeFile, ChatMessage, RemoteCursor, RoomState, ExecutionResult, ChallengePreset } from '../types';

type MessageHandler = (data: any) => void;

class SocketService {
  private ws: WebSocket | null = null;
  private handlers = new Map<string, Set<MessageHandler>>();
  private reconnectTimeout: any = null;
  private pingInterval: any = null;
  private currentRoomId: string = '';
  private currentUser: User | null = null;

  public latencyMs: number = 0;
  public packetsReceived: number = 0;
  public packetsSent: number = 0;
  public isConnected: boolean = false;

  public connect(roomId: string, user: User, onConnected?: () => void) {
    this.currentRoomId = roomId;
    this.currentUser = user;

    if (this.ws) {
      this.disconnect();
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}`;

    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.isConnected = true;
        this.emit('connection-status', { connected: true });
        
        // Join room immediately
        this.send('join-room', { roomId, user });

        // Start ping heartbeat
        this.startHeartbeat();

        if (onConnected) onConnected();
      };

      this.ws.onmessage = (event) => {
        this.packetsReceived++;
        try {
          const { type, payload } = JSON.parse(event.data);
          
          if (type === 'pong') {
            const now = Date.now();
            this.latencyMs = now - (payload.clientTimestamp || now);
            this.emit('latency-update', { latencyMs: this.latencyMs });
            return;
          }

          this.emit(type, payload);
        } catch (err) {
          console.error('Failed to parse WS message:', err);
        }
      };

      this.ws.onclose = () => {
        this.isConnected = false;
        this.emit('connection-status', { connected: false });
        this.stopHeartbeat();
        // Auto-reconnect after 2 seconds
        this.reconnectTimeout = setTimeout(() => {
          if (this.currentRoomId && this.currentUser) {
            this.connect(this.currentRoomId, this.currentUser);
          }
        }, 2000);
      };

      this.ws.onerror = (err) => {
        console.warn('WebSocket encountered error:', err);
      };
    } catch (err) {
      console.error('WebSocket connection error:', err);
    }
  }

  public disconnect() {
    this.stopHeartbeat();
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
      this.reconnectTimeout = null;
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.isConnected = false;
  }

  public send(type: string, payload: any) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.packetsSent++;
      this.ws.send(JSON.stringify({ type, payload }));
    }
  }

  public on(event: string, handler: MessageHandler) {
    if (!this.handlers.has(event)) {
      this.handlers.set(event, new Set());
    }
    this.handlers.get(event)!.add(handler);
    return () => this.off(event, handler);
  }

  public off(event: string, handler: MessageHandler) {
    const set = this.handlers.get(event);
    if (set) {
      set.delete(handler);
    }
  }

  private emit(event: string, data: any) {
    const set = this.handlers.get(event);
    if (set) {
      set.forEach(h => {
        try {
          h(data);
        } catch (e) {
          console.error(`Error in socket event handler for ${event}:`, e);
        }
      });
    }
  }

  private startHeartbeat() {
    this.stopHeartbeat();
    this.pingInterval = setInterval(() => {
      this.send('ping', { timestamp: Date.now() });
    }, 4000);
  }

  private stopHeartbeat() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  // Helper emitter methods for cleaner components
  public sendCodeChange(fileId: string, content: string, version: number) {
    this.send('code-change', { fileId, content, version });
  }

  public sendCursorMove(cursor: RemoteCursor) {
    this.send('cursor-move', { cursor });
  }

  public sendFileCreate(file: CodeFile) {
    this.send('file-create', { file });
  }

  public sendFileRename(fileId: string, newName: string) {
    this.send('file-rename', { fileId, newName });
  }

  public sendFileDelete(fileId: string) {
    this.send('file-delete', { fileId });
  }

  public sendFileSelect(fileId: string) {
    this.send('file-select', { fileId });
  }

  public sendChatMessage(message: ChatMessage) {
    this.send('chat-send', { message });
  }

  public sendWebRTCSignal(targetUserId: string, signal: any) {
    this.send('webrtc-signal', { targetUserId, signal });
  }

  public sendWebRTCState(state: { isAudioOn: boolean; isVideoOn: boolean; isScreenSharing: boolean; isSpeaking?: boolean }) {
    this.send('webrtc-state', state);
  }

  public broadcastExecution(result: ExecutionResult) {
    this.send('execute-broadcast', { result });
  }

  public loadChallenge(challenge: ChallengePreset) {
    this.send('load-challenge', { challenge });
  }
}

export const socketService = new SocketService();
