import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  Terminal, 
  Globe, 
  FileQuestion, 
  Trash2, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Maximize2,
  ChevronUp,
  ChevronDown
} from 'lucide-react';
import { ExecutionResult, ChallengePreset, CodeFile } from '../../types';

interface CodeRunnerProps {
  executionResult: ExecutionResult | null;
  onClearOutput: () => void;
  activeChallenge: ChallengePreset | null;
  files: CodeFile[];
  onRunCode: () => void;
  isRunning: boolean;
}

export const CodeRunner: React.FC<CodeRunnerProps> = ({
  executionResult,
  onClearOutput,
  activeChallenge,
  files,
  onRunCode,
  isRunning,
}) => {
  const [activeTab, setActiveTab] = useState<'console' | 'preview' | 'spec'>('console');
  const [isExpanded, setIsExpanded] = useState(false);

  // Check if execution was clean and trigger celebration confetti
  useEffect(() => {
    if (executionResult && !executionResult.error && executionResult.logs.length > 0) {
      const hasPassAssertion = executionResult.logs.some(
        (l) => l.message.includes('🎉') || l.message.toLowerCase().includes('pass') || l.message.includes('Expected')
      );
      if (hasPassAssertion) {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.8 },
        });
      }
    }
  }, [executionResult]);

  // Generate HTML preview iframe bundle
  const htmlFile = files.find((f) => f.name.endsWith('.html')) || files.find((f) => f.language === 'html');
  const cssFile = files.find((f) => f.name.endsWith('.css')) || files.find((f) => f.language === 'css');
  const jsFile = files.find((f) => f.name.endsWith('.js') && !f.name.includes('test'));

  const previewSourceDoc = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <style>
          ${cssFile ? cssFile.content : ''}
        </style>
      </head>
      <body>
        ${htmlFile ? htmlFile.content : '<div style="font-family:sans-serif;color:#888;padding:20px;">No HTML file found. Create index.html to preview web pages.</div>'}
        <script>
          ${jsFile ? jsFile.content : ''}
        </script>
      </body>
    </html>
  `;

  return (
    <div className={`transition-all duration-200 border-t border-[#30363d] bg-[#0d1117] flex flex-col ${isExpanded ? 'h-96' : 'h-64'}`}>
      {/* Tab Navigation Header */}
      <div className="h-9 bg-[#161b22] px-3 flex items-center justify-between border-b border-[#30363d] select-none shrink-0">
        <div className="flex items-center space-x-1">
          <button
            onClick={() => setActiveTab('console')}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === 'console'
                ? 'bg-[#21262d] text-sky-400 font-semibold'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#21262d]/50'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Interactive Terminal</span>
            {executionResult && (
              <span className={`w-2 h-2 rounded-full ${executionResult.error ? 'bg-rose-500' : 'bg-emerald-500'}`} />
            )}
          </button>

          <button
            onClick={() => setActiveTab('preview')}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === 'preview'
                ? 'bg-[#21262d] text-sky-400 font-semibold'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#21262d]/50'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Live DOM Sandbox</span>
          </button>

          {activeChallenge && (
            <button
              onClick={() => setActiveTab('spec')}
              className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-medium transition-colors ${
                activeTab === 'spec'
                  ? 'bg-[#21262d] text-sky-400 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#21262d]/50'
              }`}
            >
              <FileQuestion className="w-3.5 h-3.5" />
              <span>Challenge Spec</span>
            </button>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-2">
          {executionResult && (
            <div className="flex items-center space-x-1 text-[11px] font-mono text-zinc-400 bg-[#0d1117] px-2 py-0.5 rounded border border-[#30363d]">
              <Clock className="w-3 h-3 text-zinc-500" />
              <span>{executionResult.durationMs}ms</span>
              <span className="text-zinc-500">•</span>
              <span className="text-zinc-300 truncate max-w-[100px]">{executionResult.senderName}</span>
            </div>
          )}

          {activeTab === 'console' && (
            <button
              onClick={onClearOutput}
              className="p-1 text-zinc-400 hover:text-white rounded hover:bg-[#21262d] transition-colors"
              title="Clear terminal output"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 text-zinc-400 hover:text-white rounded hover:bg-[#21262d] transition-colors"
            title={isExpanded ? 'Collapse terminal' : 'Expand terminal'}
          >
            {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Tab Contents */}
      <div className="flex-1 overflow-auto p-3 font-mono text-xs">
        {activeTab === 'console' && (
          <div className="space-y-1.5 h-full">
            {!executionResult && (
              <div className="text-zinc-500 flex flex-col items-center justify-center h-full py-6">
                <Terminal className="w-6 h-6 mb-2 opacity-50" />
                <p>Click <strong className="text-emerald-400 font-medium">"Run Code"</strong> (or Cmd+Enter) to execute in the collaborative sandbox.</p>
                <p className="text-[11px] text-zinc-600 mt-1">Output streams in real-time across all connected peers.</p>
              </div>
            )}

            {executionResult?.logs.map((log, idx) => (
              <div
                key={idx}
                className={`p-1.5 rounded flex items-start space-x-2 leading-relaxed ${
                  log.type === 'error'
                    ? 'bg-rose-500/10 text-rose-300 border-l-2 border-rose-500'
                    : log.type === 'warn'
                    ? 'bg-amber-500/10 text-amber-300 border-l-2 border-amber-500'
                    : log.type === 'table'
                    ? 'bg-sky-500/10 text-sky-200 border-l-2 border-sky-500'
                    : 'text-zinc-300 hover:bg-zinc-800/30'
                }`}
              >
                <span className="text-zinc-600 select-none text-[10px] pt-0.5">❯</span>
                <pre className="whitespace-pre-wrap break-all flex-1 font-mono">{log.message}</pre>
              </div>
            ))}

            {executionResult?.returnValue && (
              <div className="mt-2 pt-2 border-t border-[#30363d]/50 flex items-center space-x-2 text-emerald-400 font-mono">
                <span className="text-zinc-500 text-[10px]">Return Value:</span>
                <span className="bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  {executionResult.returnValue}
                </span>
              </div>
            )}
          </div>
        )}

        {activeTab === 'preview' && (
          <div className="h-full w-full rounded-lg overflow-hidden border border-[#30363d] bg-white">
            <iframe
              title="Live Sandbox Preview"
              srcDoc={previewSourceDoc}
              sandbox="allow-scripts"
              className="w-full h-full border-none"
            />
          </div>
        )}

        {activeTab === 'spec' && activeChallenge && (
          <div className="space-y-3 font-sans text-zinc-300 p-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white">{activeChallenge.title}</h3>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20">
                {activeChallenge.difficulty}
              </span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">{activeChallenge.description}</p>
            <div className="flex flex-wrap gap-1.5 pt-2">
              {activeChallenge.tags.map((tag) => (
                <span key={tag} className="text-[10px] font-mono bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-zinc-400">
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
