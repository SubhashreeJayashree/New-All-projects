import React, { useState } from 'react';
import { 
  Play, 
  Share2, 
  ExternalLink, 
  BookOpen, 
  Users, 
  Activity, 
  Copy, 
  Check, 
  ChevronDown, 
  Code2, 
  Sparkles,
  Layers,
  Cpu
} from 'lucide-react';
import { User, ChallengePreset } from '../../types';
import { CHALLENGE_PRESETS } from '../../utils/challengePresets';

interface NavbarProps {
  roomId: string;
  currentUser: User;
  users: User[];
  latencyMs: number;
  isConnected: boolean;
  onRunCode: () => void;
  isRunning: boolean;
  onOpenDossier: () => void;
  onOpenPeerTab: () => void;
  onSelectChallenge: (challenge: ChallengePreset) => void;
  activeChallenge: ChallengePreset | null;
  onOpenCopilot: () => void;
  onOpenHowToRun: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  roomId,
  currentUser,
  users,
  latencyMs,
  isConnected,
  onRunCode,
  isRunning,
  onOpenDossier,
  onOpenPeerTab,
  onSelectChallenge,
  activeChallenge,
  onOpenCopilot,
  onOpenHowToRun,
}) => {
  const [copied, setCopied] = useState(false);
  const [showPresetsMenu, setShowPresetsMenu] = useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <header className="h-14 bg-[#161b22] border-b border-[#30363d] px-4 flex items-center justify-between z-20 shrink-0">
      {/* Brand & Room Info */}
      <div className="flex items-center space-x-3">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-500 via-sky-500 to-emerald-400 p-[1.5px] flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <div className="w-full h-full bg-[#0d1117] rounded-[7px] flex items-center justify-center">
              <Code2 className="w-4 h-4 text-sky-400" />
            </div>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center space-x-2">
              <span className="font-bold text-sm tracking-tight text-white flex items-center gap-1.5">
                SyncCode <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20 font-bold">GenAI Studio</span>
              </span>
              <span className="text-xs text-zinc-500">|</span>
              <div className="flex items-center space-x-1.5 text-xs text-zinc-300 font-mono bg-[#0d1117] px-2 py-0.5 rounded border border-[#30363d]">
                <span className="text-zinc-500 text-[10px]">ROOM:</span>
                <span className="text-sky-300 font-semibold">{roomId.slice(0, 10)}</span>
                <button
                  onClick={handleCopyLink}
                  title="Copy room link"
                  className="hover:text-white transition-colors ml-1 p-0.5"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-zinc-400" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Network & Latency pill */}
        <div className="hidden md:flex items-center space-x-2 px-2.5 py-1 rounded-full bg-[#0d1117] border border-[#30363d] text-xs">
          <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.7)]' : 'bg-rose-500'}`} />
          <span className="text-zinc-400 font-mono text-[11px]">{isConnected ? `${latencyMs}ms RTT` : 'Reconnecting...'}</span>
        </div>

        {/* Challenge selector dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowPresetsMenu(!showPresetsMenu)}
            className="flex items-center space-x-1.5 text-xs bg-[#21262d] hover:bg-[#30363d] text-zinc-200 px-2.5 py-1.5 rounded-md border border-[#30363d] transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="max-w-[150px] truncate font-medium">
              {activeChallenge ? activeChallenge.title : 'Multi-Head Self Attention'}
            </span>
            <ChevronDown className="w-3 h-3 text-zinc-400" />
          </button>

          {showPresetsMenu && (
            <div className="absolute left-0 mt-1 w-72 bg-[#161b22] border border-[#30363d] rounded-lg shadow-2xl py-1 z-50">
              <div className="px-3 py-1.5 text-[11px] font-semibold text-zinc-400 uppercase tracking-wider border-b border-[#30363d]">
                MCA Generative AI / ML Models
              </div>
              {CHALLENGE_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => {
                    onSelectChallenge(preset);
                    setShowPresetsMenu(false);
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-[#21262d] transition-colors flex items-center justify-between group"
                >
                  <div>
                    <div className="text-xs font-medium text-zinc-200 group-hover:text-white">{preset.title}</div>
                    <div className="text-[10px] text-zinc-400">{preset.tags.join(' • ')}</div>
                  </div>
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                    preset.difficulty === 'Easy' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                    preset.difficulty === 'Medium' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                    'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                  }`}>
                    {preset.difficulty}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Center / Action Buttons */}
      <div className="flex items-center space-x-2">
        {/* Run Code Button */}
        <button
          onClick={onRunCode}
          disabled={isRunning}
          className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs shadow-md shadow-emerald-900/30 transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 cursor-pointer"
        >
          <Play className={`w-3.5 h-3.5 fill-current ${isRunning ? 'animate-spin' : ''}`} />
          <span>{isRunning ? 'Executing...' : 'Run Code'}</span>
          <span className="hidden sm:inline-block text-[10px] bg-emerald-700/60 px-1 py-0.2 rounded font-mono ml-1">⌘↵</span>
        </button>

        {/* Gemini GenAI Copilot Trigger */}
        <button
          onClick={onOpenCopilot}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-gradient-to-r from-sky-600/30 via-indigo-600/30 to-purple-600/30 hover:from-sky-600/50 hover:to-purple-600/50 text-sky-200 border border-sky-500/40 font-semibold text-xs shadow-sm transition-all hover:scale-[1.02] cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5 text-sky-400 animate-pulse" />
          <span>GenAI Copilot</span>
        </button>

        {/* 1-Click Launch Peer Tab */}
        <button
          onClick={onOpenPeerTab}
          title="Opens a second browser window with a new identity to test real-time typing and video chat side-by-side"
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-[#21262d] hover:bg-[#30363d] text-sky-400 border border-sky-500/30 font-medium text-xs transition-colors cursor-pointer"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Open Peer Tab</span>
        </button>

        {/* Internship Dossier / Architecture Modal */}
        <button
          onClick={onOpenDossier}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-gradient-to-r from-indigo-600/30 to-purple-600/30 hover:from-indigo-600/50 hover:to-purple-600/50 text-indigo-200 border border-indigo-500/40 font-medium text-xs transition-all cursor-pointer"
        >
          <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
          <span className="font-semibold">Project Dossier</span>
        </button>

        {/* How to Run & Video Guide Modal */}
        <button
          onClick={onOpenHowToRun}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 font-semibold text-xs transition-all cursor-pointer"
          title="Interactive Video-Style How to Run Walkthrough"
        >
          <Play className="w-3 h-3 text-emerald-400 fill-current" />
          <span className="font-semibold">How to Run</span>
        </button>
      </div>

      {/* Right / Connected Collaborators */}
      <div className="flex items-center space-x-3">
        <div className="flex items-center -space-x-2 overflow-hidden">
          {users.map((u) => (
            <div
              key={u.id}
              title={`${u.name} ${u.id === currentUser.id ? '(You)' : ''}`}
              className="relative inline-block w-7 h-7 rounded-full ring-2 ring-[#161b22] text-xs font-semibold flex items-center justify-center text-white"
              style={{ backgroundColor: u.color }}
            >
              {u.name.slice(0, 1).toUpperCase()}
              {u.isSpeaking && (
                <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 border-2 border-[#161b22] rounded-full animate-ping" />
              )}
            </div>
          ))}
        </div>

        <button
          onClick={handleCopyLink}
          className="p-1.5 text-zinc-400 hover:text-zinc-100 hover:bg-[#21262d] rounded-md transition-colors"
          title="Share room invitation"
        >
          <Share2 className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
