import React, { useEffect, useRef, useState } from 'react';
import { 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  Monitor, 
  Maximize2, 
  Minimize2, 
  Volume2, 
  VolumeX, 
  Users, 
  Sparkles,
  Radio,
  Settings,
  ChevronRight,
  ChevronLeft
} from 'lucide-react';
import { User } from '../../types';
import { webrtcManager } from '../../services/webrtc';

interface VideoConferencingProps {
  currentUser: User;
  users: User[];
  remoteStreams: Map<string, MediaStream>;
  isSpeaking: boolean;
  audioVolume: number;
}

export const VideoConferencing: React.FC<VideoConferencingProps> = ({
  currentUser,
  users,
  remoteStreams,
  isSpeaking,
  audioVolume,
}) => {
  const [isAudioOn, setIsAudioOn] = useState(true);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [spotlightUserId, setSpotlightUserId] = useState<string | null>(null);

  const localVideoRef = useRef<HTMLVideoElement>(null);

  // Setup local stream to local video element
  useEffect(() => {
    if (localVideoRef.current && webrtcManager.localStream) {
      localVideoRef.current.srcObject = webrtcManager.localStream;
    }
  }, [webrtcManager.localStream, isVideoOn]);

  const handleToggleAudio = () => {
    const next = webrtcManager.toggleAudio();
    setIsAudioOn(next);
  };

  const handleToggleVideo = () => {
    const next = webrtcManager.toggleVideo();
    setIsVideoOn(next);
  };

  const handleToggleScreenShare = async () => {
    const next = await webrtcManager.toggleScreenShare();
    setIsScreenSharing(next);
  };

  // Remote peers
  const otherUsers = users.filter((u) => u.id !== currentUser.id);

  return (
    <div className={`transition-all duration-300 flex flex-col bg-[#161b22] border-l border-[#30363d] relative ${isCollapsed ? 'w-12' : 'w-72 lg:w-80'}`}>
      {/* Collapse / Expand Toggle Button */}
      <button
        onClick={() => setIsCollapsed(!isCollapsed)}
        title={isCollapsed ? 'Expand video conferencing' : 'Collapse video panel'}
        className="absolute -left-3.5 top-4 z-30 w-7 h-7 bg-[#21262d] border border-[#30363d] rounded-full text-zinc-300 hover:text-white flex items-center justify-center shadow-lg hover:bg-[#30363d] transition-all"
      >
        {isCollapsed ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
      </button>

      {isCollapsed ? (
        <div className="flex flex-col items-center py-4 space-y-4">
          <div className="w-8 h-8 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center">
            <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
          </div>
          <div className="text-[10px] uppercase font-mono font-bold tracking-widest text-zinc-500 [writing-mode:vertical-rl]">
            VIDEO CALL ({users.length})
          </div>
          <button
            onClick={handleToggleAudio}
            className={`p-2 rounded-full ${isAudioOn ? 'bg-zinc-800 text-zinc-300' : 'bg-rose-500/20 text-rose-400'}`}
          >
            {isAudioOn ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={handleToggleVideo}
            className={`p-2 rounded-full ${isVideoOn ? 'bg-zinc-800 text-zinc-300' : 'bg-rose-500/20 text-rose-400'}`}
          >
            {isVideoOn ? <Video className="w-3.5 h-3.5" /> : <VideoOff className="w-3.5 h-3.5" />}
          </button>
        </div>
      ) : (
        <>
          {/* Header */}
          <div className="px-3.5 py-2.5 border-b border-[#30363d] flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-semibold uppercase tracking-wider text-zinc-300">
                WebRTC Video & Audio ({users.length})
              </span>
            </div>
            <div className="flex items-center space-x-1">
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                P2P MESH
              </span>
            </div>
          </div>

          {/* Videos Container */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {/* Local User Video Tile */}
            <div className={`relative rounded-xl overflow-hidden bg-[#0d1117] border ${isSpeaking ? 'border-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.3)]' : 'border-[#30363d]'} transition-all aspect-video flex items-center justify-center group`}>
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover transform -scale-x-100 ${!isVideoOn ? 'hidden' : 'block'}`}
              />

              {!isVideoOn && (
                <div className="flex flex-col items-center justify-center p-4">
                  <div
                    className="w-14 h-14 rounded-full flex items-center justify-center text-xl font-bold text-white shadow-lg mb-1"
                    style={{ backgroundColor: currentUser.color }}
                  >
                    {currentUser.name.slice(0, 1).toUpperCase()}
                  </div>
                  <span className="text-[11px] text-zinc-400">Camera Off</span>
                </div>
              )}

              {/* Status bar on bottom of tile */}
              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between pointer-events-none">
                <div className="flex items-center space-x-1.5 bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-full text-[11px] text-zinc-200">
                  <span className="font-medium truncate max-w-[90px]">{currentUser.name} (You)</span>
                  {isAudioOn ? (
                    <div className="flex items-center space-x-0.5">
                      <div className="w-1 h-2 rounded-full bg-emerald-400" style={{ height: `${Math.min(12, Math.max(4, audioVolume / 8))}px` }} />
                    </div>
                  ) : (
                    <MicOff className="w-2.5 h-2.5 text-rose-400" />
                  )}
                </div>

                {isScreenSharing && (
                  <span className="text-[9px] bg-sky-500/90 text-white font-mono px-1.5 py-0.5 rounded-full font-semibold">
                    SHARING
                  </span>
                )}
              </div>
            </div>

            {/* Remote Users Video Tiles */}
            {otherUsers.map((user) => {
              const stream = remoteStreams.get(user.id);
              const isUserSpeaking = user.isSpeaking;

              return (
                <RemoteVideoTile
                  key={user.id}
                  user={user}
                  stream={stream}
                  isSpeaking={isUserSpeaking}
                  isSpotlight={spotlightUserId === user.id}
                  onToggleSpotlight={() => setSpotlightUserId(spotlightUserId === user.id ? null : user.id)}
                />
              );
            })}

            {otherUsers.length === 0 && (
              <div className="rounded-xl border border-dashed border-[#30363d] p-4 text-center">
                <Users className="w-6 h-6 text-zinc-500 mx-auto mb-2" />
                <p className="text-xs text-zinc-400 font-medium">Waiting for peers to join</p>
                <p className="text-[11px] text-zinc-500 mt-1">
                  Click <span className="text-sky-400 font-medium">"Open Peer Tab"</span> in the top bar to test live two-way video and collaborative editing!
                </p>
              </div>
            )}
          </div>

          {/* Media Controls Toolbar */}
          <div className="p-3 bg-[#0d1117] border-t border-[#30363d] flex items-center justify-around">
            <button
              onClick={handleToggleAudio}
              title={isAudioOn ? 'Mute microphone' : 'Unmute microphone'}
              className={`p-2.5 rounded-full transition-all cursor-pointer ${
                isAudioOn
                  ? 'bg-[#21262d] text-zinc-200 hover:bg-[#30363d] hover:text-white'
                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/30 hover:bg-rose-500/30'
              }`}
            >
              {isAudioOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
            </button>

            <button
              onClick={handleToggleVideo}
              title={isVideoOn ? 'Turn off camera' : 'Turn on camera'}
              className={`p-2.5 rounded-full transition-all cursor-pointer ${
                isVideoOn
                  ? 'bg-[#21262d] text-zinc-200 hover:bg-[#30363d] hover:text-white'
                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/30 hover:bg-rose-500/30'
              }`}
            >
              {isVideoOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
            </button>

            <button
              onClick={handleToggleScreenShare}
              title={isScreenSharing ? 'Stop sharing screen' : 'Share entire screen or tab'}
              className={`p-2.5 rounded-full transition-all cursor-pointer ${
                isScreenSharing
                  ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/30'
                  : 'bg-[#21262d] text-zinc-200 hover:bg-[#30363d] hover:text-white'
              }`}
            >
              <Monitor className="w-4 h-4" />
            </button>
          </div>
        </>
      )}
    </div>
  );
};

// Remote Video Tile Component with Stream Attachment
interface RemoteVideoTileProps {
  user: User;
  stream: MediaStream | undefined;
  isSpeaking: boolean;
  isSpotlight: boolean;
  onToggleSpotlight: () => void;
}

const RemoteVideoTile: React.FC<RemoteVideoTileProps> = ({
  user,
  stream,
  isSpeaking,
  isSpotlight,
  onToggleSpotlight,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  const hasVideoStream = stream && stream.getVideoTracks().length > 0 && user.isVideoOn;

  return (
    <div
      className={`relative rounded-xl overflow-hidden bg-[#0d1117] border ${
        isSpeaking ? 'border-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.3)]' : 'border-[#30363d]'
      } transition-all aspect-video flex items-center justify-center group`}
    >
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className={`w-full h-full object-cover ${!hasVideoStream ? 'hidden' : 'block'}`}
      />

      {!hasVideoStream && (
        <div className="flex flex-col items-center justify-center p-4">
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center text-xl font-bold text-white shadow-lg mb-1"
            style={{ backgroundColor: user.color }}
          >
            {user.name.slice(0, 1).toUpperCase()}
          </div>
          <span className="text-[11px] text-zinc-400">{user.name}</span>
        </div>
      )}

      {/* Overlay badges */}
      <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between pointer-events-none">
        <div className="flex items-center space-x-1.5 bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-full text-[11px] text-zinc-200">
          <span className="font-medium truncate max-w-[90px]">{user.name}</span>
          {user.isAudioOn ? (
            <Volume2 className={`w-3 h-3 ${isSpeaking ? 'text-emerald-400 animate-pulse' : 'text-zinc-400'}`} />
          ) : (
            <VolumeX className="w-3 h-3 text-rose-400" />
          )}
        </div>

        {user.isScreenSharing && (
          <span className="text-[9px] bg-sky-500 text-white font-mono px-1.5 py-0.5 rounded-full font-semibold">
            SCREEN
          </span>
        )}
      </div>

      {/* Hover action to spotlight */}
      <button
        onClick={onToggleSpotlight}
        className="absolute top-2 right-2 p-1 rounded-md bg-black/50 text-zinc-300 opacity-0 group-hover:opacity-100 hover:text-white transition-opacity"
        title="Maximize stream"
      >
        <Maximize2 className="w-3 h-3" />
      </button>
    </div>
  );
};
