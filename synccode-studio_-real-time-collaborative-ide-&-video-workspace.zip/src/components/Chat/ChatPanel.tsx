import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  MessageSquare, 
  Activity, 
  Smile, 
  Sparkles, 
  ChevronRight, 
  ChevronLeft,
  Bot,
  ExternalLink,
  HelpCircle,
  Zap
} from 'lucide-react';
import { ChatMessage, User } from '../../types';

interface ChatPanelProps {
  messages: ChatMessage[];
  onSendMessage: (content: string) => void;
  currentUser: User;
  onOpenPeerTab?: () => void;
  onOpenHowToRun?: () => void;
}

export const ChatPanel: React.FC<ChatPanelProps> = ({
  messages,
  onSendMessage,
  currentUser,
  onOpenPeerTab,
  onOpenHowToRun,
}) => {
  const [inputText, setInputText] = useState('');
  const [activeTab, setActiveTab] = useState<'chat' | 'activity'>('chat');
  const [isCollapsed, setIsCollapsed] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = inputText.trim();
    if (!trimmed) return;
    onSendMessage(trimmed);
    setInputText('');
  };

  const handleQuickPrompt = (text: string) => {
    onSendMessage(text);
  };

  const handleSimulatePeerMessage = () => {
    const peerResponses = [
      "Hey! I just reviewed the self-attention weights in line 45, the softmax normalization looks super clean! 🚀",
      "I'm testing the RAG cosine similarity query on doc-2, similarity score is 0.89! 🎯",
      "Notice how LoRA saves 99.2% memory? Perfect for our MCA Generative AI viva defense!",
      "I ran the benchmark suite, 100,000 matrix ops passed in 14.2ms! 🎉"
    ];
    const randomReply = peerResponses[Math.floor(Math.random() * peerResponses.length)];
    const mockPeerMsg: ChatMessage = {
      id: `sim-${Date.now()}-${Math.random()}`,
      userId: 'peer-sim-sarah',
      userName: 'Sarah (Peer Collab)',
      userColor: '#10b981',
      content: randomReply,
      timestamp: Date.now(),
      type: 'text',
    };
    onSendMessage(mockPeerMsg.content);
  };

  // Activity logs
  const activityLogs = messages.filter((m) => m.type === 'system' && !m.content.includes('👋'));

  return (
    <div className={`transition-all duration-300 flex flex-col bg-[#161b22] border-r border-[#30363d] relative ${isCollapsed ? 'w-10' : 'w-72 lg:w-80'}`}>
      {/* Collapse Toggle */}
      <button
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="absolute -right-3 top-3 z-30 w-6 h-6 bg-[#21262d] border border-[#30363d] rounded-full text-zinc-300 hover:text-white flex items-center justify-center shadow-lg hover:bg-[#30363d] transition-all cursor-pointer"
        title={isCollapsed ? 'Expand chat' : 'Collapse chat'}
      >
        {isCollapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
      </button>

      {isCollapsed ? (
        <div className="flex flex-col items-center py-4 space-y-4">
          <button
            onClick={() => setIsCollapsed(false)}
            className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-[#21262d] relative cursor-pointer"
            title="Open Chat"
          >
            <MessageSquare className="w-4 h-4 text-sky-400" />
            {messages.length > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-sky-400" />
            )}
          </button>
          <div className="text-[10px] uppercase font-mono font-bold tracking-widest text-zinc-500 [writing-mode:vertical-rl]">
            COLLAB CHAT
          </div>
        </div>
      ) : (
        <>
          {/* Header & Tabs */}
          <div className="h-10 px-3 border-b border-[#30363d] flex items-center justify-between select-none">
            <div className="flex items-center space-x-1">
              <button
                onClick={() => setActiveTab('chat')}
                className={`flex items-center space-x-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
                  activeTab === 'chat'
                    ? 'bg-[#21262d] text-white font-semibold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5 text-sky-400" />
                <span>Chat</span>
                <span className="text-[10px] bg-zinc-800 px-1.5 rounded-full text-zinc-400">
                  {messages.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('activity')}
                className={`flex items-center space-x-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
                  activeTab === 'activity'
                    ? 'bg-[#21262d] text-white font-semibold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                <span>Activity</span>
              </button>
            </div>

            {onOpenHowToRun && (
              <button
                onClick={onOpenHowToRun}
                className="flex items-center space-x-1 text-[11px] text-sky-400 hover:text-sky-300 font-medium px-1.5 py-0.5 rounded hover:bg-[#21262d] transition-colors cursor-pointer"
                title="How to test multi-user chat and video"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Guide</span>
              </button>
            )}
          </div>

          {/* Quick Notice Banner */}
          <div className="px-3 py-2 bg-[#0d1117] border-b border-[#30363d]/70 text-[11px] text-zinc-400 space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-zinc-300 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-sky-400" />
                <span>Real-Time Collab Tip</span>
              </span>
              {onOpenPeerTab && (
                <button
                  onClick={onOpenPeerTab}
                  className="text-sky-400 hover:underline flex items-center gap-0.5 font-medium cursor-pointer"
                >
                  <span>Open Peer Tab</span>
                  <ExternalLink className="w-2.5 h-2.5" />
                </button>
              )}
            </div>
            <p className="text-[10px] text-zinc-500 leading-tight">
              Type <code className="text-sky-300 bg-black/40 px-1 py-0.2 rounded font-mono">@ai &lt;question&gt;</code> to chat with Gemini Copilot in this room!
            </p>
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {activeTab === 'chat' ? (
              <>
                {messages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-4 text-zinc-500">
                    <MessageSquare className="w-6 h-6 mb-2 opacity-40 text-sky-400" />
                    <p className="text-xs font-semibold text-zinc-300">Chat Session Live</p>
                    <p className="text-[11px] text-zinc-500 mt-1">Send a message below or click a quick prompt to test.</p>
                  </div>
                ) : (
                  messages.map((msg) => {
                    const isMe = msg.userId === currentUser.id;
                    const isAi = msg.userId === 'ai-copilot' || msg.userName.includes('Gemini');
                    const isSystem = msg.type === 'system';

                    if (isSystem) {
                      return (
                        <div key={msg.id} className="p-2 rounded-lg bg-[#0d1117] border border-[#30363d] text-[11px] text-zinc-400 font-mono">
                          <div className="flex items-center space-x-1.5 text-sky-400 font-bold mb-0.5">
                            <Bot className="w-3 h-3" />
                            <span>{msg.userName}</span>
                          </div>
                          <p className="text-zinc-300 font-sans leading-relaxed">{msg.content}</p>
                        </div>
                      );
                    }

                    return (
                      <div
                        key={msg.id}
                        className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                      >
                        <div className="flex items-center space-x-1 text-[10px] text-zinc-500 mb-0.5 font-mono">
                          {isAi && <Sparkles className="w-2.5 h-2.5 text-sky-400" />}
                          <span style={{ color: msg.userColor }} className="font-semibold">
                            {isMe ? 'You' : msg.userName}
                          </span>
                          <span>
                            {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <div
                          className={`px-3 py-1.5 rounded-xl text-xs max-w-[90%] break-words leading-relaxed ${
                            isMe
                              ? 'bg-sky-600 text-white rounded-tr-none'
                              : isAi
                              ? 'bg-[#1e293b] text-sky-100 border border-sky-500/40 rounded-tl-none font-mono text-[11px]'
                              : 'bg-[#21262d] text-zinc-200 rounded-tl-none border border-[#30363d]'
                          }`}
                        >
                          {msg.content}
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </>
            ) : (
              <div className="space-y-2">
                {activityLogs.map((log) => (
                  <div key={log.id} className="text-[11px] font-mono text-zinc-400 p-2 rounded bg-[#0d1117] border border-[#30363d] flex items-start space-x-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1 shrink-0" />
                    <div className="flex-1 leading-snug">
                      <p>{log.content}</p>
                      <span className="text-[9px] text-zinc-600">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick Prompts Bar */}
          <div className="px-3 py-1.5 bg-[#161b22] border-t border-[#30363d] flex items-center gap-1.5 overflow-x-auto text-[10px] font-mono select-none">
            <button
              onClick={() => handleQuickPrompt('@ai explain self attention in 2 sentences')}
              className="px-2 py-0.5 rounded bg-sky-500/10 hover:bg-sky-500/20 text-sky-300 border border-sky-500/30 whitespace-nowrap cursor-pointer transition-colors"
            >
              @ai explain attention
            </button>
            <button
              onClick={() => handleQuickPrompt('@ai how does LoRA save memory?')}
              className="px-2 py-0.5 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 whitespace-nowrap cursor-pointer transition-colors"
            >
              @ai LoRA math
            </button>
            <button
              onClick={handleSimulatePeerMessage}
              className="px-2 py-0.5 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 whitespace-nowrap cursor-pointer transition-colors"
              title="Simulates a message from peer collaborator"
            >
              + Peer Msg
            </button>
          </div>

          {/* Chat Input */}
          <form onSubmit={handleSubmit} className="p-2.5 bg-[#0d1117] border-t border-[#30363d]">
            <div className="flex items-center space-x-1.5 bg-[#161b22] border border-[#30363d] rounded-lg px-2.5 py-1.5 focus-within:border-sky-500/50">
              <input
                type="text"
                placeholder="Type message or @ai <question>..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                className="flex-1 bg-transparent text-xs text-white placeholder-zinc-500 outline-none font-sans"
              />
              <button
                type="submit"
                disabled={!inputText.trim()}
                className="p-1 text-sky-400 hover:text-white disabled:opacity-30 transition-colors cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>
        </>
      )}
    </div>
  );
};
