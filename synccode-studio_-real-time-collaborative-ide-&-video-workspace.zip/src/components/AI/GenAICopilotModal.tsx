import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  X, 
  BookOpen, 
  Zap, 
  ShieldAlert, 
  Code, 
  Copy, 
  Check, 
  Share2,
  BrainCircuit,
  Cpu,
  Bot
} from 'lucide-react';
import { CodeFile, User } from '../../types';

interface GenAICopilotModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeFile: CodeFile | null;
  onShareToChat: (content: string) => void;
  currentUser: User;
}

export const GenAICopilotModal: React.FC<GenAICopilotModalProps> = ({
  isOpen,
  onClose,
  activeFile,
  onShareToChat,
  currentUser,
}) => {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [activeAction, setActiveAction] = useState<string>('explain');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCallAI = async (action: 'explain' | 'optimize' | 'debug' | 'generate' | 'chat', customPrompt?: string) => {
    if (!activeFile) return;
    setIsLoading(true);
    setActiveAction(action);

    try {
      const res = await fetch('/api/ai/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          code: activeFile.content,
          activeFile: activeFile.name,
          prompt: customPrompt || prompt,
        }),
      });

      const data = await res.json();
      if (data.text) {
        setResponse(data.text);
      } else if (data.fallbackText) {
        setResponse(data.fallbackText);
      } else {
        setResponse('No response received from GenAI Copilot.');
      }
    } catch (err: any) {
      setResponse(`Error connecting to Gemini API: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!response) return;
    navigator.clipboard.writeText(response);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleBroadcast = () => {
    if (!response) return;
    const summary = `🤖 [GenAI Copilot Insight on ${activeFile?.name}]:\n${response.slice(0, 300)}...`;
    onShareToChat(summary);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#161b22] border border-[#30363d] rounded-2xl w-full max-w-3xl max-h-[88vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#30363d] flex items-center justify-between bg-[#0d1117]/80">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 via-indigo-500 to-emerald-400 p-[1.5px] flex items-center justify-center shadow-lg shadow-sky-500/20">
              <div className="w-full h-full bg-[#0d1117] rounded-[9px] flex items-center justify-center">
                <BrainCircuit className="w-5 h-5 text-sky-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-white tracking-tight">
                  Gemini GenAI Copilot
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20">
                  MCA AI/ML Domain
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Context: <span className="font-mono text-zinc-200">{activeFile?.name || 'Active File'}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-[#21262d] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Preset Buttons */}
        <div className="px-5 py-3 border-b border-[#30363d] bg-[#161b22] flex flex-wrap gap-2">
          <button
            onClick={() => handleCallAI('explain')}
            disabled={isLoading}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
              activeAction === 'explain' && response
                ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                : 'bg-[#21262d] text-zinc-300 border-[#30363d] hover:bg-[#30363d]'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-sky-400" />
            <span>Explain Mathematical Foundations</span>
          </button>

          <button
            onClick={() => handleCallAI('optimize')}
            disabled={isLoading}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
              activeAction === 'optimize' && response
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-[#21262d] text-zinc-300 border-[#30363d] hover:bg-[#30363d]'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-emerald-400" />
            <span>Optimize Tensor & Memory Footprint</span>
          </button>

          <button
            onClick={() => handleCallAI('debug')}
            disabled={isLoading}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
              activeAction === 'debug' && response
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'bg-[#21262d] text-zinc-300 border-[#30363d] hover:bg-[#30363d]'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            <span>Audit Numerical Stability & Bounds</span>
          </button>
        </div>

        {/* Content & Response Display */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs font-mono">
          {isLoading ? (
            <div className="h-64 flex flex-col items-center justify-center space-y-3 text-zinc-400">
              <div className="w-8 h-8 rounded-full border-2 border-sky-400 border-t-transparent animate-spin" />
              <p className="font-sans text-xs">Gemini 3.8 is analyzing transformer tensors and mathematical proofs...</p>
            </div>
          ) : response ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-[#30363d] pb-2">
                <span className="font-sans text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                  <Bot className="w-4 h-4 text-sky-400" />
                  <span>GenAI Model Analysis</span>
                </span>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleCopy}
                    className="flex items-center space-x-1 text-zinc-400 hover:text-white px-2 py-1 rounded bg-[#21262d] border border-[#30363d] cursor-pointer"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span className="font-sans text-[10px]">{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                  <button
                    onClick={handleBroadcast}
                    className="flex items-center space-x-1 text-sky-400 hover:text-white px-2 py-1 rounded bg-sky-500/10 border border-sky-500/30 cursor-pointer"
                    title="Broadcast insight to all room members in chat"
                  >
                    <Share2 className="w-3 h-3" />
                    <span className="font-sans text-[10px]">Share to Room Chat</span>
                  </button>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#0d1117] border border-[#30363d] text-zinc-200 whitespace-pre-wrap leading-relaxed font-mono">
                {response}
              </div>
            </div>
          ) : (
            <div className="h-64 flex flex-col items-center justify-center text-center p-6 text-zinc-500 font-sans">
              <Sparkles className="w-8 h-8 mb-2 text-sky-400 opacity-60" />
              <p className="text-sm font-semibold text-zinc-300">Generative AI Pair Programmer</p>
              <p className="text-xs text-zinc-500 max-w-md mt-1">
                Select an analysis action above (e.g., Explain Mathematical Foundations of Self-Attention or LoRA) or enter a custom prompt below to query Gemini 3.8.
              </p>
            </div>
          )}
        </div>

        {/* Custom Prompt Input */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (prompt.trim()) handleCallAI('chat', prompt.trim());
          }}
          className="p-3 bg-[#0d1117] border-t border-[#30363d] flex items-center space-x-2"
        >
          <input
            type="text"
            placeholder="Ask a question about Transformer Attention, RAG, PyTorch embeddings, or LoRA math..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="flex-1 bg-[#161b22] border border-[#30363d] rounded-lg px-3 py-2 text-xs text-white placeholder-zinc-500 outline-none focus:border-sky-500/50 font-sans"
          />
          <button
            type="submit"
            disabled={!prompt.trim() || isLoading}
            className="px-4 py-2 bg-sky-600 hover:bg-sky-500 disabled:opacity-30 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Ask</span>
          </button>
        </form>
      </div>
    </div>
  );
};
