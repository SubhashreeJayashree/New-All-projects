import React, { useState, useEffect, useRef, useMemo } from 'react';
import Prism from 'prismjs';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-markdown';
import 'prismjs/components/prism-python';
import { 
  FileCode, 
  Plus, 
  X, 
  Download, 
  Trash2, 
  Edit3, 
  FileText, 
  Check, 
  Code,
  FileSpreadsheet
} from 'lucide-react';
import { CodeFile, RemoteCursor, User } from '../../types';

interface CodeEditorProps {
  files: CodeFile[];
  activeFileId: string;
  onSelectFile: (fileId: string) => void;
  onCodeChange: (fileId: string, content: string) => void;
  onCreateFile: (name: string, language: CodeFile['language']) => void;
  onRenameFile: (fileId: string, newName: string) => void;
  onDeleteFile: (fileId: string) => void;
  remoteCursors: RemoteCursor[];
  onCursorChange: (fileId: string, line: number, col: number) => void;
  currentUser: User;
  onRunCode: () => void;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({
  files,
  activeFileId,
  onSelectFile,
  onCodeChange,
  onCreateFile,
  onRenameFile,
  onDeleteFile,
  remoteCursors,
  onCursorChange,
  currentUser,
  onRunCode,
}) => {
  const activeFile = files.find((f) => f.id === activeFileId) || files[0];
  const [newFileName, setNewFileName] = useState('');
  const [isAddingFile, setIsAddingFile] = useState(false);
  const [editingFileId, setEditingFileId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [fontSize, setFontSize] = useState<number>(14);
  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1 });

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);

  // Sync scrolling between textarea and highlight pre
  const handleScroll = () => {
    if (textareaRef.current && preRef.current) {
      preRef.current.scrollTop = textareaRef.current.scrollTop;
      preRef.current.scrollLeft = textareaRef.current.scrollLeft;
    }
  };

  // Syntax highlighting
  const highlightedCode = useMemo(() => {
    if (!activeFile) return '';
    const lang = activeFile.language;
    const grammar = Prism.languages[lang] || Prism.languages.javascript;
    return Prism.highlight(activeFile.content, grammar, lang);
  }, [activeFile?.content, activeFile?.language]);

  // Split lines for line numbering
  const lines = useMemo(() => {
    if (!activeFile) return [1];
    const count = (activeFile.content.match(/\n/g) || []).length + 1;
    return Array.from({ length: count }, (_, i) => i + 1);
  }, [activeFile?.content]);

  // Update cursor position and notify peers
  const handleCursorUpdate = () => {
    const el = textareaRef.current;
    if (!el || !activeFile) return;

    const textBeforeCursor = el.value.substring(0, el.selectionStart);
    const line = (textBeforeCursor.match(/\n/g) || []).length + 1;
    const lastNewline = textBeforeCursor.lastIndexOf('\n');
    const col = lastNewline === -1 ? textBeforeCursor.length + 1 : textBeforeCursor.length - lastNewline;

    setCursorPos({ line, col });
    onCursorChange(activeFile.id, line, col);
  };

  // Handle Tab, Shift-Tab, Enter auto-indent, and Cmd+Enter
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const el = textareaRef.current;
    if (!el || !activeFile) return;

    // Run code shortcut: Cmd/Ctrl + Enter
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      onRunCode();
      return;
    }

    // Tab key support
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = el.selectionStart;
      const end = el.selectionEnd;
      const val = el.value;

      if (e.shiftKey) {
        // Un-indent if shift is held
        const lineStart = val.lastIndexOf('\n', start - 1) + 1;
        if (val.slice(lineStart, lineStart + 2) === '  ') {
          const newContent = val.slice(0, lineStart) + val.slice(lineStart + 2);
          onCodeChange(activeFile.id, newContent);
          setTimeout(() => {
            el.selectionStart = el.selectionEnd = Math.max(lineStart, start - 2);
            handleCursorUpdate();
          }, 0);
        }
      } else {
        // Insert 2 spaces
        const newContent = val.substring(0, start) + '  ' + val.substring(end);
        onCodeChange(activeFile.id, newContent);
        setTimeout(() => {
          el.selectionStart = el.selectionEnd = start + 2;
          handleCursorUpdate();
        }, 0);
      }
      return;
    }

    // Auto-indent on Enter
    if (e.key === 'Enter') {
      e.preventDefault();
      const start = el.selectionStart;
      const val = el.value;
      const lineStart = val.lastIndexOf('\n', start - 1) + 1;
      const currentLine = val.substring(lineStart, start);
      const match = currentLine.match(/^(\s*)/);
      const indent = match ? match[1] : '';
      
      // If previous line ends with { or :, add extra 2 spaces
      const extraIndent = /[{\[(:]\s*$/.test(currentLine) ? '  ' : '';
      const insert = '\n' + indent + extraIndent;

      const newContent = val.substring(0, start) + insert + val.substring(start);
      onCodeChange(activeFile.id, newContent);
      setTimeout(() => {
        el.selectionStart = el.selectionEnd = start + insert.length;
        handleCursorUpdate();
      }, 0);
      return;
    }
  };

  const handleCreateFileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newFileName.trim();
    if (!trimmed) return;

    let lang: CodeFile['language'] = 'javascript';
    if (trimmed.endsWith('.ts') || trimmed.endsWith('.tsx')) lang = 'typescript';
    else if (trimmed.endsWith('.py')) lang = 'python';
    else if (trimmed.endsWith('.html')) lang = 'html';
    else if (trimmed.endsWith('.css')) lang = 'css';
    else if (trimmed.endsWith('.json')) lang = 'json';
    else if (trimmed.endsWith('.md')) lang = 'markdown';

    onCreateFile(trimmed, lang);
    setNewFileName('');
    setIsAddingFile(false);
  };

  const handleDownloadActiveFile = () => {
    if (!activeFile) return;
    const blob = new Blob([activeFile.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFile.name;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Filter remote cursors that are currently in this file
  const activeRemoteCursors = remoteCursors.filter((c) => c.fileId === activeFile?.id);

  const getFileIcon = (fileName: string) => {
    if (fileName.endsWith('.ts') || fileName.endsWith('.tsx')) {
      return <span className="text-[10px] font-bold text-sky-400 font-mono">TS</span>;
    }
    if (fileName.endsWith('.js') || fileName.endsWith('.jsx')) {
      return <span className="text-[10px] font-bold text-amber-400 font-mono">JS</span>;
    }
    if (fileName.endsWith('.py')) {
      return <span className="text-[10px] font-bold text-emerald-400 font-mono">PY</span>;
    }
    if (fileName.endsWith('.html')) {
      return <span className="text-[10px] font-bold text-orange-400 font-mono">HTML</span>;
    }
    if (fileName.endsWith('.css')) {
      return <span className="text-[10px] font-bold text-pink-400 font-mono">CSS</span>;
    }
    if (fileName.endsWith('.md')) {
      return <FileText className="w-3.5 h-3.5 text-zinc-400" />;
    }
    return <FileCode className="w-3.5 h-3.5 text-sky-400" />;
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0d1117] overflow-hidden">
      {/* File Tabs Header */}
      <div className="h-10 bg-[#161b22] border-b border-[#30363d] flex items-center justify-between px-2 overflow-x-auto select-none">
        <div className="flex items-center space-x-1 overflow-x-auto">
          {files.map((file) => {
            const isActive = file.id === activeFileId;
            const isEditing = editingFileId === file.id;

            return (
              <div
                key={file.id}
                onClick={() => !isEditing && onSelectFile(file.id)}
                className={`group flex items-center space-x-2 px-3 py-1.5 rounded-t-md text-xs font-mono cursor-pointer transition-colors border-t-2 ${
                  isActive
                    ? 'bg-[#0d1117] text-white border-sky-400 shadow-sm'
                    : 'bg-transparent text-zinc-400 hover:text-zinc-200 border-transparent hover:bg-[#21262d]'
                }`}
              >
                {getFileIcon(file.name)}

                {isEditing ? (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      onRenameFile(file.id, renameValue);
                      setEditingFileId(null);
                    }}
                    className="flex items-center"
                  >
                    <input
                      type="text"
                      value={renameValue}
                      onChange={(e) => setRenameValue(e.target.value)}
                      onBlur={() => {
                        onRenameFile(file.id, renameValue);
                        setEditingFileId(null);
                      }}
                      autoFocus
                      className="bg-[#21262d] text-white px-1 py-0.5 rounded text-xs outline-none w-24"
                    />
                  </form>
                ) : (
                  <span
                    onDoubleClick={() => {
                      setEditingFileId(file.id);
                      setRenameValue(file.name);
                    }}
                    className="font-medium"
                  >
                    {file.name}
                  </span>
                )}

                {/* Remote cursor indicator dot in tab */}
                {remoteCursors.some((c) => c.fileId === file.id) && (
                  <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse" title="Peer actively viewing/editing" />
                )}

                {files.length > 1 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteFile(file.id);
                    }}
                    className="opacity-0 group-hover:opacity-100 p-0.5 hover:text-rose-400 rounded transition-opacity"
                    title="Delete file"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            );
          })}

          {/* New file button */}
          {isAddingFile ? (
            <form onSubmit={handleCreateFileSubmit} className="flex items-center space-x-1 pl-1">
              <input
                type="text"
                placeholder="filename.ts"
                value={newFileName}
                onChange={(e) => setNewFileName(e.target.value)}
                onBlur={() => setIsAddingFile(false)}
                autoFocus
                className="bg-[#21262d] border border-sky-500/50 text-white px-2 py-1 rounded text-xs outline-none w-28 font-mono"
              />
            </form>
          ) : (
            <button
              onClick={() => setIsAddingFile(true)}
              className="p-1 text-zinc-400 hover:text-white hover:bg-[#21262d] rounded transition-colors"
              title="Create new file"
            >
              <Plus className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Action icons */}
        <div className="flex items-center space-x-2">
          {/* Active typing peers indicator */}
          {activeRemoteCursors.length > 0 && (
            <div className="hidden sm:flex items-center space-x-1 text-[11px] font-mono text-zinc-400 bg-[#21262d] px-2 py-0.5 rounded">
              <span className="w-2 h-2 rounded-full animate-ping" style={{ backgroundColor: activeRemoteCursors[0].userColor }} />
              <span>{activeRemoteCursors[0].userName} is editing</span>
            </div>
          )}

          <button
            onClick={handleDownloadActiveFile}
            className="p-1 text-zinc-400 hover:text-white hover:bg-[#21262d] rounded transition-colors"
            title="Download current file"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Editor Body */}
      <div className="flex-1 relative flex overflow-hidden">
        {/* Line numbers gutter */}
        <div
          className="w-12 bg-[#0d1117] border-r border-[#30363d] py-3 text-right pr-3 select-none text-zinc-600 font-mono text-xs overflow-hidden shrink-0"
          style={{ fontSize: `${fontSize}px`, lineHeight: `${fontSize * 1.5}px` }}
        >
          {lines.map((num) => (
            <div
              key={num}
              className={`${cursorPos.line === num ? 'text-sky-400 font-semibold' : ''}`}
            >
              {num}
            </div>
          ))}
        </div>

        {/* Code textarea & Syntax highlight container */}
        <div className="flex-1 relative h-full overflow-hidden">
          {/* Syntax Highlight Layer */}
          <pre
            ref={preRef}
            aria-hidden="true"
            className="absolute inset-0 p-3 m-0 overflow-hidden font-mono whitespace-pre pointer-events-none z-0"
            style={{
              fontSize: `${fontSize}px`,
              lineHeight: `${fontSize * 1.5}px`,
            }}
            dangerouslySetInnerHTML={{ __html: highlightedCode + '<br />' }}
          />

          {/* Transparent Input Textarea */}
          <textarea
            ref={textareaRef}
            value={activeFile?.content || ''}
            onChange={(e) => {
              if (activeFile) {
                onCodeChange(activeFile.id, e.target.value);
              }
              handleCursorUpdate();
            }}
            onScroll={handleScroll}
            onClick={handleCursorUpdate}
            onKeyUp={handleCursorUpdate}
            onKeyDown={handleKeyDown}
            spellCheck={false}
            autoCapitalize="off"
            autoComplete="off"
            className="absolute inset-0 p-3 m-0 w-full h-full font-mono whitespace-pre bg-transparent text-transparent caret-white resize-none outline-none z-10 overflow-auto selection:bg-sky-500/20"
            style={{
              fontSize: `${fontSize}px`,
              lineHeight: `${fontSize * 1.5}px`,
            }}
          />

          {/* Floating Remote Cursors Markers */}
          {activeRemoteCursors.map((cursor) => {
            const lineHeight = fontSize * 1.5;
            const charWidth = fontSize * 0.6; // average monospace character width
            const top = (cursor.line - 1) * lineHeight + 12;
            const left = (cursor.col - 1) * charWidth + 12;

            return (
              <div
                key={cursor.userId}
                className="absolute pointer-events-none z-20 transition-all duration-75"
                style={{ top: `${top}px`, left: `${left}px` }}
              >
                {/* Cursor line */}
                <div
                  className="w-[2px] animate-pulse"
                  style={{
                    height: `${lineHeight}px`,
                    backgroundColor: cursor.userColor,
                    boxShadow: `0 0 8px ${cursor.userColor}`,
                  }}
                />
                {/* User Flag Badge */}
                <div
                  className="absolute -top-5 left-0 px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold text-white whitespace-nowrap shadow-md"
                  style={{ backgroundColor: cursor.userColor }}
                >
                  {cursor.userName}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Editor Status Bar */}
      <div className="h-6 bg-[#161b22] border-t border-[#30363d] px-3 flex items-center justify-between text-[11px] font-mono text-zinc-400 select-none shrink-0">
        <div className="flex items-center space-x-3">
          <span className="flex items-center space-x-1 text-zinc-300">
            <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
            <span>Ln {cursorPos.line}, Col {cursorPos.col}</span>
          </span>
          <span>Spaces: 2</span>
          <span>UTF-8</span>
          <span className="uppercase text-sky-400 font-semibold">{activeFile?.language}</span>
        </div>

        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1">
            <span>Font:</span>
            <button
              onClick={() => setFontSize(Math.max(12, fontSize - 1))}
              className="px-1 hover:text-white"
            >
              -
            </button>
            <span className="text-zinc-300">{fontSize}px</span>
            <button
              onClick={() => setFontSize(Math.min(20, fontSize + 1))}
              className="px-1 hover:text-white"
            >
              +
            </button>
          </div>
          <span className="text-zinc-500">SyncCode v1.0</span>
        </div>
      </div>
    </div>
  );
};
