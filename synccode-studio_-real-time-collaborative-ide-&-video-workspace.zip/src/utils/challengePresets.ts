import { ChallengePreset, CodeFile } from '../types';

export const STARTER_FILES: CodeFile[] = [
  {
    id: 'f-attention',
    name: 'transformer_attention.ts',
    language: 'typescript',
    content: `/**
 * MCA Generative AI Project: Core Transformer Architecture
 * Topic: Scaled Dot-Product Multi-Head Self-Attention
 * Formula: Attention(Q, K, V) = softmax( (Q * K^T) / sqrt(d_k) ) * V
 */

export interface AttentionOutput {
  context: number[][];       // Contextual representation [seq_len, d_v]
  attentionWeights: number[][]; // Attention distribution matrix [seq_len, seq_len]
}

export class ScaledDotProductAttention {
  private d_k: number;

  constructor(dimensionKey: number) {
    this.d_k = dimensionKey;
  }

  /**
   * Computes forward self-attention across sequence tokens
   * @param Q Query matrix [sequence_length x d_k]
   * @param K Key matrix [sequence_length x d_k]
   * @param V Value matrix [sequence_length x d_v]
   * @param isCausalMask If true, applies autoregressive causal triangle masking
   */
  public forward(
    Q: number[][],
    K: number[][],
    V: number[][],
    isCausalMask: boolean = false
  ): AttentionOutput {
    const seqLen = Q.length;
    const d_v = V[0].length;
    const scale = Math.sqrt(this.d_k);

    // 1. Compute Raw Attention Scores: Q * K^T
    const scores: number[][] = [];
    for (let i = 0; i < seqLen; i++) {
      scores[i] = [];
      for (let j = 0; j < seqLen; j++) {
        let dotProduct = 0;
        for (let k = 0; k < this.d_k; k++) {
          dotProduct += Q[i][k] * K[j][k];
        }
        // Scaled dot-product
        let scaledScore = dotProduct / scale;

        // Apply causal mask for autoregressive generation (GPT-style)
        if (isCausalMask && j > i) {
          scaledScore = -1e9; // Negative infinity for masked future tokens
        }
        scores[i][j] = scaledScore;
      }
    }

    // 2. Softmax along token rows: softmax(row) = exp(x_i) / sum(exp(x_j))
    const attentionWeights: number[][] = [];
    for (let i = 0; i < seqLen; i++) {
      attentionWeights[i] = [];
      // Numerical stability trick: subtract max(row)
      const maxVal = Math.max(...scores[i]);
      let sumExp = 0;
      const exps = scores[i].map((val) => {
        const e = Math.exp(val - maxVal);
        sumExp += e;
        return e;
      });

      for (let j = 0; j < seqLen; j++) {
        attentionWeights[i][j] = Number((exps[j] / sumExp).toFixed(4));
      }
    }

    // 3. Contextual Embedding Output: Weights * V
    const context: number[][] = [];
    for (let i = 0; i < seqLen; i++) {
      context[i] = [];
      for (let d = 0; d < d_v; d++) {
        let weightedSum = 0;
        for (let j = 0; j < seqLen; j++) {
          weightedSum += attentionWeights[i][j] * V[j][d];
        }
        context[i][d] = Number(weightedSum.toFixed(4));
      }
    }

    return { context, attentionWeights };
  }
}

// Interactive Generative AI Verification
console.log("🧠 Initializing Transformer Self-Attention Layer...");
const tokens = ["The", "neural", "network", "generates", "intelligence"];
const d_model = 4;

// Sample 5-token embeddings [5 x 4]
const Q = [
  [0.8, 0.2, 0.1, 0.5],
  [0.3, 0.9, 0.4, 0.2],
  [0.1, 0.4, 0.8, 0.6],
  [0.7, 0.1, 0.3, 0.9],
  [0.2, 0.8, 0.5, 0.7]
];
const K = Q; // Self-attention
const V = Q;

const attention = new ScaledDotProductAttention(d_model);
const result = attention.forward(Q, K, V, true); // Autoregressive Causal Attention

console.log("✨ Input Token Sequence:", tokens.join(" | "));
console.log("📊 Causal Attention Weight Distribution (Row = Token, Col = Attention given):");
console.table(result.attentionWeights);
console.log("🎯 Contextual Vector Embeddings [5 x 4]:");
console.log(result.context);
console.log("🎉 Scaled Dot-Product Transformer step successfully computed!");
`,
    updatedAt: Date.now(),
  },
  {
    id: 'f-rag',
    name: 'rag_vector_search.ts',
    language: 'typescript',
    content: `/**
 * MCA Generative AI Project: RAG (Retrieval-Augmented Generation) Pipeline
 * Vector Embeddings, Cosine Similarity, and Top-K Knowledge Injection
 */

export interface KnowledgeDocument {
  id: string;
  title: string;
  content: string;
  embedding: number[]; // 5-dimensional dense vector simulation
}

// Normalized cosine similarity: cos(theta) = (A . B) / (||A|| * ||B||)
export function cosineSimilarity(vecA: number[], vecB: number[]): number {
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

export class VectorRAGStore {
  private documents: KnowledgeDocument[] = [];

  public addDocument(doc: KnowledgeDocument) {
    this.documents.push(doc);
  }

  public query(queryEmbedding: number[], topK: number = 2) {
    const scored = this.documents.map((doc) => ({
      doc,
      score: cosineSimilarity(queryEmbedding, doc.embedding),
    }));

    // Sort descending by cosine similarity score
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, topK);
  }
}

// Demonstration
console.log("🔍 Initializing Vector RAG Knowledge Base...");
const rag = new VectorRAGStore();

rag.addDocument({
  id: "doc-1",
  title: "Transformer Attention Paper (Vaswani et al.)",
  content: "The Transformer relies entirely on self-attention mechanisms without recurrence or convolutions.",
  embedding: [0.92, 0.88, 0.12, 0.05, 0.74]
});

rag.addDocument({
  id: "doc-2",
  title: "LoRA Parameter-Efficient Fine-Tuning",
  content: "Freezes pre-trained model weights and injects trainable rank decomposition matrices into Transformer layers.",
  embedding: [0.85, 0.79, 0.35, 0.22, 0.91]
});

rag.addDocument({
  id: "doc-3",
  title: "Relational Database Indexing B-Trees",
  content: "B-Tree indexes optimize disk I/O operations for traditional relational database search queries.",
  embedding: [0.08, 0.15, 0.94, 0.88, 0.12]
});

// User prompt query embedding: "How to fine-tune large language models efficiently?"
const queryVector = [0.88, 0.82, 0.28, 0.18, 0.89];
console.log("Target Query Vector:", queryVector);

const results = rag.query(queryVector, 2);
console.log("Top-K Retrieved Context Documents for LLM Prompt Augmentation:");
results.forEach((res, rank) => {
  console.log(\`#\${rank + 1} [\${res.doc.title}] Similarity Score: \${res.score.toFixed(4)}\`);
  console.log(\`   Content: "\${res.doc.content}"\`);
});
`,
    updatedAt: Date.now(),
  },
  {
    id: 'f-lora',
    name: 'lora_peft.ts',
    language: 'typescript',
    content: `/**
 * MCA Generative AI Project: LoRA (Low-Rank Adaptation) PEFT
 * Mathematical Formula: W_updated = W_0 + (alpha / r) * (B @ A)
 * Where W_0 in R^(d x k), B in R^(d x r), A in R^(r x k), and rank r << min(d, k)
 */

export class LoRALayer {
  public d: number;       // Input dimension
  public k: number;       // Output dimension
  public r: number;       // Intrinsic low rank
  public alpha: number;   // Scaling factor
  public matrixA: number[][]; // [r x d] initialized with Gaussian N(0, sigma^2)
  public matrixB: number[][]; // [k x r] initialized with zeros

  constructor(inDim: number, outDim: number, rank: number = 4, alpha: number = 8) {
    this.d = inDim;
    this.k = outDim;
    this.r = rank;
    this.alpha = alpha;

    // A is initialized randomly
    this.matrixA = Array.from({ length: rank }, () =>
      Array.from({ length: inDim }, () => Number((Math.random() * 0.02 - 0.01).toFixed(4)))
    );

    // B is initialized to 0 so adaptation starts as an identity function
    this.matrixB = Array.from({ length: outDim }, () =>
      Array.from({ length: rank }, () => 0)
    );
  }

  public getParameterReductionStats(): { fullParams: number; loraParams: number; savingsPercent: string } {
    const fullParams = this.d * this.k;
    const loraParams = this.d * this.r + this.k * this.r;
    const savings = ((1 - loraParams / fullParams) * 100).toFixed(2);
    return {
      fullParams,
      loraParams,
      savingsPercent: \`\${savings}%\`
    };
  }
}

console.log("⚡ Calculating LoRA Parameter Efficiency on LLaMA-7B Linear Projection...");
// Typical Projection layer: d = 4096, k = 4096, rank r = 16
const lora = new LoRALayer(4096, 4096, 16, 32);
const stats = lora.getParameterReductionStats();

console.table({
  "Full Rank Weights (d x k)": stats.fullParams.toLocaleString() + " parameters",
  "LoRA Decomposed (A + B)": stats.loraParams.toLocaleString() + " parameters",
  "Memory / Storage Savings": stats.savingsPercent
});

console.log("✅ Ready for Low-Rank GPU fine-tuning without updating base weights!");
`,
    updatedAt: Date.now(),
  },
  {
    id: 'f-index-html',
    name: 'index.html',
    language: 'html',
    content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Generative AI Visualizer</title>
  <style>
    body {
      margin: 0;
      background: #090d16;
      color: #e2e8f0;
      font-family: 'JetBrains Mono', monospace;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 16px;
    }
    .card {
      background: #111827;
      border: 1px solid #1f2937;
      border-radius: 12px;
      padding: 16px;
      width: 90%;
      max-width: 520px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.5);
    }
    .title {
      font-size: 14px;
      color: #38bdf8;
      font-weight: bold;
      margin-bottom: 8px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .heatmap {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 4px;
      margin-top: 12px;
    }
    .cell {
      aspect-ratio: 1;
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 11px;
      font-weight: bold;
      color: #fff;
    }
    .legend {
      font-size: 10px;
      color: #94a3b8;
      margin-top: 10px;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="title">
      <span>⚡</span> Attention Weight Matrix Visualizer (5x5 Tokens)
    </div>
    <div style="font-size: 11px; color: #94a3b8;">
      Tokens: ["The", "neural", "network", "generates", "intelligence"]
    </div>
    <div class="heatmap" id="grid"></div>
    <div class="legend">Darker purple = lower attention | Brighter cyan = higher attention weight</div>
  </div>

  <script>
    // Attention distribution simulation
    const weights = [
      [1.00, 0.00, 0.00, 0.00, 0.00],
      [0.34, 0.66, 0.00, 0.00, 0.00],
      [0.21, 0.45, 0.34, 0.00, 0.00],
      [0.12, 0.18, 0.42, 0.28, 0.00],
      [0.08, 0.12, 0.25, 0.35, 0.20]
    ];

    const grid = document.getElementById('grid');
    weights.forEach(row => {
      row.forEach(val => {
        const cell = document.createElement('div');
        cell.className = 'cell';
        const opacity = Math.max(0.15, val);
        cell.style.background = val === 0 ? '#1f2937' : \`rgba(56, 189, 248, \${opacity})\`;
        cell.innerText = val > 0 ? val.toFixed(2) : '-';
        grid.appendChild(cell);
      });
    });
  </script>
</body>
</html>
`,
    updatedAt: Date.now(),
  },
  {
    id: 'f-readme',
    name: 'README.md',
    language: 'markdown',
    content: `# SyncCode GenAI Studio
## MCA Generative AI & Machine Learning Capstone Internship Project

### Student Academic Details
- **Program**: Master of Computer Applications (MCA)
- **Specialization**: Artificial Intelligence & Generative AI
- **Project Domain**: Real-Time Collaborative Development Environments for Foundation Model Engineering & Multi-Modal Streaming

### Core Modules Implemented
1. **Scaled Dot-Product Multi-Head Self-Attention**:
   - Implements query, key, value matrix multiplication ($Q \times K^T$), scaled square-root normalization, causal triangle masking, and softmax probability distributions.
2. **RAG (Retrieval-Augmented Generation) Vector Engine**:
   - High-dimensional vector space modeling, cosine similarity search, and Top-K context synthesis for LLM prompt augmentation.
3. **LoRA (Low-Rank Adaptation) Parameter Decomposition**:
   - Implements $W_0 + \frac{\alpha}{r}BA$ rank factorization, demonstrating 99.2% memory savings over full fine-tuning.
4. **WebRTC P2P Mesh Video & Audio Conferencing**:
   - Low-latency peer-to-peer audio/video streaming with STUN NAT traversal for remote AI research collaboration.
5. **Server-Side Gemini 3.8 Generative AI Copilot**:
   - Powered by the \`@google/genai\` SDK on Node.js/Express with mathematical derivation, tensor optimization, and prompt injection defense auditing.
`,
    updatedAt: Date.now(),
  }
];

export const CHALLENGE_PRESETS: ChallengePreset[] = [
  {
    id: 'transformer-attention',
    title: 'Multi-Head Self Attention',
    difficulty: 'Hard',
    description: 'Implement the core Scaled Dot-Product Attention mechanism with causal autoregressive masking used in modern Generative LLMs (GPT, Gemini, LLaMA).',
    tags: ['Generative AI', 'Transformers', 'Self-Attention', 'PyTorch/Math'],
    files: STARTER_FILES,
  },
  {
    id: 'rag-vector-search',
    title: 'RAG Semantic Vector Search',
    difficulty: 'Medium',
    description: 'Build a vector embeddings store that computes normalized cosine similarity between query and knowledge documents for Generative RAG pipelines.',
    tags: ['RAG', 'Vector Database', 'Embeddings', 'Information Retrieval'],
    files: [
      STARTER_FILES[1],
      STARTER_FILES[3],
      STARTER_FILES[4]
    ]
  },
  {
    id: 'lora-finetuning',
    title: 'LoRA PEFT Fine-Tuning Math',
    difficulty: 'Medium',
    description: 'Decompose high-dimensional weight matrices into low-rank matrices A and B for Parameter-Efficient Fine-Tuning with 99%+ parameter reduction.',
    tags: ['LoRA', 'PEFT', 'Model Adaptation', 'Matrix Factorization'],
    files: [
      STARTER_FILES[2],
      STARTER_FILES[3],
      STARTER_FILES[4]
    ]
  }
];
