export interface User {
  id: string;
  name: string;
  color: string;
  avatar: string;
  isAudioOn: boolean;
  isVideoOn: boolean;
  isScreenSharing: boolean;
  isSpeaking: boolean;
  role?: 'host' | 'interviewer' | 'candidate' | 'collaborator';
}

export interface RemoteCursor {
  userId: string;
  userName: string;
  userColor: string;
  fileId: string;
  line: number;
  col: number;
  selection?: {
    startLine: number;
    startCol: number;
    endLine: number;
    endCol: number;
  };
}

export interface CodeFile {
  id: string;
  name: string;
  language: 'javascript' | 'typescript' | 'python' | 'html' | 'css' | 'json' | 'markdown';
  content: string;
  updatedAt: number;
}

export interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  userColor: string;
  content: string;
  timestamp: number;
  type: 'text' | 'system' | 'code';
  codeSnippet?: {
    language: string;
    code: string;
  };
}

export interface ExecutionLog {
  type: 'log' | 'info' | 'warn' | 'error' | 'table';
  message: string;
  timestamp: number;
}

export interface ExecutionResult {
  senderId: string;
  senderName: string;
  logs: ExecutionLog[];
  returnValue?: string;
  error?: string;
  durationMs: number;
  testResults?: {
    passed: boolean;
    title: string;
    expected: string;
    actual: string;
  }[];
}

export interface ChallengePreset {
  id: string;
  title: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  description: string;
  tags: string[];
  files: CodeFile[];
  testRunnerCode?: string;
}

export interface GenAIResponse {
  action: 'explain' | 'optimize' | 'debug' | 'generate' | 'chat';
  text: string;
  timestamp: number;
}

export interface RoomState {
  roomId: string;
  name: string;
  files: CodeFile[];
  activeFileId: string;
  users: User[];
  messages: ChatMessage[];
  challenge?: ChallengePreset | null;
  lastExecution?: ExecutionResult | null;
  copilotHistory?: GenAIResponse[];
}
