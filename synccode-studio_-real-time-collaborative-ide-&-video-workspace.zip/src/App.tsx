/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Navbar } from './components/Header/Navbar';
import { CodeEditor } from './components/Editor/CodeEditor';
import { VideoConferencing } from './components/Video/VideoConferencing';
import { CodeRunner } from './components/Terminal/CodeRunner';
import { ChatPanel } from './components/Chat/ChatPanel';
import { InternshipDossierModal } from './components/Showcase/InternshipDossierModal';
import { GenAICopilotModal } from './components/AI/GenAICopilotModal';
import { HowToRunModal } from './components/Showcase/HowToRunModal';
import { 
  User, 
  CodeFile, 
  ChatMessage, 
  RemoteCursor, 
  ExecutionResult, 
  ChallengePreset, 
  RoomState 
} from './types';
import { socketService } from './services/socket';
import { webrtcManager } from './services/webrtc';
import { runSandboxedCode } from './services/codeRunner';
import { STARTER_FILES, CHALLENGE_PRESETS } from './utils/challengePresets';

const USER_COLORS = [
  '#38bdf8', // sky
  '#10b981', // emerald
  '#f59e0b', // amber
  '#ec4899', // pink
  '#8b5cf6', // purple
  '#06b6d4', // cyan
];

const USER_NAMES = [
  'Alex Chen',
  'Sarah Miller',
  'David Kumar',
  'Elena Rostova',
  'Jordan Vance',
  'Maya Patel',
];

export default function App() {
  // Extract or generate Room ID and User identity from URL
  const queryParams = new URLSearchParams(window.location.search);
  const initialRoomId = queryParams.get('room') || 'interview-collab-702';
  const isPeerWindow = queryParams.get('peer') === 'true';

  const [roomId, setRoomId] = useState<string>(initialRoomId);

  // Initialize unique user profile for this session
  const [currentUser] = useState<User>(() => {
    const randomIdx = isPeerWindow ? 1 : 0;
    const name = queryParams.get('name') || USER_NAMES[randomIdx] || `Dev-${Math.floor(Math.random() * 900 + 100)}`;
    const color = USER_COLORS[randomIdx] || USER_COLORS[Math.floor(Math.random() * USER_COLORS.length)];
    return {
      id: `usr-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name,
      color,
      avatar: name.slice(0, 1),
      isAudioOn: true,
      isVideoOn: true,
      isScreenSharing: false,
      isSpeaking: false,
      role: isPeerWindow ? 'candidate' : 'interviewer',
    };
  });

  const [users, setUsers] = useState<User[]>([currentUser]);
  const [files, setFiles] = useState<CodeFile[]>(STARTER_FILES);
  const [activeFileId, setActiveFileId] = useState<string>(STARTER_FILES[0].id);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [remoteCursors, setRemoteCursors] = useState<RemoteCursor[]>([]);
  const [executionResult, setExecutionResult] = useState<ExecutionResult | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [activeChallenge, setActiveChallenge] = useState<ChallengePreset | null>(CHALLENGE_PRESETS[0]);
  
  // Real-time stats & WebRTC
  const [latencyMs, setLatencyMs] = useState<number>(12);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [remoteStreams, setRemoteStreams] = useState<Map<string, MediaStream>>(new Map());
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [audioVolume, setAudioVolume] = useState<number>(0);

  // Modals
  const [isDossierOpen, setIsDossierOpen] = useState<boolean>(false);
  const [isCopilotOpen, setIsCopilotOpen] = useState<boolean>(false);
  const [isHowToRunOpen, setIsHowToRunOpen] = useState<boolean>(false);

  // Version counter to ignore local echo loops
  const localFileVersions = useRef<Map<string, number>>(new Map());

  // Connect to WebSocket and WebRTC on mount
  useEffect(() => {
    // 1. WebRTC setup
    webrtcManager.init(
      currentUser.id,
      (streams) => {
        setRemoteStreams(new Map(streams));
      },
      (speaking, vol) => {
        setIsSpeaking(speaking);
        setAudioVolume(vol);
      }
    );

    // Start local media stream (camera/mic or simulated)
    webrtcManager.startLocalMedia();

    // 2. WebSocket setup
    socketService.connect(roomId, currentUser, () => {
      setIsConnected(true);
    });

    const offConn = socketService.on('connection-status', (data) => {
      setIsConnected(data.connected);
    });

    const offLatency = socketService.on('latency-update', (data) => {
      setLatencyMs(data.latencyMs);
    });

    // Room Initialized
    const offInit = socketService.on('room-init', (data) => {
      const room: RoomState = data.roomState;
      if (room.files && room.files.length > 0) {
        setFiles(room.files);
        setActiveFileId(room.activeFileId || room.files[0].id);
      }
      if (room.users) {
        setUsers(room.users);
      }
      if (room.messages) {
        setMessages(room.messages);
      }
      if (room.challenge) {
        setActiveChallenge(room.challenge);
      }
      if (room.lastExecution) {
        setExecutionResult(room.lastExecution);
      }

      // WebRTC initiation is handled asymmetrically by existing peers upon receiving user-joined
    });

    // User Joined
    const offUserJoined = socketService.on('user-joined', (data) => {
      setUsers(data.users);
      // Initiate WebRTC call with newly joined user
      if (data.user.id !== currentUser.id) {
        webrtcManager.callUser(data.user.id);
      }
    });

    // User Left
    const offUserLeft = socketService.on('user-left', (data) => {
      setUsers(data.users);
      webrtcManager.removePeer(data.userId);
      setRemoteCursors((prev) => prev.filter((c) => c.userId !== data.userId));
    });

    // Remote User Media State
    const offMediaState = socketService.on('user-media-state', (data) => {
      setUsers((prev) =>
        prev.map((u) => (u.id === data.userId ? { ...u, ...data } : u))
      );
    });

    // Remote Code Change
    const offCodeChange = socketService.on('code-change', (data) => {
      const { fileId, content, version } = data;
      setFiles((prev) =>
        prev.map((f) => (f.id === fileId ? { ...f, content, updatedAt: Date.now() } : f))
      );
    });

    // Remote Cursor Update
    const offCursor = socketService.on('cursor-update', (data) => {
      const { cursor } = data;
      setRemoteCursors((prev) => {
        const filtered = prev.filter((c) => c.userId !== cursor.userId);
        return [...filtered, cursor];
      });
    });

    // File Actions
    const offFileCreate = socketService.on('file-create', (data) => {
      setFiles((prev) => {
        if (prev.some((f) => f.id === data.file.id)) return prev;
        return [...prev, data.file];
      });
    });

    const offFileRename = socketService.on('file-rename', (data) => {
      setFiles((prev) =>
        prev.map((f) => (f.id === data.fileId ? { ...f, name: data.newName } : f))
      );
    });

    const offFileDelete = socketService.on('file-delete', (data) => {
      setFiles((prev) => prev.filter((f) => f.id !== data.fileId));
      if (data.activeFileId) {
        setActiveFileId(data.activeFileId);
      }
    });

    const offFileSelect = socketService.on('file-select', (data) => {
      setActiveFileId(data.fileId);
    });

    // Chat Message Broadcast
    const offChat = socketService.on('chat-broadcast', (data) => {
      setMessages((prev) => {
        if (prev.some((m) => m.id === data.message.id)) {
          return prev;
        }
        return [...prev, data.message];
      });
    });

    // Execution Result Broadcast
    const offExecution = socketService.on('execute-broadcast', (data) => {
      setExecutionResult(data.result);
      setIsRunning(false);
    });

    // Load Challenge
    const offChallenge = socketService.on('load-challenge', (data) => {
      setActiveChallenge(data.challenge);
      if (data.files) setFiles(data.files);
      if (data.activeFileId) setActiveFileId(data.activeFileId);
    });

    return () => {
      offConn();
      offLatency();
      offInit();
      offUserJoined();
      offUserLeft();
      offMediaState();
      offCodeChange();
      offCursor();
      offFileCreate();
      offFileRename();
      offFileDelete();
      offFileSelect();
      offChat();
      offExecution();
      offChallenge();
      webrtcManager.cleanup();
      socketService.disconnect();
    };
  }, [roomId, currentUser.id]);

  // Code editor actions
  const handleCodeChange = (fileId: string, content: string) => {
    // Optimistic local update
    setFiles((prev) =>
      prev.map((f) => (f.id === fileId ? { ...f, content, updatedAt: Date.now() } : f))
    );

    const nextVer = (localFileVersions.current.get(fileId) || 0) + 1;
    localFileVersions.current.set(fileId, nextVer);

    // Broadcast to peers
    socketService.sendCodeChange(fileId, content, nextVer);
  };

  const handleCursorChange = (fileId: string, line: number, col: number) => {
    socketService.sendCursorMove({
      userId: currentUser.id,
      userName: currentUser.name,
      userColor: currentUser.color,
      fileId,
      line,
      col,
    });
  };

  const handleCreateFile = (name: string, language: CodeFile['language']) => {
    const newFile: CodeFile = {
      id: `f-${Date.now()}`,
      name,
      language,
      content: language === 'typescript' || language === 'javascript'
        ? `// ${name}\nconsole.log("Hello from ${name}");\n`
        : language === 'html'
        ? `<!DOCTYPE html>\n<html>\n<body>\n  <h1>${name}</h1>\n</body>\n</html>\n`
        : '',
      updatedAt: Date.now(),
    };

    setFiles((prev) => [...prev, newFile]);
    setActiveFileId(newFile.id);
    socketService.sendFileCreate(newFile);
  };

  const handleRenameFile = (fileId: string, newName: string) => {
    setFiles((prev) =>
      prev.map((f) => (f.id === fileId ? { ...f, name: newName } : f))
    );
    socketService.sendFileRename(fileId, newName);
  };

  const handleDeleteFile = (fileId: string) => {
    const remaining = files.filter((f) => f.id !== fileId);
    setFiles(remaining);
    if (activeFileId === fileId && remaining.length > 0) {
      setActiveFileId(remaining[0].id);
    }
    socketService.sendFileDelete(fileId);
  };

  const handleSelectFile = (fileId: string) => {
    setActiveFileId(fileId);
    socketService.sendFileSelect(fileId);
  };

  // Run Code execution
  const handleRunCode = () => {
    const activeFile = files.find((f) => f.id === activeFileId) || files[0];
    if (!activeFile) return;

    setIsRunning(true);

    setTimeout(() => {
      const result = runSandboxedCode(
        activeFile.content,
        activeFile.language,
        currentUser.id,
        currentUser.name
      );

      setExecutionResult(result);
      setIsRunning(false);

      // Broadcast collaborative execution to all peers in the room
      socketService.broadcastExecution(result);
    }, 50);
  };

  // Chat message send
  const handleSendMessage = (content: string) => {
    const msg: ChatMessage = {
      id: `msg-${Date.now()}-${Math.random()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userColor: currentUser.color,
      content,
      timestamp: Date.now(),
      type: 'text',
    };

    // Optimistic append
    setMessages((prev) => [...prev, msg]);
    socketService.sendChatMessage(msg);
  };

  // Load a challenge preset
  const handleSelectChallenge = (challenge: ChallengePreset) => {
    setActiveChallenge(challenge);
    setFiles(challenge.files);
    setActiveFileId(challenge.files[0]?.id || '');
    socketService.loadChallenge(challenge);
  };

  // Open Peer Tab helper for evaluating real-time collaboration
  const handleOpenPeerTab = () => {
    const peerUrl = `${window.location.origin}/?room=${encodeURIComponent(roomId)}&peer=true&name=Alex%20(Peer)`;
    window.open(peerUrl, '_blank', 'width=1280,height=800');
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-[#0d1117] text-[#e6edf3] overflow-hidden select-none">
      {/* Top Navigation */}
      <Navbar
        roomId={roomId}
        currentUser={currentUser}
        users={users}
        latencyMs={latencyMs}
        isConnected={isConnected}
        onRunCode={handleRunCode}
        isRunning={isRunning}
        onOpenDossier={() => setIsDossierOpen(true)}
        onOpenPeerTab={handleOpenPeerTab}
        onSelectChallenge={handleSelectChallenge}
        activeChallenge={activeChallenge}
        onOpenCopilot={() => setIsCopilotOpen(true)}
        onOpenHowToRun={() => setIsHowToRunOpen(true)}
      />

      {/* Main Workspace Grid */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Side: Real-Time Chat & Activity Log */}
        <ChatPanel
          messages={messages}
          onSendMessage={handleSendMessage}
          currentUser={currentUser}
          onOpenPeerTab={handleOpenPeerTab}
          onOpenHowToRun={() => setIsHowToRunOpen(true)}
        />

        {/* Center: Collaborative Editor & Terminal Runner */}
        <div className="flex-1 flex flex-col h-full overflow-hidden">
          {/* Code Editor */}
          <CodeEditor
            files={files}
            activeFileId={activeFileId}
            onSelectFile={handleSelectFile}
            onCodeChange={handleCodeChange}
            onCreateFile={handleCreateFile}
            onRenameFile={handleRenameFile}
            onDeleteFile={handleDeleteFile}
            remoteCursors={remoteCursors}
            onCursorChange={handleCursorChange}
            currentUser={currentUser}
            onRunCode={handleRunCode}
          />

          {/* Bottom Execution Terminal & DOM Preview */}
          <CodeRunner
            executionResult={executionResult}
            onClearOutput={() => setExecutionResult(null)}
            activeChallenge={activeChallenge}
            files={files}
            onRunCode={handleRunCode}
            isRunning={isRunning}
          />
        </div>

        {/* Right Side: Integrated WebRTC Video & Audio Conferencing */}
        <VideoConferencing
          currentUser={currentUser}
          users={users}
          remoteStreams={remoteStreams}
          isSpeaking={isSpeaking}
          audioVolume={audioVolume}
        />
      </div>

      {/* Internship Project Dossier & Architecture Modal */}
      <InternshipDossierModal
        isOpen={isDossierOpen}
        onClose={() => setIsDossierOpen(false)}
        roomId={roomId}
        currentUser={currentUser}
        users={users}
        latencyMs={latencyMs}
        onOpenPeerTab={handleOpenPeerTab}
      />

      {/* Gemini Generative AI Copilot Modal */}
      <GenAICopilotModal
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
        activeFile={files.find((f) => f.id === activeFileId) || files[0] || null}
        onShareToChat={handleSendMessage}
        currentUser={currentUser}
      />

      {/* How to Run & Video Guide Modal */}
      <HowToRunModal
        isOpen={isHowToRunOpen}
        onClose={() => setIsHowToRunOpen(false)}
        onOpenPeerTab={handleOpenPeerTab}
        onSendTestMessage={handleSendMessage}
      />
    </div>
  );
}
