import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { RoomState, User, CodeFile, ChatMessage, RemoteCursor, ExecutionResult } from './src/types';
import { STARTER_FILES } from './src/utils/challengePresets';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

const PORT = 3000;

// Initialize server-side Gemini client with user's key
const apiKey = process.env.GEMINI_API_KEY || 'AQ.Ab8RN6JJ6bFu3lKOlpZH9iNsfx3pH_XzAK9lvIWurivoHCw15g';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Robust model cascade helper: attempts gemini-3.1-flash-lite, gemini-3.8-flash, gemini-flash-latest
async function generateWithGemini(contents: string, systemInstruction?: string): Promise<string> {
  const models = ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-flash-latest'];
  let lastErr: any = null;
  for (const model of models) {
    try {
      const res = await ai.models.generateContent({
        model,
        contents,
        config: systemInstruction ? { systemInstruction } : undefined,
      });
      if (res.text) return res.text;
    } catch (err: any) {
      console.warn(`[Gemini SDK] Model ${model} returned: ${err?.message || err}. Cascading...`);
      lastErr = err;
    }
  }
  throw lastErr || new Error('All Gemini model fallbacks exhausted');
}

// In-memory room store
const rooms = new Map<string, RoomState>();

interface ClientMeta {
  roomId: string;
  userId: string;
  user: User;
}

const clientMap = new Map<WebSocket, ClientMeta>();

function getOrCreateRoom(roomId: string, roomName?: string): RoomState {
  if (!rooms.has(roomId)) {
    const newRoom: RoomState = {
      roomId,
      name: roomName || `Room-${roomId.slice(0, 6)}`,
      files: JSON.parse(JSON.stringify(STARTER_FILES)),
      activeFileId: STARTER_FILES[0].id,
      users: [],
      messages: [
        {
          id: 'welcome-msg',
          userId: 'system',
          userName: 'SyncCode Bot',
          userColor: '#38bdf8',
          content: '👋 Welcome to SyncCode GenAI Studio (MCA Generative AI & ML Edition)! Collaborate in real-time on Transformer Attention, Vector RAG Search, and LoRA PEFT algorithms with integrated WebRTC video and Gemini Copilot.',
          timestamp: Date.now(),
          type: 'system',
        },
      ],
      challenge: null,
      lastExecution: null,
    };
    rooms.set(roomId, newRoom);
  }
  return rooms.get(roomId)!;
}

function broadcastToRoom(roomId: string, message: any, excludeWs?: WebSocket) {
  const payload = JSON.stringify(message);
  for (const [ws, meta] of clientMap.entries()) {
    if (meta.roomId === roomId && ws !== excludeWs && ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
    }
  }
}

function sendToUser(roomId: string, targetUserId: string, message: any) {
  const payload = JSON.stringify(message);
  for (const [ws, meta] of clientMap.entries()) {
    if (meta.roomId === roomId && meta.userId === targetUserId && ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
      break;
    }
  }
}

wss.on('connection', (ws: WebSocket) => {
  ws.on('message', (data: string) => {
    try {
      const msg = JSON.parse(data.toString());
      const { type, payload } = msg;

      switch (type) {
        case 'join-room': {
          const { roomId, user } = payload;
          const room = getOrCreateRoom(roomId);

          clientMap.set(ws, { roomId, userId: user.id, user });

          // Update users in room
          const existingUserIndex = room.users.findIndex(u => u.id === user.id);
          if (existingUserIndex >= 0) {
            room.users[existingUserIndex] = user;
          } else {
            room.users.push(user);
          }

          // Send current state to joiner
          ws.send(JSON.stringify({
            type: 'room-init',
            payload: {
              roomState: room,
              yourId: user.id,
            },
          }));

          // Broadcast to other users in room
          broadcastToRoom(roomId, {
            type: 'user-joined',
            payload: {
              user,
              users: room.users,
            },
          }, ws);

          // System message
          const joinMsg: ChatMessage = {
            id: `sys-${Date.now()}-${Math.random()}`,
            userId: 'system',
            userName: 'System',
            userColor: '#10b981',
            content: `${user.name} joined the collaboration session.`,
            timestamp: Date.now(),
            type: 'system',
          };
          room.messages.push(joinMsg);
          broadcastToRoom(roomId, { type: 'chat-broadcast', payload: { message: joinMsg } });
          break;
        }

        case 'webrtc-signal': {
          // payload: { targetUserId, senderId, signal }
          const { targetUserId, senderId, signal } = payload;
          const meta = clientMap.get(ws);
          if (meta) {
            sendToUser(meta.roomId, targetUserId, {
              type: 'webrtc-signal',
              payload: {
                targetUserId,
                senderId: senderId || meta.userId,
                signal,
              },
            });
          }
          break;
        }

        case 'webrtc-state': {
          const meta = clientMap.get(ws);
          if (meta) {
            const room = rooms.get(meta.roomId);
            if (room) {
              const u = room.users.find(usr => usr.id === meta.userId);
              if (u) {
                u.isAudioOn = payload.isAudioOn;
                u.isVideoOn = payload.isVideoOn;
                u.isScreenSharing = payload.isScreenSharing;
                u.isSpeaking = payload.isSpeaking ?? u.isSpeaking;
              }
            }
            broadcastToRoom(meta.roomId, {
              type: 'user-media-state',
              payload: {
                userId: meta.userId,
                ...payload,
              },
            }, ws);
          }
          break;
        }

        case 'code-change': {
          const meta = clientMap.get(ws);
          if (meta) {
            const { fileId, content, version } = payload;
            const room = rooms.get(meta.roomId);
            if (room) {
              const file = room.files.find(f => f.id === fileId);
              if (file) {
                file.content = content;
                file.updatedAt = Date.now();
              }
            }
            broadcastToRoom(meta.roomId, {
              type: 'code-change',
              payload: {
                fileId,
                content,
                version,
                senderId: meta.userId,
              },
            }, ws);
          }
          break;
        }

        case 'cursor-move': {
          const meta = clientMap.get(ws);
          if (meta) {
            broadcastToRoom(meta.roomId, {
              type: 'cursor-update',
              payload: {
                cursor: payload.cursor,
              },
            }, ws);
          }
          break;
        }

        case 'file-create': {
          const meta = clientMap.get(ws);
          if (meta) {
            const room = rooms.get(meta.roomId);
            if (room) {
              room.files.push(payload.file);
            }
            broadcastToRoom(meta.roomId, {
              type: 'file-create',
              payload: {
                file: payload.file,
                senderId: meta.userId,
              },
            });
          }
          break;
        }

        case 'file-rename': {
          const meta = clientMap.get(ws);
          if (meta) {
            const { fileId, newName } = payload;
            const room = rooms.get(meta.roomId);
            if (room) {
              const f = room.files.find(x => x.id === fileId);
              if (f) f.name = newName;
            }
            broadcastToRoom(meta.roomId, {
              type: 'file-rename',
              payload: { fileId, newName },
            });
          }
          break;
        }

        case 'file-delete': {
          const meta = clientMap.get(ws);
          if (meta) {
            const { fileId } = payload;
            const room = rooms.get(meta.roomId);
            if (room) {
              room.files = room.files.filter(f => f.id !== fileId);
              if (room.activeFileId === fileId && room.files.length > 0) {
                room.activeFileId = room.files[0].id;
              }
            }
            broadcastToRoom(meta.roomId, {
              type: 'file-delete',
              payload: { fileId, activeFileId: room?.activeFileId },
            });
          }
          break;
        }

        case 'file-select': {
          const meta = clientMap.get(ws);
          if (meta) {
            const room = rooms.get(meta.roomId);
            if (room) {
              room.activeFileId = payload.fileId;
            }
            broadcastToRoom(meta.roomId, {
              type: 'file-select',
              payload: { fileId: payload.fileId, senderId: meta.userId },
            }, ws);
          }
          break;
        }

        case 'chat-send': {
          const meta = clientMap.get(ws);
          if (meta) {
            const room = rooms.get(meta.roomId);
            if (room) {
              room.messages.push(payload.message);
              if (room.messages.length > 200) {
                room.messages.shift();
              }
            }
            broadcastToRoom(meta.roomId, {
              type: 'chat-broadcast',
              payload: { message: payload.message },
            });

            // Check for @ai or @gemini mention
            const textContent = (payload.message.content || '').trim();
            if (textContent.toLowerCase().startsWith('@ai') || textContent.toLowerCase().startsWith('@gemini')) {
              const cleanPrompt = textContent.replace(/^@(ai|gemini)\s*/i, '') || 'Hello! How can I help with this Generative AI workspace?';
              generateWithGemini(
                cleanPrompt,
                'You are Gemini Copilot, an AI pair programmer participating in a collaborative code chat for an MCA Generative AI student. Keep your response concise (under 3-4 sentences or quick code snippet), insightful, and mathematically clear.'
              ).then((aiText) => {
                const aiReply: ChatMessage = {
                  id: `ai-${Date.now()}-${Math.random()}`,
                  userId: 'ai-copilot',
                  userName: 'Gemini Copilot 🤖',
                  userColor: '#38bdf8',
                  content: aiText,
                  timestamp: Date.now(),
                  type: 'text',
                };
                if (room) room.messages.push(aiReply);
                broadcastToRoom(meta.roomId, {
                  type: 'chat-broadcast',
                  payload: { message: aiReply },
                });
              }).catch((err) => {
                console.warn('AI chat error:', err);
              });
            }
          }
          break;
        }

        case 'execute-broadcast': {
          const meta = clientMap.get(ws);
          if (meta) {
            const room = rooms.get(meta.roomId);
            if (room) {
              room.lastExecution = payload.result;
            }
            broadcastToRoom(meta.roomId, {
              type: 'execute-broadcast',
              payload: { result: payload.result },
            });
          }
          break;
        }

        case 'load-challenge': {
          const meta = clientMap.get(ws);
          if (meta) {
            const room = rooms.get(meta.roomId);
            if (room) {
              room.challenge = payload.challenge;
              room.files = JSON.parse(JSON.stringify(payload.challenge.files));
              room.activeFileId = room.files[0]?.id || '';
            }
            broadcastToRoom(meta.roomId, {
              type: 'load-challenge',
              payload: {
                challenge: payload.challenge,
                files: room?.files,
                activeFileId: room?.activeFileId,
              },
            });
          }
          break;
        }

        case 'ping': {
          ws.send(JSON.stringify({ type: 'pong', payload: { clientTimestamp: payload.timestamp, serverTimestamp: Date.now() } }));
          break;
        }

        default:
          break;
      }
    } catch (err) {
      console.error('Error handling WebSocket message:', err);
    }
  });

  ws.on('close', () => {
    const meta = clientMap.get(ws);
    if (meta) {
      const { roomId, userId, user } = meta;
      clientMap.delete(ws);
      const room = rooms.get(roomId);
      if (room) {
        room.users = room.users.filter(u => u.id !== userId);

        broadcastToRoom(roomId, {
          type: 'user-left',
          payload: {
            userId,
            userName: user.name,
            users: room.users,
          },
        });

        const leaveMsg: ChatMessage = {
          id: `sys-${Date.now()}-${Math.random()}`,
          userId: 'system',
          userName: 'System',
          userColor: '#f43f5e',
          content: `${user.name} left the room.`,
          timestamp: Date.now(),
          type: 'system',
        };
        room.messages.push(leaveMsg);
        broadcastToRoom(roomId, { type: 'chat-broadcast', payload: { message: leaveMsg } });
      }
    }
  });
});

// Middleware & routing
app.use(express.json());

// API route for room diagnostics or health
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    roomsActive: rooms.size,
    clientsConnected: clientMap.size,
    timestamp: Date.now(),
  });
});

// Server-side Gemini Generative AI Copilot for MCA GenAI Engineering
app.post('/api/ai/copilot', async (req, res) => {
  try {
    const { action, code, activeFile, prompt } = req.body;

    let userPrompt = '';
    if (action === 'explain') {
      userPrompt = `Please explain the mathematical foundation, algorithmic mechanics, and GenAI concepts of this code from file "${activeFile || 'model.ts'}":\n\n\`\`\`\n${code}\n\`\`\`\nProvide clear mathematical equations (e.g., for Scaled Dot-Product Attention, Cosine Similarity, or LoRA Matrix decomposition) and explain why this architecture is foundational in LLMs and Generative AI. Format nicely with markdown.`;
    } else if (action === 'optimize') {
      userPrompt = `Please analyze this AI/ML and Generative AI code from "${activeFile || 'model.ts'}" for tensor performance, vectorization, computational efficiency (Big-O), and memory footprint in LLM contexts:\n\n\`\`\`\n${code}\n\`\`\`\nSuggest optimizations with clean code and explanations.`;
    } else if (action === 'debug') {
      userPrompt = `Audit this Generative AI code for potential bugs, gradient vanishing/explosion, numerical instability (e.g. missing max-subtraction in softmax), or prompt injection vulnerabilities:\n\n\`\`\`\n${code}\n\`\`\``;
    } else if (action === 'generate') {
      userPrompt = `Generate a production-ready Generative AI module or PyTorch/TypeScript implementation for: ${prompt || 'Multi-Head Attention Layer'}.\nCurrent active code context:\n\`\`\`\n${code}\n\`\`\``;
    } else {
      userPrompt = `${prompt}\n\nCurrent file context:\n\`\`\`\n${code}\n\`\`\``;
    }

    const aiText = await generateWithGemini(
      userPrompt,
      'You are an expert AI/ML and Generative AI Pair Programmer assisting an MCA Generative AI student. Deliver rigorous, clear explanations with mathematical notation and production-grade code. Keep answers focused, insightful, and formatted with clean markdown.'
    );

    res.json({
      text: aiText,
      action,
      timestamp: Date.now(),
    });
  } catch (error: any) {
    console.error('Gemini Copilot Error:', error);
    res.status(500).json({
      error: error?.message || 'Failed to communicate with GenAI Copilot',
      fallbackText: 'Unable to reach Gemini API. Ensure GEMINI_API_KEY is configured in AI Studio Secrets.',
    });
  }
});

// Vite or Static Serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`SyncCode Studio running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
