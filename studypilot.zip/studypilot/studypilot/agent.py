"""A minimal ReAct-style agent loop, written from scratch (no frameworks).

Loop:  LLM -> (JSON action) -> run tool -> OBSERVATION -> LLM -> ... -> {"final": ...}

Why JSON-in-text instead of provider-specific function calling?
It works with ANY LLM, and every step of the loop is visible for learning,
debugging and evaluation.
"""
from __future__ import annotations

import datetime as dt
import json
from dataclasses import dataclass, field
from typing import Any

from .llm import LLM
from .tools import Tool

SYSTEM_TEMPLATE = """You are StudyPilot, an autonomous study assistant for college students.
Today's date is {today}.

You can use tools to look things up and take actions. On EVERY turn reply with
exactly ONE JSON object and nothing else, in one of these two forms:

1) Call a tool:
   {{"thought": "<short reasoning>", "tool": "<tool name>", "args": {{...}}}}
2) Give the final answer to the student (when you have what you need):
   {{"final": "<helpful answer, plain text>"}}

Rules:
- After a tool call you will receive a line starting with OBSERVATION. Use it.
- Prefer the student's own notes (search_notes) over your general knowledge, and say when
  an answer came from their notes.
- Never invent tool results. If a tool returns an error, fix the arguments or explain the problem.
- Ask the student a question (via "final") if a required detail such as the exam date is missing.
- Use at most {max_steps} tool calls.

Available tools:
{tool_docs}
"""


def render_tool_docs(tools: dict[str, Tool]) -> str:
    lines = []
    for t in tools.values():
        params = ", ".join(f"{k}: {v}" for k, v in t.params.items()) or "no arguments"
        lines.append(f"- {t.name}({params}) -- {t.description}")
    return "\n".join(lines)


def parse_action(raw: str) -> dict[str, Any] | None:
    """Pull the first JSON object out of the model text (handles ```json fences / chatter)."""
    dec = json.JSONDecoder()
    for i, ch in enumerate(raw):
        if ch == "{":
            try:
                obj, _ = dec.raw_decode(raw[i:])
            except json.JSONDecodeError:
                continue
            if isinstance(obj, dict) and ("final" in obj or "tool" in obj):
                return obj
    return None


@dataclass
class Step:
    thought: str
    tool: str
    args: dict
    observation: str


@dataclass
class AgentResult:
    answer: str
    steps: list[Step] = field(default_factory=list)
    hit_step_limit: bool = False


class Agent:
    def __init__(self, llm: LLM, tools: dict[str, Tool], max_steps: int = 8, today: dt.date | None = None):
        self.llm = llm
        self.tools = tools
        self.max_steps = max_steps
        self.system = SYSTEM_TEMPLATE.format(
            today=(today or dt.date.today()).isoformat(),
            max_steps=max_steps,
            tool_docs=render_tool_docs(tools),
        )
        self.messages: list[dict] = []  # conversation memory across turns

    def run(self, user_message: str) -> AgentResult:
        self.messages.append({"role": "user", "content": user_message})
        steps: list[Step] = []
        bad_format = 0

        while len(steps) < self.max_steps:
            raw = self.llm.complete(self.system, self.messages)
            action = parse_action(raw)

            if action is None:  # model broke the format -> nudge it, but don't loop forever
                bad_format += 1
                if bad_format > 2:
                    return self._finish(raw.strip() or "Sorry, I could not produce an answer.", steps)
                self.messages += [
                    {"role": "assistant", "content": raw},
                    {"role": "user", "content": 'Invalid format. Reply with exactly one JSON object: {"tool":..., "args":...} or {"final":...}.'},
                ]
                continue

            if "final" in action:
                return self._finish(str(action["final"]), steps)

            name, args = str(action.get("tool", "")), action.get("args") or {}
            observation = self._execute(name, args)
            steps.append(Step(str(action.get("thought", "")), name, args, observation))
            self.messages += [
                {"role": "assistant", "content": raw},
                {"role": "user", "content": f"OBSERVATION: {observation}"},
            ]

        return self._finish("I reached my step limit before finishing. Here is what I found so far.", steps, limit=True)

    def _execute(self, name: str, args: Any) -> str:
        tool = self.tools.get(name)
        if tool is None:
            return json.dumps({"error": f"unknown tool '{name}'", "available": list(self.tools)})
        if not isinstance(args, dict):
            return json.dumps({"error": "args must be a JSON object"})
        try:
            return json.dumps(tool.fn(**args), default=str)[:4000]
        except TypeError as e:  # wrong / missing arguments
            return json.dumps({"error": f"bad arguments: {e}", "expected": tool.params})
        except Exception as e:  # tool-level failure: report to the model so it can recover
            return json.dumps({"error": f"{type(e).__name__}: {e}"})

    def _finish(self, answer: str, steps: list[Step], limit: bool = False) -> AgentResult:
        self.messages.append({"role": "assistant", "content": json.dumps({"final": answer})})
        return AgentResult(answer=answer, steps=steps, hit_step_limit=limit)
