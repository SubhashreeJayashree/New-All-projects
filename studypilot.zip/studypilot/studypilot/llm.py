"""LLM provider adapters. The agent only needs `complete(system, messages) -> str`.

`messages` is a list of {"role": "user"|"assistant", "content": str}.
Add a new provider by writing a class with that one method.
"""
from __future__ import annotations

import os
from typing import Protocol


class LLM(Protocol):
    def complete(self, system: str, messages: list[dict]) -> str: ...


class GeminiLLM:
    def __init__(self, model: str | None = None):
        from google import genai  # pip install google-genai

        self._types = __import__("google.genai.types", fromlist=["types"])
        self.client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
        self.model = model or os.getenv("STUDYPILOT_MODEL", "gemini-2.5-flash")

    def complete(self, system: str, messages: list[dict]) -> str:
        t = self._types
        contents = [
            t.Content(role="model" if m["role"] == "assistant" else "user", parts=[t.Part(text=m["content"])])
            for m in messages
        ]
        resp = self.client.models.generate_content(
            model=self.model,
            contents=contents,
            config=t.GenerateContentConfig(system_instruction=system, temperature=0.2),
        )
        return resp.text or ""


class AnthropicLLM:
    def __init__(self, model: str | None = None):
        import anthropic  # pip install anthropic

        self.client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY
        self.model = model or os.getenv("STUDYPILOT_MODEL", "claude-sonnet-5-5")

    def complete(self, system: str, messages: list[dict]) -> str:
        resp = self.client.messages.create(
            model=self.model, max_tokens=1500, temperature=0.2, system=system, messages=messages
        )
        return "".join(b.text for b in resp.content if b.type == "text")


class MockLLM:
    """Returns pre-scripted replies. Used for offline demo and unit tests."""

    def __init__(self, script: list[str]):
        self.script = list(script)
        self.calls: list[list[dict]] = []

    def complete(self, system: str, messages: list[dict]) -> str:
        self.calls.append(list(messages))
        return self.script.pop(0) if self.script else '{"final": "(mock script finished)"}'


def get_llm(provider: str) -> LLM:
    if provider == "gemini":
        return GeminiLLM()
    if provider == "anthropic":
        return AnthropicLLM()
    raise ValueError(f"Unknown provider '{provider}'. Use gemini | anthropic (or --demo).")
