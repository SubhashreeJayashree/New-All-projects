"""SQLite persistence: study plans, quiz results and flashcards."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any


class Store:
    def __init__(self, path: str | Path = "data/studypilot.db"):
        if str(path) != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(path))
        self.conn.row_factory = sqlite3.Row
        self._create()

    def _create(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS plans(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created TEXT, exam_date TEXT, plan_json TEXT);
            CREATE TABLE IF NOT EXISTS quiz_results(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                day TEXT, topic TEXT, score INTEGER, total INTEGER);
            CREATE TABLE IF NOT EXISTS flashcards(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                front TEXT, back TEXT, topic TEXT,
                ease REAL DEFAULT 2.5, interval INTEGER DEFAULT 0,
                reps INTEGER DEFAULT 0, due TEXT);
            """
        )
        self.conn.commit()

    # ---- plans
    def save_plan(self, created: str, exam_date: str, plan: list[dict]) -> int:
        cur = self.conn.execute(
            "INSERT INTO plans(created, exam_date, plan_json) VALUES (?,?,?)",
            (created, exam_date, json.dumps(plan)),
        )
        self.conn.commit()
        return cur.lastrowid

    def latest_plan(self) -> dict[str, Any] | None:
        row = self.conn.execute("SELECT * FROM plans ORDER BY id DESC LIMIT 1").fetchone()
        if not row:
            return None
        return {"id": row["id"], "exam_date": row["exam_date"], "plan": json.loads(row["plan_json"])}

    # ---- quizzes
    def add_quiz(self, day: str, topic: str, score: int, total: int) -> None:
        self.conn.execute(
            "INSERT INTO quiz_results(day, topic, score, total) VALUES (?,?,?,?)",
            (day, topic, score, total),
        )
        self.conn.commit()

    def quiz_rows(self) -> list[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM quiz_results ORDER BY id").fetchall()

    # ---- flashcards
    def add_card(self, front: str, back: str, topic: str, due: str) -> int:
        cur = self.conn.execute(
            "INSERT INTO flashcards(front, back, topic, due) VALUES (?,?,?,?)",
            (front, back, topic, due),
        )
        self.conn.commit()
        return cur.lastrowid

    def get_card(self, card_id: int) -> sqlite3.Row | None:
        return self.conn.execute("SELECT * FROM flashcards WHERE id=?", (card_id,)).fetchone()

    def update_card(self, card_id: int, ease: float, interval: int, reps: int, due: str) -> None:
        self.conn.execute(
            "UPDATE flashcards SET ease=?, interval=?, reps=?, due=? WHERE id=?",
            (ease, interval, reps, due, card_id),
        )
        self.conn.commit()

    def due_cards(self, today: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM flashcards WHERE due<=? ORDER BY due, id", (today,)
        ).fetchall()
