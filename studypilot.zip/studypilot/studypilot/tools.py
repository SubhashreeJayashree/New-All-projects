"""Tools the agent can call.

Each tool is a plain Python function wrapped in a `Tool` record (name,
description, parameter docs). The agent only sees the name/description/params;
the Toolbox executes them and returns JSON-serialisable results.
"""
from __future__ import annotations

import datetime as dt
import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .store import Store

_TOKEN = re.compile(r"[a-z0-9]+")


def tokenize(text: str) -> list[str]:
    return _TOKEN.findall(text.lower())


@dataclass
class Tool:
    name: str
    description: str
    params: dict[str, str]
    fn: Callable[..., Any]


class NoteIndex:
    """Tiny TF-IDF retriever over paragraphs of .md/.txt notes (no dependencies)."""

    def __init__(self, notes_dir: str | Path):
        self.notes_dir = Path(notes_dir)
        self.chunks: list[tuple[str, str]] = []  # (filename, paragraph)
        self._vecs: list[dict[str, float]] = []
        self._idf: dict[str, float] = {}
        self._build()

    def _build(self) -> None:
        for p in sorted(self.notes_dir.glob("*")):
            if p.suffix.lower() not in {".md", ".txt"}:
                continue
            heading = ""
            for para in re.split(r"\n\s*\n", p.read_text(encoding="utf-8")):
                para = para.strip()
                if para.startswith("#") and "\n" not in para:
                    heading = para.lstrip("# ").strip()  # attach heading to the next paragraph
                    continue
                if len(para) > 20:
                    self.chunks.append((p.name, f"[{heading}] {para}" if heading else para))
                    heading = ""
        n = len(self.chunks)
        df: Counter = Counter()
        for _, para in self.chunks:
            df.update(set(tokenize(para)))
        self._idf = {t: math.log((1 + n) / (1 + c)) + 1 for t, c in df.items()}
        self._vecs = [self._vec(tokenize(para)) for _, para in self.chunks]

    def _vec(self, tokens: list[str]) -> dict[str, float]:
        tf = Counter(tokens)
        v = {t: c * self._idf.get(t, 0.0) for t, c in tf.items()}
        norm = math.sqrt(sum(x * x for x in v.values())) or 1.0
        return {t: x / norm for t, x in v.items()}

    def search(self, query: str, top_k: int = 3) -> list[dict[str, Any]]:
        q = self._vec(tokenize(query))
        scored = []
        for (fname, para), vec in zip(self.chunks, self._vecs):
            s = sum(w * vec.get(t, 0.0) for t, w in q.items())
            if s > 0:
                scored.append((s, fname, para))
        scored.sort(reverse=True)
        return [{"file": f, "score": round(s, 3), "text": t} for s, f, t in scored[:top_k]]


def _as_list(value: Any) -> list[str]:
    """LLMs sometimes send 'a, b, c' instead of ['a','b','c']; accept both."""
    if isinstance(value, str):
        return [x.strip() for x in value.split(",") if x.strip()]
    return [str(x).strip() for x in value]


class Toolbox:
    def __init__(
        self,
        store: Store,
        notes_dir: str | Path = "notes",
        out_dir: str | Path = "exports",
        today: dt.date | None = None,
    ):
        self.store = store
        self.notes_dir = Path(notes_dir)
        self.out_dir = Path(out_dir)
        self.today = today or dt.date.today()
        self.index = NoteIndex(self.notes_dir)

    # ------------------------------------------------------------ notes
    def list_notes(self) -> dict:
        files = sorted(p.name for p in self.notes_dir.glob("*") if p.suffix.lower() in {".md", ".txt"})
        return {"files": files}

    def read_note(self, filename: str) -> dict:
        path = (self.notes_dir / filename).resolve()
        if self.notes_dir.resolve() not in path.parents:  # block ../ path tricks
            raise ValueError("filename must be inside the notes folder")
        if not path.exists():
            raise FileNotFoundError(f"{filename} not found")
        return {"file": filename, "content": path.read_text(encoding="utf-8")[:3000]}

    def search_notes(self, query: str, top_k: int = 3) -> dict:
        hits = self.index.search(query, int(top_k))
        return {"query": query, "results": hits} if hits else {"query": query, "results": [], "note": "no match"}

    # ------------------------------------------------------------ planning
    def make_study_plan(
        self,
        topics: Any,
        exam_date: str,
        hours_per_day: float = 2,
        difficulties: Any = None,
    ) -> dict:
        topics = _as_list(topics)
        exam = dt.date.fromisoformat(exam_date)
        study_days = (exam - self.today).days - 1  # last day before exam = revision
        if not topics:
            raise ValueError("topics must not be empty")
        if study_days < len(topics):
            raise ValueError(
                f"Only {max(study_days, 0)} study days before the exam for {len(topics)} topics; "
                "reduce topics or choose a later date."
            )
        diffs = [float(d) for d in _as_list(difficulties)] if difficulties else [3.0] * len(topics)
        if len(diffs) != len(topics):
            raise ValueError("difficulties must have the same length as topics")

        # Largest-remainder allocation: every topic gets >=1 day, harder topics get more.
        days = [1] * len(topics)
        spare = study_days - len(topics)
        total = sum(diffs)
        shares = [spare * d / total for d in diffs]
        for i, s in enumerate(shares):
            days[i] += int(s)
        leftover = study_days - sum(days)
        order = sorted(range(len(topics)), key=lambda i: shares[i] - int(shares[i]), reverse=True)
        for i in order[:leftover]:
            days[i] += 1

        plan = []
        day = self.today  # study starts today; last study day is exam-2, revision is exam-1
        for topic, n in zip(topics, days):
            for k in range(n):
                task = "Learn concepts" if k == 0 else "Practice problems + self-quiz"
                plan.append({"date": day.isoformat(), "topic": topic, "task": task, "hours": float(hours_per_day)})
                day += dt.timedelta(days=1)
        plan.append(
            {
                "date": (exam - dt.timedelta(days=1)).isoformat(),
                "topic": "ALL",
                "task": "Revision + mock test",
                "hours": float(hours_per_day),
            }
        )
        plan_id = self.store.save_plan(self.today.isoformat(), exam_date, plan)
        return {"plan_id": plan_id, "days_per_topic": dict(zip(topics, days)), "plan": plan}

    def export_calendar(self, filename: str = "study_plan.ics") -> dict:
        saved = self.store.latest_plan()
        if not saved:
            raise ValueError("No plan saved yet - call make_study_plan first")
        self.out_dir.mkdir(parents=True, exist_ok=True)
        stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//StudyPilot//EN"]
        for i, item in enumerate(saved["plan"]):
            day = item["date"].replace("-", "")
            lines += [
                "BEGIN:VEVENT",
                f"UID:studypilot-{saved['id']}-{i}@local",
                f"DTSTAMP:{stamp}",
                f"DTSTART;VALUE=DATE:{day}",
                f"SUMMARY:{item['topic']}: {item['task']} ({item['hours']}h)",
                "END:VEVENT",
            ]
        lines.append("END:VCALENDAR")
        safe = Path(filename).name
        path = self.out_dir / safe
        path.write_text("\r\n".join(lines) + "\r\n", encoding="utf-8")
        return {"saved_to": str(path), "events": len(saved["plan"])}

    # ------------------------------------------------------------ progress
    def log_quiz_result(self, topic: str, score: int, total: int) -> dict:
        score, total = int(score), int(total)
        if total <= 0 or not 0 <= score <= total:
            raise ValueError("need 0 <= score <= total and total > 0")
        self.store.add_quiz(self.today.isoformat(), topic, score, total)
        return {"logged": True, "topic": topic, "percent": round(100 * score / total, 1)}

    def get_progress(self) -> dict:
        agg: dict[str, list[int]] = {}
        for r in self.store.quiz_rows():
            a = agg.setdefault(r["topic"], [0, 0])
            a[0] += r["score"]
            a[1] += r["total"]
        topics = {t: round(100 * s / n, 1) for t, (s, n) in agg.items()}
        weak = sorted((t for t, p in topics.items() if p < 60), key=topics.get)
        return {"accuracy_percent": topics, "weak_topics": weak}

    # ------------------------------------------------------------ flashcards (SM-2)
    def add_flashcard(self, front: str, back: str, topic: str = "general") -> dict:
        cid = self.store.add_card(front, back, topic, self.today.isoformat())
        return {"card_id": cid, "due": self.today.isoformat()}

    def review_flashcard(self, card_id: int, quality: int) -> dict:
        """SM-2 spaced repetition. quality: 0 (blackout) .. 5 (perfect)."""
        q = int(quality)
        if not 0 <= q <= 5:
            raise ValueError("quality must be 0-5")
        card = self.store.get_card(int(card_id))
        if card is None:
            raise ValueError(f"card {card_id} not found")
        ease, interval, reps = card["ease"], card["interval"], card["reps"]
        if q < 3:
            reps, interval = 0, 1
        else:
            interval = 1 if reps == 0 else 6 if reps == 1 else round(interval * ease)
            reps += 1
        ease = max(1.3, ease + 0.1 - (5 - q) * (0.08 + (5 - q) * 0.02))
        due = (self.today + dt.timedelta(days=interval)).isoformat()
        self.store.update_card(card["id"], ease, interval, reps, due)
        return {"card_id": card["id"], "next_review": due, "interval_days": interval, "ease": round(ease, 2)}

    def due_flashcards(self) -> dict:
        rows = self.store.due_cards(self.today.isoformat())
        return {"due": [{"card_id": r["id"], "front": r["front"], "topic": r["topic"]} for r in rows]}

    # ------------------------------------------------------------ registry
    def tools(self) -> dict[str, Tool]:
        defs = [
            Tool("list_notes", "List the student's note files.", {}, self.list_notes),
            Tool("read_note", "Read one note file in full.", {"filename": "str"}, self.read_note),
            Tool("search_notes", "Semantic-ish (TF-IDF) search across all notes; returns best paragraphs.",
                 {"query": "str", "top_k": "int, optional (default 3)"}, self.search_notes),
            Tool("make_study_plan",
                 "Build and save a day-by-day plan until the exam. Harder topics get more days; last day is revision.",
                 {"topics": "list[str]", "exam_date": "YYYY-MM-DD", "hours_per_day": "float, optional",
                  "difficulties": "list[1-5], optional, same order as topics"}, self.make_study_plan),
            Tool("export_calendar", "Export the latest saved plan to an .ics calendar file.",
                 {"filename": "str, optional"}, self.export_calendar),
            Tool("log_quiz_result", "Record a quiz score for a topic.",
                 {"topic": "str", "score": "int", "total": "int"}, self.log_quiz_result),
            Tool("get_progress", "Show quiz accuracy per topic and list weak topics (<60%).", {}, self.get_progress),
            Tool("add_flashcard", "Create a flashcard due today.",
                 {"front": "str", "back": "str", "topic": "str, optional"}, self.add_flashcard),
            Tool("review_flashcard", "Record a review (SM-2 spaced repetition) and schedule the next one.",
                 {"card_id": "int", "quality": "int 0-5"}, self.review_flashcard),
            Tool("due_flashcards", "List flashcards due for review today.", {}, self.due_flashcards),
        ]
        return {t.name: t for t in defs}
