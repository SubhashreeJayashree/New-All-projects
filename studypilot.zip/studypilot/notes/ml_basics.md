# Machine Learning Basics

Supervised learning trains a model on labelled examples. Classification predicts a category; regression predicts a number.

Overfitting happens when a model memorises training data and performs poorly on unseen data. Remedies include more data, regularisation, simpler models and cross-validation.

Precision is TP / (TP + FP). Recall is TP / (TP + FN). F1 is the harmonic mean of precision and recall.

Gradient descent updates parameters in the direction that reduces the loss; the learning rate controls the step size.

# Generative AI Basics

A large language model (LLM) predicts the next token. Retrieval-augmented generation (RAG) retrieves relevant documents and adds them to the prompt so answers are grounded in real sources.

An AI agent runs a loop: the LLM chooses a tool, the program executes it, and the observation is fed back until the task is done.
