# DBMS - Normalization

Normalization organises a relational schema to reduce redundancy and avoid update, insert and delete anomalies.

First Normal Form (1NF) requires atomic column values: no repeating groups or multi-valued attributes in a single cell.

Second Normal Form (2NF) requires 1NF and that no non-key attribute depends on only part of a composite primary key (no partial dependency).

Third Normal Form (3NF) requires 2NF and no transitive dependency: a non-key attribute must not depend on another non-key attribute.

BCNF is stricter than 3NF: for every functional dependency X -> Y, X must be a superkey.

# DBMS - Transactions

A transaction is a logical unit of work. ACID stands for Atomicity, Consistency, Isolation and Durability.

Isolation anomalies include dirty read, non-repeatable read and phantom read. Isolation levels (read uncommitted, read committed, repeatable read, serializable) trade correctness for concurrency.
