"""StudyPilot CLI.

  python main.py --demo                        # offline walkthrough, no API key needed
  python main.py --provider gemini             # interactive chat
  python main.py --provider gemini "Plan my DBMS exam on 2026-11-20, I'm weak in normalization"
  add --trace to see every tool call the agent makes
"""
from __future__ import annotations

import argparse
import datetime as dt
import json

from studypilot import Agent, Store, Toolbox
from studypilot.llm import MockLLM, get_llm


def demo_script(exam: str) -> list[str]:
    j = json.dumps
    return [
        j({"thought": "See what notes exist", "tool": "list_notes", "args": {}}),
        j({"thought": "Find the student's notes on normalization", "tool": "search_notes", "args": {"query": "normalization 3NF"}}),
        j({"thought": "Weak in DBMS topics -> give them higher difficulty", "tool": "make_study_plan",
           "args": {"topics": ["Normalization", "Transactions", "SQL joins"], "exam_date": exam,
                    "hours_per_day": 2, "difficulties": [5, 3, 2]}}),
        j({"thought": "Save it to their calendar", "tool": "export_calendar", "args": {"filename": "dbms_plan.ics"}}),
        j({"thought": "Create a flashcard from the notes", "tool": "add_flashcard",
           "args": {"front": "What does 3NF forbid?", "back": "Transitive dependencies on the key", "topic": "Normalization"}}),
        j({"final": "I built a day-by-day plan (more days for Normalization), exported it to exports/dbms_plan.ics "
                    "and added a flashcard from your notes. Run with a real provider to chat freely."}),
    ]


def print_trace(result) -> None:
    for i, s in enumerate(result.steps, 1):
        print(f"  [{i}] {s.tool}({json.dumps(s.args)})")
        if s.thought:
            print(f"      thought: {s.thought}")
        print(f"      -> {s.observation[:200]}{'...' if len(s.observation) > 200 else ''}")


def main() -> None:
    ap = argparse.ArgumentParser(description="StudyPilot - agentic study assistant")
    ap.add_argument("prompt", nargs="?", help="one-shot request (omit for interactive chat)")
    ap.add_argument("--provider", default="gemini", choices=["gemini", "anthropic"])
    ap.add_argument("--demo", action="store_true", help="offline scripted run, no API key")
    ap.add_argument("--trace", action="store_true", help="print every tool call")
    ap.add_argument("--notes", default="notes")
    ap.add_argument("--db", default="data/studypilot.db")
    args = ap.parse_args()

    store = Store(":memory:" if args.demo else args.db)
    box = Toolbox(store, notes_dir=args.notes)
    if args.demo:
        exam = (dt.date.today() + dt.timedelta(days=14)).isoformat()
        llm, args.trace = MockLLM(demo_script(exam)), True
        args.prompt = args.prompt or f"Plan my DBMS exam on {exam}. I'm weak in normalization."
    else:
        llm = get_llm(args.provider)
    agent = Agent(llm, box.tools())

    def ask(text: str) -> None:
        result = agent.run(text)
        if args.trace:
            print_trace(result)
        print(f"\nStudyPilot: {result.answer}\n")

    if args.prompt:
        print(f"You: {args.prompt}\n")
        ask(args.prompt)
        return
    print("StudyPilot ready. Type 'exit' to quit.")
    while True:
        try:
            text = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if text.lower() in {"exit", "quit"}:
            break
        if text:
            ask(text)


if __name__ == "__main__":
    main()
