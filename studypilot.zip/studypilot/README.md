# StudyPilot - an agentic study assistant

An AI **agent** (not just a chatbot) for students. You tell it a goal in plain language -
*"My DBMS exam is on 20 Nov, I'm weak in normalization"* - and the LLM decides which tools to
call, in what order, reads the results, and keeps going until the job is done.

```
            +-----------------------------+
 user  ---> |  Agent loop (agent.py)      | <--- conversation memory
            |  LLM -> JSON action         |
            +--------------+--------------+
                           | tool call / OBSERVATION
        +------------------+------------------------------+
        v                  v                              v
  notes tools         planning tools               memory tools (SQLite)
  list/read/search    make_study_plan              log_quiz_result, get_progress
  (TF-IDF retrieval)  export_calendar (.ics)       add/review/due flashcards (SM-2)
```

## Why this is a good internship project
| Concept | Where it lives |
|---|---|
| Agent loop (ReAct), tool calling, error recovery, step limit | `studypilot/agent.py` |
| Retrieval over personal notes (TF-IDF, cosine similarity) | `NoteIndex` in `tools.py` |
| Real algorithms behind tools: weighted scheduling, SM-2 spaced repetition | `tools.py` |
| Persistent memory | `store.py` (SQLite) |
| Provider-agnostic LLM layer (Gemini / Claude / mock) | `llm.py` |
| Testing an LLM app deterministically (scripted mock LLM) | `tests/` |
| **Evaluating** agent behaviour with a real LLM | `eval/run_eval.py` |
| Safety: path-traversal guard, sandboxed file export, arg validation | `read_note`, `export_calendar` |

## Quick start
Python 3.10+. The core uses only the standard library.

```bash
python main.py --demo                  # offline walkthrough, no API key
python -m unittest discover -s tests   # 21 tests

pip install google-genai               # or: pip install anthropic
export GEMINI_API_KEY=...              # free key from Google AI Studio
python main.py --provider gemini --trace
python main.py --provider gemini "Plan my exam on 2026-11-20: Normalization, Transactions, SQL joins. Normalization is hardest."
python eval/run_eval.py --provider gemini
```
Put your own `.md`/`.txt` notes in `notes/`. `--trace` prints every tool call the agent makes.

> Model names change over time. If a call fails with "model not found", set
> `STUDYPILOT_MODEL` to a current model name from your provider's docs.
> I could not run live LLM calls while building this (no network), so the first thing
> to do is run `eval/run_eval.py` and record your real results.

## Design decisions (be ready to explain in your viva)
1. **Hand-written agent loop instead of LangChain.** Shows you understand what frameworks hide.
2. **JSON actions in plain text, not provider function-calling.** Works with every LLM; the loop is fully visible.
3. **Tool errors go back to the model as observations**, so it can fix bad arguments instead of crashing.
4. **Step limit + format-retry limit** prevent infinite loops and runaway cost.
5. **Deterministic logic lives in tools, not the LLM.** Scheduling and SM-2 are code, so they are testable and never hallucinated.

## Known limitations (put these in your report - honesty scores marks)
- TF-IDF is keyword based: "what is 3NF" can rank a BCNF paragraph above the 3NF one.
- Quiz scores are entered by the user; the agent does not generate/grade quizzes itself yet.
- No authentication or multi-user support; single local SQLite file.
- Eval set is only 6 tasks; small sample.

## Extension ideas (pick 2-3 to make it truly yours)
1. Replace TF-IDF with **embeddings** (sentence-transformers) and compare retrieval accuracy: measure top-1 hit rate on 20 questions you write.
2. Add a `generate_quiz` tool that makes MCQs from a note chunk, plus auto-grading that feeds `log_quiz_result`.
3. Add a PDF loader so students can index lecture slides.
4. Build a Streamlit or Flask UI on top of `Agent`.
5. Add **adaptive re-planning**: if `get_progress` shows weak topics, the agent extends those topics' days.
6. Compare 2-3 LLMs on `run_eval.py` and plot tool-use pass rate vs. latency/cost.

## Project layout
```
main.py                CLI (chat, one-shot, --demo)
studypilot/agent.py    ReAct loop, parsing, error handling
studypilot/tools.py    10 tools + TF-IDF index
studypilot/store.py    SQLite storage
studypilot/llm.py      Gemini / Anthropic / Mock adapters
notes/                 sample notes (replace with your own)
tests/                 unit tests (no network needed)
eval/                  tasks.json + run_eval.py
docs/                  report outline
```
