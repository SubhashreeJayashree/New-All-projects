# Internship report outline - StudyPilot

1. **Problem statement** - students juggle notes, deadlines and revision with no single adaptive tool.
2. **Objectives** - build an LLM agent that plans, retrieves from personal notes and tracks progress.
3. **Literature / background** - ReAct (Yao et al., 2022), RAG (Lewis et al., 2020), SM-2 spaced repetition
   (SuperMemo). Read the originals and cite them; do not copy from this file.
4. **System design** - architecture diagram (see README), data model (3 SQLite tables), tool list.
5. **Implementation** - agent loop, retrieval, scheduling algorithm, SM-2, provider layer.
6. **Testing** - unit tests with scripted mock LLM; list what each test proves.
7. **Evaluation** - run `eval/run_eval.py` on >=2 models; table of pass rates; failure analysis.
   Add your own retrieval experiment (TF-IDF vs embeddings).
8. **Limitations and ethics** - hallucination risk, data privacy of notes, API key handling.
9. **Future work** - from the README extension list.
10. **Declaration** - state clearly which parts were AI-assisted and what you modified/extended yourself.

## Viva questions to prepare
- What is the difference between a chatbot, RAG and an agent?
- What happens if the LLM returns invalid JSON? An unknown tool? Loops forever?
- Why is the study-plan logic a tool instead of asked from the LLM directly?
- Explain TF-IDF and cosine similarity. Why can it fail? How would embeddings help?
- Explain the SM-2 update rule for ease factor and interval.
- How did you evaluate the agent? What does a 'pass' mean and what are its weaknesses?
