import datetime as dt
import json
import unittest

from studypilot import Agent, Store, Toolbox
from studypilot.agent import parse_action
from studypilot.llm import MockLLM

TODAY = dt.date(2026, 11, 1)


def make_agent(script, max_steps=8):
    box = Toolbox(Store(":memory:"), notes_dir="notes", today=TODAY)
    llm = MockLLM(script)
    return Agent(llm, box.tools(), max_steps=max_steps, today=TODAY), llm


class TestParse(unittest.TestCase):
    def test_plain_json(self):
        self.assertEqual(parse_action('{"final": "hi"}'), {"final": "hi"})

    def test_fenced_with_chatter(self):
        raw = 'Sure!\n```json\n{"tool": "list_notes", "args": {}}\n```'
        self.assertEqual(parse_action(raw)["tool"], "list_notes")

    def test_garbage(self):
        self.assertIsNone(parse_action("no json here"))


class TestLoop(unittest.TestCase):
    def test_tool_then_final(self):
        agent, llm = make_agent([
            json.dumps({"tool": "search_notes", "args": {"query": "overfitting"}}),
            json.dumps({"final": "Overfitting = memorising training data."}),
        ])
        res = agent.run("What is overfitting?")
        self.assertEqual([s.tool for s in res.steps], ["search_notes"])
        self.assertIn("memoris", res.steps[0].observation)
        self.assertIn("OBSERVATION", llm.calls[1][-1]["content"])  # observation fed back
        self.assertFalse(res.hit_step_limit)

    def test_unknown_tool_is_recoverable(self):
        agent, _ = make_agent([
            json.dumps({"tool": "hack_nasa", "args": {}}),
            json.dumps({"final": "ok"}),
        ])
        res = agent.run("x")
        self.assertIn("unknown tool", res.steps[0].observation)
        self.assertEqual(res.answer, "ok")

    def test_bad_args_reported_to_model(self):
        agent, _ = make_agent([
            json.dumps({"tool": "log_quiz_result", "args": {"topic": "SQL"}}),
            json.dumps({"final": "ok"}),
        ])
        self.assertIn("bad arguments", agent.run("x").steps[0].observation)

    def test_tool_exception_reported(self):
        agent, _ = make_agent([
            json.dumps({"tool": "export_calendar", "args": {}}),  # no plan yet
            json.dumps({"final": "need a plan first"}),
        ])
        self.assertIn("No plan saved", agent.run("x").steps[0].observation)

    def test_bad_format_then_recovery(self):
        agent, _ = make_agent(["blah blah", json.dumps({"final": "fine"})])
        self.assertEqual(agent.run("x").answer, "fine")

    def test_step_limit(self):
        loop = [json.dumps({"tool": "list_notes", "args": {}})] * 10
        agent, _ = make_agent(loop, max_steps=3)
        res = agent.run("x")
        self.assertTrue(res.hit_step_limit)
        self.assertEqual(len(res.steps), 3)

    def test_memory_across_turns(self):
        agent, llm = make_agent([json.dumps({"final": "a"}), json.dumps({"final": "b"})])
        agent.run("first")
        agent.run("second")
        contents = [m["content"] for m in llm.calls[1]]
        self.assertTrue(any("first" in c for c in contents))


if __name__ == "__main__":
    unittest.main()
