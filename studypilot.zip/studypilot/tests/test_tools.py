import datetime as dt
import tempfile
import unittest
from pathlib import Path

from studypilot import Store, Toolbox

TODAY = dt.date(2026, 11, 1)


def make_box(out=None):
    return Toolbox(Store(":memory:"), notes_dir="notes", out_dir=out or tempfile.mkdtemp(), today=TODAY)


class TestNotes(unittest.TestCase):
    def test_search_finds_right_paragraph(self):
        r = make_box().search_notes("transitive dependency third normal form")
        self.assertTrue(r["results"])
        self.assertIn("transitive", r["results"][0]["text"].lower())
        self.assertGreater(len(r["results"][0]["text"]), 40)  # real paragraph, not a bare heading
        self.assertEqual(r["results"][0]["file"], "dbms_normalization.md")

    def test_search_no_match(self):
        self.assertEqual(make_box().search_notes("zzzzqqq")["results"], [])

    def test_read_note_blocks_path_traversal(self):
        with self.assertRaises(ValueError):
            make_box().read_note("../README.md")


class TestPlan(unittest.TestCase):
    def test_plan_covers_every_day_and_ends_with_revision(self):
        box = make_box()
        res = box.make_study_plan(["A", "B", "C"], "2026-11-11", 2, [5, 3, 2])
        plan = res["plan"]
        self.assertEqual(plan[0]["date"], "2026-11-01")
        self.assertEqual(plan[-1]["task"], "Revision + mock test")
        self.assertEqual(plan[-1]["date"], "2026-11-10")
        self.assertEqual(sum(res["days_per_topic"].values()), 9)  # 10 days - 1 revision day
        self.assertGreater(res["days_per_topic"]["A"], res["days_per_topic"]["C"])
        dates = [p["date"] for p in plan]
        self.assertEqual(len(dates), len(set(dates)))  # no two tasks on same day

    def test_accepts_comma_string(self):
        res = make_box().make_study_plan("A, B", "2026-11-08")
        self.assertEqual(list(res["days_per_topic"]), ["A", "B"])

    def test_too_many_topics_errors(self):
        with self.assertRaises(ValueError):
            make_box().make_study_plan(["A", "B", "C", "D"], "2026-11-04")

    def test_calendar_export(self):
        out = tempfile.mkdtemp()
        box = make_box(out)
        with self.assertRaises(ValueError):
            box.export_calendar()
        box.make_study_plan(["A", "B"], "2026-11-08")
        info = box.export_calendar("../evil.ics")  # must stay inside out_dir
        text = Path(info["saved_to"]).read_text()
        self.assertTrue(info["saved_to"].startswith(out))
        self.assertEqual(text.count("BEGIN:VEVENT"), info["events"])


class TestProgressAndCards(unittest.TestCase):
    def test_weak_topics(self):
        box = make_box()
        box.log_quiz_result("SQL", 9, 10)
        box.log_quiz_result("Normalization", 2, 10)
        prog = box.get_progress()
        self.assertEqual(prog["weak_topics"], ["Normalization"])
        self.assertEqual(prog["accuracy_percent"]["SQL"], 90.0)

    def test_invalid_quiz(self):
        with self.assertRaises(ValueError):
            make_box().log_quiz_result("X", 11, 10)

    def test_sm2_schedule(self):
        box = make_box()
        cid = box.add_flashcard("Q", "A")["card_id"]
        self.assertEqual(box.review_flashcard(cid, 5)["interval_days"], 1)
        self.assertEqual(box.review_flashcard(cid, 5)["interval_days"], 6)
        third = box.review_flashcard(cid, 5)
        self.assertGreater(third["interval_days"], 6)
        self.assertEqual(box.review_flashcard(cid, 1)["interval_days"], 1)  # lapse resets

    def test_due_cards(self):
        box = make_box()
        cid = box.add_flashcard("Q", "A")["card_id"]
        self.assertEqual(len(box.due_flashcards()["due"]), 1)
        box.review_flashcard(cid, 5)
        self.assertEqual(box.due_flashcards()["due"], [])


if __name__ == "__main__":
    unittest.main()
