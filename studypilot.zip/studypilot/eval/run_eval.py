"""Evaluate the agent's tool-use behaviour with a REAL LLM.

  python eval/run_eval.py --provider gemini

For each task in tasks.json we check (a) the required tools were called,
(b) forbidden tools were not, (c) the agent did not hit the step limit.
Report the pass rate and per-task failures in your internship report; try
different models / prompts and compare.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from studypilot import Agent, Store, Toolbox  # noqa: E402
from studypilot.llm import get_llm  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--provider", default="gemini", choices=["gemini", "anthropic"])
    args = ap.parse_args()

    today = dt.date.today()
    fmt = {f"exam_{n}": (today + dt.timedelta(days=n)).isoformat() for n in (10, 14)}
    tasks = json.loads((Path(__file__).parent / "tasks.json").read_text())
    llm = get_llm(args.provider)

    passed = 0
    for t in tasks:
        box = Toolbox(Store(":memory:"), notes_dir="notes", out_dir="exports/eval")  # fresh state per task
        res = Agent(llm, box.tools()).run(t["prompt"].format(**fmt))
        used = [s.tool for s in res.steps]
        problems = []
        problems += [f"missing {m}" for m in t["must_call"] if m not in used]
        problems += [f"forbidden {m}" for m in t["must_not_call"] if m in used]
        if res.hit_step_limit:
            problems.append("hit step limit")
        ok = not problems
        passed += ok
        print(f"{'PASS' if ok else 'FAIL'}  {t['id']:<18} tools={used} {problems or ''}")
    print(f"\nTool-use pass rate: {passed}/{len(tasks)} = {100*passed/len(tasks):.0f}%")


if __name__ == "__main__":
    main()
