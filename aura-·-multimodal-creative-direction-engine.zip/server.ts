import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '30mb' }));

// Initialize Gemini if key is provided
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  } catch (err) {
    console.error('Failed to initialize GoogleGenAI client:', err);
  }
}

// Fallback high-fidelity presets for zero-latency or offline scenarios
const SAMPLE_PRESETS: Record<string, any> = {
  "haute_couture": {
    conceptTitle: "CHRONO-CHITIN: Architectural Armor",
    tagline: "Structure as Sanctuary. Form Beyond Flesh.",
    creativeManifesto: "In a world saturated with ephemeral disposable fast-craft, Chrono-Chitin asserts the primacy of radical silhouettes. The collection draws from entomological biomechanics and brutalist monoliths—transforming high-fashion into protective kinetic architecture for modern metropolises.",
    brandArchetype: "The Outlaw & The Magician",
    emotionalVectors: {
      tension: "Vulnerability vs Invulnerability in urban hyper-surveillance",
      release: "The transformative armor that gives sovereignty to the wearer",
      resonance: "Quiet, uncompromising authority with zero hesitation"
    },
    colorPalette: [
      { hex: "#0A0B0E", name: "Obsidian Void", role: "Primary Canvas", usage: "Deep studio backdrops & structural shadows" },
      { hex: "#2A3A40", name: "Chitin Teal", role: "Structural Surface", usage: "Iridescent fabric undertones and rim lights" },
      { hex: "#E2A458", name: "Amber Filament", role: "Key Accent", usage: "3200K tungsten edge kicks and micro-stitching" },
      { hex: "#D4D8DD", name: "Liquid Platinum", role: "Highlights", usage: "Specular reflections on metallic zipper seams" },
      { hex: "#17181C", name: "Basalt Carbon", role: "Sub-neutral", usage: "Secondary garments and floor reflections" }
    ],
    cinematography: {
      cameraGear: "ARRI Alexa 35 with Hawk V-Lite 2x Anamorphic lenses",
      lensChoice: "45mm & 80mm Anamorphic Primes (T2.2)",
      lightingScheme: "Single hard tungsten key (5kW fresnel) with subtle diffused cyan ambient negative fill",
      colorGradingLUT: "Custom Kodak 5219 emulation with cold shadow skew and warm specular roll-off",
      aspectRatio: "2.39:1 CinemaScope"
    },
    storyboard: [
      {
        sceneNumber: 1,
        shotName: "The Monolith Silhouette",
        cameraAngle: "Extreme Low-Angle Static 45mm",
        lighting: "Stark Chiaroscuro back-rim light penetrating heavy industrial haze",
        action: "Model stands motionless in cavernous architectural space; coat lapels catch sudden warm amber kicker",
        visualDescription: "Tall imposing structural silhouette in obsidian leather; geometric folds create sharp graphic planes against the dark stone wall",
        audioCue: "Deep sub-harmonic 34Hz drone, distant resonant metallic chime",
        voiceover: "We did not inherit the future. We built its armor.",
        durationSeconds: 4.5,
        compositionRule: "Vertical Golden Ratio with low horizon line"
      },
      {
        sceneNumber: 2,
        shotName: "Kinetic Geometry in Macro",
        cameraAngle: "Extreme Close-Up 80mm Macro Tracking",
        lighting: "Directional raking light skimming the faceted iridescent textile texture",
        action: "Fingers in matte black titanium rings brush down the origami pleated sleeve; micro-zipper catches platinum reflection",
        visualDescription: "Hyper-detailed macro view of synthetic chromatic chitin scales shifting under movement",
        audioCue: "Tactile mechanical fabric friction sound, synchronized click of magnetic clasp",
        voiceover: "Every seam a deliberate defiance against entropy.",
        durationSeconds: 3.8,
        compositionRule: "Dynamic diagonal leading line from upper-right to lower-left"
      },
      {
        sceneNumber: 3,
        shotName: "The Sovereign Gaze",
        cameraAngle: "Medium Close-Up Profile to Front Dutch Angle Pan",
        lighting: "Twin rim lights (Amber left, Steel Cyan right) framing sculpted cheekbones",
        action: "Model turns 90 degrees directly into camera lens; expression is calm, penetrating, absolute",
        visualDescription: "Sleek wet-look hair, subtle iridescent eyelid sheen mirroring coat coloration",
        audioCue: "Swell of analog synth strings with tape saturation and breath intake",
        voiceover: "Step outside the uniform. Inhabit the archetype.",
        durationSeconds: 5.0,
        compositionRule: "Rule of Thirds eye-line positioning at 66% frame height"
      },
      {
        sceneNumber: 4,
        shotName: "The Urban Departure",
        cameraAngle: "Wide Tracking Shot following from behind",
        lighting: "Distant sodium streetlights dissolving into dense atmospheric rain mist",
        action: "Model strides down wet concrete runway; wide structural collar acts as wings against the city skyline",
        visualDescription: "Reflections of neon signage bleed across the damp asphalt floor as the figure disappears into the twilight",
        audioCue: "Rhythmic bass pulse rising to a sudden clean cut; lingering reverberant tail",
        voiceover: "Chrono-Chitin. Built for tomorrow's monoliths.",
        durationSeconds: 6.2,
        compositionRule: "Central single-point perspective converge"
      }
    ],
    sonicIdentity: {
      keySignature: "D Minor",
      bpm: 72,
      textures: ["Moog Model D Sub-bass Drone", "Bowed metallic cymbal harmonics", "Processed 35mm film shutter clicks", "Warm analog tape saturation"],
      sonicLogoDescription: "A three-tier acoustic strike: low 40Hz kinetic boom, followed by a crisp mechanical titanium click, decaying into a shimmering glass reverb tail.",
      narrationScript: "We did not inherit the future. We built its armor. In the convergence of geometry and sovereignty, you are not merely seen—you are indelible. Chrono-Chitin.",
      recommendedVoicePersona: "Kore (Low register, disciplined, intimate European editorial cadence)"
    },
    campaignDeliverables: {
      keyVisualHeadline: "SOVEREIGNTY ENGINEERED IN SILK & STEEL",
      keyVisualSubtext: "Autumn / Winter Haute Couture Campaign Suite. Available in numbered editions.",
      socialReelScript: {
        hook: "What if clothing was not meant to decorate—but to fortify?",
        body: "Precision-engineered origami pleating that shifts color under municipal light. Hand-cast titanium clasps. Zero compromises.",
        cta: "Explore the lookbook film · Link in profile"
      },
      billboardCopy: "FORM IS POWER. PARIS · MILAN · TOKYO",
      dosAndDonts: {
        dos: [
          "Maintain deep shadow dominance (minimum 60% negative space)",
          "Keep posture statuesque, architectural, and deliberate",
          "Ensure light catches edge geometry rather than flat frontal flooding"
        ],
        donts: [
          "No commercial smiling or playful lifestyle poses",
          "No saturated neon pink or turquoise filters",
          "Never crowd typography over the model's structural silhouette"
        ]
      }
    }
  },
  "sustainable_luxury": {
    conceptTitle: "AETHEREA: Terrestrial Essence",
    tagline: "Distilled From The Earth's Silent Hours.",
    creativeManifesto: "Aetherea rejects synthetic ostentation. Born from volcanic basalt, wild sea brine, and sun-baked amber resin, the fragrance embodies raw elemental luxury. The creative direction marries wabi-sabi tactile textures with museum-grade glass geometry.",
    brandArchetype: "The Sage & The Caregiver",
    emotionalVectors: {
      tension: "Urban sensory burnout vs grounding elemental stillness",
      release: "The transcendent breath of petrichor and ancient stone",
      resonance: "Deep serenity, organic permanence, and timeless craftsmanship"
    },
    colorPalette: [
      { hex: "#1C1C1E", name: "Volcanic Basalt", role: "Primary Canvas", usage: "Porous stone surfaces and mineral backdrops" },
      { hex: "#C78C48", name: "Aged Amber", role: "Hero Element", usage: "Perfume flacon liquid glow & warm sunlight refraction" },
      { hex: "#6D7973", name: "Nordic Sage", role: "Organic Grounding", usage: "Foliage accents and typography sub-headers" },
      { hex: "#E8E6DF", name: "Travertine Chalk", role: "Clean Contrast", usage: "Minimalist packaging paper & key visual headlines" },
      { hex: "#3A4540", name: "Deep Lichen", role: "Shadow Tonal", usage: "Water reflections and shadow depth" }
    ],
    cinematography: {
      cameraGear: "RED V-Raptor 8K VV with Cooke S7/i Full Frame Plus Primes",
      lensChoice: "65mm & 110mm Macro Primes",
      lightingScheme: "Natural raking morning sunlight through water ripple glass diffuser",
      colorGradingLUT: "Naturalistic Nordic film emulation with rich earthen amber mids",
      aspectRatio: "1.85:1 Academy Flat"
    },
    storyboard: [
      {
        sceneNumber: 1,
        shotName: "The Basalt Cradle",
        cameraAngle: "Low Angle 45-degree macro",
        lighting: "Raking low-sunlight creating crystalline caustics through sculpted glass",
        action: "Morning sea water gently laps against the black basalt stone; amber perfume flacon stands completely immovable",
        visualDescription: "Rough volcanic mineral texture contrasting with optically pure organic glass bottle; name 'AETHEREA' embossed in blind letterpress style",
        audioCue: "Gentle ocean swell, crisp morning breeze, distant shorebirds",
        voiceover: "Before the noise of the world, there was the silence of stone.",
        durationSeconds: 5.0,
        compositionRule: "Rule of Thirds focal placement on golden horizon"
      },
      {
        sceneNumber: 2,
        shotName: "The Amber Refraction",
        cameraAngle: "Extreme Macro 110mm Rack Focus",
        lighting: "Backlit liquid amber casting golden light pools onto wet dark pebbles",
        action: "A single distilled dewdrop slides down the glass shoulder, magnifying the amber warmth",
        visualDescription: "Golden amber liquid illuminated from within, suspended tiny botanical resins catching sunlight sparkles",
        audioCue: "Soft organic woodwind tone, acoustic harp pluck with sustained ring",
        voiceover: "Captured in the brief window between dawn and dew.",
        durationSeconds: 4.2,
        compositionRule: "Circular focal center with radial vignette"
      },
      {
        sceneNumber: 3,
        shotName: "The Ritual Application",
        cameraAngle: "Over-the-Shoulder Medium Shot",
        lighting: "Diffused linen curtain morning light in minimalist travertine interior",
        action: "Hands with clean natural nails lift the sculpted volcanic stone stopper; vapor mist disperses in slow motion",
        visualDescription: "Fine micro-mist caught in sunbeam dust motes against minimalist limestone wall",
        audioCue: "Clean mechanical pump hiss, gentle intake of breath",
        voiceover: "Wear the elements. Inhabit the eternal.",
        durationSeconds: 4.8,
        compositionRule: "Balanced asymmetrical split between person and ambient space"
      }
    ],
    sonicIdentity: {
      keySignature: "F Major",
      bpm: 58,
      textures: ["Felted acoustic grand piano chords", "Field recording of Icelandic coastal tide", "Warm cello drone", "Subtle wind chime reverberation"],
      sonicLogoDescription: "A soft water droplet strike resolving into a rich, warm C-major piano chord held with sustain pedal for 6 seconds.",
      narrationScript: "Before the noise of the world, there was the silence of stone. Distilled from the earth's quietest hours, Aetherea is not a scent—it is an anchor.",
      recommendedVoicePersona: "Zephyr (Soft, warm, articulate, grounded cadence)"
    },
    campaignDeliverables: {
      keyVisualHeadline: "THE ESSENCE OF UNBROKEN SILENCE",
      keyVisualSubtext: "Extrait de Parfum · Wild Basalt Cap & Refillable Crystal Flacon",
      socialReelScript: {
        hook: "What does pure stillness smell like?",
        body: "Crushed juniper, volcanic mineral petrichor, and warm coastal amber. Crafted without synthetic fixatives.",
        cta: "Experience the olfactive gallery · Reserve your discovery set"
      },
      billboardCopy: "DISTILLED FROM NATURE. REFINED BY TIME.",
      dosAndDonts: {
        dos: [
          "Use real raw mineral, wood, and water textures",
          "Prioritize soft, diffused, natural morning sunlight",
          "Ensure wide breathing margins around product photography"
        ],
        donts: [
          "No aggressive CGI explosions or glitter effects",
          "No loud high-energy dance music cues",
          "Never obscure the raw stone bottle stopper"
        ]
      }
    }
  },
  "spatial_audio": {
    conceptTitle: "AETHERIS: Spatial Acoustic Architecture",
    tagline: "Sound Not Heard, But Inhabited.",
    creativeManifesto: "Aetheris redefines personal listening as a physical architectural phenomenon. Engineered with titanium acoustic mesh and lambskin isolation chambers, the direction treats sound waves as sculptural light planes carving through negative space.",
    brandArchetype: "The Creator & The Explorer",
    emotionalVectors: {
      tension: "Flat compressed digital audio fatigue",
      release: "Expansive 360-degree spatial clarity with infinite headroom",
      resonance: "Physical intimacy with the musician's breath and resonance"
    },
    colorPalette: [
      { hex: "#0E1116", name: "Acoustic Slate", role: "Primary Canvas", usage: "Soundstage background & felt isolation panels" },
      { hex: "#9AA0A6", name: "Brushed Titanium", role: "Hardware Metal", usage: "Earcups, headband yolk, and audio jack casing" },
      { hex: "#D97706", name: "Amber Valve Glow", role: "Acoustic Warmth", usage: "Vacuum tube indicators and soundwave highlights" },
      { hex: "#23272F", name: "Matte Carbon", role: "Structural Surface", usage: "Plinth pedestal and packaging container" },
      { hex: "#F3F4F6", name: "Pure Signal White", role: "Display Copy", usage: "Clean typography and frequency curve lines" }
    ],
    cinematography: {
      cameraGear: "Sony FX9 with Master Anamorphic Primes",
      lensChoice: "50mm & 100mm Macro Cine Primes",
      lightingScheme: "Sculpted rim lighting with dual strip softboxes framing metal curvatures",
      colorGradingLUT: "High-dynamic range industrial monochrome with selective amber accentuation",
      aspectRatio: "2.0:1 Univisium"
    },
    storyboard: [
      {
        sceneNumber: 1,
        shotName: "The Titanium Plinth",
        cameraAngle: "Low Angle Slow Orbit 50mm",
        lighting: "Precision overhead edge light revealing micro-perforated acoustic driver grille",
        action: "Headphones rest on raw travertine block; camera sweeps smoothly around the brushed aluminum gimbals",
        visualDescription: "Intricate metallic texture, machined concentric rings reflecting a razor-thin highlight stripe",
        audioCue: "High-definition acoustic guitar pluck, sound of finger sliding across wound steel string",
        voiceover: "Most headphones transmit sound. Aetheris constructs space.",
        durationSeconds: 4.6,
        compositionRule: "Centric Hero placement with 50/50 balance"
      },
      {
        sceneNumber: 2,
        shotName: "The Driver Anatomy",
        cameraAngle: "Exploded View Kinetic Macro 100mm",
        lighting: "Strobe-pulse synchronizing with low-frequency rumble",
        action: "Planar magnetic diaphragm vibrates in slow motion 1000fps; dust particles dance above the copper voice coil",
        visualDescription: "Transparent internal casing revealing hand-wound planar trace array",
        audioCue: "Pure 20Hz sine wave sweeping up through 432Hz harmonic overtones",
        voiceover: "Fifty-millimeter planar drivers. Zero phase distortion.",
        durationSeconds: 5.2,
        compositionRule: "Dynamic diagonal symmetry"
      },
      {
        sceneNumber: 3,
        shotName: "The Isolation Seal",
        cameraAngle: "Side Profile Silhouette into Light",
        lighting: "High-contrast rim silhouette with gentle warmth on ear cushion",
        action: "Listener places headphones over ears; outside environmental noise immediately ducks to total silence",
        visualDescription: "Supple leather conforming to listener's contour; eyes close in relaxed concentration",
        audioCue: "Sudden absolute silence, followed by a crisp stereo orchestral crescendo enveloping the field",
        voiceover: "Step inside the master recording.",
        durationSeconds: 4.4,
        compositionRule: "Golden section profile"
      }
    ],
    sonicIdentity: {
      keySignature: "A Minor",
      bpm: 85,
      textures: ["432Hz calibrated sine resonance", "Crisp analog vinyl crackle decay", "Full spectrum spatial frequency sweep", "Deep sub-kick with stereo reverb width"],
      sonicLogoDescription: "A wide stereophonic binaural sweep from left to right ear, resolving into an ultra-clean acoustic chime with 96kHz harmonic extension.",
      narrationScript: "Most headphones simply transmit sound. Aetheris builds an acoustic sanctuary. With planar magnetic precision and zero-resonance titanium, discover every nuance the artist felt in the studio.",
      recommendedVoicePersona: "Fenrir (Authoritative, resonant, technical, warm studio engineer tone)"
    },
    campaignDeliverables: {
      keyVisualHeadline: "HEAR THE ROOM. INHABIT THE SOUND.",
      keyVisualSubtext: "Planar Magnetic Reference Headphones. Hand-assembled in Munich.",
      socialReelScript: {
        hook: "Have you ever heard the sound of the air in the recording booth?",
        body: "Standard headphones compress your music into two flat speakers. Planar magnetic drivers rebuild the entire three-dimensional acoustic space around you.",
        cta: "Book a private acoustic audition · Studio appointments open"
      },
      billboardCopy: "ACOUSTIC PERFECTION. ZERO COMPROMISE.",
      dosAndDonts: {
        dos: [
          "Highlight brushed metallic highlights and precision craftsmanship",
          "Emphasize silence and spatial depth in sound design",
          "Use clean architectural typography with monospace technical annotations"
        ],
        donts: [
          "Do not show tangled messy cords or plasticky consumer finishes",
          "Avoid gimmicky bass-heavy party rave tropes",
          "Never distort or clip the audio master"
        ]
      }
    }
  }
};

// POST /api/generate-campaign
app.post('/api/generate-campaign', async (req, res) => {
  try {
    const {
      brandName = "Vanguard Audio",
      industry = "Consumer Electronics",
      brief = "Next-gen spatial audio headphones crafted for purists",
      archetype = "The Creator",
      aestheticTone = "Neo-Minimalist Architectural & Warm Amber",
      temperatureDial = 50,
      avantGardeDial = 65,
      pacingDial = 40,
      presetKey
    } = req.body;

    // Check if preset requested
    if (presetKey && SAMPLE_PRESETS[presetKey]) {
      return res.json({
        success: true,
        source: 'preset',
        data: SAMPLE_PRESETS[presetKey]
      });
    }

    // If Gemini client available, synthesize unique multimodal direction
    if (aiClient) {
      try {
        const prompt = `You are a world-class Executive Creative Director at an award-winning advertising and design agency (like Wieden+Kennedy, Droga5, Pentagram, or Apple Marcom).
Craft a complete, production-grade Multimodal Creative Direction Package for the following brief:

Brand Name: ${brandName}
Industry: ${industry}
Creative Brief: ${brief}
Brand Archetype: ${archetype}
Aesthetic Tone: ${aestheticTone}
Creative Dial Parameters:
- Brand Temperature: ${temperatureDial}/100 (0 = Cold Monolithic Minimalism, 100 = Warm Organic Tactility)
- Stance: ${avantGardeDial}/100 (0 = Commercial Mainstream, 100 = Radical High-Art Avant-Garde)
- Pacing: ${pacingDial}/100 (0 = Contemplative Meditative Slow-Burn, 100 = High-Energy Kinetic)

Return a strictly valid JSON object matching this schema:
{
  "conceptTitle": "Evocative overarching campaign title",
  "tagline": "Unforgettable memorable 3-7 word brand line",
  "creativeManifesto": "A powerful 2-3 paragraph creative director manifesto stating the tension, the thesis, and the aesthetic stance",
  "brandArchetype": "Detailed archetype breakdown",
  "emotionalVectors": {
    "tension": "The societal or personal friction",
    "release": "How the creative resolves this",
    "resonance": "The long-lasting feeling left in the audience"
  },
  "colorPalette": [
    { "hex": "#HEX", "name": "Name", "role": "Primary Canvas | Key Accent | Structural Surface | Shadow Depth | Highlights", "usage": "Specific lighting/material instruction" }
  ],
  "cinematography": {
    "cameraGear": "Cine camera body & sensor",
    "lensChoice": "Specific focal lengths, anamorphic or spherical, vintage or modern",
    "lightingScheme": "Exact lighting grammar (e.g. Chiaroscuro 5000K key with sodium fill)",
    "colorGradingLUT": "Film stock emulation & color space notes",
    "aspectRatio": "e.g. 2.39:1 CinemaScope or 1.85:1"
  },
  "storyboard": [
    {
      "sceneNumber": 1,
      "shotName": "Shot name",
      "cameraAngle": "Camera angle and focal length",
      "lighting": "Specific light setup",
      "action": "What happens in the frame",
      "visualDescription": "Detailed art direction for set, model, props",
      "audioCue": "Exact sound effects, musical notes",
      "voiceover": "Spoken line or silence",
      "durationSeconds": 4.5,
      "compositionRule": "e.g. Golden Spiral, Low-angle single-point perspective"
    }
  ],
  "sonicIdentity": {
    "keySignature": "Musical key e.g. D Minor or C# Major",
    "bpm": 70,
    "textures": ["Array of 4 acoustic/synthetic texture descriptions"],
    "sonicLogoDescription": "Description of the 3-second sonic brand mark",
    "narrationScript": "Full 40-50 word director's voiceover script for commercial narration",
    "recommendedVoicePersona": "Voice tone description e.g. Kore or Fenrir style"
  },
  "campaignDeliverables": {
    "keyVisualHeadline": "Bold uppercase print/digital billboard headline",
    "keyVisualSubtext": "Sophisticated sub-headline",
    "socialReelScript": {
      "hook": "First 3-second hook for 9:16 vertical video",
      "body": "Core message delivery",
      "cta": "Single-line call to action"
    },
    "billboardCopy": "Short impactful out-of-home copy",
    "dosAndDonts": {
      "dos": ["3 actionable art direction rules"],
      "donts": ["3 explicit things to avoid to protect brand prestige"]
    }
  }
}`;

        const response = await aiClient.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
            temperature: 0.8,
          },
        });

        const text = response.text;
        if (text) {
          const parsed = JSON.parse(text);
          return res.json({
            success: true,
            source: 'gemini-3.8-flash',
            data: parsed
          });
        }
      } catch (geminiError) {
        console.warn('Gemini generation encountered an issue, falling back to smart engine:', geminiError);
      }
    }

    // Dynamic procedural fallback if API key is absent or errored
    const dynamicFallback = {
      conceptTitle: `${brandName.toUpperCase()}: The Vanguard Directive`,
      tagline: `Engineered for the Uncompromising.`,
      creativeManifesto: `In an era of relentless algorithmic homogeneity, ${brandName} introduces a paradigm of intentional design. Our creative direction synthesizes ${aestheticTone.toLowerCase()} with uncompromising technical rigor. Every frame, every tactile frequency, and every millimeter of negative space is calculated to evoke genuine presence.`,
      brandArchetype: archetype,
      emotionalVectors: {
        tension: "The fatigue of disposable, ephemeral consumer commodities",
        release: `The enduring substance and tactile sovereignty delivered by ${brandName}`,
        resonance: "Unapologetic permanence and refined discernment"
      },
      colorPalette: [
        { hex: "#0B0D12", name: "Deep Charcoal Canvas", role: "Primary Canvas", usage: "Studio negative space and high-contrast backdrop" },
        { hex: temperatureDial > 50 ? "#D97706" : "#2563EB", name: temperatureDial > 50 ? "Warm Amber Resonance" : "Kinetic Cobalt Flare", role: "Key Accent", usage: "Specular rim kickers and typography focal points" },
        { hex: "#232834", name: "Machined Graphite", role: "Structural Surface", usage: "Product housing textures and secondary geometry" },
        { hex: "#E5E7EB", name: "Pure Titanium White", role: "Highlights", usage: "Editorial headlines and laser-etched markings" },
        { hex: "#151821", name: "Shadow Obsidian", role: "Shadow Depth", usage: "Deep floor reflections and subtle vignette" }
      ],
      cinematography: {
        cameraGear: "ARRI Alexa Mini LF with Cooke Anamorphic Full Frame Plus Primes",
        lensChoice: avantGardeDial > 60 ? "32mm & 65mm Ultra-wide Anamorphic" : "50mm & 85mm Classic Portrait Cine Primes",
        lightingScheme: temperatureDial > 50 ? "3200K Tungsten Fresnel Key with warm diffuse practicals" : "5600K Clean daylight HMI with negative black velvet fill",
        colorGradingLUT: "Custom 35mm film print curve with lifted low-blacks and saturated micro-contrast",
        aspectRatio: "2.39:1 CinemaScope"
      },
      storyboard: [
        {
          sceneNumber: 1,
          shotName: "The Monolith Revealing",
          cameraAngle: "Extreme Low-Angle Tracking 35mm",
          lighting: "Single linear razor-light sweeping slowly across matte textures",
          action: `The hero ${brandName} subject emerges from darkness, light catching precision machined chamfers`,
          visualDescription: "Pristine negative space; high contrast surfaces casting elongated architectural shadows",
          audioCue: "Sub-bass harmonic pulse at 38Hz, gradual emergence of room tone",
          voiceover: "We stopped asking what could be made faster.",
          durationSeconds: 4.8,
          compositionRule: "Single-point central perspective"
        },
        {
          sceneNumber: 2,
          shotName: "Tactile Kinetic Macro",
          cameraAngle: "Extreme Close-Up 100mm Macro Dolly",
          lighting: "Hard directional rim light highlighting micro-tolerances and tactile switches",
          action: "Human hands interact with mechanical elements; physical detent feedback matches sound",
          visualDescription: "Intimate focus on organic skin texture meeting brushed aerospace-grade alloy",
          audioCue: "Synchronized crisp mechanical click with 1.2s acoustic plate reverb",
          voiceover: "And started demanding what deserves to last.",
          durationSeconds: 3.9,
          compositionRule: "Golden ratio spiral focusing on contact point"
        },
        {
          sceneNumber: 3,
          shotName: "The Climax In Situ",
          cameraAngle: "Medium Dynamic Orbit Shot",
          lighting: "Full volumetric atmospheric haze with striking backlit halo",
          action: `Full contextual presence of ${brandName} in its natural element; model exhibits tranquil command`,
          visualDescription: "Atmospheric depth, soft dust motes in light beam, refined color grading palette",
          audioCue: "Swell of analog cello arrangement, building to harmonic resolution",
          voiceover: `${brandName}. Form, function, and permanence.`,
          durationSeconds: 5.5,
          compositionRule: "Rule of Thirds balanced eye-line"
        }
      ],
      sonicIdentity: {
        keySignature: temperatureDial > 50 ? "E Minor" : "C# Minor",
        bpm: pacingDial > 60 ? 110 : 68,
        textures: ["Acoustic resonance decay", "Tape saturated analog synth pads", "Precision physical tactile clicks", "Atmospheric environmental air"],
        sonicLogoDescription: "A dual-stage acoustic signature: a low resonant metallic thump followed by an upward melodic shimmer decaying over 3.5 seconds.",
        narrationScript: `We stopped asking what could be made faster, and started demanding what deserves to last. In the intersection of discipline and imagination, ${brandName} is your anchor.`,
        recommendedVoicePersona: "Fenrir (Rich, grounded baritone with deliberate pacing)"
      },
      campaignDeliverables: {
        keyVisualHeadline: `${brandName.toUpperCase()} · SOVEREIGNTY IN DESIGN`,
        keyVisualSubtext: `${brief}. Crafted for those who discern the difference.`,
        socialReelScript: {
          hook: `Why does modern design feel so disposable?`,
          body: `Because most things are engineered for the feed, not for permanence. ${brandName} was built with a different philosophy.`,
          cta: `Explore the campaign lookbook now.`
        },
        billboardCopy: `NOT FOR EVERYONE. ONLY FOR THE DISCERNING.`,
        dosAndDonts: {
          dos: [
            "Maintain minimum 50% clean structural negative space",
            "Keep cinematic camera motion smooth and motivated",
            "Prioritize genuine physical textures over digital glitz"
          ],
          donts: [
            "Never use generic commercial stock photography poses",
            "Avoid neon oversaturation or trendy TikTok filters",
            "Do not clutter key visuals with more than two lines of text"
          ]
        }
      }
    };

    return res.json({
      success: true,
      source: 'procedural-director-engine',
      data: dynamicFallback
    });

  } catch (error: any) {
    console.error('Error generating campaign:', error);
    res.status(500).json({ success: false, error: error.message || 'Internal server error' });
  }
});

// POST /api/critique-creative: Real-time Creative Director review of an element
app.post('/api/critique-creative', async (req, res) => {
  try {
    const { targetText, contextRole, temperatureDial, avantGardeDial, brandName } = req.body;

    if (aiClient) {
      try {
        const response = await aiClient.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: `You are an elite Creative Director at a top-tier luxury & tech agency.
Critique the following creative asset for the brand "${brandName}":
Element Role: ${contextRole}
Asset Content: "${targetText}"
Current Direction Sliders:
- Brand Temperature: ${temperatureDial}/100 (0=Cold Minimalist, 100=Warm Organic)
- Avant-Garde Stance: ${avantGardeDial}/100 (0=Commercial Mainstream, 100=Radical Art)

Provide:
1. "directorVerdict": A sharp, insightful 1-2 sentence assessment
2. "suggestedRevision": A polished, elevated alternative version
3. "cinematicNote": Art direction guidance on color, lighting, or pacing to accompany it

Return pure JSON:
{
  "directorVerdict": "string",
  "suggestedRevision": "string",
  "cinematicNote": "string"
}`,
          config: {
            responseMimeType: 'application/json',
            temperature: 0.7,
          }
        });

        const text = response.text;
        if (text) {
          return res.json({ success: true, ...JSON.parse(text) });
        }
      } catch (err) {
        console.warn('Gemini critique fallback:', err);
      }
    }

    // Procedural critique feedback
    const isAvant = avantGardeDial > 50;
    const isWarm = temperatureDial > 50;
    res.json({
      success: true,
      directorVerdict: isAvant 
        ? "Concept holds genuine intrigue, but needs sharper typographic tension to cut through high-fashion noise."
        : "Strong commercial resonance; consider stripping one decorative word to amplify memorability and punch.",
      suggestedRevision: isAvant
        ? `"${targetText.toUpperCase()} · RECONFIGURED IN OBSIDIAN"`
        : `"${targetText.replace(/very|simply|just/gi, '').trim()}"`,
      cinematicNote: isWarm
        ? "Shift the key lighting toward 3200K tungsten amber and allow the shadow falloff to breathe naturally."
        : "Enforce cold high-contrast anamorphic rim lighting to carve clean silhouettes from the background."
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Setup Vite in Dev or static files in Production
const isProduction = process.env.NODE_ENV === 'production';
if (!isProduction) {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (_req, res) => {
    res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
  });
}

const PORT = 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`[AURA Engine] Creative Director Server running on http://0.0.0.0:${PORT}`);
});
