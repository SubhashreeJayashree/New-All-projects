import React from 'react';
import { Sparkles, Download, Layers } from 'lucide-react';

interface TopBarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenBriefModal: () => void;
  onOpenExportModal: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  setActiveTab,
  onOpenBriefModal,
  onOpenExportModal,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-neutral-950/85 backdrop-blur-md border-b border-neutral-800/80 px-6 py-3.5 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-2.5 h-2.5 bg-neutral-200 rotate-45" />
          <span className="text-base font-semibold tracking-tight text-neutral-100 whitespace-nowrap">
            AURA <span className="text-neutral-400 font-normal">/ Creative Direction Engine</span>
          </span>
        </div>

        {/* Zone 2: 4-5 clean single-line text navigation links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium">
          <button
            onClick={() => setActiveTab('treatment')}
            className={`whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'treatment'
                ? 'text-white border-b-2 border-white pb-0.5'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Director's Treatment
          </button>
          <button
            onClick={() => setActiveTab('storyboard')}
            className={`whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'storyboard'
                ? 'text-white border-b-2 border-white pb-0.5'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Cinematic Storyboard
          </button>
          <button
            onClick={() => setActiveTab('sonic')}
            className={`whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'sonic'
                ? 'text-white border-b-2 border-white pb-0.5'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Sonic Identity & Voice
          </button>
          <button
            onClick={() => setActiveTab('adaptation')}
            className={`whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'adaptation'
                ? 'text-white border-b-2 border-white pb-0.5'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Multi-Format Matrix
          </button>
        </nav>

        {/* Zone 3: 1 primary action (with secondary export) */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenExportModal}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:text-white bg-neutral-900 border border-neutral-800 hover:border-neutral-700 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            title="Export Campaign Deck"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Deck</span>
          </button>
          <button
            onClick={onOpenBriefModal}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-neutral-950 bg-white hover:bg-neutral-200 rounded-lg shadow-sm transition-colors whitespace-nowrap cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Compose New Brief</span>
          </button>
        </div>
      </div>
    </header>
  );
};
