import React, { useState } from 'react';
import { CampaignTreatment } from '../types/campaign';
import { Eye, Grid, Maximize2, Sliders, ArrowUpRight } from 'lucide-react';
import { ASSET_IMAGES } from '../data/presets';

interface HeroSectionProps {
  currentTreatment: CampaignTreatment;
  activePresetId: string;
  onSelectPreset: (presetId: string) => void;
  onOpenBriefModal: () => void;
  onScrollToTreatment: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  currentTreatment,
  activePresetId,
  onSelectPreset,
  onOpenBriefModal,
  onScrollToTreatment,
}) => {
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [showCinemaBars, setShowCinemaBars] = useState<boolean>(false);

  return (
    <section className="relative pt-8 pb-12 px-6 border-b border-neutral-900">
      <div className="max-w-7xl mx-auto">
        {/* Editorial Subheader Kicker */}
        <div className="flex items-center gap-3 text-xs tracking-wider uppercase text-neutral-400 mb-4">
          <span>Multimodal Direction Core</span>
          <span aria-hidden="true">·</span>
          <span>Cross-Modal Reasoning Engine</span>
          <span aria-hidden="true">·</span>
          <span>Zero-Latency Synthesis</span>
        </div>

        {/* 2-Column Split: Editorial Proposition + Marquee Studio Viewport */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch mb-10">
          {/* Left Column: Proposition & Presets */}
          <div className="lg:col-span-5 flex flex-col justify-between">
            <div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white mb-4 leading-[1.15] text-balance">
                Autonomous Creative Direction for High-Impact Brands
              </h1>
              <p className="text-neutral-400 text-sm sm:text-base leading-relaxed mb-6 max-w-xl">
                A unified multimodal intelligence that transforms raw product briefs, moodboard assets, and sonic sensibilities into complete, cinema-grade brand campaigns and storyboards.
              </p>

              {/* Preset Selector */}
              <div className="mb-6">
                <div className="text-xs uppercase tracking-wider text-neutral-400 mb-2.5 font-medium">
                  Curated Agency Productions
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => onSelectPreset('haute_couture')}
                    className={`px-3 py-2 text-xs font-medium rounded-lg border transition-all cursor-pointer whitespace-nowrap ${
                      activePresetId === 'haute_couture'
                        ? 'bg-neutral-100 text-neutral-950 border-white shadow-sm'
                        : 'bg-neutral-900/80 text-neutral-300 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    High Fashion · Chrono-Chitin
                  </button>
                  <button
                    onClick={() => onSelectPreset('sustainable_luxury')}
                    className={`px-3 py-2 text-xs font-medium rounded-lg border transition-all cursor-pointer whitespace-nowrap ${
                      activePresetId === 'sustainable_luxury'
                        ? 'bg-neutral-100 text-neutral-950 border-white shadow-sm'
                        : 'bg-neutral-900/80 text-neutral-300 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    Fine Olfactive · Aetherea
                  </button>
                  <button
                    onClick={() => onSelectPreset('spatial_audio')}
                    className={`px-3 py-2 text-xs font-medium rounded-lg border transition-all cursor-pointer whitespace-nowrap ${
                      activePresetId === 'spatial_audio'
                        ? 'bg-neutral-100 text-neutral-950 border-white shadow-sm'
                        : 'bg-neutral-900/80 text-neutral-300 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    Spatial Hardware · Aetheris
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Actions & Current Concept Badge */}
            <div className="pt-4 border-t border-neutral-900 flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="text-xs text-neutral-400">Current Production</div>
                <div className="text-sm font-semibold text-neutral-100 truncate max-w-xs">
                  {currentTreatment.conceptTitle}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={onScrollToTreatment}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:text-white bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded-lg transition-colors cursor-pointer"
                >
                  <span>Explore Treatment</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Marquee Visual Viewport with Cine Overlays */}
          <div className="lg:col-span-7 relative group">
            <div className="relative rounded-xl overflow-hidden border border-neutral-800/80 bg-neutral-900 aspect-16/10 sm:aspect-16/9 flex items-center justify-center">
              {/* Main Visual Image with Fallback */}
              <img
                src={currentTreatment.heroImage || ASSET_IMAGES.heroStudio}
                alt={currentTreatment.conceptTitle}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.02]"
              />

              {/* Optional CinemaScope 2.39:1 Letterbox Bars */}
              {showCinemaBars && (
                <>
                  <div className="absolute top-0 left-0 right-0 h-9 bg-black/95 z-20 transition-all" />
                  <div className="absolute bottom-0 left-0 right-0 h-9 bg-black/95 z-20 transition-all" />
                </>
              )}

              {/* Compositional Grid Overlay */}
              {showGrid && (
                <div className="absolute inset-0 pointer-events-none z-10 grid grid-cols-3 grid-rows-3">
                  <div className="border-r border-b border-white/20" />
                  <div className="border-r border-b border-white/20" />
                  <div className="border-b border-white/20" />
                  <div className="border-r border-b border-white/20" />
                  <div className="border-r border-b border-white/20" />
                  <div className="border-b border-white/20" />
                  <div className="border-r border-white/20" />
                  <div className="border-r border-white/20" />
                  <div />
                </div>
              )}

              {/* Gradient scrim for legibility */}
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/90 via-neutral-950/20 to-neutral-950/30 pointer-events-none" />

              {/* Viewport Top HUD Overlay */}
              <div className="absolute top-3 left-3 right-3 flex items-center justify-between text-[11px] font-mono text-neutral-300 z-20 pointer-events-none">
                <div className="bg-neutral-950/80 backdrop-blur-md px-2.5 py-1 rounded border border-neutral-800">
                  <span>REC 2.39:1 · {currentTreatment.cinematography.cameraGear.split(' ')[0]}</span>
                </div>
                <div className="bg-neutral-950/80 backdrop-blur-md px-2.5 py-1 rounded border border-neutral-800 tabular-nums">
                  <span>24.00 FPS · 800 ISO · T2.0</span>
                </div>
              </div>

              {/* Viewport Bottom Overlay & Interactive Controls */}
              <div className="absolute bottom-3 left-3 right-3 flex flex-wrap items-end justify-between gap-3 z-20">
                <div className="max-w-md">
                  <div className="text-[11px] font-mono uppercase tracking-wider text-neutral-400 mb-1">
                    Key Visual Directive
                  </div>
                  <div className="text-white font-medium text-sm sm:text-base leading-snug drop-shadow-md">
                    {currentTreatment.tagline}
                  </div>
                </div>

                {/* Viewport Toggles */}
                <div className="flex items-center gap-1.5 bg-neutral-950/85 backdrop-blur-md p-1 rounded-lg border border-neutral-800">
                  <button
                    onClick={() => setShowGrid(!showGrid)}
                    className={`p-1.5 rounded text-xs transition-colors cursor-pointer ${
                      showGrid ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                    title="Toggle Composition Grid"
                  >
                    <Grid className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setShowCinemaBars(!showCinemaBars)}
                    className={`p-1.5 rounded text-xs transition-colors cursor-pointer ${
                      showCinemaBars ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                    title="Toggle CinemaScope Bars"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4-Item Strip: Direction Pillars (Strict Quantitative/Adjacency Design) */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-6 border-t border-neutral-900 text-xs">
          <div className="p-3 bg-neutral-900/40 rounded-lg border border-neutral-800/60">
            <div className="text-neutral-400 font-medium mb-1">Brand Archetype</div>
            <div className="font-semibold text-neutral-200 truncate">{currentTreatment.brandArchetype}</div>
          </div>
          <div className="p-3 bg-neutral-900/40 rounded-lg border border-neutral-800/60">
            <div className="text-neutral-400 font-medium mb-1">Lens & Aspect Ratio</div>
            <div className="font-semibold text-neutral-200 truncate">{currentTreatment.cinematography.aspectRatio}</div>
          </div>
          <div className="p-3 bg-neutral-900/40 rounded-lg border border-neutral-800/60">
            <div className="text-neutral-400 font-medium mb-1">Sonic Key & Tempo</div>
            <div className="font-semibold text-neutral-200 truncate">
              {currentTreatment.sonicIdentity.keySignature} · {currentTreatment.sonicIdentity.bpm} BPM
            </div>
          </div>
          <div className="p-3 bg-neutral-900/40 rounded-lg border border-neutral-800/60">
            <div className="text-neutral-400 font-medium mb-1">Storyboard Depth</div>
            <div className="font-semibold text-neutral-200 truncate">
              {currentTreatment.storyboard.length} Key Cinema Frames
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
