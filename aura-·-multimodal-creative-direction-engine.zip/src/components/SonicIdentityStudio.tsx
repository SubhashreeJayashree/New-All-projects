import React, { useState, useEffect, useRef } from 'react';
import { SonicIdentity } from '../types/campaign';
import { Play, Pause, RotateCcw, Volume2, Mic, Activity, MessageSquareCode } from 'lucide-react';

interface SonicIdentityStudioProps {
  sonicIdentity: SonicIdentity;
  brandName: string;
  onRequestCritique: (targetText: string, contextRole: string) => void;
}

export const SonicIdentityStudio: React.FC<SonicIdentityStudioProps> = ({
  sonicIdentity,
  brandName,
  onRequestCritique,
}) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1.0);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceIndex, setSelectedVoiceIndex] = useState<number>(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Load browser speech synthesis voices
  useEffect(() => {
    const updateVoices = () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        const voices = window.speechSynthesis.getVoices();
        if (voices.length > 0) {
          setAvailableVoices(voices);
          // Try to select an English voice with natural tone
          const englishIndex = voices.findIndex((v) => v.lang.startsWith('en') && !v.name.includes('Google'));
          if (englishIndex !== -1) setSelectedVoiceIndex(englishIndex);
        }
      }
    };

    updateVoices();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = updateVoices;
    }

    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Animated Audio Visualizer loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let step = 0;
    const draw = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const barCount = 36;
      const barWidth = width / barCount - 2;

      for (let i = 0; i < barCount; i++) {
        // Calculate dynamic wave height based on playing state
        const wave = isPlaying
          ? Math.sin(step * 0.15 + i * 0.3) * 0.4 + 0.6
          : Math.sin(step * 0.05 + i * 0.2) * 0.1 + 0.15;
        const barHeight = wave * (height * 0.75);

        const x = i * (barWidth + 2);
        const y = (height - barHeight) / 2;

        ctx.fillStyle = isPlaying
          ? i % 2 === 0
            ? 'rgba(217, 119, 6, 0.85)' // Warm amber
            : 'rgba(243, 244, 246, 0.75)'
          : 'rgba(115, 115, 115, 0.35)';

        ctx.fillRect(x, y, barWidth, barHeight);
      }

      step += 1;
      animationFrameRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying]);

  const handlePlayVoiceover = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      alert('Speech synthesis is not supported on this device.');
      return;
    }

    if (isPlaying) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(sonicIdentity.narrationScript);
    utterance.rate = playbackRate;
    utterance.pitch = 0.95; // Slightly lower, authoritative pitch

    if (availableVoices.length > 0 && availableVoices[selectedVoiceIndex]) {
      utterance.voice = availableVoices[selectedVoiceIndex];
    }

    utterance.onend = () => setIsPlaying(false);
    utterance.onerror = () => setIsPlaying(false);

    window.speechSynthesis.speak(utterance);
    setIsPlaying(true);
  };

  const handleStopVoiceover = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlaying(false);
  };

  return (
    <div className="space-y-12">
      {/* 01. Audio Architecture & Sonic Logo */}
      <section className="bg-neutral-900/30 rounded-xl border border-neutral-800/80 p-6 sm:p-8">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3 text-xs tracking-wider uppercase text-neutral-400">
            <span>01</span>
            <span aria-hidden="true">·</span>
            <span>Sonic Identity Architecture</span>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono text-neutral-400">
            <span>Key: {sonicIdentity.keySignature}</span>
            <span aria-hidden="true">·</span>
            <span>Tempo: {sonicIdentity.bpm} BPM</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Sonic Logo Description */}
          <div className="lg:col-span-7 space-y-4">
            <div>
              <div className="text-xs uppercase tracking-wider text-neutral-400 mb-1">
                3-Second Sonic Brand Mark
              </div>
              <h3 className="text-lg sm:text-xl font-semibold text-white tracking-tight">
                {sonicIdentity.sonicLogoDescription}
              </h3>
            </div>

            <div className="text-xs text-neutral-400 font-mono">
              Recommended Persona: <span className="text-neutral-200">{sonicIdentity.recommendedVoicePersona}</span>
            </div>

            {/* Acoustic Textures */}
            <div>
              <div className="text-xs uppercase tracking-wider text-neutral-500 mb-2 font-mono">
                Acoustic Textural Layers
              </div>
              <div className="flex flex-wrap gap-2">
                {sonicIdentity.textures.map((texture: string, idx: number) => (
                  <span
                    key={idx}
                    className="px-3 py-1 bg-neutral-900 border border-neutral-800 text-neutral-300 rounded-lg text-xs"
                  >
                    {texture}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Visual Frequency Canvas */}
          <div className="lg:col-span-5 bg-neutral-950 p-4 rounded-xl border border-neutral-800 flex flex-col items-center justify-center">
            <div className="text-[11px] font-mono text-neutral-500 uppercase tracking-wider mb-2 flex items-center gap-2">
              <Activity className="w-3.5 h-3.5 text-amber-500/80" />
              <span>Real-Time Frequency Monitor</span>
            </div>
            <canvas
              ref={canvasRef}
              width={280}
              height={70}
              className="w-full max-w-[280px] h-[70px]"
            />
            <div className="text-[10px] text-neutral-600 font-mono mt-2">
              20Hz — 20kHz Dynamic Master Spectrum
            </div>
          </div>
        </div>
      </section>

      {/* 02. Voiceover Narration Studio */}
      <section className="bg-neutral-900/30 rounded-xl border border-neutral-800/80 p-6 sm:p-8">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3 text-xs tracking-wider uppercase text-neutral-400">
            <span>02</span>
            <span aria-hidden="true">·</span>
            <span>Director's Script & Audition Studio</span>
          </div>

          <button
            onClick={() => onRequestCritique(sonicIdentity.narrationScript, 'Audio Script')}
            className="inline-flex items-center gap-1.5 px-3 py-1 text-xs text-neutral-300 hover:text-white bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded-lg transition-colors cursor-pointer"
          >
            <MessageSquareCode className="w-3.5 h-3.5" />
            <span>Critique Voiceover Copy</span>
          </button>
        </div>

        {/* Script Display */}
        <div className="p-6 bg-neutral-950/80 rounded-xl border border-neutral-800/80 mb-6">
          <div className="text-xs uppercase tracking-wider text-neutral-500 mb-2 font-mono flex items-center gap-2">
            <Mic className="w-3.5 h-3.5 text-amber-400" />
            <span>Teleprompter Script ({brandName})</span>
          </div>
          <p className="text-base sm:text-lg text-neutral-200 leading-relaxed font-normal italic">
            "{sonicIdentity.narrationScript}"
          </p>
        </div>

        {/* Player Controls Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-neutral-900/60 rounded-xl border border-neutral-800">
          <div className="flex items-center gap-3">
            <button
              onClick={handlePlayVoiceover}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-neutral-950 bg-white hover:bg-neutral-200 rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-4 h-4 fill-current" />
                  <span>Pause Audition</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>Listen to Voiceover</span>
                </>
              )}
            </button>

            {isPlaying && (
              <button
                onClick={handleStopVoiceover}
                className="p-2 text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
                title="Reset"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Voice Selector & Speed Slider */}
          <div className="flex flex-wrap items-center gap-4 text-xs">
            {availableVoices.length > 0 && (
              <div className="flex items-center gap-2">
                <span className="text-neutral-500">Voice:</span>
                <select
                  value={selectedVoiceIndex}
                  onChange={(e) => setSelectedVoiceIndex(Number(e.target.value))}
                  className="bg-neutral-950 border border-neutral-800 text-neutral-300 rounded px-2.5 py-1 text-xs outline-none focus:border-neutral-600 max-w-[160px] truncate"
                >
                  {availableVoices.map((v, i) => (
                    <option key={i} value={i}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="flex items-center gap-2">
              <span className="text-neutral-500">Cadence:</span>
              <input
                type="range"
                min="0.8"
                max="1.2"
                step="0.05"
                value={playbackRate}
                onChange={(e) => setPlaybackRate(Number(e.target.value))}
                className="w-20 accent-amber-500 cursor-pointer"
              />
              <span className="font-mono text-neutral-300 w-8">{playbackRate.toFixed(2)}x</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
