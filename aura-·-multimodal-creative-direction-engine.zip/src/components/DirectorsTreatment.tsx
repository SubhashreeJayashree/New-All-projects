import React, { useState } from 'react';
import { CampaignTreatment, ColorSwatch } from '../types/campaign';
import { Copy, Check, MessageSquareCode, Film, Palette, Compass, ShieldAlert, Sparkles } from 'lucide-react';

interface DirectorsTreatmentProps {
  treatment: CampaignTreatment;
  onRequestCritique: (targetText: string, contextRole: string) => void;
}

export const DirectorsTreatment: React.FC<DirectorsTreatmentProps> = ({
  treatment,
  onRequestCritique,
}) => {
  const [copiedHex, setCopiedHex] = useState<string | null>(null);

  const handleCopyHex = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 1800);
  };

  return (
    <div className="space-y-12">
      {/* 01. Manifesto & Creative Vision */}
      <section className="bg-neutral-900/30 rounded-xl border border-neutral-800/80 p-6 sm:p-8">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3 text-xs tracking-wider uppercase text-neutral-400">
            <span>01</span>
            <span aria-hidden="true">·</span>
            <span>Creative Director's Manifesto</span>
          </div>
          <button
            onClick={() => onRequestCritique(treatment.creativeManifesto, 'Creative Manifesto')}
            className="inline-flex items-center gap-1.5 px-3 py-1 text-xs text-neutral-300 hover:text-white bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded-lg transition-colors cursor-pointer"
          >
            <MessageSquareCode className="w-3.5 h-3.5" />
            <span>Critique Manifesto</span>
          </button>
        </div>

        <div className="mb-4">
          <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight text-white mb-2">
            {treatment.conceptTitle}
          </h2>
          <div className="text-base sm:text-lg italic text-neutral-300 font-light">
            "{treatment.tagline}"
          </div>
        </div>

        <div className="text-sm sm:text-base leading-relaxed text-neutral-300 max-w-4xl space-y-3 font-normal">
          <p>{treatment.creativeManifesto}</p>
        </div>
      </section>

      {/* 02. Emotional Vector Triad */}
      <section>
        <div className="flex items-center gap-3 text-xs tracking-wider uppercase text-neutral-400 mb-4">
          <span>02</span>
          <span aria-hidden="true">·</span>
          <span>Emotional Vector Triad</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-5 bg-neutral-900/40 rounded-xl border border-neutral-800/70">
            <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
              <span className="font-semibold uppercase tracking-wider text-rose-400/90">01. Societal Tension</span>
            </div>
            <div className="text-sm text-neutral-200 leading-relaxed font-medium">
              {treatment.emotionalVectors.tension}
            </div>
          </div>

          <div className="p-5 bg-neutral-900/40 rounded-xl border border-neutral-800/70">
            <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
              <span className="font-semibold uppercase tracking-wider text-amber-400/90">02. Cathartic Release</span>
            </div>
            <div className="text-sm text-neutral-200 leading-relaxed font-medium">
              {treatment.emotionalVectors.release}
            </div>
          </div>

          <div className="p-5 bg-neutral-900/40 rounded-xl border border-neutral-800/70">
            <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
              <span className="font-semibold uppercase tracking-wider text-emerald-400/90">03. Cultural Resonance</span>
            </div>
            <div className="text-sm text-neutral-200 leading-relaxed font-medium">
              {treatment.emotionalVectors.resonance}
            </div>
          </div>
        </div>
      </section>

      {/* 03. Color Science & Material Swatches */}
      <section>
        <div className="flex items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-3 text-xs tracking-wider uppercase text-neutral-400">
            <span>03</span>
            <span aria-hidden="true">·</span>
            <span>Color Science & Material Grammar</span>
          </div>
          <span className="text-xs text-neutral-500 font-mono">Click to copy hex</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
          {treatment.colorPalette.map((color: ColorSwatch, idx: number) => (
            <div
              key={idx}
              onClick={() => handleCopyHex(color.hex)}
              className="group p-3.5 bg-neutral-900/40 hover:bg-neutral-900/80 rounded-xl border border-neutral-800/80 transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div
                  className="w-full h-16 rounded-lg mb-3 border border-white/10 shadow-inner transition-transform group-hover:scale-[1.02]"
                  style={{ backgroundColor: color.hex }}
                />
                <div className="text-xs font-semibold text-neutral-200 truncate">{color.name}</div>
                <div className="text-[11px] text-neutral-400 font-mono mb-2">{color.role}</div>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-neutral-800/60 text-[11px] font-mono text-neutral-400">
                <span>{color.hex}</span>
                {copiedHex === color.hex ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5 text-neutral-600 group-hover:text-neutral-300" />
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 04. Cinematography Specification */}
      <section className="bg-neutral-900/30 rounded-xl border border-neutral-800/80 p-6 sm:p-8">
        <div className="flex items-center gap-3 text-xs tracking-wider uppercase text-neutral-400 mb-6">
          <span>04</span>
          <span aria-hidden="true">·</span>
          <span>Cinematography & Optical Signature</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-sm">
          <div>
            <div className="text-xs uppercase tracking-wider text-neutral-400 mb-1">Camera Sensor & Body</div>
            <div className="font-medium text-neutral-200">{treatment.cinematography.cameraGear}</div>
          </div>
          <div>
            <div className="text-xs uppercase tracking-wider text-neutral-400 mb-1">Lens Formulation</div>
            <div className="font-medium text-neutral-200">{treatment.cinematography.lensChoice}</div>
          </div>
          <div>
            <div className="text-xs uppercase tracking-wider text-neutral-400 mb-1">Aspect Ratio</div>
            <div className="font-mono text-neutral-200">{treatment.cinematography.aspectRatio}</div>
          </div>
          <div className="md:col-span-2">
            <div className="text-xs uppercase tracking-wider text-neutral-400 mb-1">Lighting Grammar</div>
            <div className="text-neutral-300 leading-relaxed">{treatment.cinematography.lightingScheme}</div>
          </div>
          <div>
            <div className="text-xs uppercase tracking-wider text-neutral-400 mb-1">Color Grading LUT</div>
            <div className="text-neutral-300 leading-relaxed">{treatment.cinematography.colorGradingLUT}</div>
          </div>
        </div>
      </section>

      {/* 05. Brand Discipline: Do's and Don'ts */}
      <section>
        <div className="flex items-center gap-3 text-xs tracking-wider uppercase text-neutral-400 mb-4">
          <span>05</span>
          <span aria-hidden="true">·</span>
          <span>Brand Discipline & Creative Guardrails</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Do's */}
          <div className="p-6 bg-neutral-900/40 rounded-xl border border-neutral-800/80">
            <div className="text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-4">
              Art Direction Directives (Do's)
            </div>
            <ul className="space-y-3 text-sm text-neutral-300">
              {treatment.campaignDeliverables.dosAndDonts.dos.map((item: string, idx: number) => (
                <li key={idx} className="flex items-start gap-2.5">
                  <span className="text-emerald-400 font-mono text-xs mt-0.5">✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Don'ts */}
          <div className="p-6 bg-neutral-900/40 rounded-xl border border-neutral-800/80">
            <div className="text-xs font-semibold uppercase tracking-wider text-rose-400 mb-4">
              Strict Brand Violations (Don'ts)
            </div>
            <ul className="space-y-3 text-sm text-neutral-300">
              {treatment.campaignDeliverables.dosAndDonts.donts.map((item: string, idx: number) => (
                <li key={idx} className="flex items-start gap-2.5">
                  <span className="text-rose-400 font-mono text-xs mt-0.5">✕</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};
