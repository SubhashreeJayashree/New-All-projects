import React, { useState } from 'react';
import { CampaignTreatment } from '../types/campaign';
import { Download, Copy, Check, FileText, Code2 } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  treatment: CampaignTreatment;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  treatment,
}) => {
  const [exportFormat, setExportFormat] = useState<'markdown' | 'json'>('markdown');
  const [isCopied, setIsCopied] = useState(false);

  if (!isOpen) return null;

  const markdownContent = `# ${treatment.conceptTitle}
**Brand:** ${treatment.brandName} (${treatment.industry})
**Tagline:** "${treatment.tagline}"
**Brand Archetype:** ${treatment.brandArchetype}

---

## 1. Creative Director's Manifesto
${treatment.creativeManifesto}

### Emotional Vectors
- **Societal Tension:** ${treatment.emotionalVectors.tension}
- **Cathartic Release:** ${treatment.emotionalVectors.release}
- **Cultural Resonance:** ${treatment.emotionalVectors.resonance}

---

## 2. Color Palette & Material Science
${treatment.colorPalette.map(c => `- **${c.name}** (\`${c.hex}\`) — ${c.role}: ${c.usage}`).join('\n')}

---

## 3. Cinematography Package
- **Camera Body & Sensor:** ${treatment.cinematography.cameraGear}
- **Lens Selection:** ${treatment.cinematography.lensChoice}
- **Aspect Ratio:** ${treatment.cinematography.aspectRatio}
- **Lighting Scheme:** ${treatment.cinematography.lightingScheme}
- **Color Grading LUT:** ${treatment.cinematography.colorGradingLUT}

---

## 4. Production Storyboard & Shot List
${treatment.storyboard.map(s => `### Scene ${s.sceneNumber}: ${s.shotName} (${s.durationSeconds}s)
- **Framing & Angle:** ${s.cameraAngle}
- **Lighting:** ${s.lighting}
- **Action:** ${s.action}
- **Visual Description:** ${s.visualDescription}
- **Audio Cue:** ${s.audioCue}
- **Voiceover:** "${s.voiceover}"
- **Composition:** ${s.compositionRule}
`).join('\n')}

---

## 5. Sonic Identity
- **Musical Key:** ${treatment.sonicIdentity.keySignature}
- **BPM:** ${treatment.sonicIdentity.bpm}
- **Textures:** ${treatment.sonicIdentity.textures.join(', ')}
- **Sonic Brand Mark:** ${treatment.sonicIdentity.sonicLogoDescription}
- **Voiceover Script:** "${treatment.sonicIdentity.narrationScript}"
- **Voice Persona:** ${treatment.sonicIdentity.recommendedVoicePersona}

---

## 6. Campaign Deliverables
- **Key Visual Headline:** ${treatment.campaignDeliverables.keyVisualHeadline}
- **Key Visual Subtext:** ${treatment.campaignDeliverables.keyVisualSubtext}
- **OOH Billboard Copy:** ${treatment.campaignDeliverables.billboardCopy}
- **Social Reel Hook:** "${treatment.campaignDeliverables.socialReelScript.hook}"
- **Social Reel Body:** "${treatment.campaignDeliverables.socialReelScript.body}"
- **Social Reel CTA:** "${treatment.campaignDeliverables.socialReelScript.cta}"

---
*Generated via AURA · Multimodal Creative Direction Engine*
`;

  const jsonContent = JSON.stringify(treatment, null, 2);

  const displayContent = exportFormat === 'markdown' ? markdownContent : jsonContent;

  const handleCopy = () => {
    navigator.clipboard.writeText(displayContent);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleDownload = () => {
    const filename = `${treatment.brandName.toLowerCase().replace(/\s+/g, '_')}_campaign_deck.${exportFormat === 'markdown' ? 'md' : 'json'}`;
    const blob = new Blob([displayContent], { type: exportFormat === 'markdown' ? 'text/markdown' : 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-neutral-800">
          <div>
            <div className="text-xs font-mono uppercase text-neutral-400 mb-1">
              Campaign Deck & Asset Manifest
            </div>
            <h2 className="text-lg font-semibold text-white">
              Export Creative Treatment ({treatment.brandName})
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-neutral-950 rounded-lg border border-neutral-800 text-xs">
              <button
                onClick={() => setExportFormat('markdown')}
                className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 cursor-pointer ${
                  exportFormat === 'markdown' ? 'bg-neutral-800 text-white' : 'text-neutral-400'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Markdown Deck</span>
              </button>
              <button
                onClick={() => setExportFormat('json')}
                className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 cursor-pointer ${
                  exportFormat === 'json' ? 'bg-neutral-800 text-white' : 'text-neutral-400'
                }`}
              >
                <Code2 className="w-3.5 h-3.5" />
                <span>JSON Schema</span>
              </button>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-sm"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Code Content Viewport */}
        <div className="flex-1 p-6 overflow-y-auto bg-neutral-950">
          <pre className="text-xs font-mono text-neutral-300 whitespace-pre-wrap leading-relaxed selection:bg-neutral-800">
            {displayContent}
          </pre>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between p-4 sm:p-6 border-t border-neutral-800 bg-neutral-900/60">
          <span className="text-xs text-neutral-500 font-mono">
            Ready for client presentation & production teams
          </span>

          <div className="flex items-center gap-3">
            <button
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-neutral-200 bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
            >
              {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{isCopied ? 'Copied to Clipboard' : 'Copy All'}</span>
            </button>
            <button
              onClick={handleDownload}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-neutral-950 bg-white hover:bg-neutral-200 rounded-lg transition-colors shadow-sm cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
