import React, { useState } from 'react';
import { Sparkles, Loader2, ArrowRight } from 'lucide-react';

interface BriefModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSynthesize: (briefData: {
    brandName: string;
    industry: string;
    brief: string;
    archetype: string;
    aestheticTone: string;
  }) => Promise<void>;
  isLoading: boolean;
}

export const BriefModal: React.FC<BriefModalProps> = ({
  isOpen,
  onClose,
  onSynthesize,
  isLoading,
}) => {
  const [brandName, setBrandName] = useState('');
  const [industry, setIndustry] = useState('Luxury & Technology');
  const [brief, setBrief] = useState('');
  const [archetype, setArchetype] = useState('The Creator');
  const [aestheticTone, setAestheticTone] = useState('Neo-Futuristic Architectural & Chiaroscuro');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!brandName.trim() || !brief.trim()) return;
    await onSynthesize({
      brandName: brandName.trim(),
      industry,
      brief: brief.trim(),
      archetype,
      aestheticTone,
    });
    onClose();
  };

  const handleQuickFill = (example: 'watch' | 'vehicle' | 'space') => {
    if (example === 'watch') {
      setBrandName('KAIROS HOROLOGY');
      setIndustry('High-End Horology');
      setBrief('Titanium chronometer forged from meteorite fragments, engineered for deep abyssal exploration and celestial navigation.');
      setArchetype('The Explorer & The Sage');
      setAestheticTone('Monolithic Titanium & Deep Abyss Blue');
    } else if (example === 'vehicle') {
      setBrandName('AURA ELECTRIC');
      setIndustry('Clean Hyper-Mobility');
      setBrief('Silent carbon-monocoque electric grand tourer with adaptive aerodynamic surfaces and raw linen interior.');
      setArchetype('The Magician & The Outlaw');
      setAestheticTone('Nordic Minimalist Twilight & Amber Streaks');
    } else {
      setBrandName('SOLARIS LABS');
      setIndustry('Bio-Acoustic Wellness');
      setBrief('Organic ceramic home sound sculpture emitting psycho-acoustic frequency baths tailored to circadian rhythms.');
      setArchetype('The Caregiver & The Creator');
      setAestheticTone('Warm Travertine Limestone & Morning Sunbeam');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-xl w-full p-6 sm:p-8 shadow-2xl relative">
        <button
          onClick={onClose}
          disabled={isLoading}
          className="absolute top-6 right-6 text-neutral-400 hover:text-white transition-colors cursor-pointer text-sm"
        >
          ✕
        </button>

        <div className="flex items-center gap-2.5 text-xs font-mono uppercase tracking-wider text-amber-500 mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Multimodal Campaign Brief Ingestion</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-semibold text-white tracking-tight mb-2">
          Commission Creative Direction
        </h2>
        <p className="text-xs text-neutral-400 mb-6 leading-relaxed">
          Input your product specs or narrative brief. The multimodal engine will generate an end-to-end campaign suite including cinematic storyboards, color science, and sonic identity.
        </p>

        {/* Quick Fill Starters */}
        <div className="mb-6">
          <div className="text-[11px] font-mono uppercase text-neutral-400 mb-2">
            Quick-Fill Exemplar Briefs
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => handleQuickFill('watch')}
              className="px-2.5 py-1 text-xs bg-neutral-950 hover:bg-neutral-800 text-neutral-300 rounded border border-neutral-800 transition-colors cursor-pointer"
            >
              Horology Timepiece
            </button>
            <button
              type="button"
              onClick={() => handleQuickFill('vehicle')}
              className="px-2.5 py-1 text-xs bg-neutral-950 hover:bg-neutral-800 text-neutral-300 rounded border border-neutral-800 transition-colors cursor-pointer"
            >
              Electric Grand Tourer
            </button>
            <button
              type="button"
              onClick={() => handleQuickFill('space')}
              className="px-2.5 py-1 text-xs bg-neutral-950 hover:bg-neutral-800 text-neutral-300 rounded border border-neutral-800 transition-colors cursor-pointer"
            >
              Acoustic Architecture
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-neutral-300 font-medium mb-1.5">
                Brand / Product Name
              </label>
              <input
                type="text"
                required
                value={brandName}
                onChange={(e) => setBrandName(e.target.value)}
                placeholder="e.g. VANGUARD AUDIO"
                className="w-full bg-neutral-950 border border-neutral-800 focus:border-neutral-600 rounded-lg px-3.5 py-2.5 text-neutral-200 placeholder-neutral-600 outline-none text-xs"
              />
            </div>

            <div>
              <label className="block text-neutral-300 font-medium mb-1.5">
                Industry Category
              </label>
              <input
                type="text"
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                placeholder="e.g. Fine Watchmaking"
                className="w-full bg-neutral-950 border border-neutral-800 focus:border-neutral-600 rounded-lg px-3.5 py-2.5 text-neutral-200 placeholder-neutral-600 outline-none text-xs"
              />
            </div>
          </div>

          <div>
            <label className="block text-neutral-300 font-medium mb-1.5">
              Creative Brief & Core Proposition
            </label>
            <textarea
              required
              rows={3}
              value={brief}
              onChange={(e) => setBrief(e.target.value)}
              placeholder="Describe the product, its origin, materials, or the emotional transformation it offers to users..."
              className="w-full bg-neutral-950 border border-neutral-800 focus:border-neutral-600 rounded-lg p-3.5 text-neutral-200 placeholder-neutral-600 outline-none text-xs leading-relaxed"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-neutral-300 font-medium mb-1.5">
                Brand Archetype
              </label>
              <select
                value={archetype}
                onChange={(e) => setArchetype(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 focus:border-neutral-600 rounded-lg px-3.5 py-2.5 text-neutral-200 outline-none text-xs"
              >
                <option value="The Creator">The Creator (Originality & Vision)</option>
                <option value="The Outlaw">The Outlaw (Disruption & Sovereignty)</option>
                <option value="The Magician">The Magician (Transformation & Wonder)</option>
                <option value="The Explorer">The Explorer (Freedom & Discovery)</option>
                <option value="The Sage">The Sage (Wisdom & Discernment)</option>
                <option value="The Ruler">The Ruler (Power & Preeminence)</option>
              </select>
            </div>

            <div>
              <label className="block text-neutral-300 font-medium mb-1.5">
                Aesthetic Direction
              </label>
              <input
                type="text"
                value={aestheticTone}
                onChange={(e) => setAestheticTone(e.target.value)}
                placeholder="e.g. Dark Chiaroscuro & Titanium"
                className="w-full bg-neutral-950 border border-neutral-800 focus:border-neutral-600 rounded-lg px-3.5 py-2.5 text-neutral-200 outline-none text-xs"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-neutral-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="px-4 py-2.5 rounded-lg text-neutral-400 hover:text-white transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading || !brandName || !brief}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-white hover:bg-neutral-200 disabled:opacity-50 text-neutral-950 font-semibold rounded-lg shadow-sm transition-all cursor-pointer"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Synthesizing Treatment...</span>
                </>
              ) : (
                <>
                  <span>Synthesize Campaign</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
