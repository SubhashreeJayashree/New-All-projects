import React, { useState } from 'react';
import { StoryboardShot } from '../types/campaign';
import { Camera, Clock, Volume2, Mic, Maximize2, MessageSquareCode, Check, Copy } from 'lucide-react';

interface CinematicStoryboardProps {
  storyboard: StoryboardShot[];
  onRequestCritique: (targetText: string, contextRole: string) => void;
}

export const CinematicStoryboard: React.FC<CinematicStoryboardProps> = ({
  storyboard,
  onRequestCritique,
}) => {
  const [selectedShotIndex, setSelectedShotIndex] = useState<number | null>(null);
  const [copiedPromptIndex, setCopiedPromptIndex] = useState<number | null>(null);
  const [activeOverlay, setActiveOverlay] = useState<'none' | 'thirds' | 'crosshair'>('thirds');

  const selectedShot = selectedShotIndex !== null ? storyboard[selectedShotIndex] : null;

  const handleCopyPrompt = (shot: StoryboardShot, index: number) => {
    const fullPrompt = `Cinematic ${shot.cameraAngle}, ${shot.visualDescription}. Lighting: ${shot.lighting}. Shot on 35mm anamorphic, photorealistic 8k commercial film still.`;
    navigator.clipboard.writeText(fullPrompt);
    setCopiedPromptIndex(index);
    setTimeout(() => setCopiedPromptIndex(null), 1800);
  };

  return (
    <div className="space-y-8">
      {/* Section Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 text-xs tracking-wider uppercase text-neutral-400 mb-1">
            <span>Production Timeline</span>
            <span aria-hidden="true">·</span>
            <span>Shot-by-Shot Storyboard</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-semibold text-white tracking-tight">
            Cinematic Narrative & Shot List
          </h2>
        </div>

        <div className="flex items-center gap-3 text-xs text-neutral-400 font-mono">
          <span>{storyboard.length} Production Frames</span>
          <span aria-hidden="true">·</span>
          <span>
            Total Run: {storyboard.reduce((acc, s) => acc + s.durationSeconds, 0).toFixed(1)}s
          </span>
        </div>
      </div>

      {/* Storyboard Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
        {storyboard.map((shot: StoryboardShot, index: number) => (
          <div
            key={shot.sceneNumber}
            className="group bg-neutral-900/40 rounded-xl border border-neutral-800/80 hover:border-neutral-700/80 transition-all overflow-hidden flex flex-col justify-between"
          >
            {/* Visual Frame Container */}
            <div className="relative aspect-16/9 bg-neutral-950 overflow-hidden cursor-pointer" onClick={() => setSelectedShotIndex(index)}>
              {shot.imageFallback ? (
                <img
                  src={shot.imageFallback}
                  alt={shot.shotName}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-neutral-900 to-neutral-950">
                  <Camera className="w-8 h-8 text-neutral-600 mb-2" />
                  <div className="text-xs text-neutral-400 font-mono">{shot.cameraAngle}</div>
                </div>
              )}

              {/* Composition Guideline Overlay */}
              <div className="absolute inset-0 pointer-events-none opacity-40 group-hover:opacity-75 transition-opacity grid grid-cols-3 grid-rows-3">
                <div className="border-r border-b border-white/20" />
                <div className="border-r border-b border-white/20" />
                <div className="border-b border-white/20" />
                <div className="border-r border-b border-white/20" />
                <div className="border-r border-b border-white/20" />
                <div className="border-b border-white/20" />
                <div className="border-r border-b border-white/20" />
                <div className="border-r border-b border-white/20" />
                <div />
              </div>

              {/* Scrim */}
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/90 via-transparent to-neutral-950/40" />

              {/* Frame Tags */}
              <div className="absolute top-3 left-3 right-3 flex items-center justify-between text-[11px] font-mono">
                <span className="bg-neutral-950/80 backdrop-blur-md px-2 py-0.5 rounded text-neutral-200 border border-neutral-800">
                  SCENE {String(shot.sceneNumber).padStart(2, '0')}
                </span>
                <span className="bg-neutral-950/80 backdrop-blur-md px-2 py-0.5 rounded text-neutral-300 border border-neutral-800 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-neutral-400" />
                  <span>{shot.durationSeconds.toFixed(1)}s</span>
                </span>
              </div>

              {/* Bottom Frame Kicker */}
              <div className="absolute bottom-3 left-3 right-3">
                <h3 className="text-sm font-semibold text-white drop-shadow-sm mb-0.5 truncate">
                  {shot.shotName}
                </h3>
                <div className="text-[11px] text-neutral-300 font-mono truncate">
                  {shot.cameraAngle}
                </div>
              </div>

              {/* Hover expand indicator */}
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-neutral-900/90 rounded-lg border border-neutral-700">
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span>Inspect Frame</span>
                </span>
              </div>
            </div>

            {/* Shot Art Direction Details */}
            <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
              <div className="space-y-3">
                <div>
                  <div className="text-[11px] uppercase tracking-wider text-neutral-500 mb-1 font-medium">
                    Visual & Action Description
                  </div>
                  <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
                    {shot.visualDescription}
                  </p>
                </div>

                <div className="pt-2 border-t border-neutral-800/60 grid grid-cols-1 gap-2 text-xs">
                  <div className="flex items-start gap-2 text-neutral-400">
                    <Volume2 className="w-3.5 h-3.5 text-neutral-500 shrink-0 mt-0.5" />
                    <span className="leading-snug">{shot.audioCue}</span>
                  </div>
                  {shot.voiceover && (
                    <div className="flex items-start gap-2 text-neutral-200">
                      <Mic className="w-3.5 h-3.5 text-amber-400/80 shrink-0 mt-0.5" />
                      <span className="italic leading-snug">"{shot.voiceover}"</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Shot Actions */}
              <div className="pt-3 border-t border-neutral-800/60 flex items-center justify-between gap-2 text-xs">
                <span className="text-[11px] font-mono text-neutral-400 truncate max-w-[160px]">
                  {shot.compositionRule}
                </span>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => handleCopyPrompt(shot, index)}
                    className="p-1.5 text-neutral-400 hover:text-neutral-200 bg-neutral-900 hover:bg-neutral-800 rounded border border-neutral-800 transition-colors cursor-pointer"
                    title="Copy Image Generation Prompt"
                  >
                    {copiedPromptIndex === index ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                  <button
                    onClick={() => onRequestCritique(shot.visualDescription, `Scene ${shot.sceneNumber} - ${shot.shotName}`)}
                    className="p-1.5 text-neutral-400 hover:text-neutral-200 bg-neutral-900 hover:bg-neutral-800 rounded border border-neutral-800 transition-colors cursor-pointer"
                    title="Critique Shot"
                  >
                    <MessageSquareCode className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Frame Inspector Modal */}
      {selectedShot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-4 sm:p-6 border-b border-neutral-800">
              <div>
                <div className="text-xs uppercase tracking-wider text-neutral-400 font-mono">
                  Scene {String(selectedShot.sceneNumber).padStart(2, '0')} · Cinematography Inspector
                </div>
                <h3 className="text-lg font-semibold text-white">{selectedShot.shotName}</h3>
              </div>
              <button
                onClick={() => setSelectedShotIndex(null)}
                className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Modal Image Viewport */}
            <div className="relative aspect-16/9 bg-neutral-950 border-b border-neutral-800 overflow-hidden">
              {selectedShot.imageFallback ? (
                <img
                  src={selectedShot.imageFallback}
                  alt={selectedShot.shotName}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Camera className="w-12 h-12 text-neutral-600" />
                </div>
              )}

              {/* Overlays */}
              {activeOverlay === 'thirds' && (
                <div className="absolute inset-0 pointer-events-none grid grid-cols-3 grid-rows-3">
                  <div className="border-r border-b border-amber-400/40" />
                  <div className="border-r border-b border-amber-400/40" />
                  <div className="border-b border-amber-400/40" />
                  <div className="border-r border-b border-amber-400/40" />
                  <div className="border-r border-b border-amber-400/40" />
                  <div className="border-b border-amber-400/40" />
                  <div className="border-r border-b border-amber-400/40" />
                  <div className="border-r border-b border-amber-400/40" />
                  <div />
                </div>
              )}
              {activeOverlay === 'crosshair' && (
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                  <div className="w-12 h-12 border border-white/50 rounded-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-white/70 rounded-full" />
                  </div>
                </div>
              )}

              {/* Overlay Toggle Bar */}
              <div className="absolute bottom-3 right-3 flex items-center gap-1.5 bg-neutral-950/85 backdrop-blur-md p-1 rounded-lg border border-neutral-800 text-xs">
                <button
                  onClick={() => setActiveOverlay('none')}
                  className={`px-2 py-1 rounded cursor-pointer ${
                    activeOverlay === 'none' ? 'bg-neutral-800 text-white' : 'text-neutral-400'
                  }`}
                >
                  Clean
                </button>
                <button
                  onClick={() => setActiveOverlay('thirds')}
                  className={`px-2 py-1 rounded cursor-pointer ${
                    activeOverlay === 'thirds' ? 'bg-neutral-800 text-white' : 'text-neutral-400'
                  }`}
                >
                  Rule of Thirds
                </button>
                <button
                  onClick={() => setActiveOverlay('crosshair')}
                  className={`px-2 py-1 rounded cursor-pointer ${
                    activeOverlay === 'crosshair' ? 'bg-neutral-800 text-white' : 'text-neutral-400'
                  }`}
                >
                  Center Axis
                </button>
              </div>
            </div>

            {/* Modal Body Info */}
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800/80">
                  <div className="text-neutral-500 mb-1 font-mono">Camera Angle & Framing</div>
                  <div className="font-semibold text-neutral-200">{selectedShot.cameraAngle}</div>
                </div>
                <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800/80">
                  <div className="text-neutral-500 mb-1 font-mono">Lighting Setup</div>
                  <div className="font-semibold text-neutral-200">{selectedShot.lighting}</div>
                </div>
              </div>

              <div>
                <div className="text-xs uppercase tracking-wider text-neutral-500 mb-1 font-mono">
                  Visual Direction
                </div>
                <p className="text-sm text-neutral-200 leading-relaxed">
                  {selectedShot.visualDescription}
                </p>
              </div>

              <div>
                <div className="text-xs uppercase tracking-wider text-neutral-500 mb-1 font-mono">
                  Audio & Voiceover
                </div>
                <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800/80 space-y-1.5 text-xs">
                  <div className="text-neutral-400">Audio Cue: {selectedShot.audioCue}</div>
                  {selectedShot.voiceover && (
                    <div className="text-amber-300 font-medium italic">
                      Voiceover: "{selectedShot.voiceover}"
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-4 border-t border-neutral-800 flex justify-end gap-3">
                <button
                  onClick={() => {
                    handleCopyPrompt(selectedShot, selectedShot.sceneNumber);
                  }}
                  className="px-4 py-2 text-xs font-medium text-neutral-200 bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
                >
                  Copy Studio Prompt
                </button>
                <button
                  onClick={() => {
                    onRequestCritique(selectedShot.visualDescription, `Scene ${selectedShot.sceneNumber}`);
                    setSelectedShotIndex(null);
                  }}
                  className="px-4 py-2 text-xs font-medium text-neutral-950 bg-white hover:bg-neutral-200 rounded-lg transition-colors cursor-pointer"
                >
                  Critique Scene with Director
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
