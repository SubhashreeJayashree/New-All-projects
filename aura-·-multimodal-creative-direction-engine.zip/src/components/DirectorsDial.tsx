import React, { useState } from 'react';
import { DirectorDials, DirectorCritique } from '../types/campaign';
import { Sliders, RefreshCw, Sparkles, MessageSquareCode, CheckCircle2 } from 'lucide-react';

interface DirectorsDialProps {
  dials: DirectorDials;
  onUpdateDials: (newDials: DirectorDials) => void;
  brandName: string;
  activeCritique: { targetText: string; contextRole: string } | null;
  onCloseCritique: () => void;
}

export const DirectorsDial: React.FC<DirectorsDialProps> = ({
  dials,
  onUpdateDials,
  brandName,
  activeCritique,
  onCloseCritique,
}) => {
  const [critiqueResult, setCritiqueResult] = useState<DirectorCritique | null>(null);
  const [isLoadingCritique, setIsLoadingCritique] = useState<boolean>(false);

  const handleSliderChange = (key: keyof DirectorDials, value: number) => {
    onUpdateDials({
      ...dials,
      [key]: value,
    });
  };

  const handleResetDials = () => {
    onUpdateDials({
      temperature: 50,
      avantGarde: 65,
      pacing: 45,
    });
  };

  const runCritique = async (text: string, role: string) => {
    setIsLoadingCritique(true);
    setCritiqueResult(null);

    try {
      const response = await fetch('/api/critique-creative', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetText: text,
          contextRole: role,
          temperatureDial: dials.temperature,
          avantGardeDial: dials.avantGarde,
          brandName,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setCritiqueResult({
          directorVerdict: data.directorVerdict,
          suggestedRevision: data.suggestedRevision,
          cinematicNote: data.cinematicNote,
        });
      }
    } catch (err) {
      console.error('Failed to run critique:', err);
    } finally {
      setIsLoadingCritique(false);
    }
  };

  // If activeCritique changes, trigger critique automatically
  React.useEffect(() => {
    if (activeCritique) {
      runCritique(activeCritique.targetText, activeCritique.contextRole);
    }
  }, [activeCritique]);

  return (
    <aside className="bg-neutral-900/60 rounded-xl border border-neutral-800/80 p-5 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-neutral-300">
          <Sliders className="w-3.5 h-3.5 text-amber-500/90" />
          <span>Director's Tuning Dials</span>
        </div>
        <button
          onClick={handleResetDials}
          className="text-xs text-neutral-500 hover:text-neutral-300 transition-colors flex items-center gap-1 cursor-pointer"
          title="Reset to default stance"
        >
          <RefreshCw className="w-3 h-3" />
          <span>Reset</span>
        </button>
      </div>

      {/* Dial 1: Temperature */}
      <div className="space-y-1.5 text-xs">
        <div className="flex justify-between items-center text-neutral-400">
          <span>Brand Temperature</span>
          <span className="font-mono text-neutral-200">{dials.temperature}%</span>
        </div>
        <input
          type="range"
          min="0"
          max="100"
          value={dials.temperature}
          onChange={(e) => handleSliderChange('temperature', Number(e.target.value))}
          className="w-full accent-amber-500 cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-neutral-500 font-mono">
          <span>Cold Minimalist</span>
          <span>Warm Organic</span>
        </div>
      </div>

      {/* Dial 2: Avant-Garde */}
      <div className="space-y-1.5 text-xs">
        <div className="flex justify-between items-center text-neutral-400">
          <span>Artistic Stance</span>
          <span className="font-mono text-neutral-200">{dials.avantGarde}%</span>
        </div>
        <input
          type="range"
          min="0"
          max="100"
          value={dials.avantGarde}
          onChange={(e) => handleSliderChange('avantGarde', Number(e.target.value))}
          className="w-full accent-amber-500 cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-neutral-500 font-mono">
          <span>Commercial Clean</span>
          <span>Radical Avant-Garde</span>
        </div>
      </div>

      {/* Dial 3: Pacing */}
      <div className="space-y-1.5 text-xs">
        <div className="flex justify-between items-center text-neutral-400">
          <span>Cinematic Velocity</span>
          <span className="font-mono text-neutral-200">{dials.pacing}%</span>
        </div>
        <input
          type="range"
          min="0"
          max="100"
          value={dials.pacing}
          onChange={(e) => handleSliderChange('pacing', Number(e.target.value))}
          className="w-full accent-amber-500 cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-neutral-500 font-mono">
          <span>Contemplative Slow-Burn</span>
          <span>Kinetic Rapid-Cut</span>
        </div>
      </div>

      {/* Dynamic Stance Summary */}
      <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800/80 text-[11px] text-neutral-400 font-mono space-y-1">
        <div className="text-neutral-500 uppercase tracking-wider text-[10px]">Active Aesthetic Profile</div>
        <div className="text-neutral-200">
          {dials.temperature < 40 ? 'Monolithic Cryo-Modernism' : dials.temperature > 65 ? 'Tactile Wabi-Sabi Warmth' : 'Tempered Architectural Neutral'}
        </div>
        <div className="text-amber-400/90">
          {dials.avantGarde > 70 ? 'Museum-Grade Editorial' : dials.avantGarde < 35 ? 'Broad Mass-Market Appeal' : 'Elevated Commercial Tier'}
        </div>
      </div>

      {/* Live Critique Drawer if requested */}
      {activeCritique && (
        <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-800 space-y-3 animate-in fade-in duration-200">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-neutral-300 flex items-center gap-1.5">
              <MessageSquareCode className="w-3.5 h-3.5 text-amber-400" />
              <span>Director's Critique</span>
            </span>
            <button
              onClick={onCloseCritique}
              className="text-neutral-500 hover:text-neutral-300 text-xs cursor-pointer"
            >
              ✕
            </button>
          </div>

          <div className="text-[11px] text-neutral-500 font-mono truncate">
            Target: {activeCritique.contextRole}
          </div>

          {isLoadingCritique ? (
            <div className="py-4 text-center text-xs text-neutral-400 animate-pulse font-mono">
              Analyzing against current dials...
            </div>
          ) : critiqueResult ? (
            <div className="space-y-3 text-xs">
              <div>
                <div className="text-[10px] font-mono uppercase text-neutral-500 mb-0.5">Appraisal</div>
                <p className="text-neutral-200 leading-relaxed font-medium">
                  {critiqueResult.directorVerdict}
                </p>
              </div>

              <div>
                <div className="text-[10px] font-mono uppercase text-amber-500 mb-0.5">Suggested Revision</div>
                <div className="p-2.5 bg-neutral-900 rounded border border-neutral-800 text-amber-200 font-serif italic text-xs leading-snug">
                  {critiqueResult.suggestedRevision}
                </div>
              </div>

              <div>
                <div className="text-[10px] font-mono uppercase text-neutral-500 mb-0.5">Art Direction Note</div>
                <p className="text-neutral-400 leading-snug text-[11px]">
                  {critiqueResult.cinematicNote}
                </p>
              </div>
            </div>
          ) : null}
        </div>
      )}
    </aside>
  );
};
