import React, { useState } from 'react';
import { CampaignTreatment } from '../types/campaign';
import { Smartphone, Monitor, Square, Presentation, Copy, Check, MessageSquareCode } from 'lucide-react';

interface MultiFormatMatrixProps {
  treatment: CampaignTreatment;
  onRequestCritique: (targetText: string, contextRole: string) => void;
}

export const MultiFormatMatrix: React.FC<MultiFormatMatrixProps> = ({
  treatment,
  onRequestCritique,
}) => {
  const [activeFormat, setActiveFormat] = useState<'all' | '16x9' | '9x16' | '1x1' | 'ooh'>('all');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1800);
  };

  const { campaignDeliverables, brandName, heroImage } = treatment;

  return (
    <div className="space-y-8">
      {/* Header & Filter Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 text-xs tracking-wider uppercase text-neutral-400 mb-1">
            <span>Multi-Channel Syndication</span>
            <span aria-hidden="true">·</span>
            <span>Omnichannel Format Adaptation</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-semibold text-white tracking-tight">
            Production Deliverables Matrix
          </h2>
        </div>

        {/* Format Selector Tabs */}
        <div className="flex items-center gap-1 p-1 bg-neutral-900 rounded-lg border border-neutral-800 text-xs">
          <button
            onClick={() => setActiveFormat('all')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              activeFormat === 'all' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            All Formats
          </button>
          <button
            onClick={() => setActiveFormat('16x9')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              activeFormat === '16x9' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            16:9 Key Visual
          </button>
          <button
            onClick={() => setActiveFormat('9x16')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              activeFormat === '9x16' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            9:16 Vertical Reel
          </button>
          <button
            onClick={() => setActiveFormat('1x1')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              activeFormat === '1x1' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            1:1 Editorial Feed
          </button>
          <button
            onClick={() => setActiveFormat('ooh')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              activeFormat === 'ooh' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            OOH Billboard
          </button>
        </div>
      </div>

      {/* Grid of Format Deliverables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* 1. 16:9 Cinema / Key Visual Banner */}
        {(activeFormat === 'all' || activeFormat === '16x9') && (
          <div className="bg-neutral-900/40 rounded-xl border border-neutral-800/80 overflow-hidden flex flex-col justify-between">
            <div className="p-4 border-b border-neutral-800/80 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-neutral-300 font-medium">
                <Monitor className="w-4 h-4 text-amber-500/80" />
                <span>16:9 Cinematic Key Visual / Website Hero</span>
              </div>
              <button
                onClick={() => handleCopy(campaignDeliverables.keyVisualHeadline, 'kv-headline')}
                className="text-neutral-400 hover:text-neutral-200 transition-colors flex items-center gap-1 cursor-pointer"
              >
                {copiedKey === 'kv-headline' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="text-[11px] font-mono">Copy Copy</span>
              </button>
            </div>

            {/* Visual Canvas */}
            <div className="relative aspect-16/9 bg-neutral-950 overflow-hidden group">
              <img
                src={heroImage}
                alt="16:9 Key Visual"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/90 via-neutral-950/20 to-transparent" />
              
              <div className="absolute bottom-5 left-5 right-5">
                <div className="text-[10px] font-mono tracking-widest uppercase text-amber-400/90 mb-1">
                  {brandName} · GLOBAL CAMPAIGN
                </div>
                <h3 className="text-lg sm:text-xl font-bold tracking-tight text-white mb-1">
                  {campaignDeliverables.keyVisualHeadline}
                </h3>
                <p className="text-xs text-neutral-300 max-w-lg">
                  {campaignDeliverables.keyVisualSubtext}
                </p>
              </div>
            </div>

            <div className="p-4 text-xs text-neutral-400 font-mono border-t border-neutral-800/60 flex items-center justify-between">
              <span>Resolution: 3840 × 2160 (4K UHD)</span>
              <span>LUT: {treatment.cinematography.colorGradingLUT.split(' ')[0]}</span>
            </div>
          </div>
        )}

        {/* 2. 9:16 Social Reel / Vertical Video */}
        {(activeFormat === 'all' || activeFormat === '9x16') && (
          <div className="bg-neutral-900/40 rounded-xl border border-neutral-800/80 overflow-hidden flex flex-col justify-between">
            <div className="p-4 border-b border-neutral-800/80 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-neutral-300 font-medium">
                <Smartphone className="w-4 h-4 text-amber-500/80" />
                <span>9:16 Vertical Video / Social Reel Script</span>
              </div>
              <button
                onClick={() =>
                  handleCopy(
                    `HOOK: ${campaignDeliverables.socialReelScript.hook}\nBODY: ${campaignDeliverables.socialReelScript.body}\nCTA: ${campaignDeliverables.socialReelScript.cta}`,
                    'reel-script'
                  )
                }
                className="text-neutral-400 hover:text-neutral-200 transition-colors flex items-center gap-1 cursor-pointer"
              >
                {copiedKey === 'reel-script' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="text-[11px] font-mono">Copy Reel Script</span>
              </button>
            </div>

            <div className="p-6 grid grid-cols-1 sm:grid-cols-12 gap-6 items-center">
              {/* Phone Mockup Frame */}
              <div className="sm:col-span-5 flex justify-center">
                <div className="w-44 h-80 rounded-2xl bg-neutral-950 border-2 border-neutral-800 relative overflow-hidden shadow-xl flex flex-col justify-between p-3">
                  <img
                    src={heroImage}
                    alt="9:16 Reel"
                    referrerPolicy="no-referrer"
                    className="absolute inset-0 w-full h-full object-cover opacity-70"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-black/40" />

                  <div className="relative z-10 flex justify-between items-center text-[9px] text-white/80 font-mono">
                    <span>9:16 REEL</span>
                    <span>15 SEC</span>
                  </div>

                  <div className="relative z-10 space-y-2">
                    <div className="bg-black/60 backdrop-blur-md p-2 rounded text-[10px] text-white font-medium leading-tight border border-white/10">
                      "{campaignDeliverables.socialReelScript.hook}"
                    </div>
                    <div className="text-[9px] text-neutral-300 line-clamp-3">
                      {campaignDeliverables.socialReelScript.body}
                    </div>
                    <div className="bg-white text-black font-semibold text-[9px] text-center py-1 rounded">
                      {campaignDeliverables.socialReelScript.cta}
                    </div>
                  </div>
                </div>
              </div>

              {/* Script Details */}
              <div className="sm:col-span-7 space-y-4 text-xs">
                <div>
                  <div className="text-[11px] font-mono uppercase text-neutral-400 mb-1">
                    0-3s Visual Hook (Thumb-Stopper)
                  </div>
                  <div className="p-2.5 bg-neutral-950 rounded-lg border border-neutral-800 text-neutral-200">
                    "{campaignDeliverables.socialReelScript.hook}"
                  </div>
                </div>

                <div>
                  <div className="text-[11px] font-mono uppercase text-neutral-400 mb-1">
                    3-12s Narrative Core
                  </div>
                  <div className="p-2.5 bg-neutral-950 rounded-lg border border-neutral-800 text-neutral-300 leading-relaxed">
                    {campaignDeliverables.socialReelScript.body}
                  </div>
                </div>

                <div>
                  <div className="text-[11px] font-mono uppercase text-neutral-400 mb-1">
                    12-15s Conversion CTA
                  </div>
                  <div className="p-2.5 bg-neutral-950 rounded-lg border border-neutral-800 text-neutral-200 font-medium">
                    {campaignDeliverables.socialReelScript.cta}
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 text-xs text-neutral-400 font-mono border-t border-neutral-800/60 flex items-center justify-between">
              <span>Optimized for IG Reels & TikTok</span>
              <span>1080 × 1920 Native</span>
            </div>
          </div>
        )}

        {/* 3. 1:1 Press & Editorial Feed Asset */}
        {(activeFormat === 'all' || activeFormat === '1x1') && (
          <div className="bg-neutral-900/40 rounded-xl border border-neutral-800/80 overflow-hidden flex flex-col justify-between">
            <div className="p-4 border-b border-neutral-800/80 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-neutral-300 font-medium">
                <Square className="w-4 h-4 text-amber-500/80" />
                <span>1:1 Square Press & Social Grid Asset</span>
              </div>
              <button
                onClick={() => handleCopy(treatment.tagline, 'square-copy')}
                className="text-neutral-400 hover:text-neutral-200 transition-colors flex items-center gap-1 cursor-pointer"
              >
                {copiedKey === 'square-copy' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="text-[11px] font-mono">Copy Tagline</span>
              </button>
            </div>

            <div className="p-6 flex flex-col sm:flex-row gap-6 items-center">
              <div className="w-52 h-52 shrink-0 bg-neutral-950 rounded-lg overflow-hidden border border-neutral-800 relative">
                <img
                  src={heroImage}
                  alt="1:1 Asset"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <div className="text-[9px] font-mono text-amber-400 uppercase">{brandName}</div>
                  <div className="text-xs font-semibold leading-tight">{treatment.conceptTitle}</div>
                </div>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <div className="text-[11px] font-mono text-neutral-400 uppercase mb-1">
                    Editorial Feed Copy
                  </div>
                  <p className="text-neutral-300 leading-relaxed">
                    {treatment.creativeManifesto.slice(0, 180)}...
                  </p>
                </div>
                <div className="p-2.5 bg-neutral-950 rounded-lg border border-neutral-800 font-mono text-neutral-400 text-[11px]">
                  #CreativeDirection #{brandName.replace(/\s+/g, '')} #DesignSovereignty
                </div>
              </div>
            </div>

            <div className="p-4 text-xs text-neutral-400 font-mono border-t border-neutral-800/60 flex items-center justify-between">
              <span>Resolution: 2048 × 2048 Square</span>
              <span>Aspect: 1:1 Clean</span>
            </div>
          </div>
        )}

        {/* 4. OOH Out-Of-Home Billboard */}
        {(activeFormat === 'all' || activeFormat === 'ooh') && (
          <div className="bg-neutral-900/40 rounded-xl border border-neutral-800/80 overflow-hidden flex flex-col justify-between">
            <div className="p-4 border-b border-neutral-800/80 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-neutral-300 font-medium">
                <Presentation className="w-4 h-4 text-amber-500/80" />
                <span>Out-Of-Home (OOH) High-Impact Billboard</span>
              </div>
              <button
                onClick={() => handleCopy(campaignDeliverables.billboardCopy, 'ooh-copy')}
                className="text-neutral-400 hover:text-neutral-200 transition-colors flex items-center gap-1 cursor-pointer"
              >
                {copiedKey === 'ooh-copy' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="text-[11px] font-mono">Copy OOH</span>
              </button>
            </div>

            <div className="p-6">
              {/* Ultra-wide Billboard Mockup */}
              <div className="w-full bg-neutral-950 rounded-lg border border-neutral-800 p-8 flex flex-col items-center justify-center text-center relative overflow-hidden shadow-2xl">
                <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px]" />
                
                <div className="relative z-10 max-w-xl">
                  <div className="text-[11px] font-mono tracking-widest uppercase text-neutral-400 mb-3">
                    {brandName}
                  </div>
                  <h3 className="text-xl sm:text-3xl font-extrabold tracking-tight text-white mb-4 leading-none">
                    {campaignDeliverables.billboardCopy}
                  </h3>
                  <div className="text-xs text-neutral-400 font-mono">
                    LONDON · NEW YORK · TOKYO
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 text-xs text-neutral-400 font-mono border-t border-neutral-800/60 flex items-center justify-between">
              <span>Standard Super-Site Ratio 14:48</span>
              <span>Max Viewing Distance: 150m</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
