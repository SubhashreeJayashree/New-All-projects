export interface ColorSwatch {
  hex: string;
  name: string;
  role: string;
  usage: string;
}

export interface StoryboardShot {
  sceneNumber: number;
  shotName: string;
  cameraAngle: string;
  lighting: string;
  action: string;
  visualDescription: string;
  audioCue: string;
  voiceover: string;
  durationSeconds: number;
  compositionRule: string;
  imageFallback?: string;
}

export interface SonicIdentity {
  keySignature: string;
  bpm: number;
  textures: string[];
  sonicLogoDescription: string;
  narrationScript: string;
  recommendedVoicePersona: string;
}

export interface CampaignDeliverables {
  keyVisualHeadline: string;
  keyVisualSubtext: string;
  socialReelScript: {
    hook: string;
    body: string;
    cta: string;
  };
  billboardCopy: string;
  dosAndDonts: {
    dos: string[];
    donts: string[];
  };
}

export interface Cinematography {
  cameraGear: string;
  lensChoice: string;
  lightingScheme: string;
  colorGradingLUT: string;
  aspectRatio: string;
}

export interface EmotionalVectors {
  tension: string;
  release: string;
  resonance: string;
}

export interface CampaignTreatment {
  id: string;
  brandName: string;
  industry: string;
  conceptTitle: string;
  tagline: string;
  creativeManifesto: string;
  brandArchetype: string;
  emotionalVectors: EmotionalVectors;
  colorPalette: ColorSwatch[];
  cinematography: Cinematography;
  storyboard: StoryboardShot[];
  sonicIdentity: SonicIdentity;
  campaignDeliverables: CampaignDeliverables;
  heroImage: string;
}

export interface DirectorDials {
  temperature: number; // 0 (Cold Minimal) -> 100 (Warm Organic)
  avantGarde: number;  // 0 (Commercial) -> 100 (Avant-Garde)
  pacing: number;      // 0 (Contemplative) -> 100 (Kinetic)
}

export interface DirectorCritique {
  directorVerdict: string;
  suggestedRevision: string;
  cinematicNote: string;
}
