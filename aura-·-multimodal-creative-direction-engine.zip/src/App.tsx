/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { CampaignTreatment, DirectorDials } from './types/campaign';
import { INITIAL_PRESETS, ASSET_IMAGES } from './data/presets';
import { TopBar } from './components/TopBar';
import { HeroSection } from './components/HeroSection';
import { DirectorsTreatment } from './components/DirectorsTreatment';
import { CinematicStoryboard } from './components/CinematicStoryboard';
import { SonicIdentityStudio } from './components/SonicIdentityStudio';
import { MultiFormatMatrix } from './components/MultiFormatMatrix';
import { DirectorsDial } from './components/DirectorsDial';
import { BriefModal } from './components/BriefModal';
import { ExportModal } from './components/ExportModal';

export default function App() {
  const [currentTreatment, setCurrentTreatment] = useState<CampaignTreatment>(
    INITIAL_PRESETS['haute_couture']
  );
  const [activePresetId, setActivePresetId] = useState<string>('haute_couture');
  const [activeTab, setActiveTab] = useState<string>('treatment');
  const [dials, setDials] = useState<DirectorDials>({
    temperature: 50,
    avantGarde: 65,
    pacing: 45,
  });

  const [activeCritique, setActiveCritique] = useState<{
    targetText: string;
    contextRole: string;
  } | null>(null);

  const [isBriefModalOpen, setIsBriefModalOpen] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [isSynthesizing, setIsSynthesizing] = useState<boolean>(false);

  const treatmentSectionRef = useRef<HTMLDivElement | null>(null);

  const handleSelectPreset = (presetId: string) => {
    if (INITIAL_PRESETS[presetId]) {
      setCurrentTreatment(INITIAL_PRESETS[presetId]);
      setActivePresetId(presetId);
      // Adjust dials to preset defaults
      if (presetId === 'haute_couture') {
        setDials({ temperature: 30, avantGarde: 85, pacing: 60 });
      } else if (presetId === 'sustainable_luxury') {
        setDials({ temperature: 75, avantGarde: 50, pacing: 35 });
      } else {
        setDials({ temperature: 45, avantGarde: 70, pacing: 55 });
      }
    }
  };

  const handleRequestCritique = (targetText: string, contextRole: string) => {
    setActiveCritique({ targetText, contextRole });
    // Scroll to dial section on mobile if needed
  };

  const handleScrollToTreatment = () => {
    treatmentSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSynthesizeBrief = async (briefData: {
    brandName: string;
    industry: string;
    brief: string;
    archetype: string;
    aestheticTone: string;
  }) => {
    setIsSynthesizing(true);
    try {
      const response = await fetch('/api/generate-campaign', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...briefData,
          temperatureDial: dials.temperature,
          avantGardeDial: dials.avantGarde,
          pacingDial: dials.pacing,
        }),
      });

      const result = await response.json();
      if (result.success && result.data) {
        const synthesized: CampaignTreatment = {
          id: `custom_${Date.now()}`,
          brandName: briefData.brandName,
          industry: briefData.industry,
          heroImage: ASSET_IMAGES.heroStudio,
          ...result.data,
          storyboard: result.data.storyboard.map((s: any, idx: number) => ({
            ...s,
            imageFallback:
              idx === 0
                ? ASSET_IMAGES.heroStudio
                : idx === 1
                ? ASSET_IMAGES.audio
                : idx === 2
                ? ASSET_IMAGES.fashion
                : ASSET_IMAGES.luxury,
          })),
        };

        setCurrentTreatment(synthesized);
        setActivePresetId('custom');
        setActiveTab('treatment');
        handleScrollToTreatment();
      }
    } catch (err) {
      console.error('Failed to synthesize custom campaign:', err);
    } finally {
      setIsSynthesizing(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-neutral-800 selection:text-white">
      {/* 3-Zone Top Navigation Contract */}
      <TopBar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenBriefModal={() => setIsBriefModalOpen(true)}
        onOpenExportModal={() => setIsExportModalOpen(true)}
      />

      <main className="flex-1">
        {/* Editorial Hero Split */}
        <HeroSection
          currentTreatment={currentTreatment}
          activePresetId={activePresetId}
          onSelectPreset={handleSelectPreset}
          onOpenBriefModal={() => setIsBriefModalOpen(true)}
          onScrollToTreatment={handleScrollToTreatment}
        />

        {/* Studio Workspace Section */}
        <div ref={treatmentSectionRef} className="max-w-7xl mx-auto px-6 py-12">
          {/* Workspace Tabs (Secondary on-page navigation) */}
          <div className="flex items-center justify-between border-b border-neutral-900 pb-4 mb-8">
            <div className="flex items-center gap-1 p-1 bg-neutral-900/60 rounded-xl border border-neutral-800/80">
              <button
                onClick={() => setActiveTab('treatment')}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === 'treatment'
                    ? 'bg-neutral-100 text-neutral-950 shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                Director's Treatment
              </button>
              <button
                onClick={() => setActiveTab('storyboard')}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === 'storyboard'
                    ? 'bg-neutral-100 text-neutral-950 shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                Cinematic Storyboard ({currentTreatment.storyboard.length})
              </button>
              <button
                onClick={() => setActiveTab('sonic')}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === 'sonic'
                    ? 'bg-neutral-100 text-neutral-950 shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                Sonic Identity & Audition
              </button>
              <button
                onClick={() => setActiveTab('adaptation')}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === 'adaptation'
                    ? 'bg-neutral-100 text-neutral-950 shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                Deliverables Matrix
              </button>
            </div>

            <div className="hidden sm:flex items-center gap-2 text-xs text-neutral-400 font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-500/80" />
              <span>Multimodal Pipeline Ready</span>
            </div>
          </div>

          {/* Main 2-Column Content Layout: Active Tab Content + Stance Tuning Sidebar */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Primary Viewport Column */}
            <div className="lg:col-span-8">
              {activeTab === 'treatment' && (
                <DirectorsTreatment
                  treatment={currentTreatment}
                  onRequestCritique={handleRequestCritique}
                />
              )}

              {activeTab === 'storyboard' && (
                <CinematicStoryboard
                  storyboard={currentTreatment.storyboard}
                  onRequestCritique={handleRequestCritique}
                />
              )}

              {activeTab === 'sonic' && (
                <SonicIdentityStudio
                  sonicIdentity={currentTreatment.sonicIdentity}
                  brandName={currentTreatment.brandName}
                  onRequestCritique={handleRequestCritique}
                />
              )}

              {activeTab === 'adaptation' && (
                <MultiFormatMatrix
                  treatment={currentTreatment}
                  onRequestCritique={handleRequestCritique}
                />
              )}
            </div>

            {/* Sidebar Column: Real-Time Director's Tuning Dial */}
            <div className="lg:col-span-4 sticky top-20">
              <DirectorsDial
                dials={dials}
                onUpdateDials={setDials}
                brandName={currentTreatment.brandName}
                activeCritique={activeCritique}
                onCloseCritique={() => setActiveCritique(null)}
              />
            </div>
          </div>
        </div>
      </main>

      {/* Quiet Editorial Footer */}
      <footer className="border-t border-neutral-900 bg-neutral-950 px-6 py-8 text-xs text-neutral-500 font-mono">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-neutral-400">
            <span className="font-semibold text-neutral-300">AURA MCDE</span>
            <span aria-hidden="true">·</span>
            <span>Multimodal Creative Direction Architecture</span>
          </div>
          <div>
            Built with Cross-Modal Reasoning, Anamorphic Optics & Sonic Identity Synthesis
          </div>
        </div>
      </footer>

      {/* Modals */}
      <BriefModal
        isOpen={isBriefModalOpen}
        onClose={() => setIsBriefModalOpen(false)}
        onSynthesize={handleSynthesizeBrief}
        isLoading={isSynthesizing}
      />

      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        treatment={currentTreatment}
      />
    </div>
  );
}
