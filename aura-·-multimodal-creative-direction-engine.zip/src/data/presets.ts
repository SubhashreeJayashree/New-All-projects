import { CampaignTreatment } from '../types/campaign';

import heroStudioImg from '../assets/images/hero_creative_director_workspace_1791987080502.jpg';
import fashionImg from '../assets/images/campaign_cyber_fashion_1791987080547.jpg';
import luxuryImg from '../assets/images/campaign_sustainable_luxury_1791987080883.jpg';
import audioImg from '../assets/images/campaign_spatial_audio_1791987080826.jpg';

export const ASSET_IMAGES = {
  heroStudio: heroStudioImg,
  fashion: fashionImg,
  luxury: luxuryImg,
  audio: audioImg,
};

export const INITIAL_PRESETS: Record<string, CampaignTreatment> = {
  "haute_couture": {
    id: "haute_couture",
    brandName: "VALENCE STUDIO",
    industry: "Avant-Garde High Fashion & Kinetic Wear",
    conceptTitle: "CHRONO-CHITIN: Architectural Armor",
    tagline: "Structure as Sanctuary. Form Beyond Flesh.",
    creativeManifesto: "In a world saturated with ephemeral disposable fast-craft, Chrono-Chitin asserts the primacy of radical silhouettes. The collection draws from entomological biomechanics and brutalist monoliths—transforming high-fashion into protective kinetic architecture for modern metropolises.",
    brandArchetype: "The Outlaw & The Magician",
    emotionalVectors: {
      tension: "Vulnerability vs Invulnerability in urban hyper-surveillance",
      release: "The transformative armor that gives sovereignty to the wearer",
      resonance: "Quiet, uncompromising authority with zero hesitation"
    },
    colorPalette: [
      { hex: "#0A0B0E", name: "Obsidian Void", role: "Primary Canvas", usage: "Deep studio backdrops & structural shadows" },
      { hex: "#2A3A40", name: "Chitin Teal", role: "Structural Surface", usage: "Iridescent fabric undertones and rim lights" },
      { hex: "#E2A458", name: "Amber Filament", role: "Key Accent", usage: "3200K tungsten edge kicks and micro-stitching" },
      { hex: "#D4D8DD", name: "Liquid Platinum", role: "Highlights", usage: "Specular reflections on metallic zipper seams" },
      { hex: "#17181C", name: "Basalt Carbon", role: "Sub-neutral", usage: "Secondary garments and floor reflections" }
    ],
    cinematography: {
      cameraGear: "ARRI Alexa 35 with Hawk V-Lite 2x Anamorphic lenses",
      lensChoice: "45mm & 80mm Anamorphic Primes (T2.2)",
      lightingScheme: "Single hard tungsten key (5kW fresnel) with subtle diffused cyan ambient negative fill",
      colorGradingLUT: "Custom Kodak 5219 emulation with cold shadow skew and warm specular roll-off",
      aspectRatio: "2.39:1 CinemaScope"
    },
    storyboard: [
      {
        sceneNumber: 1,
        shotName: "The Monolith Silhouette",
        cameraAngle: "Extreme Low-Angle Static 45mm",
        lighting: "Stark Chiaroscuro back-rim light penetrating heavy industrial haze",
        action: "Model stands motionless in cavernous architectural space; coat lapels catch sudden warm amber kicker",
        visualDescription: "Tall imposing structural silhouette in obsidian leather; geometric folds create sharp graphic planes against dark slate wall",
        audioCue: "Deep sub-harmonic 34Hz drone, distant resonant metallic chime",
        voiceover: "We did not inherit the future. We built its armor.",
        durationSeconds: 4.5,
        compositionRule: "Vertical Golden Ratio with low horizon line",
        imageFallback: fashionImg
      },
      {
        sceneNumber: 2,
        shotName: "Kinetic Geometry in Macro",
        cameraAngle: "Extreme Close-Up 80mm Macro Tracking",
        lighting: "Directional raking light skimming the faceted iridescent textile texture",
        action: "Fingers in matte black titanium rings brush down the origami pleated sleeve; micro-zipper catches platinum reflection",
        visualDescription: "Hyper-detailed macro view of synthetic chromatic chitin scales shifting under movement",
        audioCue: "Tactile mechanical fabric friction sound, synchronized click of magnetic clasp",
        voiceover: "Every seam a deliberate defiance against entropy.",
        durationSeconds: 3.8,
        compositionRule: "Dynamic diagonal leading line from upper-right to lower-left",
        imageFallback: fashionImg
      },
      {
        sceneNumber: 3,
        shotName: "The Sovereign Gaze",
        cameraAngle: "Medium Close-Up Profile to Front Dutch Angle Pan",
        lighting: "Twin rim lights (Amber left, Steel Cyan right) framing sculpted cheekbones",
        action: "Model turns 90 degrees directly into camera lens; expression is calm, penetrating, absolute",
        visualDescription: "Sleek wet-look hair, subtle iridescent eyelid sheen mirroring coat coloration",
        audioCue: "Swell of analog synth strings with tape saturation and breath intake",
        voiceover: "Step outside the uniform. Inhabit the archetype.",
        durationSeconds: 5.0,
        compositionRule: "Rule of Thirds eye-line positioning at 66% frame height",
        imageFallback: fashionImg
      },
      {
        sceneNumber: 4,
        shotName: "The Urban Departure",
        cameraAngle: "Wide Tracking Shot following from behind",
        lighting: "Distant sodium streetlights dissolving into dense atmospheric rain mist",
        action: "Model strides down wet concrete runway; wide structural collar acts as wings against the city skyline",
        visualDescription: "Reflections of neon signage bleed across damp asphalt floor as figure disappears into twilight",
        audioCue: "Rhythmic bass pulse rising to a sudden clean cut; lingering reverberant tail",
        voiceover: "Chrono-Chitin. Built for tomorrow's monoliths.",
        durationSeconds: 6.2,
        compositionRule: "Central single-point perspective converge",
        imageFallback: fashionImg
      }
    ],
    sonicIdentity: {
      keySignature: "D Minor",
      bpm: 72,
      textures: ["Moog Model D Sub-bass Drone", "Bowed metallic cymbal harmonics", "Processed 35mm film shutter clicks", "Warm analog tape saturation"],
      sonicLogoDescription: "A three-tier acoustic strike: low 40Hz kinetic boom, followed by a crisp mechanical titanium click, decaying into a shimmering glass reverb tail.",
      narrationScript: "We did not inherit the future. We built its armor. In the convergence of geometry and sovereignty, you are not merely seen—you are indelible. Chrono-Chitin.",
      recommendedVoicePersona: "Kore (Low register, disciplined, intimate European editorial cadence)"
    },
    campaignDeliverables: {
      keyVisualHeadline: "SOVEREIGNTY ENGINEERED IN SILK & STEEL",
      keyVisualSubtext: "Autumn / Winter Haute Couture Campaign Suite. Available in numbered editions.",
      socialReelScript: {
        hook: "What if clothing was not meant to decorate—but to fortify?",
        body: "Precision-engineered origami pleating that shifts color under municipal light. Hand-cast titanium clasps. Zero compromises.",
        cta: "Explore the lookbook film · Link in profile"
      },
      billboardCopy: "FORM IS POWER. PARIS · MILAN · TOKYO",
      dosAndDonts: {
        dos: [
          "Maintain deep shadow dominance (minimum 60% negative space)",
          "Keep posture statuesque, architectural, and deliberate",
          "Ensure light catches edge geometry rather than flat frontal flooding"
        ],
        donts: [
          "No commercial smiling or playful lifestyle poses",
          "No saturated neon pink or turquoise filters",
          "Never crowd typography over the model's structural silhouette"
        ]
      }
    },
    heroImage: fashionImg
  },

  "sustainable_luxury": {
    id: "sustainable_luxury",
    brandName: "AETHEREA",
    industry: "Fine Fragrance & Elemental Olfactive Arts",
    conceptTitle: "TERRESTRIAL ESSENCE: The Unbroken Silence",
    tagline: "Distilled From The Earth's Silent Hours.",
    creativeManifesto: "Aetherea rejects synthetic ostentation. Born from volcanic basalt, wild sea brine, and sun-baked amber resin, the fragrance embodies raw elemental luxury. The creative direction marries wabi-sabi tactile textures with museum-grade glass geometry.",
    brandArchetype: "The Sage & The Caregiver",
    emotionalVectors: {
      tension: "Urban sensory burnout and digital artificiality",
      release: "The transcendent breath of petrichor and ancient stone",
      resonance: "Deep serenity, organic permanence, and timeless craftsmanship"
    },
    colorPalette: [
      { hex: "#1C1C1E", name: "Volcanic Basalt", role: "Primary Canvas", usage: "Porous stone surfaces and mineral backdrops" },
      { hex: "#C78C48", name: "Aged Amber", role: "Hero Element", usage: "Perfume flacon liquid glow & warm sunlight refraction" },
      { hex: "#6D7973", name: "Nordic Sage", role: "Organic Grounding", usage: "Foliage accents and typography sub-headers" },
      { hex: "#E8E6DF", name: "Travertine Chalk", role: "Clean Contrast", usage: "Minimalist packaging paper & key visual headlines" },
      { hex: "#3A4540", name: "Deep Lichen", role: "Shadow Tonal", usage: "Water reflections and shadow depth" }
    ],
    cinematography: {
      cameraGear: "RED V-Raptor 8K VV with Cooke S7/i Full Frame Plus Primes",
      lensChoice: "65mm & 110mm Macro Primes",
      lightingScheme: "Natural raking morning sunlight through water ripple glass diffuser",
      colorGradingLUT: "Naturalistic Nordic film emulation with rich earthen amber mids",
      aspectRatio: "1.85:1 Academy Flat"
    },
    storyboard: [
      {
        sceneNumber: 1,
        shotName: "The Basalt Cradle",
        cameraAngle: "Low Angle 45-degree macro",
        lighting: "Raking low-sunlight creating crystalline caustics through sculpted glass",
        action: "Morning sea water gently laps against black basalt stone; amber perfume flacon stands completely immovable",
        visualDescription: "Rough volcanic mineral texture contrasting with optically pure organic glass bottle; name 'AETHEREA' embossed in blind letterpress style",
        audioCue: "Gentle ocean swell, crisp morning breeze, distant shorebirds",
        voiceover: "Before the noise of the world, there was the silence of stone.",
        durationSeconds: 5.0,
        compositionRule: "Rule of Thirds focal placement on golden horizon",
        imageFallback: luxuryImg
      },
      {
        sceneNumber: 2,
        shotName: "The Amber Refraction",
        cameraAngle: "Extreme Macro 110mm Rack Focus",
        lighting: "Backlit liquid amber casting golden light pools onto wet dark pebbles",
        action: "A single distilled dewdrop slides down the glass shoulder, magnifying amber warmth",
        visualDescription: "Golden amber liquid illuminated from within, suspended tiny botanical resins catching sunlight sparkles",
        audioCue: "Soft organic woodwind tone, acoustic harp pluck with sustained ring",
        voiceover: "Captured in the brief window between dawn and dew.",
        durationSeconds: 4.2,
        compositionRule: "Circular focal center with radial vignette",
        imageFallback: luxuryImg
      },
      {
        sceneNumber: 3,
        shotName: "The Ritual Application",
        cameraAngle: "Over-the-Shoulder Medium Shot",
        lighting: "Diffused linen curtain morning light in minimalist travertine interior",
        action: "Hands with clean natural nails lift sculpted volcanic stone stopper; vapor mist disperses in slow motion",
        visualDescription: "Fine micro-mist caught in sunbeam dust motes against minimalist limestone wall",
        audioCue: "Clean mechanical pump hiss, gentle intake of breath",
        voiceover: "Wear the elements. Inhabit the eternal.",
        durationSeconds: 4.8,
        compositionRule: "Balanced asymmetrical split between person and ambient space",
        imageFallback: luxuryImg
      }
    ],
    sonicIdentity: {
      keySignature: "F Major",
      bpm: 58,
      textures: ["Felted acoustic grand piano chords", "Field recording of coastal tide", "Warm cello drone", "Subtle wind chime reverberation"],
      sonicLogoDescription: "A soft water droplet strike resolving into a rich, warm C-major piano chord held with sustain pedal for 6 seconds.",
      narrationScript: "Before the noise of the world, there was the silence of stone. Distilled from the earth's quietest hours, Aetherea is not a scent—it is an anchor.",
      recommendedVoicePersona: "Zephyr (Soft, warm, articulate, grounded cadence)"
    },
    campaignDeliverables: {
      keyVisualHeadline: "THE ESSENCE OF UNBROKEN SILENCE",
      keyVisualSubtext: "Extrait de Parfum · Wild Basalt Cap & Refillable Crystal Flacon",
      socialReelScript: {
        hook: "What does pure stillness smell like?",
        body: "Crushed juniper, volcanic mineral petrichor, and warm coastal amber. Crafted without synthetic fixatives.",
        cta: "Experience the olfactive gallery · Reserve your discovery set"
      },
      billboardCopy: "DISTILLED FROM NATURE. REFINED BY TIME.",
      dosAndDonts: {
        dos: [
          "Use real raw mineral, wood, and water textures",
          "Prioritize soft, diffused, natural morning sunlight",
          "Ensure wide breathing margins around product photography"
        ],
        donts: [
          "No aggressive CGI explosions or glitter effects",
          "No loud high-energy dance music cues",
          "Never obscure the raw stone bottle stopper"
        ]
      }
    },
    heroImage: luxuryImg
  },

  "spatial_audio": {
    id: "spatial_audio",
    brandName: "AETHERIS",
    industry: "High-Fidelity Spatial Acoustics & Industrial Design",
    conceptTitle: "ACOUSTIC MONOLITH: Architecture of Listening",
    tagline: "Sound Not Heard, But Inhabited.",
    creativeManifesto: "Aetheris redefines personal listening as a physical architectural phenomenon. Engineered with titanium acoustic mesh and lambskin isolation chambers, the direction treats sound waves as sculptural light planes carving through negative space.",
    brandArchetype: "The Creator & The Explorer",
    emotionalVectors: {
      tension: "Flat compressed digital audio fatigue",
      release: "Expansive 360-degree spatial clarity with infinite headroom",
      resonance: "Physical intimacy with the musician's breath and resonance"
    },
    colorPalette: [
      { hex: "#0E1116", name: "Acoustic Slate", role: "Primary Canvas", usage: "Soundstage background & felt isolation panels" },
      { hex: "#9AA0A6", name: "Brushed Titanium", role: "Hardware Metal", usage: "Earcups, headband yolk, and audio jack casing" },
      { hex: "#D97706", name: "Amber Valve Glow", role: "Acoustic Warmth", usage: "Vacuum tube indicators and soundwave highlights" },
      { hex: "#23272F", name: "Matte Carbon", role: "Structural Surface", usage: "Plinth pedestal and packaging container" },
      { hex: "#F3F4F6", name: "Pure Signal White", role: "Display Copy", usage: "Clean typography and frequency curve lines" }
    ],
    cinematography: {
      cameraGear: "Sony FX9 with Master Anamorphic Primes",
      lensChoice: "50mm & 100mm Macro Cine Primes",
      lightingScheme: "Sculpted rim lighting with dual strip softboxes framing metal curvatures",
      colorGradingLUT: "High-dynamic range industrial monochrome with selective amber accentuation",
      aspectRatio: "2.0:1 Univisium"
    },
    storyboard: [
      {
        sceneNumber: 1,
        shotName: "The Titanium Plinth",
        cameraAngle: "Low Angle Slow Orbit 50mm",
        lighting: "Precision overhead edge light revealing micro-perforated acoustic driver grille",
        action: "Headphones rest on raw travertine block; camera sweeps smoothly around brushed aluminum gimbals",
        visualDescription: "Intricate metallic texture, machined concentric rings reflecting a razor-thin highlight stripe",
        audioCue: "High-definition acoustic guitar pluck, sound of finger sliding across wound steel string",
        voiceover: "Most headphones transmit sound. Aetheris constructs space.",
        durationSeconds: 4.6,
        compositionRule: "Centric Hero placement with 50/50 balance",
        imageFallback: audioImg
      },
      {
        sceneNumber: 2,
        shotName: "The Driver Anatomy",
        cameraAngle: "Exploded View Kinetic Macro 100mm",
        lighting: "Strobe-pulse synchronizing with low-frequency rumble",
        action: "Planar magnetic diaphragm vibrates in slow motion 1000fps; dust particles dance above copper voice coil",
        visualDescription: "Transparent internal casing revealing hand-wound planar trace array",
        audioCue: "Pure 20Hz sine wave sweeping up through 432Hz harmonic overtones",
        voiceover: "Fifty-millimeter planar drivers. Zero phase distortion.",
        durationSeconds: 5.2,
        compositionRule: "Dynamic diagonal symmetry",
        imageFallback: audioImg
      },
      {
        sceneNumber: 3,
        shotName: "The Isolation Seal",
        cameraAngle: "Side Profile Silhouette into Light",
        lighting: "High-contrast rim silhouette with gentle warmth on ear cushion",
        action: "Listener places headphones over ears; outside environmental noise immediately ducks to total silence",
        visualDescription: "Supple leather conforming to listener's contour; eyes close in relaxed concentration",
        audioCue: "Sudden absolute silence, followed by a crisp stereo orchestral crescendo enveloping field",
        voiceover: "Step inside the master recording.",
        durationSeconds: 4.4,
        compositionRule: "Golden section profile",
        imageFallback: audioImg
      }
    ],
    sonicIdentity: {
      keySignature: "A Minor",
      bpm: 85,
      textures: ["432Hz calibrated sine resonance", "Crisp analog vinyl crackle decay", "Full spectrum spatial frequency sweep", "Deep sub-kick with stereo reverb width"],
      sonicLogoDescription: "A wide stereophonic binaural sweep from left to right ear, resolving into an ultra-clean acoustic chime with 96kHz harmonic extension.",
      narrationScript: "Most headphones simply transmit sound. Aetheris builds an acoustic sanctuary. With planar magnetic precision and zero-resonance titanium, discover every nuance the artist felt in the studio.",
      recommendedVoicePersona: "Fenrir (Authoritative, resonant, technical, warm studio engineer tone)"
    },
    campaignDeliverables: {
      keyVisualHeadline: "HEAR THE ROOM. INHABIT THE SOUND.",
      keyVisualSubtext: "Planar Magnetic Reference Headphones. Hand-assembled in Munich.",
      socialReelScript: {
        hook: "Have you ever heard the sound of the air in the recording booth?",
        body: "Standard headphones compress your music into two flat speakers. Planar magnetic drivers rebuild the entire three-dimensional acoustic space around you.",
        cta: "Book a private acoustic audition · Studio appointments open"
      },
      billboardCopy: "ACOUSTIC PERFECTION. ZERO COMPROMISE.",
      dosAndDonts: {
        dos: [
          "Highlight brushed metallic highlights and precision craftsmanship",
          "Emphasize silence and spatial depth in sound design",
          "Use clean architectural typography with monospace technical annotations"
        ],
        donts: [
          "Do not show tangled messy cords or plasticky consumer finishes",
          "Avoid gimmicky bass-heavy party rave tropes",
          "Never distort or clip the audio master"
        ]
      }
    },
    heroImage: audioImg
  }
};
