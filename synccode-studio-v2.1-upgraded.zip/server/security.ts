/** Tiny in-memory token bucket; no dependencies. */
export class Bucket {
  private tokens: number;
  private last = Date.now();
  constructor(private capacity: number, private refillPerSec: number) { this.tokens = capacity; }
  take(n = 1): boolean {
    const now = Date.now();
    this.tokens = Math.min(this.capacity, this.tokens + ((now - this.last) / 1000) * this.refillPerSec);
    this.last = now;
    if (this.tokens < n) return false;
    this.tokens -= n;
    return true;
  }
}

export class KeyedLimiter {
  private m = new Map<string, Bucket>();
  constructor(private capacity: number, private refillPerSec: number) {
    (setInterval(() => { if (this.m.size > 5000) this.m.clear(); }, 10 * 60_000) as any).unref?.();
  }
  allow(key: string) {
    let b = this.m.get(key);
    if (!b) { b = new Bucket(this.capacity, this.refillPerSec); this.m.set(key, b); }
    return b.take();
  }
}
