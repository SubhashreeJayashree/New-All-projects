import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

export interface Account {
  id: string;
  email: string;
  name: string;
  passwordSalt: string;
  passwordHash: string;
}

interface AuthSession {
  tokenHash: string;
  accountId: string;
  expiresAt: number;
}

interface AuthData {
  accounts: Account[];
  sessions: AuthSession[];
}

const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const PASSWORD_KEY_LENGTH = 64;

export class AuthStore {
  private data: AuthData = { accounts: [], sessions: [] };
  private readonly filePath: string;

  constructor(dataDir: string) {
    fs.mkdirSync(dataDir, { recursive: true });
    this.filePath = path.join(dataDir, 'accounts.json');
    if (fs.existsSync(this.filePath)) {
      const parsed: unknown = JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
      if (!parsed || typeof parsed !== 'object' || !Array.isArray((parsed as AuthData).accounts) || !Array.isArray((parsed as AuthData).sessions)) {
        throw new Error('Account database has an invalid format.');
      }
      this.data = parsed as AuthData;
    }
  }

  register(email: string, name: string, password: string): Account | null {
    const normalizedEmail = email.trim().toLowerCase();
    if (this.data.accounts.some((account) => account.email === normalizedEmail)) return null;
    const passwordSalt = crypto.randomBytes(16).toString('hex');
    const passwordHash = this.hashPassword(password, passwordSalt);
    const account = {
      id: crypto.randomUUID(),
      email: normalizedEmail,
      name: name.trim().slice(0, 32),
      passwordSalt,
      passwordHash,
    };
    this.data.accounts.push(account);
    this.save();
    return account;
  }

  login(email: string, password: string): { account: Account; token: string } | null {
    const normalizedEmail = email.trim().toLowerCase();
    const account = this.data.accounts.find((item) => item.email === normalizedEmail);
    const salt = account?.passwordSalt ?? '00000000000000000000000000000000';
    const expected = account?.passwordHash ?? this.hashPassword('invalid-password', salt);
    const actual = this.hashPassword(password, salt);
    if (!crypto.timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(actual, 'hex')) || !account) return null;

    const token = crypto.randomBytes(32).toString('base64url');
    this.data.sessions = this.data.sessions.filter((session) => session.expiresAt > Date.now());
    this.data.sessions.push({
      tokenHash: this.hashToken(token),
      accountId: account.id,
      expiresAt: Date.now() + SESSION_TTL_MS,
    });
    this.save();
    return { account, token };
  }

  authenticate(token: string | undefined): Account | null {
    if (!token) return null;
    const now = Date.now();
    const tokenHash = this.hashToken(token);
    const session = this.data.sessions.find((item) => item.tokenHash === tokenHash && item.expiresAt > now);
    if (!session) return null;
    return this.data.accounts.find((item) => item.id === session.accountId) ?? null;
  }

  revoke(token: string | undefined) {
    if (!token) return;
    const tokenHash = this.hashToken(token);
    this.data.sessions = this.data.sessions.filter((session) => session.tokenHash !== tokenHash);
    this.save();
  }

  publicAccount(account: Account) {
    return { id: account.id, email: account.email, name: account.name };
  }

  private hashPassword(password: string, salt: string) {
    return crypto.scryptSync(password, salt, PASSWORD_KEY_LENGTH).toString('hex');
  }

  private hashToken(token: string) {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  private save() {
    const tmp = `${this.filePath}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.data), { mode: 0o600 });
    fs.renameSync(tmp, this.filePath);
  }
}
