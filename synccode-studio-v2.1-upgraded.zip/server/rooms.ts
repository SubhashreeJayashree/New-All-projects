import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { RoomState, User, CodeFile, ChatMessage, Stroke, TimerState, ReplayEntry, ReviewComment } from '../src/types';
import { Op, apply, transform, validateOp } from '../src/shared/ot';
import { STARTER_FILES } from '../src/utils/challengePresets';

export const LIMITS = {
  maxFileChars: 1_000_000,
  maxFiles: 40,
  maxMessages: 200,
  maxStrokes: 1500,
  maxStrokePoints: 6000,
  history: 500,
  replayEntries: 80,
  replayFileChars: 300_000,
  replayTotalChars: 900_000,
  reviewComments: 500,
  roomTtlMs: 7 * 24 * 3600 * 1000,
};

export const ROOM_ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
const COLOR_RE = /^#[0-9a-fA-F]{6}$/;

export function sanitizeName(raw: unknown): string {
  const s = String(raw ?? '').replace(/[\u0000-\u001f\u007f<>]/g, '').trim().slice(0, 32);
  return s || 'Guest';
}
export function sanitizeUser(raw: any, id: string): User {
  return {
    id,
    name: sanitizeName(raw?.name),
    color: COLOR_RE.test(raw?.color) ? raw.color : '#38bdf8',
    avatar: sanitizeName(raw?.name).slice(0, 1).toUpperCase(),
    isAudioOn: !!raw?.isAudioOn,
    isVideoOn: !!raw?.isVideoOn,
    isScreenSharing: false,
    isSpeaking: false,
    isHandRaised: false,
    role: 'collaborator',
  };
}

export function sanitizeFileName(raw: unknown): string | null {
  const n = String(raw ?? '').trim();
  if (!n || n.length > 80 || /[\\/\u0000-\u001f<>:"|?*]/.test(n) || n.startsWith('.')) return null;
  return n;
}

export function langOf(name: string): CodeFile['language'] {
  if (/\.(ts|tsx)$/.test(name)) return 'typescript';
  if (/\.py$/.test(name)) return 'python';
  if (/\.c$|\.h$/i.test(name)) return 'c';
  if (/\.(cc|cpp|cxx|hpp|hh|hxx)$/i.test(name)) return 'cpp';
  if (/\.java$/i.test(name)) return 'java';
  if (/\.cs$/i.test(name)) return 'csharp';
  if (/\.go$/i.test(name)) return 'go';
  if (/\.rs$/i.test(name)) return 'rust';
  if (/\.php$/i.test(name)) return 'php';
  if (/\.rb$/i.test(name)) return 'ruby';
  if (/\.html?$/.test(name)) return 'html';
  if (/\.css$/.test(name)) return 'css';
  if (/\.json$/.test(name)) return 'json';
  if (/\.md$/.test(name)) return 'markdown';
  return 'javascript';
}

interface HistoryEntry { version: number; op: Op }

export interface ServerRoom extends RoomState {
  hostId: string;
  editLocked: boolean;
  timer: TimerState;
  strokes: Stroke[];
  lastActive: number;
  history: Map<string, HistoryEntry[]>;
  replayEntries: ReplayEntry[];
  reviewComments: ReviewComment[];
  tokens: Map<string, string>; // userId -> secret, blocks impersonation
}

export type OpResult =
  | { ok: true; op: Op; version: number }
  | { ok: false; reason: 'resync' | 'invalid' | 'forbidden' | 'toolarge' };

function clone<T>(v: T): T { return JSON.parse(JSON.stringify(v)); }

export class RoomStore {
  rooms = new Map<string, ServerRoom>();
  private timers = new Map<string, NodeJS.Timeout>();

  constructor(private dataDir: string | null = null) {
    if (dataDir) fs.mkdirSync(dataDir, { recursive: true });
  }

  private file(roomId: string) { return path.join(this.dataDir!, `${roomId}.json`); }

  private fresh(roomId: string): ServerRoom {
    const files = clone(STARTER_FILES).map((f) => ({ ...f, version: 0 }));
    return {
      roomId,
      name: `Room-${roomId.slice(0, 6)}`,
      files,
      activeFileId: files[0].id,
      users: [],
      messages: [{
        id: 'welcome-msg', userId: 'system', userName: 'SyncCode Bot', userColor: '#38bdf8', type: 'system',
        content: '👋 Welcome to SyncCode Studio! Edit together in real time, run code in a sandbox, and chat with @ai.',
        timestamp: Date.now(),
      }],
      challenge: null,
      lastExecution: null,
      hostId: '',
      editLocked: false,
      timer: { durationMs: 30 * 60_000, remainingMs: 30 * 60_000, running: false, at: Date.now() },
      strokes: [],
      lastActive: Date.now(),
      history: new Map(),
      replayEntries: [],
      reviewComments: [],
      tokens: new Map(),
    };
  }

  getOrCreate(roomId: string): ServerRoom {
    let room = this.rooms.get(roomId);
    if (room) return room;
    room = this.fresh(roomId);
    if (this.dataDir) {
      try {
        const saved = JSON.parse(fs.readFileSync(this.file(roomId), 'utf8'));
        room.files = saved.files.map((f: CodeFile) => ({ ...f, version: f.version ?? 0 }));
        room.activeFileId = saved.activeFileId || room.files[0]?.id || '';
        room.messages = saved.messages || room.messages;
        room.challenge = saved.challenge ?? null;
        room.strokes = saved.strokes || [];
        room.name = saved.name || room.name;
        room.replayEntries = Array.isArray(saved.replayEntries) ? saved.replayEntries : [];
        room.reviewComments = Array.isArray(saved.reviewComments) ? saved.reviewComments : [];
      } catch { /* no snapshot yet */ }
    }
    this.rooms.set(roomId, room);
    return room;
  }

  // ---------- membership ----------
  /** Returns false if the userId is already claimed by someone with a different token. */
  join(room: ServerRoom, user: User, token: string): boolean {
    const known = room.tokens.get(user.id);
    if (known && known !== token) return false;
    room.tokens.set(user.id, token);
    const i = room.users.findIndex((u) => u.id === user.id);
    if (i >= 0) room.users[i] = { ...user, role: room.users[i].role };
    else room.users.push(user);
    if (!room.hostId || !room.users.some((u) => u.id === room.hostId)) room.hostId = room.users[0].id;
    this.refreshRoles(room);
    room.lastActive = Date.now();
    return true;
  }

  leave(room: ServerRoom, userId: string) {
    room.users = room.users.filter((u) => u.id !== userId);
    if (room.hostId === userId) room.hostId = room.users[0]?.id || '';
    this.refreshRoles(room);
    if (room.users.length === 0) this.pauseTimer(room);
    this.scheduleSave(room);
  }

  private refreshRoles(room: ServerRoom) {
    room.users.forEach((u) => { u.role = u.id === room.hostId ? 'host' : 'collaborator'; });
  }

  canEdit(room: ServerRoom, userId: string) {
    return userId === room.hostId || !room.editLocked;
  }

  // ---------- documents ----------
  applyOp(room: ServerRoom, userId: string, fileId: string, baseVersion: unknown, rawOp: unknown): OpResult {
    if (!this.canEdit(room, userId)) return { ok: false, reason: 'forbidden' };
    const file = room.files.find((f) => f.id === fileId);
    if (!file || !Number.isInteger(baseVersion)) return { ok: false, reason: 'invalid' };
    const cur = file.version ?? 0;
    const base = baseVersion as number;
    if (base > cur || base < 0) return { ok: false, reason: 'resync' };
    const hist = room.history.get(fileId) || [];
    if (cur - base > hist.length) return { ok: false, reason: 'resync' };

    // validate against the doc the client saw (base), which is only reconstructible via transform;
    // do a loose structural check here and a strict one after transforming.
    if (!Array.isArray(rawOp) || rawOp.length > 8) return { ok: false, reason: 'invalid' };
    let op = rawOp as Op;
    if (!validateOp(op, Number.MAX_SAFE_INTEGER)) return { ok: false, reason: 'invalid' };
    for (const h of hist) {
      if (h.version > base) op = transform(op, h.op, false)[0];
    }
    if (!validateOp(op, file.content.length)) return { ok: false, reason: 'invalid' };
    const next = apply(file.content, op);
    if (next.length > LIMITS.maxFileChars) return { ok: false, reason: 'toolarge' };

    file.content = next;
    file.version = cur + 1;
    file.updatedAt = Date.now();
    hist.push({ version: file.version, op });
    if (hist.length > LIMITS.history) hist.shift();
    room.history.set(fileId, hist);
    room.lastActive = Date.now();
    this.recordSnapshot(room, file, userId);
    this.scheduleSave(room);
    return { ok: true, op, version: file.version };
  }

  recordSnapshot(room: ServerRoom, file: CodeFile, userId: string) {
    if (file.content.length > LIMITS.replayFileChars) return false;
    const previous = [...room.replayEntries].reverse().find((entry) => entry.fileId === file.id);
    if (previous && previous.content === file.content) return false;
    if (previous && Date.now() - previous.timestamp < 1500) return false;

    room.replayEntries.push({
      id: `replay-${crypto.randomUUID()}`,
      fileId: file.id,
      fileName: file.name,
      content: file.content,
      version: file.version ?? 0,
      userName: room.users.find((user) => user.id === userId)?.name ?? 'Collaborator',
      timestamp: Date.now(),
    });
    while (room.replayEntries.length > LIMITS.replayEntries ||
      room.replayEntries.reduce((total, entry) => total + entry.content.length, 0) > LIMITS.replayTotalChars) {
      room.replayEntries.shift();
    }
    return true;
  }

  addReviewComment(room: ServerRoom, user: User, raw: unknown): ReviewComment | null {
    if (room.reviewComments.length >= LIMITS.reviewComments || !raw || typeof raw !== 'object') return null;
    const input = raw as Record<string, unknown>;
    const file = room.files.find((item) => item.id === input.fileId);
    const line = input.line;
    const content = typeof input.content === 'string' ? input.content.trim() : '';
    const selectedText = typeof input.selectedText === 'string' ? input.selectedText.slice(0, 500) : '';
    const lineCount = file ? Math.max(1, file.content.split('\n').length) : 0;
    if (!file || !Number.isInteger(line) || (line as number) < 1 || (line as number) > lineCount ||
      content.length < 1 || content.length > 2000) return null;

    const comment: ReviewComment = {
      id: `review-${crypto.randomUUID()}`,
      fileId: file.id,
      fileName: file.name,
      line: line as number,
      selectedText,
      content,
      userId: user.id,
      userName: user.name,
      resolved: false,
      timestamp: Date.now(),
    };
    room.reviewComments.push(comment);
    this.scheduleSave(room);
    return comment;
  }

  setReviewResolved(room: ServerRoom, commentId: string, userId: string, isHost: boolean, resolved: boolean) {
    const comment = room.reviewComments.find((item) => item.id === commentId);
    if (!comment || (!isHost && comment.userId !== userId)) return false;
    comment.resolved = resolved;
    this.scheduleSave(room);
    return true;
  }

  deleteReviewComment(room: ServerRoom, commentId: string, userId: string, isHost: boolean) {
    const comment = room.reviewComments.find((item) => item.id === commentId);
    if (!comment || (!isHost && comment.userId !== userId)) return false;
    room.reviewComments = room.reviewComments.filter((item) => item.id !== commentId);
    this.scheduleSave(room);
    return true;
  }

  addFile(room: ServerRoom, f: any): CodeFile | null {
    const name = sanitizeFileName(f?.name);
    if (!name || room.files.length >= LIMITS.maxFiles) return null;
    if (room.files.some((x) => x.name === name)) return null;
    const content = typeof f?.content === 'string' ? f.content.slice(0, LIMITS.maxFileChars) : '';
    const id = typeof f?.id === 'string' && /^[\w-]{1,64}$/.test(f.id) && !room.files.some((x) => x.id === f.id)
      ? f.id : `f-${Date.now()}-${Math.floor(Math.random() * 1e4)}`;
    const file: CodeFile = { id, name, language: langOf(name), content, updatedAt: Date.now(), version: 0 };
    room.files.push(file);
    this.scheduleSave(room);
    return file;
  }

  renameFile(room: ServerRoom, fileId: string, rawName: unknown): CodeFile | null {
    const name = sanitizeFileName(rawName);
    const f = room.files.find((x) => x.id === fileId);
    if (!f || !name || room.files.some((x) => x.name === name && x.id !== fileId)) return null;
    f.name = name;
    f.language = langOf(name);
    this.scheduleSave(room);
    return f;
  }

  deleteFile(room: ServerRoom, fileId: string): boolean {
    if (room.files.length <= 1 || !room.files.some((f) => f.id === fileId)) return false;
    room.files = room.files.filter((f) => f.id !== fileId);
    room.history.delete(fileId);
    if (room.activeFileId === fileId) room.activeFileId = room.files[0].id;
    this.scheduleSave(room);
    return true;
  }

  loadFiles(room: ServerRoom, files: CodeFile[]) {
    room.files = clone(files).map((f) => ({ ...f, version: 0 }));
    room.history.clear();
    room.activeFileId = room.files[0]?.id || '';
    this.scheduleSave(room);
  }

  // ---------- chat ----------
  addMessage(room: ServerRoom, msg: ChatMessage) {
    room.messages.push(msg);
    while (room.messages.length > LIMITS.maxMessages) room.messages.shift();
    this.scheduleSave(room);
  }

  // ---------- whiteboard ----------
  addStrokePoints(room: ServerRoom, userId: string, color: string, id: string, size: number, pts: number[]): Stroke | null {
    if (!/^[\w-]{1,40}$/.test(id) || !Array.isArray(pts) || pts.length > 400) return null;
    if (!pts.every((n) => typeof n === 'number' && isFinite(n))) return null;
    let s = room.strokes.find((x) => x.id === id);
    if (!s) {
      s = { id, userId, color, size: Math.min(24, Math.max(1, Math.round(size) || 3)), pts: [] };
      room.strokes.push(s);
      if (room.strokes.length > LIMITS.maxStrokes) room.strokes.shift();
    }
    if (s.userId !== userId || s.pts.length + pts.length > LIMITS.maxStrokePoints * 2) return null;
    s.pts.push(...pts.map((n) => Math.round(n)));
    return s;
  }
  undoStroke(room: ServerRoom, userId: string, id: string) {
    const before = room.strokes.length;
    room.strokes = room.strokes.filter((s) => !(s.id === id && s.userId === userId));
    return room.strokes.length !== before;
  }

  // ---------- timer ----------
  timerSnapshot(room: ServerRoom): TimerState {
    const t = room.timer;
    if (t.running) {
      const remaining = Math.max(0, t.remainingMs - (Date.now() - t.at));
      return { ...t, remainingMs: remaining, running: remaining > 0, at: Date.now() };
    }
    return { ...t, at: Date.now() };
  }
  timerAction(room: ServerRoom, action: string, durationMs?: number): TimerState {
    const snap = this.timerSnapshot(room);
    if (action === 'set' && Number.isFinite(durationMs)) {
      const d = Math.min(8 * 3600_000, Math.max(60_000, durationMs as number));
      room.timer = { durationMs: d, remainingMs: d, running: false, at: Date.now() };
    } else if (action === 'start') {
      room.timer = { ...snap, running: snap.remainingMs > 0 };
    } else if (action === 'pause') {
      room.timer = { ...snap, running: false };
    } else if (action === 'reset') {
      room.timer = { ...snap, remainingMs: snap.durationMs, running: false };
    }
    return room.timer;
  }
  private pauseTimer(room: ServerRoom) {
    if (room.timer.running) room.timer = { ...this.timerSnapshot(room), running: false };
  }

  // ---------- persistence ----------
  scheduleSave(room: ServerRoom) {
    if (!this.dataDir || this.timers.has(room.roomId)) return;
    this.timers.set(room.roomId, setTimeout(() => {
      this.timers.delete(room.roomId);
      this.saveNow(room);
    }, 1500));
  }
  saveNow(room: ServerRoom) {
    if (!this.dataDir) return;
    const snap = {
      name: room.name, files: room.files, activeFileId: room.activeFileId,
      messages: room.messages, challenge: room.challenge, strokes: room.strokes,
      replayEntries: room.replayEntries, reviewComments: room.reviewComments, savedAt: Date.now(),
    };
    const tmp = this.file(room.roomId) + '.tmp';
    fs.writeFile(tmp, JSON.stringify(snap), (err) => {
      if (!err) fs.rename(tmp, this.file(room.roomId), () => {});
    });
  }
  flushAll() {
    for (const t of this.timers.values()) clearTimeout(t);
    this.timers.clear();
    if (!this.dataDir) return;
    for (const r of this.rooms.values()) {
      fs.writeFileSync(this.file(r.roomId), JSON.stringify({
        name: r.name, files: r.files, activeFileId: r.activeFileId, messages: r.messages,
        challenge: r.challenge, strokes: r.strokes, replayEntries: r.replayEntries,
        reviewComments: r.reviewComments, savedAt: Date.now(),
      }));
    }
  }

  /** Drop empty idle rooms from memory and expired snapshots from disk. */
  sweep() {
    const now = Date.now();
    for (const [id, r] of this.rooms) {
      if (r.users.length === 0 && now - r.lastActive > 30 * 60_000) {
        this.saveNow(r);
        this.rooms.delete(id);
      }
    }
    if (!this.dataDir) return;
    for (const f of fs.readdirSync(this.dataDir)) {
      const p = path.join(this.dataDir, f);
      try { if (now - fs.statSync(p).mtimeMs > LIMITS.roomTtlMs) fs.unlinkSync(p); } catch {}
    }
  }

  publicState(room: ServerRoom): RoomState {
    const { history, replayEntries, tokens, lastActive, ...rest } = room;
    return { ...rest, timer: this.timerSnapshot(room) };
  }
}
