import { User } from '../types';

export const USER_COLORS = ['#38bdf8', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4', '#f97316', '#84cc16'];

export function uuid(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}
export function secret(): string {
  const a = new Uint8Array(16);
  crypto.getRandomValues(a);
  return Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('');
}
export function colorFor(id: string) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return USER_COLORS[h % USER_COLORS.length];
}
export function randomRoomId() {
  const w = ['neural', 'tensor', 'vector', 'gradient', 'kernel', 'lambda', 'quark', 'delta'];
  return `${w[Math.floor(Math.random() * w.length)]}-${Math.random().toString(36).slice(2, 7)}`;
}

/** Identity lives in sessionStorage so two tabs behave as two different people. */
export function loadSession(): { id: string; token: string } {
  try {
    const raw = sessionStorage.getItem('synccode:session');
    if (raw) return JSON.parse(raw);
  } catch {}
  const s = { id: uuid(), token: secret() };
  try { sessionStorage.setItem('synccode:session', JSON.stringify(s)); } catch {}
  return s;
}

export function makeUser(id: string, name: string, audio: boolean, video: boolean): User {
  return {
    id, name, color: colorFor(id), avatar: name.slice(0, 1).toUpperCase(),
    isAudioOn: audio, isVideoOn: video, isScreenSharing: false, isSpeaking: false, role: 'collaborator',
  };
}

export const store = {
  get(k: string, d = '') { try { return localStorage.getItem(`synccode:${k}`) ?? d; } catch { return d; } },
  set(k: string, v: string) { try { localStorage.setItem(`synccode:${k}`, v); } catch {} },
};
