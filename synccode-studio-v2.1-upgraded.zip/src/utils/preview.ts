import { CodeFile } from '../types';

/** Builds the iframe document: inlines <link href> / <script src> that point at project files. */
export function buildPreviewDoc(files: CodeFile[]): string {
  const html = files.find((f) => f.name === 'index.html') || files.find((f) => f.language === 'html');
  if (!html) {
    return '<div style="font-family:sans-serif;color:#888;padding:20px;">No HTML file found. Create <b>index.html</b> to preview web pages.</div>';
  }
  const byName = new Map(files.map((f) => [f.name, f]));
  const lookup = (ref: string) => byName.get(ref.replace(/^\.?\//, '').split(/[?#]/)[0]);
  const safeJs = (s: string) => s.replace(/<\/script/gi, '<\\/script');
  let doc = html.content;
  doc = doc.replace(/<link\b[^>]*href=["']([^"']+)["'][^>]*>/gi, (tag, href) => {
    const f = lookup(href);
    return f && /stylesheet/i.test(tag) ? `<style>\n${f.content}\n</style>` : tag;
  });
  doc = doc.replace(/<script\b[^>]*src=["']([^"']+)["'][^>]*>\s*<\/script>/gi, (tag, src) => {
    const f = lookup(src);
    return f ? `<script>\n${safeJs(f.content)}\n</script>` : tag;
  });
  return doc;
}
