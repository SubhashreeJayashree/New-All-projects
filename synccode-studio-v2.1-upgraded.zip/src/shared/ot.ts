/**
 * Minimal text Operational Transformation.
 * An Op is a list of primitives applied sequentially:
 *   { t:'i', p, s }  insert string s at index p
 *   { t:'d', p, n }  delete n chars starting at p
 * Isomorphic: used by both the server (authoritative) and the browser clients.
 */
export type Prim = { t: 'i'; p: number; s: string } | { t: 'd'; p: number; n: number };
export type Op = Prim[];

export function apply(text: string, op: Op): string {
  let out = text;
  for (const c of op) {
    if (c.t === 'i') out = out.slice(0, c.p) + c.s + out.slice(c.p);
    else out = out.slice(0, c.p) + out.slice(c.p + c.n);
  }
  return out;
}

const isHigh = (c: number) => c >= 0xd800 && c <= 0xdbff;
const isLow = (c: number) => c >= 0xdc00 && c <= 0xdfff;

/** Smallest single-range edit turning a into b (never splits surrogate pairs). */
export function diff(a: string, b: string): Op {
  if (a === b) return [];
  const max = Math.min(a.length, b.length);
  let s = 0;
  while (s < max && a.charCodeAt(s) === b.charCodeAt(s)) s++;
  if (s > 0 && isHigh(a.charCodeAt(s - 1))) s--;
  let e = 0;
  while (e < max - s && a.charCodeAt(a.length - 1 - e) === b.charCodeAt(b.length - 1 - e)) e++;
  if (e > 0 && isLow(a.charCodeAt(a.length - e))) e--;
  const del = a.length - s - e;
  const ins = b.slice(s, b.length - e);
  const op: Op = [];
  if (del > 0) op.push({ t: 'd', p: s, n: del });
  if (ins) op.push({ t: 'i', p: s, s: ins });
  return op;
}

type Pair = [Prim[], Prim[]];

/** Transform primitive a against b (concurrent). Returns [a', b']. */
function tp(a: Prim, b: Prim, aFirst: boolean): Pair {
  if (a.t === 'i' && b.t === 'i') {
    const aBefore = a.p < b.p || (a.p === b.p && aFirst);
    if (aBefore) return [[a], [{ t: 'i', p: b.p + a.s.length, s: b.s }]];
    return [[{ t: 'i', p: a.p + b.s.length, s: a.s }], [b]];
  }
  if (a.t === 'i' && b.t === 'd') {
    const ap = a.p <= b.p ? a.p : a.p >= b.p + b.n ? a.p - b.n : b.p;
    let bp: Prim[];
    if (a.p <= b.p) bp = [{ t: 'd', p: b.p + a.s.length, n: b.n }];
    else if (a.p >= b.p + b.n) bp = [b];
    else {
      const left = a.p - b.p;
      bp = [
        { t: 'd', p: b.p, n: left },
        { t: 'd', p: b.p + a.s.length, n: b.n - left },
      ];
    }
    return [[{ t: 'i', p: ap, s: a.s }], bp];
  }
  if (a.t === 'd' && b.t === 'i') {
    const [bp, ap] = tp(b, a, !aFirst);
    return [ap, bp];
  }
  const x = a as { t: 'd'; p: number; n: number };
  const y = b as { t: 'd'; p: number; n: number };
  const ov = Math.max(0, Math.min(x.p + x.n, y.p + y.n) - Math.max(x.p, y.p));
  const pos = (u: typeof x, v: typeof y) => (u.p <= v.p ? u.p : u.p >= v.p + v.n ? u.p - v.n : v.p);
  const an = x.n - ov;
  const bn = y.n - ov;
  return [
    an > 0 ? [{ t: 'd', p: pos(x, y), n: an }] : [],
    bn > 0 ? [{ t: 'd', p: pos(y, x), n: bn }] : [],
  ];
}

/**
 * Transform op lists A and B (both made against the same document).
 * Returns [A', B'] such that apply(apply(d,B),A') === apply(apply(d,A),B').
 * aFirst decides insert-vs-insert ties at the same index.
 */
export function transform(A: Op, B: Op, aFirst: boolean): [Op, Op] {
  if (A.length === 0) return [[], B];
  if (B.length === 0) return [A, []];
  if (A.length === 1 && B.length === 1) return tp(A[0], B[0], aFirst);
  if (A.length > 1) {
    const [a1, b1] = transform([A[0]], B, aFirst);
    const [a2, b2] = transform(A.slice(1), b1, aFirst);
    return [a1.concat(a2), b2];
  }
  const [a1, b1] = transform(A, [B[0]], aFirst);
  const [a2, b2] = transform(a1, B.slice(1), aFirst);
  return [a2, b1.concat(b2)];
}

/** Map a caret/index through an op. Inserts exactly at idx do not move it. */
export function transformIndex(idx: number, op: Op): number {
  for (const c of op) {
    if (c.t === 'i') {
      if (c.p < idx) idx += c.s.length;
    } else if (idx > c.p) {
      idx = idx >= c.p + c.n ? idx - c.n : c.p;
    }
  }
  return idx;
}

/** Structural validation for untrusted ops against a document length. */
export function validateOp(op: unknown, docLen: number, maxInsert = 200_000): op is Op {
  if (!Array.isArray(op) || op.length > 8) return false;
  let len = docLen;
  for (const c of op as any[]) {
    if (!c || typeof c !== 'object') return false;
    if (c.t === 'i') {
      if (!Number.isInteger(c.p) || c.p < 0 || c.p > len) return false;
      if (typeof c.s !== 'string' || c.s.length === 0 || c.s.length > maxInsert) return false;
      len += c.s.length;
    } else if (c.t === 'd') {
      if (!Number.isInteger(c.p) || !Number.isInteger(c.n) || c.p < 0 || c.n <= 0 || c.p + c.n > len) return false;
      len -= c.n;
    } else return false;
  }
  return true;
}
