export interface User {
  id: string;
  name: string;
  color: string;
  avatar: string;
  isAudioOn: boolean;
  isVideoOn: boolean;
  isScreenSharing: boolean;
  isSpeaking: boolean;
  role?: 'host' | 'interviewer' | 'candidate' | 'collaborator';
  isHandRaised?: boolean;
}

export interface RemoteCursor {
  userId: string;
  userName: string;
  userColor: string;
  fileId: string;
  /** absolute character offsets into the file text */
  offset: number;
  selStart: number;
  selEnd: number;
}

export type CodeLanguage =
  | 'javascript' | 'typescript' | 'python' | 'html' | 'css' | 'json' | 'markdown'
  | 'c' | 'cpp' | 'java' | 'csharp' | 'go' | 'rust' | 'php' | 'ruby';

export interface CodeFile {
  id: string;
  name: string;
  language: CodeLanguage;
  content: string;
  updatedAt: number;
  /** server OT version of this file */
  version?: number;
}

export interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  userColor: string;
  content: string;
  timestamp: number;
  type: 'text' | 'system' | 'code';
  codeSnippet?: {
    language: string;
    code: string;
  };
}

export interface ExecutionLog {
  type: 'log' | 'info' | 'warn' | 'error' | 'table';
  message: string;
  timestamp: number;
}

export interface ExecutionResult {
  senderId: string;
  senderName: string;
  logs: ExecutionLog[];
  returnValue?: string;
  error?: string;
  durationMs: number;
  testResults?: {
    passed: boolean;
    title: string;
    expected: string;
    actual: string;
    error?: string;
  }[];
  kind?: 'run' | 'tests';
  language?: string;
}

export interface ChallengePreset {
  id: string;
  title: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  description: string;
  tags: string[];
  files: CodeFile[];
  testRunnerCode?: string;
}

export interface GenAIResponse {
  action: 'explain' | 'optimize' | 'debug' | 'generate' | 'chat';
  text: string;
  timestamp: number;
}

export interface Stroke {
  id: string;
  userId: string;
  color: string;
  size: number;
  /** flat [x0,y0,x1,y1,...] in a 1600x900 virtual canvas */
  pts: number[];
}

export interface TimerState {
  durationMs: number;
  remainingMs: number;
  running: boolean;
  /** server clock when this snapshot was taken */
  at: number;
}

export interface ReplayEntry {
  id: string;
  fileId: string;
  fileName: string;
  content: string;
  version: number;
  userName: string;
  timestamp: number;
}

export interface ReviewComment {
  id: string;
  fileId: string;
  fileName: string;
  line: number;
  selectedText: string;
  content: string;
  userId: string;
  userName: string;
  resolved: boolean;
  timestamp: number;
}

export interface RoomState {
  hostId?: string;
  editLocked?: boolean;
  timer?: TimerState;
  strokes?: Stroke[];
  roomId: string;
  name: string;
  files: CodeFile[];
  activeFileId: string;
  users: User[];
  messages: ChatMessage[];
  challenge?: ChallengePreset | null;
  lastExecution?: ExecutionResult | null;
  copilotHistory?: GenAIResponse[];
  reviewComments?: ReviewComment[];
}
