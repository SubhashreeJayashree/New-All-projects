declare module 'prismjs/components/prism-c' {}
declare module 'prismjs/components/prism-cpp' {}
declare module 'prismjs/components/prism-java' {}
declare module 'prismjs/components/prism-csharp' {}
declare module 'prismjs/components/prism-go' {}
declare module 'prismjs/components/prism-rust' {}
declare module 'prismjs/components/prism-php' {}
declare module 'prismjs/components/prism-ruby' {}
