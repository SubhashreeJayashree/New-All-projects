import React, { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, Video, VideoOff, Monitor, Pin, PinOff, Volume2, VolumeX, Users, Radio, Hand, ChevronRight, ChevronLeft, Settings2, Smile } from 'lucide-react';
import { User } from '../../types';
import { webrtcManager } from '../../services/webrtc';

export interface FloatingReaction { id: number; emoji: string; left: number }

interface Props {
  currentUser: User;
  users: User[];
  localStream: MediaStream | null;
  remoteStreams: Map<string, MediaStream>;
  isSpeaking: boolean;
  audioVolume: number;
  reactions: FloatingReaction[];
  onReact: (emoji: string) => void;
  onToggleHand: () => void;
  onMediaChange: () => void;
}

const EMOJIS = ['👍', '👏', '😂', '🎉', '❤️', '🤔'];

const Tile: React.FC<{
  name: string; color: string; stream?: MediaStream | null; local?: boolean; audioOn: boolean; videoOn: boolean;
  speaking: boolean; hand?: boolean; sharing?: boolean; volume?: number; pinned: boolean; onPin: () => void; big?: boolean;
}> = ({ name, color, stream, local, audioOn, videoOn, speaking, hand, sharing, volume = 0, pinned, onPin, big }) => {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => { if (ref.current && stream && ref.current.srcObject !== stream) ref.current.srcObject = stream; }, [stream]);
  const showVideo = !!stream && stream.getVideoTracks().length > 0 && videoOn;
  return (
    <div className={`relative rounded-xl overflow-hidden bg-[#0d1117] border ${speaking ? 'border-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.3)]' : 'border-[#30363d]'} aspect-video flex items-center justify-center group transition-all`}>
      <video ref={ref} autoPlay playsInline muted={local} className={`w-full h-full ${sharing ? 'object-contain' : 'object-cover'} ${local && !sharing ? '-scale-x-100' : ''} ${showVideo ? 'block' : 'hidden'}`} />
      {!showVideo && (
        <div className="flex flex-col items-center p-2">
          <div className={`${big ? 'w-20 h-20 text-3xl' : 'w-12 h-12 text-lg'} rounded-full flex items-center justify-center font-bold text-white shadow-lg mb-1`} style={{ background: color }}>{name.slice(0, 1).toUpperCase()}</div>
          <span className="text-[11px] text-zinc-400">{local ? 'Camera off' : name}</span>
        </div>
      )}
      <div className="absolute bottom-1.5 left-1.5 right-1.5 flex items-center justify-between pointer-events-none">
        <div className="flex items-center space-x-1.5 bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-full text-[11px] text-zinc-200">
          <span className="font-medium truncate max-w-[90px]">{name}{local ? ' (You)' : ''}</span>
          {audioOn
            ? (local ? <div className="w-1 rounded-full bg-emerald-400" style={{ height: `${Math.min(12, Math.max(4, volume / 8))}px` }} /> : <Volume2 className={`w-3 h-3 ${speaking ? 'text-emerald-400 animate-pulse' : 'text-zinc-400'}`} />)
            : (local ? <MicOff className="w-2.5 h-2.5 text-rose-400" /> : <VolumeX className="w-3 h-3 text-rose-400" />)}
        </div>
        {sharing && <span className="text-[9px] bg-sky-500 text-white font-mono px-1.5 py-0.5 rounded-full font-semibold">SCREEN</span>}
      </div>
      {hand && <div className="absolute top-1.5 left-1.5 text-lg animate-bounce" title={`${name} raised a hand`}>✋</div>}
      <button onClick={onPin} className="absolute top-1.5 right-1.5 p-1 rounded-md bg-black/50 text-zinc-300 opacity-0 group-hover:opacity-100 focus:opacity-100 hover:text-white cursor-pointer" aria-label={pinned ? 'Unpin' : 'Pin to spotlight'} title={pinned ? 'Unpin' : 'Spotlight'}>
        {pinned ? <PinOff className="w-3 h-3" /> : <Pin className="w-3 h-3" />}
      </button>
    </div>
  );
};

export const VideoConferencing: React.FC<Props> = (p) => {
  const [audioOn, setAudioOn] = useState(webrtcManager.isAudioEnabled);
  const [videoOn, setVideoOn] = useState(webrtcManager.isVideoEnabled);
  const [sharing, setSharing] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [pin, setPin] = useState<string | null>(null);
  const [showEmoji, setShowEmoji] = useState(false);
  const [showDevices, setShowDevices] = useState(false);
  const [devices, setDevices] = useState<{ mics: MediaDeviceInfo[]; cams: MediaDeviceInfo[] }>({ mics: [], cams: [] });

  useEffect(() => { setAudioOn(webrtcManager.isAudioEnabled); setVideoOn(webrtcManager.isVideoEnabled); }, [p.localStream]);

  const toggleAudio = () => { setAudioOn(webrtcManager.toggleAudio()); p.onMediaChange(); };
  const toggleVideo = () => { setVideoOn(webrtcManager.toggleVideo()); p.onMediaChange(); };
  const toggleShare = async () => { setSharing(await webrtcManager.toggleScreenShare()); p.onMediaChange(); };
  const openDevices = async () => { setShowDevices((s) => !s); setDevices(await webrtcManager.listDevices()); };

  const others = p.users.filter((u) => u.id !== p.currentUser.id);
  const me = p.users.find((u) => u.id === p.currentUser.id) || p.currentUser;

  type T = { id: string; node: (big: boolean) => React.ReactNode };
  const tiles: T[] = [
    { id: 'local', node: (big) => <Tile key="local" local big={big} name={p.currentUser.name} color={p.currentUser.color} stream={p.localStream} audioOn={audioOn} videoOn={videoOn} speaking={p.isSpeaking} hand={me.isHandRaised} sharing={sharing} volume={p.audioVolume} pinned={pin === 'local'} onPin={() => setPin(pin === 'local' ? null : 'local')} /> },
    ...others.map((u): T => ({ id: u.id, node: (big) => <Tile key={u.id} big={big} name={u.name} color={u.color} stream={p.remoteStreams.get(u.id)} audioOn={u.isAudioOn} videoOn={u.isVideoOn} speaking={u.isSpeaking} hand={u.isHandRaised} sharing={u.isScreenSharing} pinned={pin === u.id} onPin={() => setPin(pin === u.id ? null : u.id)} /> })),
  ];
  const pinned = tiles.find((t) => t.id === pin);
  const rest = pinned ? tiles.filter((t) => t.id !== pin) : tiles;

  const ctl = (on: boolean, danger = true) => `p-2.5 rounded-full transition-all cursor-pointer ${on ? 'bg-[#21262d] text-zinc-200 hover:bg-[#30363d]' : danger ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' : ''}`;

  return (
    <div className={`transition-all duration-300 flex flex-col bg-[#161b22] border-l border-[#30363d] relative shrink-0 ${collapsed ? 'w-12' : 'w-72 lg:w-80'}`}>
      <button onClick={() => setCollapsed(!collapsed)} aria-label={collapsed ? 'Expand video panel' : 'Collapse video panel'}
        className="absolute -left-3.5 top-4 z-30 w-7 h-7 bg-[#21262d] border border-[#30363d] rounded-full text-zinc-300 hover:text-white flex items-center justify-center shadow-lg cursor-pointer">
        {collapsed ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
      </button>

      {collapsed ? (
        <div className="flex flex-col items-center py-4 space-y-4">
          <div className="w-8 h-8 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center"><Radio className="w-4 h-4 text-emerald-400 animate-pulse" /></div>
          <div className="text-[10px] uppercase font-mono font-bold tracking-widest text-zinc-500 [writing-mode:vertical-rl]">VIDEO ({p.users.length})</div>
          <button onClick={toggleAudio} className={ctl(audioOn)} aria-label="Toggle mic">{audioOn ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}</button>
          <button onClick={toggleVideo} className={ctl(videoOn)} aria-label="Toggle camera">{videoOn ? <Video className="w-3.5 h-3.5" /> : <VideoOff className="w-3.5 h-3.5" />}</button>
        </div>
      ) : (
        <>
          <div className="px-3.5 py-2.5 border-b border-[#30363d] flex items-center justify-between shrink-0">
            <div className="flex items-center space-x-2"><span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /><span className="text-xs font-semibold uppercase tracking-wider text-zinc-300">Video & Audio ({p.users.length})</span></div>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">P2P MESH</span>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-3 min-h-0 relative">
            {pinned && pinned.node(true)}
            <div className={pinned ? 'grid grid-cols-2 gap-2' : 'space-y-3'}>{rest.map((t) => t.node(false))}</div>
            {others.length === 0 && (
              <div className="rounded-xl border border-dashed border-[#30363d] p-4 text-center">
                <Users className="w-6 h-6 text-zinc-500 mx-auto mb-2" />
                <p className="text-xs text-zinc-400 font-medium">Waiting for others to join</p>
                <p className="text-[11px] text-zinc-500 mt-1">Share the room link, or use <span className="text-sky-400">Open Peer Tab</span> to test locally.</p>
              </div>
            )}
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 overflow-hidden" aria-hidden="true">
              {p.reactions.map((r) => <span key={r.id} className="reaction-float absolute bottom-2 text-3xl" style={{ left: `${r.left}%` }}>{r.emoji}</span>)}
            </div>
          </div>

          <div className="relative p-3 bg-[#0d1117] border-t border-[#30363d] flex items-center justify-around shrink-0">
            <button onClick={toggleAudio} title={audioOn ? 'Mute' : 'Unmute'} aria-label={audioOn ? 'Mute microphone' : 'Unmute microphone'} className={ctl(audioOn)}>{audioOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}</button>
            <button onClick={toggleVideo} title={videoOn ? 'Camera off' : 'Camera on'} aria-label={videoOn ? 'Turn camera off' : 'Turn camera on'} className={ctl(videoOn)}>{videoOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}</button>
            <button onClick={toggleShare} title="Share screen" aria-label="Share screen" className={`p-2.5 rounded-full cursor-pointer ${sharing ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/30' : 'bg-[#21262d] text-zinc-200 hover:bg-[#30363d]'}`}><Monitor className="w-4 h-4" /></button>
            <button onClick={p.onToggleHand} title="Raise hand" aria-label="Raise hand" className={`p-2.5 rounded-full cursor-pointer ${me.isHandRaised ? 'bg-amber-500/25 text-amber-300 border border-amber-500/40' : 'bg-[#21262d] text-zinc-200 hover:bg-[#30363d]'}`}><Hand className="w-4 h-4" /></button>
            <button onClick={() => { setShowEmoji(!showEmoji); setShowDevices(false); }} title="Reactions" aria-label="Reactions" className="p-2.5 rounded-full bg-[#21262d] text-zinc-200 hover:bg-[#30363d] cursor-pointer"><Smile className="w-4 h-4" /></button>
            <button onClick={() => { openDevices(); setShowEmoji(false); }} title="Devices" aria-label="Choose devices" className="p-2.5 rounded-full bg-[#21262d] text-zinc-200 hover:bg-[#30363d] cursor-pointer"><Settings2 className="w-4 h-4" /></button>

            {showEmoji && (
              <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 flex gap-1 bg-[#161b22] border border-[#30363d] rounded-full px-2 py-1 shadow-2xl">
                {EMOJIS.map((e) => <button key={e} onClick={() => { p.onReact(e); setShowEmoji(false); }} className="text-xl hover:scale-125 transition-transform cursor-pointer" aria-label={`React ${e}`}>{e}</button>)}
              </div>
            )}
            {showDevices && (
              <div className="absolute bottom-full mb-2 right-2 left-2 bg-[#161b22] border border-[#30363d] rounded-lg p-3 shadow-2xl space-y-2 text-[11px] text-zinc-300">
                {([['Microphone', 'audio', devices.mics, webrtcManager.micId], ['Camera', 'video', devices.cams, webrtcManager.camId]] as const).map(([label, kind, list, cur]) => (
                  <label key={kind} className="block">{label}
                    <select value={cur} onChange={(e) => webrtcManager.switchDevice(kind, e.target.value).catch(() => {})} className="mt-1 w-full bg-[#0d1117] border border-[#30363d] rounded px-2 py-1 text-xs text-white">
                      <option value="">Default</option>
                      {list.filter((d) => d.deviceId).map((d, i) => <option key={d.deviceId} value={d.deviceId}>{d.label || `${label} ${i + 1}`}</option>)}
                    </select>
                  </label>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};
