import React, { useEffect, useRef, useState } from 'react';
import { Send, MessageSquare, Activity, Sparkles, ChevronRight, ChevronLeft, Bot, ExternalLink, HelpCircle } from 'lucide-react';
import { ChatMessage, User } from '../../types';
import { Markdown, CodeAction } from '../Common/Markdown';

interface Props {
  messages: ChatMessage[];
  onSendMessage: (content: string) => void;
  onTyping: (typing: boolean) => void;
  typingUsers: string[];
  aiTyping: boolean;
  currentUser: User;
  codeActions: CodeAction[];
  onOpenPeerTab?: () => void;
  onOpenHowToRun?: () => void;
}

export const ChatPanel: React.FC<Props> = ({ messages, onSendMessage, onTyping, typingUsers, aiTyping, currentUser, codeActions, onOpenPeerTab, onOpenHowToRun }) => {
  const [text, setText] = useState('');
  const [tab, setTab] = useState<'chat' | 'activity'>('chat');
  const [collapsed, setCollapsed] = useState(false);
  const [unread, setUnread] = useState(0);
  const endRef = useRef<HTMLDivElement>(null);
  const seen = useRef(messages.length);
  const typingTimer = useRef<any>(null);
  const isTyping = useRef(false);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, typingUsers, aiTyping]);
  useEffect(() => {
    if (collapsed) setUnread((u) => u + Math.max(0, messages.filter((m) => m.type !== 'system').length - seen.current));
    seen.current = messages.filter((m) => m.type !== 'system').length;
  }, [messages]); // eslint-disable-line
  useEffect(() => { if (!collapsed) setUnread(0); }, [collapsed]);

  const stopTyping = () => { clearTimeout(typingTimer.current); if (isTyping.current) { isTyping.current = false; onTyping(false); } };
  const onChange = (v: string) => {
    setText(v);
    if (!isTyping.current && v) { isTyping.current = true; onTyping(true); }
    clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(stopTyping, 2500);
  };
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const t = text.trim();
    if (!t) return;
    onSendMessage(t); setText(''); stopTyping();
  };

  const activity = messages.filter((m) => m.type === 'system' && m.id !== 'welcome-msg');
  const quick = [['@ai explain this file', 'sky'], ['@ai find bugs in this file', 'emerald'], ['@ai suggest tests', 'amber']] as const;

  return (
    <div className={`transition-all duration-300 flex flex-col bg-[#161b22] border-r border-[#30363d] relative shrink-0 ${collapsed ? 'w-10' : 'w-72 lg:w-80'}`}>
      <button onClick={() => setCollapsed(!collapsed)} aria-label={collapsed ? 'Expand chat' : 'Collapse chat'}
        className="absolute -right-3 top-3 z-30 w-6 h-6 bg-[#21262d] border border-[#30363d] rounded-full text-zinc-300 hover:text-white flex items-center justify-center shadow-lg cursor-pointer">
        {collapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
      </button>

      {collapsed ? (
        <div className="flex flex-col items-center py-4 space-y-4">
          <button onClick={() => setCollapsed(false)} className="p-2 rounded-lg hover:bg-[#21262d] relative cursor-pointer" aria-label="Open chat">
            <MessageSquare className="w-4 h-4 text-sky-400" />
            {unread > 0 && <span className="absolute -top-0.5 -right-0.5 min-w-4 h-4 px-1 rounded-full bg-rose-500 text-white text-[9px] flex items-center justify-center font-bold">{unread > 9 ? '9+' : unread}</span>}
          </button>
          <div className="text-[10px] uppercase font-mono font-bold tracking-widest text-zinc-500 [writing-mode:vertical-rl]">COLLAB CHAT</div>
        </div>
      ) : (
        <>
          <div className="h-10 px-3 border-b border-[#30363d] flex items-center justify-between select-none shrink-0">
            <div className="flex items-center space-x-1" role="tablist">
              {([['chat', MessageSquare, 'text-sky-400', 'Chat'], ['activity', Activity, 'text-emerald-400', 'Activity']] as const).map(([id, Icon, c, label]) => (
                <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
                  className={`flex items-center space-x-1.5 px-2.5 py-1 rounded text-xs font-medium cursor-pointer ${tab === id ? 'bg-[#21262d] text-white font-semibold' : 'text-zinc-400 hover:text-zinc-200'}`}>
                  <Icon className={`w-3.5 h-3.5 ${c}`} /><span>{label}</span>
                </button>
              ))}
            </div>
            {onOpenHowToRun && <button onClick={onOpenHowToRun} className="flex items-center space-x-1 text-[11px] text-sky-400 hover:text-sky-300 px-1.5 py-0.5 rounded hover:bg-[#21262d] cursor-pointer"><HelpCircle className="w-3.5 h-3.5" /><span>Guide</span></button>}
          </div>

          <div className="px-3 py-2 bg-[#0d1117] border-b border-[#30363d]/70 text-[10px] text-zinc-500 leading-tight flex items-center justify-between gap-2 shrink-0">
            <span>Type <code className="text-sky-300 bg-black/40 px-1 rounded font-mono">@ai …</code> to ask Gemini (it can see the open file).</span>
            {onOpenPeerTab && <button onClick={onOpenPeerTab} className="text-sky-400 hover:underline flex items-center gap-0.5 font-medium shrink-0 cursor-pointer">Peer tab<ExternalLink className="w-2.5 h-2.5" /></button>}
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-3 min-h-0" aria-live="polite">
            {tab === 'chat' ? (
              <>
                {messages.map((m) => {
                  const me = m.userId === currentUser.id, ai = m.userId === 'ai-copilot';
                  if (m.type === 'system') {
                    if (m.id !== 'welcome-msg') return null;
                    return (
                      <div key={m.id} className="p-2 rounded-lg bg-[#0d1117] border border-[#30363d] text-[11px]">
                        <div className="flex items-center space-x-1.5 text-sky-400 font-bold mb-0.5 font-mono"><Bot className="w-3 h-3" /><span>{m.userName}</span></div>
                        <p className="text-zinc-300 leading-relaxed">{m.content}</p>
                      </div>
                    );
                  }
                  return (
                    <div key={m.id} className={`flex flex-col ${me ? 'items-end' : 'items-start'}`}>
                      <div className="flex items-center space-x-1 text-[10px] text-zinc-500 mb-0.5 font-mono">
                        {ai && <Sparkles className="w-2.5 h-2.5 text-sky-400" />}
                        <span style={{ color: m.userColor }} className="font-semibold">{me ? 'You' : m.userName}</span>
                        <span>{new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                      <div className={`px-3 py-1.5 rounded-xl text-xs max-w-[95%] break-words leading-relaxed select-text ${me ? 'bg-sky-600 text-white rounded-tr-none' : ai ? 'bg-[#1e293b] text-sky-100 border border-sky-500/40 rounded-tl-none' : 'bg-[#21262d] text-zinc-200 rounded-tl-none border border-[#30363d]'}`}>
                        <Markdown text={m.content} compact codeActions={ai ? codeActions : undefined} />
                      </div>
                    </div>
                  );
                })}
                {(typingUsers.length > 0 || aiTyping) && (
                  <div className="text-[11px] text-zinc-500 italic flex items-center gap-1.5">
                    <span className="flex gap-0.5">{[0, 1, 2].map((i) => <span key={i} className="w-1 h-1 rounded-full bg-zinc-500 animate-bounce" style={{ animationDelay: `${i * 120}ms` }} />)}</span>
                    {aiTyping ? 'Gemini is thinking…' : `${typingUsers.slice(0, 2).join(', ')} ${typingUsers.length > 1 ? 'are' : 'is'} typing…`}
                  </div>
                )}
                <div ref={endRef} />
              </>
            ) : (
              <div className="space-y-2">
                {activity.length === 0 && <p className="text-xs text-zinc-500 text-center py-6">No activity yet.</p>}
                {activity.map((l) => (
                  <div key={l.id} className="text-[11px] text-zinc-400 p-2 rounded bg-[#0d1117] border border-[#30363d] flex items-start space-x-2">
                    <span className="w-1.5 h-1.5 rounded-full mt-1 shrink-0" style={{ background: l.userColor }} />
                    <div className="flex-1 leading-snug"><p>{l.content}</p><span className="text-[9px] text-zinc-600">{new Date(l.timestamp).toLocaleTimeString()}</span></div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="px-3 py-1.5 bg-[#161b22] border-t border-[#30363d] flex items-center gap-1.5 overflow-x-auto text-[10px] font-mono select-none shrink-0">
            {quick.map(([q, c]) => (
              <button key={q} onClick={() => onSendMessage(q)} className={`px-2 py-0.5 rounded border whitespace-nowrap cursor-pointer ${c === 'sky' ? 'bg-sky-500/10 text-sky-300 border-sky-500/30' : c === 'emerald' ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30' : 'bg-amber-500/10 text-amber-300 border-amber-500/30'} hover:brightness-125`}>{q}</button>
            ))}
          </div>

          <form onSubmit={submit} className="p-2.5 bg-[#0d1117] border-t border-[#30363d] shrink-0">
            <div className="flex items-center space-x-1.5 bg-[#161b22] border border-[#30363d] rounded-lg px-2.5 py-1.5 focus-within:border-sky-500/50">
              <input type="text" aria-label="Message" placeholder="Message, or @ai <question>…" value={text} onChange={(e) => onChange(e.target.value)} maxLength={4000}
                className="flex-1 bg-transparent text-xs text-white placeholder-zinc-500 outline-none" />
              <button type="submit" disabled={!text.trim()} className="p-1 text-sky-400 hover:text-white disabled:opacity-30 cursor-pointer" aria-label="Send"><Send className="w-3.5 h-3.5" /></button>
            </div>
          </form>
        </>
      )}
    </div>
  );
};
