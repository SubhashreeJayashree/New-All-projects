import React, { useEffect, useRef, useState } from 'react';
import { Play, Share2, ExternalLink, BookOpen, Copy, Check, ChevronDown, Code2, Sparkles, FlaskConical, Command, Lock, Unlock, Timer, Pause, RotateCcw, MoreHorizontal, Crown, Eye, Loader2, History, MessageSquareText, LogOut } from 'lucide-react';
import { User, ChallengePreset, TimerState } from '../../types';
import { CHALLENGE_PRESETS } from '../../utils/challengePresets';

export type TimerView = TimerState & { receivedAt: number };

interface Props {
  roomId: string;
  currentUser: User;
  users: User[];
  hostId: string;
  isHost: boolean;
  latencyMs: number;
  isConnected: boolean;
  isRunning: boolean;
  hasTests: boolean;
  editLocked: boolean;
  timer: TimerView | null;
  followUserId: string | null;
  activeChallenge: ChallengePreset | null;
  onRunCode: () => void;
  onRunTests: () => void;
  onOpenPalette: () => void;
  onOpenDossier: () => void;
  onOpenPeerTab: () => void;
  onOpenCopilot: () => void;
  onOpenHowToRun: () => void;
  onOpenReplay: () => void;
  onOpenReviews: () => void;
  accountEmail?: string;
  onSignOut?: () => void;
  onSelectChallenge: (c: ChallengePreset) => void;
  onToggleLock: () => void;
  onTimerAction: (action: string, durationMs?: number) => void;
  onToggleFollow: (id: string | null) => void;
  onTimerExpire: () => void;
}

const fmt = (ms: number) => { const s = Math.ceil(ms / 1000); return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; };

const useClickAway = (open: boolean, close: () => void) => {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) close(); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [open, close]);
  return ref;
};

const TimerPill: React.FC<Pick<Props, 'timer' | 'isHost' | 'onTimerAction' | 'onTimerExpire'>> = ({ timer, isHost, onTimerAction, onTimerExpire }) => {
  const [, tick] = useState(0);
  const [open, setOpen] = useState(false);
  const ref = useClickAway(open, () => setOpen(false));
  const fired = useRef(false);
  useEffect(() => { const i = setInterval(() => tick((n) => n + 1), 500); return () => clearInterval(i); }, []);
  if (!timer) return null;
  const remaining = timer.running ? Math.max(0, timer.remainingMs - (Date.now() - timer.receivedAt)) : timer.remainingMs;
  const low = remaining < 5 * 60_000 && remaining > 0, done = remaining === 0;
  if (timer.running && done && !fired.current) { fired.current = true; onTimerExpire(); }
  if (!done || !timer.running) { if (remaining > 0) fired.current = false; }
  return (
    <div className="relative" ref={ref}>
      <button onClick={() => isHost && setOpen(!open)} title={isHost ? 'Interview timer (host controls)' : 'Shared timer'}
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs font-mono ${done ? 'bg-rose-500/20 border-rose-500/40 text-rose-300 animate-pulse' : low ? 'bg-amber-500/15 border-amber-500/40 text-amber-300' : 'bg-[#0d1117] border-[#30363d] text-zinc-300'} ${isHost ? 'cursor-pointer hover:border-sky-500/40' : 'cursor-default'}`}>
        <Timer className="w-3.5 h-3.5" />{fmt(remaining)}{!timer.running && remaining > 0 && <Pause className="w-3 h-3 text-zinc-500" />}
      </button>
      {open && isHost && (
        <div className="absolute left-0 mt-1 w-52 bg-[#161b22] border border-[#30363d] rounded-lg shadow-2xl p-2 z-50 space-y-2">
          <div className="grid grid-cols-4 gap-1">
            {[15, 30, 45, 60].map((m) => <button key={m} onClick={() => onTimerAction('set', m * 60_000)} className={`text-[11px] py-1 rounded border cursor-pointer ${timer.durationMs === m * 60_000 ? 'bg-sky-500/20 border-sky-500/40 text-sky-300' : 'border-[#30363d] text-zinc-300 hover:bg-[#21262d]'}`}>{m}m</button>)}
          </div>
          <div className="flex gap-1">
            <button onClick={() => onTimerAction(timer.running ? 'pause' : 'start')} className="flex-1 flex items-center justify-center gap-1 text-[11px] py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer">{timer.running ? <><Pause className="w-3 h-3" />Pause</> : <><Play className="w-3 h-3" />Start</>}</button>
            <button onClick={() => onTimerAction('reset')} className="px-2 rounded border border-[#30363d] text-zinc-300 hover:bg-[#21262d] cursor-pointer" aria-label="Reset timer"><RotateCcw className="w-3 h-3" /></button>
          </div>
        </div>
      )}
    </div>
  );
};

export const Navbar: React.FC<Props> = (p) => {
  const [copied, setCopied] = useState(false);
  const [presets, setPresets] = useState(false);
  const [more, setMore] = useState(false);
  const presetsRef = useClickAway(presets, () => setPresets(false));
  const moreRef = useClickAway(more, () => setMore(false));

  const copyLink = () => {
    const url = `${location.origin}/?room=${encodeURIComponent(p.roomId)}`;
    navigator.clipboard.writeText(url);
    setCopied(true); setTimeout(() => setCopied(false), 1800);
  };

  const menuItem = (icon: React.ReactNode, label: string, fn: () => void) => (
    <button onClick={() => { setMore(false); fn(); }} className="w-full flex items-center gap-2 px-3 py-2 text-xs text-zinc-300 hover:bg-[#21262d] hover:text-white text-left cursor-pointer">{icon}{label}</button>
  );

  return (
    <header className="h-14 bg-[#161b22] border-b border-[#30363d] px-4 flex items-center justify-between z-20 shrink-0 gap-3">
      <div className="flex items-center space-x-3 min-w-0">
        <div className="flex items-center space-x-2 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-500 via-sky-500 to-emerald-400 p-[1.5px] shadow-lg shadow-indigo-500/20">
            <div className="w-full h-full bg-[#0d1117] rounded-[7px] flex items-center justify-center"><Code2 className="w-4 h-4 text-sky-400" /></div>
          </div>
          <span className="hidden xl:flex font-bold text-sm text-white items-center gap-1.5">SyncCode <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20">Studio</span></span>
        </div>

        <div className="flex items-center space-x-1.5 text-xs font-mono bg-[#0d1117] px-2 py-1 rounded border border-[#30363d] shrink-0">
          <span className="text-zinc-500 text-[10px]">ROOM</span>
          <span className="text-sky-300 font-semibold max-w-[110px] truncate">{p.roomId}</span>
          <button onClick={copyLink} title="Copy invite link" aria-label="Copy invite link" className="ml-1 p-0.5 text-zinc-400 hover:text-white cursor-pointer">{copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}</button>
        </div>

        <div className="hidden lg:flex items-center space-x-2 px-2.5 py-1 rounded-full bg-[#0d1117] border border-[#30363d] text-xs shrink-0" role="status">
          <span className={`w-2 h-2 rounded-full ${p.isConnected ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.7)]' : 'bg-rose-500 animate-pulse'}`} />
          <span className="text-zinc-400 font-mono text-[11px]">{p.isConnected ? `${p.latencyMs}ms` : 'Reconnecting…'}</span>
        </div>

        <TimerPill timer={p.timer} isHost={p.isHost} onTimerAction={p.onTimerAction} onTimerExpire={p.onTimerExpire} />

        <div className="relative hidden md:block" ref={presetsRef}>
          <button onClick={() => setPresets(!presets)} className="flex items-center space-x-1.5 text-xs bg-[#21262d] hover:bg-[#30363d] text-zinc-200 px-2.5 py-1.5 rounded-md border border-[#30363d] cursor-pointer">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" /><span className="max-w-[140px] truncate font-medium">{p.activeChallenge?.title || 'Challenges'}</span><ChevronDown className="w-3 h-3 text-zinc-400" />
          </button>
          {presets && (
            <div className="absolute left-0 mt-1 w-72 bg-[#161b22] border border-[#30363d] rounded-lg shadow-2xl py-1 z-50">
              <div className="px-3 py-1.5 text-[11px] font-semibold text-zinc-400 uppercase tracking-wider border-b border-[#30363d]">GenAI / ML challenges {!p.isHost && <span className="normal-case text-zinc-600">(host only)</span>}</div>
              {CHALLENGE_PRESETS.map((c) => (
                <button key={c.id} disabled={!p.isHost} onClick={() => { p.onSelectChallenge(c); setPresets(false); }} className="w-full text-left px-3 py-2 hover:bg-[#21262d] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-between group cursor-pointer">
                  <div><div className="text-xs font-medium text-zinc-200 group-hover:text-white">{c.title}</div><div className="text-[10px] text-zinc-500">{c.tags.slice(0, 3).join(' • ')}</div></div>
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${c.difficulty === 'Easy' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : c.difficulty === 'Medium' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-rose-500/10 text-rose-400 border-rose-500/20'}`}>{c.difficulty}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center space-x-2 shrink-0">
        <button onClick={p.onRunCode} disabled={p.isRunning} className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs shadow-md shadow-emerald-900/30 disabled:opacity-60 cursor-pointer">
          {p.isRunning ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-current" />}<span>{p.isRunning ? 'Running…' : 'Run'}</span>
          <span className="hidden sm:inline-block text-[10px] bg-emerald-700/60 px-1 rounded font-mono ml-1">⌘↵</span>
        </button>
        {p.hasTests && (
          <button onClick={p.onRunTests} disabled={p.isRunning} className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-[#21262d] hover:bg-[#30363d] text-emerald-300 border border-emerald-500/30 font-medium text-xs disabled:opacity-60 cursor-pointer"><FlaskConical className="w-3.5 h-3.5" /><span className="hidden sm:inline">Run Tests</span></button>
        )}
        <button onClick={p.onOpenCopilot} className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-gradient-to-r from-sky-600/30 via-indigo-600/30 to-purple-600/30 hover:from-sky-600/50 hover:to-purple-600/50 text-sky-200 border border-sky-500/40 font-semibold text-xs cursor-pointer"><Sparkles className="w-3.5 h-3.5 text-sky-400" /><span className="hidden md:inline">Copilot</span></button>
        <button onClick={p.onOpenPalette} title="Command palette (Ctrl/⌘+K)" aria-label="Command palette" className="flex items-center gap-1 px-2 py-1.5 rounded-md bg-[#21262d] hover:bg-[#30363d] text-zinc-300 border border-[#30363d] text-xs cursor-pointer"><Command className="w-3.5 h-3.5" /><span className="hidden lg:inline font-mono text-[10px] text-zinc-500">K</span></button>

        {p.isHost && (
          <button onClick={p.onToggleLock} title={p.editLocked ? 'Editing locked for guests — click to unlock' : 'Lock editing for guests'} aria-pressed={p.editLocked}
            className={`p-1.5 rounded-md border cursor-pointer ${p.editLocked ? 'bg-amber-500/15 border-amber-500/40 text-amber-300' : 'bg-[#21262d] border-[#30363d] text-zinc-400 hover:text-white'}`}>
            {p.editLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
          </button>
        )}

        <div className="relative" ref={moreRef}>
          <button onClick={() => setMore(!more)} aria-label="More" className="p-1.5 rounded-md bg-[#21262d] hover:bg-[#30363d] text-zinc-300 border border-[#30363d] cursor-pointer"><MoreHorizontal className="w-4 h-4" /></button>
          {more && (
            <div className="absolute right-0 mt-1 w-48 bg-[#161b22] border border-[#30363d] rounded-lg shadow-2xl py-1 z-50">
              {menuItem(<ExternalLink className="w-3.5 h-3.5 text-sky-400" />, 'Open peer tab', p.onOpenPeerTab)}
              {menuItem(<History className="w-3.5 h-3.5 text-sky-400" />, 'Session replay', p.onOpenReplay)}
              {menuItem(<MessageSquareText className="w-3.5 h-3.5 text-violet-400" />, 'Inline code review', p.onOpenReviews)}
              {menuItem(<BookOpen className="w-3.5 h-3.5 text-indigo-400" />, 'Project dossier', p.onOpenDossier)}
              {menuItem(<Play className="w-3.5 h-3.5 text-emerald-400" />, 'How to run', p.onOpenHowToRun)}
              {p.accountEmail && p.onSignOut && menuItem(<LogOut className="w-3.5 h-3.5 text-zinc-400" />, `Sign out (${p.accountEmail})`, p.onSignOut)}
            </div>
          )}
        </div>

        <div className="flex items-center -space-x-2 pl-1">
          {p.users.map((u) => {
            const me = u.id === p.currentUser.id, host = u.id === p.hostId, following = p.followUserId === u.id;
            return (
              <button key={u.id} onClick={() => !me && p.onToggleFollow(following ? null : u.id)} disabled={me}
                title={`${u.name}${me ? ' (you)' : ''}${host ? ' — host' : ''}${me ? '' : following ? ' — click to stop following' : ' — click to follow'}`}
                className={`relative w-7 h-7 rounded-full text-xs font-semibold flex items-center justify-center text-white ring-2 ${following ? 'ring-violet-400' : 'ring-[#161b22]'} ${me ? 'cursor-default' : 'cursor-pointer hover:z-10'}`} style={{ backgroundColor: u.color }}>
                {u.name.slice(0, 1).toUpperCase()}
                {host && <Crown className="absolute -top-2 left-1/2 -translate-x-1/2 w-3 h-3 text-amber-300 fill-amber-300" />}
                {u.isHandRaised && <span className="absolute -top-2 -right-1 text-[11px]">✋</span>}
                {following && <Eye className="absolute -bottom-1 -right-1 w-3 h-3 text-violet-300 bg-[#161b22] rounded-full" />}
                {u.isSpeaking && <span className="absolute -bottom-0.5 -left-0.5 w-2.5 h-2.5 bg-emerald-400 border-2 border-[#161b22] rounded-full" />}
              </button>
            );
          })}
        </div>
        <button onClick={copyLink} className="p-1.5 text-zinc-400 hover:text-zinc-100 hover:bg-[#21262d] rounded-md cursor-pointer" title="Copy invite link" aria-label="Share"><Share2 className="w-4 h-4" /></button>
      </div>
    </header>
  );
};
