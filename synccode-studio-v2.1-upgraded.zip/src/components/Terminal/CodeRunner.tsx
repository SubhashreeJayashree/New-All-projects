import React, { useEffect, useMemo, useRef, useState } from 'react';
import confetti from 'canvas-confetti';
import { Terminal, Globe, FileQuestion, Trash2, CheckCircle2, XCircle, Clock, ChevronUp, ChevronDown, PenTool, Loader2, FlaskConical } from 'lucide-react';
import { ExecutionResult, ChallengePreset, CodeFile } from '../../types';
import { buildPreviewDoc } from '../../utils/preview';

export type RunnerTab = 'console' | 'tests' | 'preview' | 'board' | 'spec';

interface Props {
  executionResult: ExecutionResult | null;
  onClearOutput: () => void;
  activeChallenge: ChallengePreset | null;
  files: CodeFile[];
  isRunning: boolean;
  runStatus: string;
  tab: RunnerTab;
  onTabChange: (t: RunnerTab) => void;
  board: React.ReactNode;
}

export const CodeRunner: React.FC<Props> = ({ executionResult, onClearOutput, activeChallenge, files, isRunning, runStatus, tab, onTabChange, board }) => {
  const [height, setHeight] = useState(() => Math.round(Math.min(300, window.innerHeight * 0.35)));
  const [previewDoc, setPreviewDoc] = useState(() => buildPreviewDoc(files));
  const dragRef = useRef<{ y: number; h: number } | null>(null);

  // debounce so the iframe doesn't reload on every keystroke
  useEffect(() => {
    if (tab !== 'preview') return;
    const t = setTimeout(() => setPreviewDoc(buildPreviewDoc(files)), 350);
    return () => clearTimeout(t);
  }, [files, tab]);

  const tests = executionResult?.testResults;
  const passed = tests?.filter((t) => t.passed).length ?? 0;
  const allPass = !!tests && tests.length > 0 && passed === tests.length;

  useEffect(() => {
    if (executionResult?.kind === 'tests' && allPass) confetti({ particleCount: 70, spread: 70, origin: { y: 0.85 } });
  }, [executionResult, allPass]);

  const tabBtn = (id: RunnerTab, icon: React.ReactNode, label: string, badge?: React.ReactNode) => (
    <button role="tab" aria-selected={tab === id} onClick={() => onTabChange(id)}
      className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-medium cursor-pointer ${tab === id ? 'bg-[#21262d] text-sky-400 font-semibold' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#21262d]/50'}`}>
      {icon}<span>{label}</span>{badge}
    </button>
  );

  const startDrag = (e: React.PointerEvent) => {
    dragRef.current = { y: e.clientY, h: height };
    (e.target as Element).setPointerCapture(e.pointerId);
  };
  const onDrag = (e: React.PointerEvent) => {
    if (!dragRef.current) return;
    setHeight(Math.min(window.innerHeight * 0.75, Math.max(120, dragRef.current.h + (dragRef.current.y - e.clientY))));
  };

  const failedCount = tests ? tests.length - passed : 0;
  const logs = useMemo(() => executionResult?.logs ?? [], [executionResult]);

  return (
    <div className="border-t border-[#30363d] bg-[#0d1117] flex flex-col shrink-0" style={{ height }}>
      <div onPointerDown={startDrag} onPointerMove={onDrag} onPointerUp={() => (dragRef.current = null)}
        className="h-1.5 -mt-0.5 cursor-row-resize hover:bg-sky-500/40 transition-colors shrink-0" title="Drag to resize" />
      <div className="h-9 bg-[#161b22] px-3 flex items-center justify-between border-b border-[#30363d] select-none shrink-0">
        <div className="flex items-center space-x-1 overflow-x-auto" role="tablist">
          {tabBtn('console', <Terminal className="w-3.5 h-3.5" />, 'Terminal',
            isRunning ? <Loader2 className="w-3 h-3 animate-spin text-amber-400" /> : executionResult && <span className={`w-2 h-2 rounded-full ${executionResult.error ? 'bg-rose-500' : 'bg-emerald-500'}`} />)}
          {tabBtn('tests', <FlaskConical className="w-3.5 h-3.5" />, 'Tests',
            tests && <span className={`text-[10px] px-1.5 rounded-full ${failedCount ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'}`}>{passed}/{tests.length}</span>)}
          {tabBtn('preview', <Globe className="w-3.5 h-3.5" />, 'Live Preview')}
          {tabBtn('board', <PenTool className="w-3.5 h-3.5" />, 'Whiteboard')}
          {activeChallenge && tabBtn('spec', <FileQuestion className="w-3.5 h-3.5" />, 'Challenge')}
        </div>
        <div className="flex items-center space-x-2">
          {isRunning && runStatus && <span className="text-[11px] text-amber-300 font-mono hidden md:inline">{runStatus}</span>}
          {executionResult && !isRunning && (
            <div className="flex items-center space-x-1 text-[11px] font-mono text-zinc-400 bg-[#0d1117] px-2 py-0.5 rounded border border-[#30363d]">
              <Clock className="w-3 h-3 text-zinc-500" /><span>{executionResult.durationMs}ms</span>
              <span className="text-zinc-600">•</span><span className="text-zinc-300 truncate max-w-[100px]">{executionResult.senderName}</span>
            </div>
          )}
          {tab === 'console' && <button onClick={onClearOutput} className="p-1 text-zinc-400 hover:text-white rounded hover:bg-[#21262d] cursor-pointer" title="Clear output" aria-label="Clear output"><Trash2 className="w-3.5 h-3.5" /></button>}
          <button onClick={() => setHeight((h) => (h < 400 ? Math.round(window.innerHeight * 0.6) : 260))} className="p-1 text-zinc-400 hover:text-white rounded hover:bg-[#21262d] cursor-pointer" aria-label="Toggle panel size">
            {height < 400 ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-3 font-mono text-xs min-h-0">
        {tab === 'console' && (
          <div className="space-y-1.5">
            {!executionResult && !isRunning && (
              <div className="text-zinc-500 flex flex-col items-center justify-center py-6 text-center">
                <Terminal className="w-6 h-6 mb-2 opacity-50" />
                <p>Press <strong className="text-emerald-400">Run</strong> (Ctrl/⌘+Enter) to run the selected file. JavaScript, TypeScript, and Python run locally.</p>
                <p className="text-[11px] text-zinc-600 mt-1">C, C++, Java, C#, Go, Rust, PHP, and Ruby use an optional external runner after you approve sending that file. Output is shared with the room.</p>
              </div>
            )}
            {isRunning && !executionResult && <div className="text-amber-300 flex items-center gap-2"><Loader2 className="w-3.5 h-3.5 animate-spin" />{runStatus || 'Running…'}</div>}
            {logs.map((log, i) => (
              <div key={i} className={`p-1.5 rounded flex items-start space-x-2 leading-relaxed ${log.type === 'error' ? 'bg-rose-500/10 text-rose-300 border-l-2 border-rose-500' : log.type === 'warn' ? 'bg-amber-500/10 text-amber-300 border-l-2 border-amber-500' : log.type === 'table' ? 'bg-sky-500/10 text-sky-200 border-l-2 border-sky-500' : 'text-zinc-300 hover:bg-zinc-800/30'}`}>
                <span className="text-zinc-600 select-none text-[10px] pt-0.5">❯</span>
                <pre className="whitespace-pre-wrap break-all flex-1 font-mono select-text">{log.message}</pre>
              </div>
            ))}
            {executionResult?.returnValue && (
              <div className="mt-2 pt-2 border-t border-[#30363d]/50 flex items-center space-x-2 text-emerald-400">
                <span className="text-zinc-500 text-[10px]">Return value:</span>
                <span className="bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 select-text">{executionResult.returnValue}</span>
              </div>
            )}
          </div>
        )}

        {tab === 'tests' && (
          <div className="space-y-2 font-sans">
            {!tests ? (
              <div className="text-zinc-500 text-center py-6 font-mono">
                <FlaskConical className="w-6 h-6 mx-auto mb-2 opacity-50" />
                <p>No test results yet. Click <strong className="text-emerald-400">Run Tests</strong>.</p>
                <p className="text-[11px] text-zinc-600 mt-1">Files named <code>*.test.ts</code>/<code>*.test.js</code> can use <code>test()</code>, <code>describe()</code> and <code>expect()</code>.</p>
              </div>
            ) : (
              <>
                <div className={`flex items-center gap-2 text-sm font-semibold ${failedCount ? 'text-rose-300' : 'text-emerald-300'}`}>
                  {failedCount ? <XCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
                  {failedCount ? `${failedCount} failed, ${passed} passed` : `All ${tests.length} tests passed 🎉`}
                </div>
                {executionResult?.error && <pre className="text-rose-300 text-[11px] whitespace-pre-wrap select-text">{executionResult.error}</pre>}
                {tests.map((t, i) => (
                  <div key={i} className={`rounded-lg border p-2 ${t.passed ? 'border-emerald-500/20 bg-emerald-500/5' : 'border-rose-500/30 bg-rose-500/5'}`}>
                    <div className="flex items-center gap-2 text-xs text-zinc-200">
                      {t.passed ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> : <XCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />}
                      <span>{t.title}</span>
                    </div>
                    {!t.passed && (
                      <div className="mt-1.5 ml-5 text-[11px] font-mono space-y-0.5 select-text">
                        {t.error && <div className="text-rose-300">{t.error.split('\n')[0]}</div>}
                        {t.expected && <div><span className="text-zinc-500">expected </span><span className="text-emerald-300 whitespace-pre-wrap">{t.expected}</span></div>}
                        {t.actual && <div><span className="text-zinc-500">received </span><span className="text-rose-300 whitespace-pre-wrap">{t.actual}</span></div>}
                      </div>
                    )}
                  </div>
                ))}
              </>
            )}
          </div>
        )}

        {tab === 'preview' && (
          <div className="h-full w-full rounded-lg overflow-hidden border border-[#30363d] bg-white">
            <iframe title="Live Preview" srcDoc={previewDoc} sandbox="allow-scripts" className="w-full h-full border-none" />
          </div>
        )}

        {tab === 'board' && <div className="h-full font-sans">{board}</div>}

        {tab === 'spec' && activeChallenge && (
          <div className="space-y-3 font-sans text-zinc-300 p-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white">{activeChallenge.title}</h3>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20">{activeChallenge.difficulty}</span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">{activeChallenge.description}</p>
            <div className="flex flex-wrap gap-1.5 pt-2">
              {activeChallenge.tags.map((t) => <span key={t} className="text-[10px] font-mono bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-zinc-400">#{t}</span>)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
