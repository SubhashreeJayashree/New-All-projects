import React, { useEffect, useMemo, useState } from 'react';
import { History, Pause, Play, X } from 'lucide-react';
import { ReplayEntry } from '../../types';

interface Props {
  isOpen: boolean;
  entries: ReplayEntry[];
  loading: boolean;
  onClose: () => void;
}

export const SessionReplay: React.FC<Props> = ({ isOpen, entries, loading, onClose }) => {
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const ordered = useMemo(() => [...entries].sort((a, b) => a.timestamp - b.timestamp), [entries]);
  const selected = ordered[index] ?? null;

  useEffect(() => {
    if (!playing || ordered.length < 2) return;
    const timer = window.setInterval(() => {
      setIndex((current) => {
        if (current >= ordered.length - 1) { setPlaying(false); return 0; }
        return current + 1;
      });
    }, 1200);
    return () => window.clearInterval(timer);
  }, [playing, ordered.length]);

  useEffect(() => { if (!isOpen) setPlaying(false); }, [isOpen]);
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/70 p-4" role="dialog" aria-modal="true" aria-labelledby="replay-title">
      <section className="flex max-h-[90vh] w-full max-w-5xl flex-col overflow-hidden rounded-xl border border-[#30363d] bg-[#161b22] shadow-2xl">
        <header className="flex items-center justify-between border-b border-[#30363d] px-4 py-3">
          <div className="flex items-center gap-2"><History className="h-4 w-4 text-sky-400" /><div><h2 id="replay-title" className="text-sm font-semibold text-white">Session replay</h2><p className="text-[11px] text-zinc-500">Recent code snapshots saved in this room</p></div></div>
          <button onClick={onClose} aria-label="Close session replay" className="rounded p-1 text-zinc-400 hover:bg-[#21262d] hover:text-white cursor-pointer"><X className="h-4 w-4" /></button>
        </header>
        {selected ? (
          <>
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#30363d] px-4 py-2 text-xs">
              <div className="min-w-0 text-zinc-300"><span className="font-semibold text-sky-300">{selected.fileName}</span><span className="mx-2 text-zinc-600">·</span>{selected.userName}<span className="mx-2 text-zinc-600">·</span>{new Date(selected.timestamp).toLocaleString()}</div>
              <span className="shrink-0 font-mono text-[10px] text-zinc-500">Version {selected.version}</span>
            </div>
            <pre className="min-h-0 flex-1 overflow-auto whitespace-pre-wrap break-words bg-[#0d1117] p-4 font-mono text-xs leading-5 text-zinc-200">{selected.content}</pre>
            <footer className="flex items-center gap-3 border-t border-[#30363d] px-4 py-3">
              <button onClick={() => setPlaying((value) => !value)} disabled={ordered.length < 2} aria-label={playing ? 'Pause replay' : 'Play replay'} className="rounded border border-[#30363d] p-2 text-zinc-200 hover:bg-[#21262d] disabled:opacity-40 cursor-pointer">
                {playing ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
              </button>
              <input aria-label="Replay position" className="min-w-0 flex-1 accent-sky-500" type="range" min={0} max={ordered.length - 1} value={index} onChange={(event) => { setPlaying(false); setIndex(Number(event.target.value)); }} />
              <span className="w-16 text-right font-mono text-[10px] text-zinc-500">{index + 1} / {ordered.length}</span>
            </footer>
          </>
        ) : (
          <div className="flex min-h-64 flex-col items-center justify-center gap-2 p-8 text-center">
            <History className="h-8 w-8 text-zinc-600" />
            <p className="text-sm text-zinc-300">{loading ? 'Loading room history…' : 'No replay snapshots yet'}</p>
            <p className="max-w-md text-xs text-zinc-500">Snapshots are captured while collaborators edit. Reopen replay after making changes to review the timeline.</p>
          </div>
        )}
      </section>
    </div>
  );
};
