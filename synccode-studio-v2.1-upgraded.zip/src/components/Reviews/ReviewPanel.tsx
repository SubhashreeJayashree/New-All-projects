import React, { useMemo, useState } from 'react';
import { Check, CheckCheck, MessageSquareText, Trash2, X } from 'lucide-react';
import { ReviewComment } from '../../types';

interface Props {
  isOpen: boolean;
  comments: ReviewComment[];
  fileId: string;
  fileName: string;
  line: number;
  selectedText: string;
  onClose: () => void;
  onAdd: (content: string) => void;
  onResolve: (id: string, resolved: boolean) => void;
  onDelete: (id: string) => void;
}

export const ReviewPanel: React.FC<Props> = ({ isOpen, comments, fileId, fileName, line, selectedText, onClose, onAdd, onResolve, onDelete }) => {
  const [draft, setDraft] = useState('');
  const [showResolved, setShowResolved] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const visible = useMemo(() => comments.filter((comment) => showResolved || !comment.resolved), [comments, showResolved]);

  if (!isOpen) return null;
  const submit = () => {
    const content = draft.trim();
    if (!content || submitting) return;
    setSubmitting(true);
    onAdd(content);
    setDraft('');
    window.setTimeout(() => setSubmitting(false), 300);
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/70 p-4" role="dialog" aria-modal="true" aria-labelledby="review-title">
      <section className="flex max-h-[90vh] w-full max-w-2xl flex-col overflow-hidden rounded-xl border border-[#30363d] bg-[#161b22] shadow-2xl">
        <header className="flex items-center justify-between border-b border-[#30363d] px-4 py-3">
          <div className="flex items-center gap-2"><MessageSquareText className="h-4 w-4 text-violet-400" /><div><h2 id="review-title" className="text-sm font-semibold text-white">Inline code review</h2><p className="text-[11px] text-zinc-500">Shared comments anchored to file lines</p></div></div>
          <button onClick={onClose} aria-label="Close code review" className="rounded p-1 text-zinc-400 hover:bg-[#21262d] hover:text-white cursor-pointer"><X className="h-4 w-4" /></button>
        </header>
        <div className="border-b border-[#30363d] p-4">
          <div className="mb-2 text-xs text-zinc-400">New comment · <span className="text-sky-300">{fileName || 'No file'}</span> · line {line}</div>
          {!!selectedText && <pre className="mb-2 max-h-20 overflow-auto whitespace-pre-wrap rounded border border-[#30363d] bg-[#0d1117] p-2 font-mono text-[11px] text-zinc-400">{selectedText}</pre>}
          <textarea aria-label="Write a review comment" value={draft} onChange={(event) => setDraft(event.target.value)} maxLength={2000} rows={3} placeholder="Suggest a change or ask a question…" className="w-full resize-y rounded-lg border border-[#30363d] bg-[#0d1117] p-2.5 text-xs text-white outline-none focus:border-violet-500/60" />
          <div className="mt-2 flex items-center justify-between">
            <button onClick={() => setShowResolved((value) => !value)} className="text-[11px] text-zinc-500 hover:text-zinc-300 cursor-pointer">{showResolved ? 'Hide resolved' : 'Show resolved'}</button>
            <button disabled={!draft.trim() || !fileId || submitting} onClick={submit} className="rounded-lg bg-violet-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-violet-600 disabled:opacity-40 cursor-pointer">Add comment</button>
          </div>
        </div>
        <div className="min-h-0 flex-1 space-y-2 overflow-y-auto p-4">
          {visible.length ? visible.map((comment) => (
            <article key={comment.id} className={`rounded-lg border p-3 ${comment.resolved ? 'border-emerald-500/20 bg-emerald-500/5 opacity-75' : 'border-[#30363d] bg-[#0d1117]'}`}>
              <div className="mb-2 flex items-start justify-between gap-3">
                <div className="min-w-0 text-[11px] text-zinc-400"><span className="font-semibold text-zinc-200">{comment.userName}</span><span className="mx-1.5 text-zinc-600">·</span><span className="text-sky-300">{comment.fileName}</span><span className="mx-1.5 text-zinc-600">·</span>line {comment.line}<div className="text-[10px] text-zinc-600">{new Date(comment.timestamp).toLocaleString()}</div></div>
                <div className="flex shrink-0 gap-1">
                  <button onClick={() => onResolve(comment.id, !comment.resolved)} title={comment.resolved ? 'Reopen comment' : 'Resolve comment'} aria-label={comment.resolved ? 'Reopen comment' : 'Resolve comment'} className="rounded p-1 text-zinc-400 hover:bg-[#21262d] hover:text-emerald-300 cursor-pointer">{comment.resolved ? <CheckCheck className="h-3.5 w-3.5" /> : <Check className="h-3.5 w-3.5" />}</button>
                  <button onClick={() => onDelete(comment.id)} title="Delete comment" aria-label="Delete comment" className="rounded p-1 text-zinc-500 hover:bg-rose-500/10 hover:text-rose-300 cursor-pointer"><Trash2 className="h-3.5 w-3.5" /></button>
                </div>
              </div>
              {comment.selectedText && <pre className="mb-2 whitespace-pre-wrap break-words border-l-2 border-violet-500/60 pl-2 font-mono text-[11px] text-zinc-500">{comment.selectedText}</pre>}
              <p className="whitespace-pre-wrap break-words text-xs leading-relaxed text-zinc-200">{comment.content}</p>
            </article>
          )) : <p className="py-6 text-center text-xs text-zinc-500">No {showResolved ? '' : 'open '}review comments yet.</p>}
        </div>
      </section>
    </div>
  );
};
