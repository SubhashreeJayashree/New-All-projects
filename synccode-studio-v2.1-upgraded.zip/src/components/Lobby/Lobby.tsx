import React, { useEffect, useRef, useState } from 'react';
import { Code2, Mic, MicOff, Video, VideoOff, ArrowRight, Dice5, Users, LogIn, LogOut, UserPlus } from 'lucide-react';
import { randomRoomId, store } from '../../utils/identity';

export interface AccountProfile { id: string; email: string; name: string }
export interface JoinInfo { name: string; roomId: string; audio: boolean; video: boolean; account?: AccountProfile | null }

export const Lobby: React.FC<{ initialRoom: string; onJoin: (j: JoinInfo) => void }> = ({ initialRoom, onJoin }) => {
  const [name, setName] = useState(store.get('name'));
  const [room, setRoom] = useState(initialRoom || randomRoomId());
  const [audio, setAudio] = useState(true);
  const [video, setVideo] = useState(true);
  const [camState, setCamState] = useState<'pending' | 'ok' | 'denied'>('pending');
  const [account, setAccount] = useState<AccountProfile | null>(null);
  const [authMode, setAuthMode] = useState<'closed' | 'login' | 'register'>('closed');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authName, setAuthName] = useState('');
  const [authBusy, setAuthBusy] = useState(false);
  const [authError, setAuthError] = useState('');
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/auth/me', { credentials: 'same-origin' })
      .then(async (response) => {
        if (response.ok) {
          const data = await response.json();
          if (!cancelled) { setAccount(data.account); setName(data.account.name); }
        }
      })
      .catch(() => { if (!cancelled) setAuthError('Account service is unavailable; you can still join as a guest.'); });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    let dead = false;
    navigator.mediaDevices?.getUserMedia({ video: true, audio: true })
      .then((s) => {
        if (dead) { s.getTracks().forEach((t) => t.stop()); return; }
        streamRef.current = s;
        if (videoRef.current) videoRef.current.srcObject = s;
        setCamState('ok');
      })
      .catch(() => !dead && setCamState('denied'));
    return () => { dead = true; streamRef.current?.getTracks().forEach((t) => t.stop()); };
  }, []);

  useEffect(() => { streamRef.current?.getVideoTracks().forEach((t) => (t.enabled = video)); }, [video]);

  const validRoom = /^[A-Za-z0-9_-]{1,64}$/.test(room);
  const canJoin = name.trim().length > 0 && validRoom;

  const join = () => {
    if (!canJoin) return;
    streamRef.current?.getTracks().forEach((t) => t.stop()); // release camera before the workspace claims it
    streamRef.current = null;
    store.set('name', name.trim());
    onJoin({ name: name.trim(), roomId: room, audio, video, account });
  };

  const submitAuth = async () => {
    if (!/^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/.test(email.trim())) {
      setAuthError('Enter a valid email address.');
      return;
    }
    if (password.length < 10 || password.length > 128) {
      setAuthError('Password must be between 10 and 128 characters.');
      return;
    }
    if (authMode === 'register' && !authName.trim()) {
      setAuthError('Enter a display name.');
      return;
    }
    setAuthBusy(true);
    setAuthError('');
    try {
      const response = await fetch(`/api/auth/${authMode}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ email, password, name: authName }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not sign in.');
      setAccount(data.account);
      setName(data.account.name);
      setAuthMode('closed');
      setPassword('');
    } catch (error) {
      setAuthError(error instanceof Error ? error.message : 'Could not sign in.');
    } finally {
      setAuthBusy(false);
    }
  };

  const signOut = async () => {
    try {
      const response = await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
      if (!response.ok) throw new Error('Could not sign out.');
      setAccount(null);
      setAuthError('');
    } catch (error) {
      setAuthError(error instanceof Error ? error.message : 'Could not sign out.');
    }
  };

  return (
    <div className="h-screen w-screen flex items-center justify-center bg-[#0d1117] p-4 overflow-auto select-none">
      <div className="w-full max-w-3xl grid md:grid-cols-2 gap-6 bg-[#161b22] border border-[#30363d] rounded-2xl p-6 shadow-2xl">
        <div className="space-y-3">
          <div className="relative aspect-video rounded-xl overflow-hidden bg-[#0d1117] border border-[#30363d] flex items-center justify-center">
            <video ref={videoRef} autoPlay playsInline muted className={`w-full h-full object-cover -scale-x-100 ${video && camState === 'ok' ? 'block' : 'hidden'}`} />
            {!(video && camState === 'ok') && (
              <div className="text-center text-zinc-500 text-xs px-4">
                <VideoOff className="w-7 h-7 mx-auto mb-2 opacity-60" />
                {camState === 'denied' ? 'Camera unavailable — you can still join (a placeholder feed is used).' : video ? 'Starting camera…' : 'Camera off'}
              </div>
            )}
          </div>
          <div className="flex justify-center gap-3">
            <button onClick={() => setAudio(!audio)} className={`p-2.5 rounded-full border cursor-pointer ${audio ? 'bg-[#21262d] border-[#30363d] text-zinc-200' : 'bg-rose-500/20 border-rose-500/30 text-rose-400'}`} aria-label="Toggle microphone">
              {audio ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
            </button>
            <button onClick={() => setVideo(!video)} className={`p-2.5 rounded-full border cursor-pointer ${video ? 'bg-[#21262d] border-[#30363d] text-zinc-200' : 'bg-rose-500/20 border-rose-500/30 text-rose-400'}`} aria-label="Toggle camera">
              {video ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <form className="flex flex-col justify-center space-y-4" onSubmit={(e) => { e.preventDefault(); join(); }}>
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-indigo-500 via-sky-500 to-emerald-400 p-[1.5px]">
              <div className="w-full h-full bg-[#0d1117] rounded-[7px] flex items-center justify-center"><Code2 className="w-4 h-4 text-sky-400" /></div>
            </div>
            <div>
              <h1 className="text-base font-bold text-white leading-tight">SyncCode Studio</h1>
              <p className="text-[11px] text-zinc-500">Real-time collaborative IDE & video workspace</p>
            </div>
          </div>

          {account ? (
            <div className="flex items-center justify-between gap-2 rounded-lg border border-emerald-500/25 bg-emerald-500/5 px-3 py-2">
              <div className="min-w-0 text-[11px]">
                <div className="font-medium text-emerald-300">Signed in as {account.name}</div>
                <div className="truncate text-zinc-500">{account.email}</div>
              </div>
              <button type="button" onClick={signOut} className="flex items-center gap-1 rounded border border-[#30363d] px-2 py-1 text-[11px] text-zinc-300 hover:text-white cursor-pointer"><LogOut className="w-3 h-3" /> Sign out</button>
            </div>
          ) : authMode === 'closed' ? (
            <div className="flex items-center gap-2">
              <button type="button" onClick={() => { setAuthMode('login'); setAuthError(''); }} className="flex items-center gap-1.5 rounded-lg border border-[#30363d] px-3 py-2 text-xs text-zinc-300 hover:border-sky-500/40 hover:text-white cursor-pointer"><LogIn className="w-3.5 h-3.5" /> Sign in</button>
              <button type="button" onClick={() => { setAuthMode('register'); setAuthError(''); }} className="flex items-center gap-1.5 rounded-lg border border-[#30363d] px-3 py-2 text-xs text-zinc-300 hover:border-sky-500/40 hover:text-white cursor-pointer"><UserPlus className="w-3.5 h-3.5" /> Create account</button>
              <span className="text-[10px] text-zinc-500">Optional</span>
            </div>
          ) : (
            <div className="space-y-2 rounded-lg border border-[#30363d] bg-[#0d1117] p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-zinc-200">{authMode === 'login' ? 'Sign in' : 'Create an account'}</span>
                <button type="button" onClick={() => { setAuthMode('closed'); setAuthError(''); }} className="text-[11px] text-zinc-500 hover:text-white cursor-pointer">Continue as guest</button>
              </div>
              {authMode === 'register' && <input required value={authName} onChange={(event) => setAuthName(event.target.value)} maxLength={32} placeholder="Display name" autoComplete="name" className="w-full rounded border border-[#30363d] bg-[#161b22] px-2.5 py-2 text-xs text-white outline-none focus:border-sky-500/60" />}
              <input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} maxLength={320} placeholder="Email address" autoComplete="email" className="w-full rounded border border-[#30363d] bg-[#161b22] px-2.5 py-2 text-xs text-white outline-none focus:border-sky-500/60" />
              <input required type="password" value={password} onChange={(event) => setPassword(event.target.value)} minLength={10} maxLength={128} placeholder="Password (at least 10 characters)" autoComplete={authMode === 'login' ? 'current-password' : 'new-password'} className="w-full rounded border border-[#30363d] bg-[#161b22] px-2.5 py-2 text-xs text-white outline-none focus:border-sky-500/60" />
              <button type="button" onClick={submitAuth} disabled={authBusy || !email.trim() || !password} className="w-full rounded-lg bg-sky-700 px-3 py-2 text-xs font-semibold text-white hover:bg-sky-600 disabled:opacity-50 cursor-pointer">{authBusy ? 'Please wait…' : authMode === 'login' ? 'Sign in' : 'Create account'}</button>
              {authError && <p role="alert" className="text-[11px] text-rose-300">{authError}</p>}
            </div>
          )}
          {authMode === 'closed' && authError && <p role="status" className="text-[11px] text-amber-300">{authError}</p>}

          <label className="block text-xs text-zinc-400">
            Your name
            <input autoFocus value={name} onChange={(e) => setName(e.target.value)} maxLength={32} placeholder="e.g. Priya Sharma"
              className="mt-1 w-full bg-[#0d1117] border border-[#30363d] focus:border-sky-500/60 rounded-lg px-3 py-2 text-sm text-white outline-none select-text" />
          </label>

          <label className="block text-xs text-zinc-400">
            Room code
            <div className="mt-1 flex gap-2">
              <input value={room} onChange={(e) => setRoom(e.target.value.replace(/\s/g, '-'))} maxLength={64}
                className={`flex-1 bg-[#0d1117] border rounded-lg px-3 py-2 text-sm text-white font-mono outline-none select-text ${validRoom ? 'border-[#30363d] focus:border-sky-500/60' : 'border-rose-500/60'}`} />
              <button type="button" onClick={() => setRoom(randomRoomId())} title="Generate a new room" className="px-3 rounded-lg bg-[#21262d] border border-[#30363d] text-zinc-300 hover:text-white cursor-pointer">
                <Dice5 className="w-4 h-4" />
              </button>
            </div>
            {!validRoom && <span className="text-[11px] text-rose-400">Use letters, numbers, - and _ only.</span>}
          </label>

          <button type="submit" disabled={!canJoin}
            className="flex items-center justify-center gap-2 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-sm font-semibold cursor-pointer transition-colors">
            Join session <ArrowRight className="w-4 h-4" />
          </button>
          <p className="flex items-center gap-1.5 text-[11px] text-zinc-500"><Users className="w-3 h-3" /> The first person in a room becomes the host. Share the link to invite others.</p>
        </form>
      </div>
    </div>
  );
};
