import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';

export interface CodeAction {
  label: string;
  run: (code: string, lang: string) => void;
}

interface Props {
  text: string;
  codeActions?: CodeAction[];
  compact?: boolean;
}

/** Small, safe markdown renderer (headings, lists, bold, inline code, fenced blocks). No raw HTML. */
export const Markdown: React.FC<Props> = ({ text, codeActions, compact }) => {
  const parts: { code: boolean; lang: string; body: string }[] = [];
  const re = /```([\w+-]*)[^\n]*\n([\s\S]*?)(```|$)/g;
  let last = 0, m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push({ code: false, lang: '', body: text.slice(last, m.index) });
    parts.push({ code: true, lang: m[1], body: m[2].replace(/\n$/, '') });
    last = m.index + m[0].length;
    if (m[3] === '') break;
  }
  if (last < text.length) parts.push({ code: false, lang: '', body: text.slice(last) });

  return (
    <div className={compact ? 'space-y-1.5' : 'space-y-2.5'}>
      {parts.map((p, i) => (p.code ? <CodeBlock key={i} {...p} actions={codeActions} /> : <Prose key={i} text={p.body} />))}
    </div>
  );
};

const CodeBlock: React.FC<{ lang: string; body: string; actions?: CodeAction[] }> = ({ lang, body, actions }) => {
  const [copied, setCopied] = useState(false);
  return (
    <div className="rounded-lg border border-[#30363d] bg-[#0d1117] overflow-hidden my-1">
      <div className="flex items-center justify-between px-2 py-1 bg-[#161b22] border-b border-[#30363d] select-none">
        <span className="text-[10px] font-mono text-zinc-500">{lang || 'code'}</span>
        <div className="flex items-center gap-1">
          {actions?.map((a) => (
            <button key={a.label} onClick={() => a.run(body, lang)} className="text-[10px] px-1.5 py-0.5 rounded bg-sky-500/10 text-sky-300 border border-sky-500/30 hover:bg-sky-500/20 cursor-pointer">
              {a.label}
            </button>
          ))}
          <button
            onClick={() => { navigator.clipboard.writeText(body); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
            className="text-[10px] px-1.5 py-0.5 rounded bg-[#21262d] text-zinc-300 border border-[#30363d] hover:text-white flex items-center gap-1 cursor-pointer"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
      </div>
      <pre className="p-2.5 overflow-x-auto text-[11px] leading-relaxed text-zinc-200 font-mono select-text whitespace-pre">{body}</pre>
    </div>
  );
};

function inline(s: string): React.ReactNode[] {
  const out: React.ReactNode[] = [];
  const re = /(`[^`]+`|\*\*[^*]+\*\*)/g;
  let last = 0, m: RegExpExecArray | null, k = 0;
  while ((m = re.exec(s))) {
    if (m.index > last) out.push(s.slice(last, m.index));
    const tok = m[0];
    out.push(tok.startsWith('`')
      ? <code key={k++} className="px-1 py-0.5 rounded bg-black/40 text-sky-300 font-mono text-[0.95em]">{tok.slice(1, -1)}</code>
      : <strong key={k++} className="text-white font-semibold">{tok.slice(2, -2)}</strong>);
    last = m.index + tok.length;
  }
  if (last < s.length) out.push(s.slice(last));
  return out;
}

const Prose: React.FC<{ text: string }> = ({ text }) => {
  const lines = text.split('\n');
  const blocks: React.ReactNode[] = [];
  let list: { ordered: boolean; items: string[] } | null = null;
  let para: string[] = [];
  const flushPara = () => { if (para.length) { blocks.push(<p key={blocks.length} className="leading-relaxed">{inline(para.join(' '))}</p>); para = []; } };
  const flushList = () => {
    if (!list) return;
    const Tag = list.ordered ? 'ol' : 'ul';
    blocks.push(<Tag key={blocks.length} className={`${list.ordered ? 'list-decimal' : 'list-disc'} pl-5 space-y-0.5`}>{list.items.map((it, i) => <li key={i}>{inline(it)}</li>)}</Tag>);
    list = null;
  };
  for (const line of lines) {
    const h = line.match(/^(#{1,4})\s+(.*)$/);
    const li = line.match(/^\s*([-*]|\d+\.)\s+(.*)$/);
    if (h) { flushPara(); flushList(); blocks.push(<div key={blocks.length} className="font-semibold text-white mt-1">{inline(h[2])}</div>); }
    else if (li) {
      flushPara();
      const ordered = /\d/.test(li[1]);
      if (!list || list.ordered !== ordered) { flushList(); list = { ordered, items: [] }; }
      list.items.push(li[2]);
    } else if (!line.trim()) { flushPara(); flushList(); }
    else { flushList(); para.push(line.trim()); }
  }
  flushPara(); flushList();
  return <>{blocks}</>;
};
