import React from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export interface Toast { id: number; text: string; kind: 'info' | 'success' | 'error' }

export const ToastHost: React.FC<{ toasts: Toast[]; dismiss: (id: number) => void }> = ({ toasts, dismiss }) => (
  <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[70] flex flex-col items-center gap-2 pointer-events-none">
    {toasts.map((t) => (
      <div key={t.id} role="status" className="pointer-events-auto flex items-center gap-2 pl-3 pr-2 py-2 rounded-lg border bg-[#161b22] shadow-2xl text-xs text-zinc-200 border-[#30363d] animate-[toast-in_.2s_ease-out]">
        {t.kind === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : t.kind === 'error' ? <AlertCircle className="w-4 h-4 text-rose-400" /> : <Info className="w-4 h-4 text-sky-400" />}
        <span className="max-w-[60vw]">{t.text}</span>
        <button onClick={() => dismiss(t.id)} className="p-0.5 text-zinc-500 hover:text-white cursor-pointer" aria-label="Dismiss"><X className="w-3 h-3" /></button>
      </div>
    ))}
  </div>
);
