import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import Prism from 'prismjs';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-markdown';
import 'prismjs/components/prism-python';
import { Plus, X, Download, Upload, FileText, FileCode, Search, ChevronUp, ChevronDown, Lock, Eye, Archive } from 'lucide-react';
import { CodeFile, CodeLanguage, RemoteCursor, User } from '../../types';
import { Op, transformIndex } from '../../shared/ot';
import { store } from '../../utils/identity';

const PAD = 12;
const TAB = 2;
const PAIRS: Record<string, string> = { '(': ')', '[': ']', '{': '}', '"': '"', "'": "'", '`': '`' };
const CLOSERS = new Set([')', ']', '}']);
const TEXT_EXT = /\.(ts|tsx|js|jsx|py|c|h|cc|cpp|cxx|hpp|hh|hxx|java|cs|go|rs|php|rb|html?|css|json|md|txt|csv|yml|yaml|toml|ini|sh)$/i;

interface Props {
  files: CodeFile[];
  activeFileId: string;
  users: User[];
  currentUser: User;
  remoteCursors: RemoteCursor[];
  readOnly: boolean;
  readOnlyReason?: string;
  followUserId: string | null;
  findSignal: number;
  onSelectFile: (id: string) => void;
  onCodeChange: (fileId: string, content: string) => void;
  onCreateFile: (name: string) => void;
  onRenameFile: (id: string, name: string) => void;
  onDeleteFile: (id: string) => void;
  onCursorChange: (fileId: string, offset: number, selStart: number, selEnd: number) => void;
  onRunCode: () => void;
  onSave: () => void;
  onImportFiles: (files: { name: string; content: string }[]) => void;
  onDownloadZip: () => void;
  onToggleFollow: (userId: string | null) => void;
  subscribeRemoteOps: (cb: (fileId: string, op: Op) => void) => () => void;
  notify: (text: string, kind?: 'info' | 'success' | 'error') => void;
}

/** Insert/replace text while keeping the browser's native undo stack where possible. */
function edit(el: HTMLTextAreaElement, start: number, end: number, text: string, selStart: number, selEnd = selStart) {
  el.focus();
  el.setSelectionRange(start, end);
  let ok = false;
  try { ok = text === '' ? (start === end ? true : document.execCommand('delete')) : document.execCommand('insertText', false, text); } catch { ok = false; }
  if (!ok) {
    const next = el.value.slice(0, start) + text + el.value.slice(end);
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!;
    setter.call(el, next);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }
  el.setSelectionRange(selStart, selEnd);
}

const lineStartOf = (v: string, i: number) => v.lastIndexOf('\n', i - 1) + 1;
const lineEndOf = (v: string, i: number) => { const e = v.indexOf('\n', i); return e < 0 ? v.length : e; };
function blockRange(v: string, s: number, e: number): [number, number] {
  const ls = lineStartOf(v, s);
  const endRef = e > s && v[e - 1] === '\n' ? e - 1 : e;
  return [ls, lineEndOf(v, endRef)];
}

const COMMENT: Partial<Record<CodeFile['language'], [string, string]>> = {
  javascript: ['// ', ''], typescript: ['// ', ''], python: ['# ', ''], css: ['/* ', ' */'], html: ['<!-- ', ' -->'],
};

const EXTRA_GRAMMARS: Partial<Record<CodeLanguage, () => Promise<unknown>>> = {
  c: () => import('prismjs/components/prism-c'),
  cpp: () => import('prismjs/components/prism-cpp'),
  java: () => import('prismjs/components/prism-java'),
  csharp: () => import('prismjs/components/prism-csharp'),
  go: () => import('prismjs/components/prism-go'),
  rust: () => import('prismjs/components/prism-rust'),
  php: () => import('prismjs/components/prism-php'),
  ruby: () => import('prismjs/components/prism-ruby'),
};

export const CodeEditor: React.FC<Props> = (p) => {
  const { files, activeFileId, remoteCursors, readOnly } = p;
  const file = files.find((f) => f.id === activeFileId) || files[0];
  const text = file?.content ?? '';

  const [fontSize, setFontSize] = useState(() => Math.min(20, Math.max(11, Number(store.get('font', '14')) || 14)));
  const [caret, setCaret] = useState({ line: 1, col: 1, sel: 0 });
  const [addingFile, setAddingFile] = useState(false);
  const [newName, setNewName] = useState('');
  const [renaming, setRenaming] = useState<string | null>(null);
  const [renameVal, setRenameVal] = useState('');
  const [charW, setCharW] = useState(fontSize * 0.6);
  const [grammarRevision, setGrammarRevision] = useState(0);
  const [dragOver, setDragOver] = useState(false);
  const [find, setFind] = useState({ open: false, q: '', r: '', cs: false, idx: 0, showReplace: false });

  const taRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const measureRef = useRef<HTMLSpanElement>(null);
  const findInputRef = useRef<HTMLInputElement>(null);
  const uploadRef = useRef<HTMLInputElement>(null);
  const pendingSel = useRef<[number, number] | null>(null);
  const lh = Math.round(fontSize * 1.5);

  useEffect(() => {
    if (!file || Prism.languages[file.language]) return;
    const load = EXTRA_GRAMMARS[file.language];
    if (!load) return;
    let active = true;
    load().then(() => {
      if (active) setGrammarRevision((revision) => revision + 1);
    }).catch((error: unknown) => console.error(`Could not load syntax highlighting for ${file.language}`, error));
    return () => { active = false; };
  }, [file?.language]);

  useEffect(() => { store.set('font', String(fontSize)); }, [fontSize]);

  // exact monospace advance width
  useLayoutEffect(() => {
    const measure = () => { const w = measureRef.current?.getBoundingClientRect().width; if (w) setCharW(w / 100); };
    measure();
    document.fonts?.ready.then(measure);
  }, [fontSize]);

  // ---------- derived ----------
  const html = useMemo(() => {
    if (!file) return '';
    const grammar = Prism.languages[file.language] || Prism.languages.javascript;
    return Prism.highlight(text, grammar, file.language);
  }, [text, file?.language, grammarRevision]);

  const lineStarts = useMemo(() => {
    const a = [0];
    for (let i = 0; i < text.length; i++) if (text.charCodeAt(i) === 10) a.push(i + 1);
    return a;
  }, [text]);

  const xy = useCallback((off: number) => {
    off = Math.max(0, Math.min(off, text.length));
    let lo = 0, hi = lineStarts.length - 1;
    while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (lineStarts[mid] <= off) lo = mid; else hi = mid - 1; }
    const lineText = text.slice(lineStarts[lo], off);
    let vcol = 0;
    for (const ch of lineText) vcol += ch === '\t' ? TAB - (vcol % TAB) : 1;
    return { line: lo, vcol, x: PAD + vcol * charW, y: PAD + lo * lh };
  }, [text, lineStarts, charW, lh]);

  const rects = useCallback((a: number, b: number) => {
    if (a > b) [a, b] = [b, a];
    const out: { x: number; y: number; w: number }[] = [];
    const s = xy(a), e = xy(b);
    for (let l = s.line; l <= e.line; l++) {
      const x0 = l === s.line ? s.vcol : 0;
      let x1: number;
      if (l === e.line) x1 = e.vcol;
      else { const len = (lineStarts[l + 1] ?? text.length + 1) - lineStarts[l] - 1; x1 = len + 1; }
      if (x1 > x0) out.push({ x: PAD + x0 * charW, y: PAD + l * lh, w: (x1 - x0) * charW });
    }
    return out;
  }, [xy, lineStarts, text.length, charW, lh]);

  const maxLen = useMemo(() => { let m = 0; for (let i = 0; i < lineStarts.length; i++) m = Math.max(m, (lineStarts[i + 1] ?? text.length + 1) - lineStarts[i]); return m; }, [lineStarts, text.length]);

  // ---------- find ----------
  const matches = useMemo(() => {
    if (!find.open || !find.q) return [] as number[];
    const hay = find.cs ? text : text.toLowerCase();
    const needle = find.cs ? find.q : find.q.toLowerCase();
    const out: number[] = [];
    for (let i = hay.indexOf(needle); i >= 0 && out.length < 5000; i = hay.indexOf(needle, i + Math.max(1, needle.length))) out.push(i);
    return out;
  }, [find.open, find.q, find.cs, text]);

  useEffect(() => { if (find.open) findInputRef.current?.focus(); }, [find.open, p.findSignal]);
  useEffect(() => { if (p.findSignal) setFind((f) => ({ ...f, open: true })); }, [p.findSignal]);

  // ---------- scrolling helpers ----------
  const reveal = useCallback((off: number, center = false) => {
    const sc = scrollRef.current;
    if (!sc) return;
    const { x, y } = xy(off);
    const gutter = 56;
    if (center || y < sc.scrollTop + lh || y > sc.scrollTop + sc.clientHeight - lh * 2) sc.scrollTop = Math.max(0, y - (center ? sc.clientHeight / 2 : sc.clientHeight / 3));
    if (x < sc.scrollLeft + gutter + 8) sc.scrollLeft = Math.max(0, x - gutter - 40);
    else if (x > sc.scrollLeft + sc.clientWidth - 24) sc.scrollLeft = x - sc.clientWidth + 80;
  }, [xy, lh]);

  const jumpToMatch = useCallback((i: number) => {
    if (!matches.length) return;
    const k = ((i % matches.length) + matches.length) % matches.length;
    setFind((f) => ({ ...f, idx: k }));
    reveal(matches[k], true);
  }, [matches, reveal]);

  useEffect(() => { if (find.open && matches.length) { const k = Math.min(find.idx, matches.length - 1); reveal(matches[k], true); } }, [find.q, find.cs]); // eslint-disable-line

  // ---------- remote edits: keep the local caret stable ----------
  useEffect(() => p.subscribeRemoteOps((fid, op) => {
    const el = taRef.current;
    if (!el || fid !== activeFileId || document.activeElement !== el) return;
    pendingSel.current = [transformIndex(el.selectionStart, op), transformIndex(el.selectionEnd, op)];
  }), [p.subscribeRemoteOps, activeFileId]); // eslint-disable-line

  useLayoutEffect(() => {
    const el = taRef.current;
    if (el && pendingSel.current) {
      const [a, b] = pendingSel.current;
      pendingSel.current = null;
      el.setSelectionRange(a, b);
    }
  }, [text]);

  // follow mode
  useEffect(() => {
    if (!p.followUserId) return;
    const c = remoteCursors.find((r) => r.userId === p.followUserId && r.fileId === activeFileId);
    if (c) reveal(c.offset, true);
  }, [remoteCursors, p.followUserId, activeFileId]); // eslint-disable-line

  // ---------- caret reporting ----------
  const onCaret = useCallback((scroll = true) => {
    const el = taRef.current;
    if (!el || !file) return;
    const s = el.selectionStart, e = el.selectionEnd;
    const pos = xy(s);
    setCaret({ line: pos.line + 1, col: s - lineStarts[pos.line] + 1, sel: Math.abs(e - s) });
    p.onCursorChange(file.id, el.selectionEnd === s ? s : e, Math.min(s, e), Math.max(s, e));
    if (scroll) reveal(el.selectionDirection === 'backward' ? s : e);
  }, [file?.id, xy, lineStarts, reveal, p.onCursorChange]); // eslint-disable-line

  // ---------- keyboard ----------
  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const el = taRef.current;
    if (!el || !file || e.nativeEvent.isComposing) return;
    const mod = e.metaKey || e.ctrlKey;
    const key = e.key;

    if (mod && key === 'Enter') { e.preventDefault(); p.onRunCode(); return; }
    if (mod && key.toLowerCase() === 's') { e.preventDefault(); p.onSave(); return; }
    if (mod && key.toLowerCase() === 'f') { e.preventDefault(); setFind((f) => ({ ...f, open: true })); return; }
    if (readOnly) return;

    const v = el.value, s = el.selectionStart, en = el.selectionEnd;

    // comment toggle
    if (mod && key === '/') {
      const syn = COMMENT[file.language];
      if (!syn) return;
      e.preventDefault();
      const [bs, be] = blockRange(v, s, en);
      const lines = v.slice(bs, be).split('\n');
      const [open, close] = syn;
      const trimOpen = open.trim(), trimClose = close.trim();
      const isC = (l: string) => { const t = l.trim(); return t.startsWith(trimOpen) && (!trimClose || t.endsWith(trimClose)); };
      const all = lines.filter((l) => l.trim()).every(isC);
      const minIndent = Math.min(...lines.filter((l) => l.trim()).map((l) => l.match(/^\s*/)![0].length), 1e9);
      const out = lines.map((l) => {
        if (!l.trim()) return l;
        if (all) {
          const ind = l.match(/^\s*/)![0];
          let body = l.slice(ind.length).slice(trimOpen.length);
          if (body.startsWith(' ')) body = body.slice(1);
          if (trimClose) body = body.replace(new RegExp(`\\s*${trimClose.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*$`), '');
          return ind + body;
        }
        return l.slice(0, minIndent) + open + l.slice(minIndent) + close;
      }).join('\n');
      edit(el, bs, be, out, bs, bs + out.length);
      return;
    }

    // move / duplicate lines
    if (e.altKey && (key === 'ArrowUp' || key === 'ArrowDown')) {
      e.preventDefault();
      const [bs, be] = blockRange(v, s, en);
      const block = v.slice(bs, be);
      if (e.shiftKey) {
        edit(el, be, be, '\n' + block, key === 'ArrowDown' ? s + block.length + 1 : s, key === 'ArrowDown' ? en + block.length + 1 : en);
      } else if (key === 'ArrowUp' && bs > 0) {
        const ps = lineStartOf(v, bs - 1);
        const prev = v.slice(ps, bs - 1);
        edit(el, ps, be, block + '\n' + prev, s - prev.length - 1, en - prev.length - 1);
      } else if (key === 'ArrowDown' && be < v.length) {
        const ne = lineEndOf(v, be + 1);
        const next = v.slice(be + 1, ne);
        edit(el, bs, ne, next + '\n' + block, s + next.length + 1, en + next.length + 1);
      }
      return;
    }

    if (mod || e.altKey) return;

    // Tab / Shift+Tab
    if (key === 'Tab') {
      e.preventDefault();
      const multi = v.slice(s, en).includes('\n');
      const ind = ' '.repeat(TAB);
      if (!e.shiftKey && !multi && s === en) { edit(el, s, en, ind, s + TAB); return; }
      if (!e.shiftKey && s !== en && !multi) { edit(el, s, en, ind, s + TAB); return; }
      const [bs, be] = blockRange(v, s, en);
      const lines = v.slice(bs, be).split('\n');
      let firstDelta = 0, total = 0;
      const out = lines.map((l, i) => {
        if (!e.shiftKey) { if (i === 0) firstDelta = TAB; total += TAB; return l.trim() ? ind + l : l; }
        const m = l.match(/^( {1,2}|\t)/);
        const d = m ? m[0].length : 0;
        if (i === 0) firstDelta = -d; total -= d;
        return l.slice(d);
      });
      const joined = out.join('\n');
      edit(el, bs, be, joined, Math.max(bs, s + firstDelta), en + total);
      return;
    }

    // Enter: smart indent + brace expansion
    if (key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      const ls = lineStartOf(v, s);
      const before = v.slice(ls, s);
      const indent = before.match(/^\s*/)![0];
      const extra = /[{\[(:]\s*$/.test(before) ? ' '.repeat(TAB) : '';
      const prev = v[s - 1], next = v[en];
      if (s === en && prev && next && PAIRS[prev] === next && '{[('.includes(prev)) {
        const ins = '\n' + indent + extra + '\n' + indent;
        edit(el, s, en, ins, s + 1 + indent.length + extra.length);
      } else {
        const ins = '\n' + indent + extra;
        edit(el, s, en, ins, s + ins.length);
      }
      return;
    }

    // Backspace on an empty pair
    if (key === 'Backspace' && s === en && s > 0 && PAIRS[v[s - 1]] === v[s] && file.language !== 'markdown') {
      e.preventDefault();
      edit(el, s - 1, s + 1, '', s - 1);
      return;
    }

    // auto-close / overtype
    if (file.language !== 'markdown' && key.length === 1) {
      if (CLOSERS.has(key) && s === en && v[s] === key) { e.preventDefault(); el.setSelectionRange(s + 1, s + 1); onCaret(); return; }
      if (PAIRS[key]) {
        const close = PAIRS[key];
        const isQuote = key === close;
        if (s !== en) { e.preventDefault(); edit(el, s, en, key + v.slice(s, en) + close, s + 1, en + 1); return; }
        if (isQuote) {
          if (v[s] === key) { e.preventDefault(); el.setSelectionRange(s + 1, s + 1); onCaret(); return; }
          if (/[\w]/.test(v[s - 1] || '')) return; // apostrophes, 2x"…
        }
        if (/[\w]/.test(v[s] || '') && !isQuote) return;
        e.preventDefault();
        edit(el, s, en, key + close, s + 1);
      }
    }
  };

  // ---------- find actions ----------
  const replaceCurrent = () => {
    const el = taRef.current;
    if (!el || readOnly || !matches.length) return;
    const k = Math.min(find.idx, matches.length - 1), at = matches[k];
    edit(el, at, at + find.q.length, find.r, at + find.r.length);
    setTimeout(() => findInputRef.current?.focus(), 0);
  };
  const replaceAll = () => {
    const el = taRef.current;
    if (!el || readOnly || !matches.length) return;
    let out = '', last = 0;
    for (const at of matches) { out += text.slice(last, at) + find.r; last = at + find.q.length; }
    out += text.slice(last);
    edit(el, 0, text.length, out, 0);
    p.notify(`Replaced ${matches.length} occurrence${matches.length > 1 ? 's' : ''}`, 'success');
  };

  // ---------- files ----------
  const readFiles = async (list: FileList | File[]) => {
    const out: { name: string; content: string }[] = [];
    for (const f of Array.from(list)) {
      if (!TEXT_EXT.test(f.name) && !f.type.startsWith('text/')) { p.notify(`Skipped ${f.name} (not a text file)`, 'error'); continue; }
      if (f.size > 500_000) { p.notify(`Skipped ${f.name} (over 500 KB)`, 'error'); continue; }
      out.push({ name: f.name, content: await f.text() });
    }
    if (out.length) p.onImportFiles(out);
  };

  const download = () => {
    if (!file) return;
    const url = URL.createObjectURL(new Blob([file.content], { type: 'text/plain' }));
    const a = document.createElement('a'); a.href = url; a.download = file.name; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 500);
  };

  const icon = (n: string) => /\.tsx?$/.test(n) ? <span className="text-[10px] font-bold text-sky-400 font-mono">TS</span>
    : /\.jsx?$/.test(n) ? <span className="text-[10px] font-bold text-amber-400 font-mono">JS</span>
    : /\.py$/.test(n) ? <span className="text-[10px] font-bold text-emerald-400 font-mono">PY</span>
    : /\.html?$/.test(n) ? <span className="text-[10px] font-bold text-orange-400 font-mono">HTML</span>
    : /\.css$/.test(n) ? <span className="text-[10px] font-bold text-pink-400 font-mono">CSS</span>
    : /\.md$/.test(n) ? <FileText className="w-3.5 h-3.5 text-zinc-400" /> : <FileCode className="w-3.5 h-3.5 text-sky-400" />;

  const here = remoteCursors.filter((c) => c.fileId === file?.id);
  const fontStyle: React.CSSProperties = { fontSize, lineHeight: `${lh}px`, tabSize: TAB, fontFamily: "'JetBrains Mono','Fira Code',ui-monospace,Menlo,Consolas,monospace" };
  const nLines = lineStarts.length;

  if (!file) return <div className="flex-1 bg-[#0d1117]" />;

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-[#0d1117] overflow-hidden relative"
      onDragOver={(e) => { if (e.dataTransfer.types.includes('Files')) { e.preventDefault(); setDragOver(true); } }}
      onDragLeave={() => setDragOver(false)}
      onDrop={(e) => { e.preventDefault(); setDragOver(false); if (e.dataTransfer.files.length) readFiles(e.dataTransfer.files); }}>

      {/* Tabs */}
      <div className="h-10 bg-[#161b22] border-b border-[#30363d] flex items-center justify-between px-2 select-none shrink-0">
        <div className="flex items-center space-x-1 overflow-x-auto min-w-0" role="tablist">
          {files.map((f) => {
            const active = f.id === activeFileId;
            const viewers = remoteCursors.filter((c) => c.fileId === f.id);
            return (
              <div key={f.id} role="tab" aria-selected={active} onClick={() => renaming !== f.id && p.onSelectFile(f.id)}
                className={`group flex items-center space-x-2 px-3 py-1.5 rounded-t-md text-xs font-mono cursor-pointer border-t-2 shrink-0 ${active ? 'bg-[#0d1117] text-white border-sky-400' : 'text-zinc-400 hover:text-zinc-200 border-transparent hover:bg-[#21262d]'}`}>
                {icon(f.name)}
                {renaming === f.id ? (
                  <form onSubmit={(e) => { e.preventDefault(); p.onRenameFile(f.id, renameVal.trim()); setRenaming(null); }}>
                    <input autoFocus value={renameVal} onChange={(e) => setRenameVal(e.target.value)} onBlur={() => setRenaming(null)}
                      onKeyDown={(e) => e.key === 'Escape' && setRenaming(null)} className="bg-[#21262d] text-white px-1 py-0.5 rounded text-xs outline-none w-28" />
                  </form>
                ) : (
                  <span className="font-medium" onDoubleClick={() => !readOnly && (setRenaming(f.id), setRenameVal(f.name))} title="Double-click to rename">{f.name}</span>
                )}
                {viewers.length > 0 && (
                  <span className="flex -space-x-1">{viewers.slice(0, 3).map((v) => <span key={v.userId} title={`${v.userName} is here`} className="w-2 h-2 rounded-full ring-1 ring-[#161b22]" style={{ background: v.userColor }} />)}</span>
                )}
                {files.length > 1 && !readOnly && (
                  <button onClick={(e) => { e.stopPropagation(); if (confirm(`Delete ${f.name} for everyone in the room?`)) p.onDeleteFile(f.id); }}
                    className="opacity-0 group-hover:opacity-100 p-0.5 hover:text-rose-400 rounded" title="Delete file" aria-label={`Delete ${f.name}`}><X className="w-3 h-3" /></button>
                )}
              </div>
            );
          })}
          {addingFile ? (
            <form onSubmit={(e) => { e.preventDefault(); if (newName.trim()) p.onCreateFile(newName.trim()); setNewName(''); setAddingFile(false); }}>
              <input autoFocus placeholder="name.ts" value={newName} onChange={(e) => setNewName(e.target.value)} onBlur={() => setAddingFile(false)}
                onKeyDown={(e) => e.key === 'Escape' && setAddingFile(false)} className="bg-[#21262d] border border-sky-500/50 text-white px-2 py-1 rounded text-xs outline-none w-28 font-mono ml-1" />
            </form>
          ) : (
            <button onClick={() => !readOnly && setAddingFile(true)} disabled={readOnly} className="p-1 text-zinc-400 hover:text-white hover:bg-[#21262d] rounded disabled:opacity-30 cursor-pointer" title="New file" aria-label="New file"><Plus className="w-4 h-4" /></button>
          )}
        </div>
        <div className="flex items-center space-x-1 pl-2 shrink-0">
          {here.length > 0 && (
            <div className="hidden lg:flex items-center space-x-1 text-[11px] font-mono text-zinc-400 bg-[#21262d] px-2 py-0.5 rounded mr-1">
              <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: here[0].userColor }} />
              <span>{here.length === 1 ? `${here[0].userName} is here` : `${here.length} others here`}</span>
            </div>
          )}
          <input ref={uploadRef} type="file" multiple hidden onChange={(e) => { if (e.target.files) readFiles(e.target.files); e.target.value = ''; }} />
          <button onClick={() => uploadRef.current?.click()} disabled={readOnly} className="p-1.5 text-zinc-400 hover:text-white hover:bg-[#21262d] rounded disabled:opacity-30 cursor-pointer" title="Import files (or drag & drop)" aria-label="Import files"><Upload className="w-3.5 h-3.5" /></button>
          <button onClick={download} className="p-1.5 text-zinc-400 hover:text-white hover:bg-[#21262d] rounded cursor-pointer" title="Download this file" aria-label="Download file"><Download className="w-3.5 h-3.5" /></button>
          <button onClick={p.onDownloadZip} className="p-1.5 text-zinc-400 hover:text-white hover:bg-[#21262d] rounded cursor-pointer" title="Download whole project (.zip)" aria-label="Download zip"><Archive className="w-3.5 h-3.5" /></button>
        </div>
      </div>

      {/* Editor body */}
      <div className="flex-1 relative min-h-0">
        <div ref={scrollRef} className="absolute inset-0 overflow-auto">
          <div className="flex min-h-full" style={{ minWidth: 'max-content' }}>
            <div className="sticky left-0 z-10 shrink-0 bg-[#0d1117] border-r border-[#30363d] text-right select-none text-zinc-600 font-mono"
              style={{ ...fontStyle, width: 52, paddingTop: PAD, paddingRight: 10 }} aria-hidden="true">
              {Array.from({ length: nLines }, (_, i) => <div key={i} className={caret.line === i + 1 ? 'text-sky-400 font-semibold' : ''}>{i + 1}</div>)}
            </div>

            <div className="relative flex-1" style={{ minWidth: PAD * 2 + maxLen * charW + 60 }}>
              {/* highlighted text (in flow: defines the scroll size) */}
              <pre aria-hidden="true" className="m-0 relative z-[1] pointer-events-none whitespace-pre font-mono"
                style={{ ...fontStyle, padding: `${PAD}px ${PAD + 48}px ${PAD + lh * 3}px ${PAD}px` }}
                dangerouslySetInnerHTML={{ __html: html + '<br/>' }} />

              {/* selection / find highlights (under text) */}
              <div className="absolute inset-0 z-0 pointer-events-none">
                {find.open && matches.slice(0, 500).map((m, i) => rects(m, m + find.q.length).map((r, j) => (
                  <div key={`m${i}-${j}`} className="absolute rounded-sm" style={{ left: r.x, top: r.y, width: r.w, height: lh, background: i === find.idx ? 'rgba(250,204,21,.45)' : 'rgba(250,204,21,.18)' }} />
                )))}
                {here.map((c) => c.selStart !== c.selEnd && rects(c.selStart, c.selEnd).map((r, j) => (
                  <div key={`s${c.userId}-${j}`} className="absolute" style={{ left: r.x, top: r.y, width: r.w, height: lh, background: c.userColor, opacity: 0.25 }} />
                )))}
              </div>

              <textarea ref={taRef} value={text} readOnly={readOnly} spellCheck={false} autoCapitalize="off" autoComplete="off" autoCorrect="off"
                aria-label={`Editor for ${file.name}`}
                onChange={(e) => { p.onCodeChange(file.id, e.target.value); onCaret(); }}
                onKeyDown={onKeyDown} onKeyUp={(e) => { if (!['Control', 'Meta', 'Alt', 'Shift'].includes(e.key)) onCaret(); }}
                onClick={() => onCaret(false)} onSelect={() => onCaret(false)} onFocus={() => onCaret(false)}
                className="absolute inset-0 z-[2] w-full h-full m-0 font-mono whitespace-pre bg-transparent text-transparent caret-white resize-none outline-none overflow-hidden selection:bg-sky-500/30"
                style={{ ...fontStyle, padding: PAD, WebkitTextFillColor: 'transparent' }} />

              {/* remote carets */}
              <div className="absolute inset-0 z-[3] pointer-events-none">
                {here.map((c) => {
                  const { x, y } = xy(c.offset);
                  return (
                    <div key={c.userId} className="absolute transition-[left,top] duration-75" style={{ left: x, top: y }}>
                      <div style={{ width: 2, height: lh, background: c.userColor, boxShadow: `0 0 6px ${c.userColor}` }} />
                      <div className="absolute left-0 px-1.5 rounded-sm text-[10px] font-mono font-semibold text-white whitespace-nowrap shadow" style={{ top: -15, background: c.userColor }}>{c.userName}</div>
                    </div>
                  );
                })}
              </div>
              <span ref={measureRef} aria-hidden="true" className="absolute invisible whitespace-pre font-mono" style={fontStyle}>{'M'.repeat(100)}</span>
            </div>
          </div>
        </div>

        {/* find bar */}
        {find.open && (
          <div className="absolute top-2 right-4 z-20 bg-[#161b22] border border-[#30363d] rounded-lg shadow-2xl p-2 space-y-1.5 w-72" role="search">
            <div className="flex items-center gap-1">
              <Search className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
              <input ref={findInputRef} value={find.q} onChange={(e) => setFind({ ...find, q: e.target.value, idx: 0 })} placeholder="Find"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') { e.preventDefault(); jumpToMatch(find.idx + (e.shiftKey ? -1 : 1)); }
                  if (e.key === 'Escape') { setFind({ ...find, open: false }); taRef.current?.focus(); }
                }} className="flex-1 min-w-0 bg-[#0d1117] border border-[#30363d] rounded px-2 py-1 text-xs text-white outline-none focus:border-sky-500/60" />
              <span className="text-[10px] text-zinc-500 w-12 text-center shrink-0">{find.q ? `${matches.length ? Math.min(find.idx, matches.length - 1) + 1 : 0}/${matches.length}` : ''}</span>
              <button onClick={() => jumpToMatch(find.idx - 1)} className="p-0.5 text-zinc-400 hover:text-white cursor-pointer" aria-label="Previous match"><ChevronUp className="w-3.5 h-3.5" /></button>
              <button onClick={() => jumpToMatch(find.idx + 1)} className="p-0.5 text-zinc-400 hover:text-white cursor-pointer" aria-label="Next match"><ChevronDown className="w-3.5 h-3.5" /></button>
              <button onClick={() => { setFind({ ...find, open: false }); taRef.current?.focus(); }} className="p-0.5 text-zinc-400 hover:text-white cursor-pointer" aria-label="Close find"><X className="w-3.5 h-3.5" /></button>
            </div>
            <div className="flex items-center gap-1 text-[10px]">
              <button onClick={() => setFind({ ...find, cs: !find.cs })} className={`px-1.5 py-0.5 rounded border cursor-pointer ${find.cs ? 'bg-sky-500/20 border-sky-500/40 text-sky-300' : 'border-[#30363d] text-zinc-400'}`} title="Match case">Aa</button>
              <button onClick={() => setFind({ ...find, showReplace: !find.showReplace })} className="px-1.5 py-0.5 rounded border border-[#30363d] text-zinc-400 hover:text-white cursor-pointer">Replace</button>
            </div>
            {find.showReplace && (
              <div className="flex items-center gap-1">
                <input value={find.r} onChange={(e) => setFind({ ...find, r: e.target.value })} placeholder="Replace with"
                  onKeyDown={(e) => e.key === 'Enter' && replaceCurrent()} className="flex-1 min-w-0 bg-[#0d1117] border border-[#30363d] rounded px-2 py-1 text-xs text-white outline-none focus:border-sky-500/60" />
                <button onClick={replaceCurrent} disabled={readOnly} className="px-1.5 py-1 text-[10px] rounded bg-[#21262d] border border-[#30363d] text-zinc-300 hover:text-white disabled:opacity-40 cursor-pointer">One</button>
                <button onClick={replaceAll} disabled={readOnly} className="px-1.5 py-1 text-[10px] rounded bg-[#21262d] border border-[#30363d] text-zinc-300 hover:text-white disabled:opacity-40 cursor-pointer">All</button>
              </div>
            )}
          </div>
        )}

        {readOnly && (
          <div className="absolute bottom-3 right-5 z-20 flex items-center gap-1.5 text-[11px] px-2.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 pointer-events-none">
            <Lock className="w-3 h-3" />{p.readOnlyReason || 'Read-only'}
          </div>
        )}
        {dragOver && <div className="absolute inset-0 z-30 flex items-center justify-center bg-sky-500/10 border-2 border-dashed border-sky-400 text-sky-200 text-sm pointer-events-none">Drop files to add them to the room</div>}
      </div>

      {/* Status bar */}
      <div className="h-6 bg-[#161b22] border-t border-[#30363d] px-3 flex items-center justify-between text-[11px] font-mono text-zinc-400 select-none shrink-0">
        <div className="flex items-center space-x-3 min-w-0">
          <span className="flex items-center space-x-1 text-zinc-300"><span className="w-1.5 h-1.5 rounded-full bg-sky-400" /><span>Ln {caret.line}, Col {caret.col}{caret.sel ? ` (${caret.sel} sel)` : ''}</span></span>
          <span className="hidden sm:inline">Spaces: {TAB}</span>
          <span className="uppercase text-sky-400 font-semibold">{file.language}</span>
          {p.followUserId && (
            <button onClick={() => p.onToggleFollow(null)} className="flex items-center gap-1 text-violet-300 hover:text-white cursor-pointer"><Eye className="w-3 h-3" />Following {p.users.find((u) => u.id === p.followUserId)?.name} ✕</button>
          )}
        </div>
        <div className="flex items-center space-x-3">
          <span className="hidden md:inline text-zinc-600">⌘/Ctrl: K palette · F find · / comment · Alt↑↓ move line</span>
          <div className="flex items-center space-x-1">
            <button onClick={() => setFontSize((s) => Math.max(11, s - 1))} className="px-1 hover:text-white cursor-pointer" aria-label="Smaller font">−</button>
            <span className="text-zinc-300">{fontSize}px</span>
            <button onClick={() => setFontSize((s) => Math.min(20, s + 1))} className="px-1 hover:text-white cursor-pointer" aria-label="Larger font">+</button>
          </div>
        </div>
      </div>
    </div>
  );
};
