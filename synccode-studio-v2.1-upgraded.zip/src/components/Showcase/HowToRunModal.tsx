import React, { useState } from 'react';
import { 
  X, 
  Play, 
  ExternalLink, 
  MessageSquare, 
  Video, 
  Code2, 
  CheckCircle2, 
  Sparkles, 
  Terminal, 
  Layers, 
  Copy, 
  Check,
  Tv
} from 'lucide-react';

interface HowToRunModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenPeerTab: () => void;
  onSendTestMessage: (text: string) => void;
}

export const HowToRunModal: React.FC<HowToRunModalProps> = ({
  isOpen,
  onClose,
  onOpenPeerTab,
  onSendTestMessage,
}) => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [copiedCmd, setCopiedCmd] = useState(false);

  if (!isOpen) return null;

  const handleCopyCmd = (cmd: string) => {
    navigator.clipboard.writeText(cmd);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  const steps = [
    {
      step: 1,
      title: "Step 1: Open Collaborator / Peer Tab",
      desc: "Because SyncCode Studio is a real-time multi-user environment, you need two participants to test two-way video, live typing cursors, and instant chat.",
      actionText: "Click 'Launch Peer Tab' button to open a second browser window with a collaborator persona.",
      badge: "WebRTC & WebSockets",
      highlight: "Click 'Open Peer Tab' in the top header",
    },
    {
      step: 2,
      title: "Step 2: Split Screens & Test Live WebRTC Video",
      desc: "Place the two browser tabs side-by-side. The WebRTC mesh automatically negotiates video and audio streams between both tabs using Google STUN servers.",
      actionText: "Toggle camera/mic or speaking to see the green volume visualizer ring glow in both windows.",
      badge: "P2P Mesh Video",
      highlight: "Webcam feeds and audio meters sync peer-to-peer",
    },
    {
      step: 3,
      title: "Step 3: Test Real-Time Chat & @ai Gemini Mentions",
      desc: "Type a message in Tab 1's chat. It instantly appears in Tab 2 without page reloads! You can also type '@ai <question>' to query Gemini Copilot right in the room chat.",
      actionText: "Send '@ai explain self attention math' to receive a collaborative AI response in chat.",
      badge: "Instant Sync & GenAI",
      highlight: "Zero latency bi-directional WebSocket broadcasting",
    },
    {
      step: 4,
      title: "Step 4: Real-Time Collaborative Code Editing",
      desc: "Type code in 'transformer_attention.ts' in one tab. Watch the colored cursor flag with your peer's name blink and move across lines in the other tab in real-time.",
      actionText: "Try editing lines 40-55 to see multi-user typing and selection highlights.",
      badge: "Operational Transforms",
      highlight: "Sub-20ms remote cursor and selection tracking",
    },
    {
      step: 5,
      title: "Step 5: Run the Current File",
      desc: "Click New File (+) and give it a language extension such as main.c, Main.java, main.go, or script.rb. Select that file, then press Run in the header or Ctrl+Enter.",
      actionText: "External runs show a consent prompt first and send only the active file when you approve. Results appear in Terminal and are shared with the room.",
      badge: "Run Current File",
      highlight: "Choose a file → Run → inspect Terminal output",
    },
    {
      step: 6,
      title: "Step 6: Enable Gemini AI (Optional)",
      desc: "The editor and file runner work without Gemini. AI chat and Copilot need a Gemini API key in a server-side .env file.",
      actionText: "In PowerShell, run Copy-Item .env.example .env, edit .env to set GEMINI_API_KEY, stop the server with Ctrl+C, then run npm run dev again.",
      badge: "Optional Gemini key",
      highlight: "Never paste the key into chat or commit your .env file",
    },
  ];

  const currentStepData = steps[activeStep - 1];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#161b22] border border-[#30363d] rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#30363d] flex items-center justify-between bg-[#0d1117]/80">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 via-indigo-500 to-emerald-400 p-[1.5px] flex items-center justify-center shadow-lg shadow-sky-500/20">
              <div className="w-full h-full bg-[#0d1117] rounded-[10px] flex items-center justify-center">
                <Tv className="w-5 h-5 text-sky-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-bold text-white tracking-tight">
                  How to Run & Video Walkthrough Guide
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  LIVE INTERACTIVE GUIDE
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Step-by-step instructions for testing multi-user real-time chat, video conferencing, and code collaboration
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-[#21262d] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Indicator Bar */}
        <div className="px-6 py-3 border-b border-[#30363d] bg-[#161b22] flex items-center justify-between overflow-x-auto">
          {steps.map((s) => {
            const isActive = activeStep === s.step;
            const isCompleted = activeStep > s.step;
            return (
              <button
                key={s.step}
                onClick={() => setActiveStep(s.step)}
                className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-sm'
                    : isCompleted
                    ? 'text-emerald-400 hover:bg-[#21262d]'
                    : 'text-zinc-400 hover:bg-[#21262d]'
                }`}
              >
                <span className={`w-5 h-5 rounded-full text-[10px] font-bold flex items-center justify-center ${
                  isActive ? 'bg-sky-500 text-white' : isCompleted ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-[#21262d] text-zinc-400'
                }`}>
                  {s.step}
                </span>
                <span className="hidden sm:inline">{s.title.split(':')[1] || s.title}</span>
              </button>
            );
          })}
        </div>

        {/* Animated Interactive Visual Player (Simulated Video Frame) */}
        <div className="p-6 flex-1 overflow-y-auto space-y-6">
          <div className="rounded-2xl border border-[#30363d] bg-[#0d1117] p-5 relative overflow-hidden shadow-inner">
            {/* Mock Player Header */}
            <div className="flex items-center justify-between border-b border-[#30363d]/60 pb-3 mb-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                <span className="text-[11px] font-mono text-zinc-400 ml-2">
                  Simulation Player: {currentStepData.title}
                </span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20">
                {currentStepData.badge}
              </span>
            </div>

            {/* Visual Diagram per Step */}
            <div className="min-h-[200px] flex flex-col justify-center">
              {activeStep === 1 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-[#161b22] border border-[#30363d] space-y-2">
                    <span className="text-xs font-bold text-sky-400 flex items-center gap-1.5">
                      <ExternalLink className="w-4 h-4" /> Window 1: You (Host / Interviewer)
                    </span>
                    <p className="text-xs text-zinc-400">
                      Already running on port 3000. Your user profile is active in room <code className="text-sky-300 bg-black/40 px-1 py-0.5 rounded">interview-collab-702</code>.
                    </p>
                    <div className="pt-2">
                      <button
                        onClick={onOpenPeerTab}
                        className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center space-x-1.5 shadow-md cursor-pointer"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Launch Window 2 (Peer Tab) Now</span>
                      </button>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-[#161b22] border border-dashed border-sky-500/40 flex flex-col justify-center items-center text-center space-y-2">
                    <div className="w-10 h-10 rounded-full bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
                      <Layers className="w-5 h-5 animate-pulse" />
                    </div>
                    <span className="text-xs font-semibold text-zinc-200">Window 2: Peer Collaborator</span>
                    <p className="text-[11px] text-zinc-400 max-w-xs">
                      Opens with a unique identity and connects to the same room WebSocket gateway and WebRTC mesh.
                    </p>
                  </div>
                </div>
              )}

              {activeStep === 2 && (
                <div className="p-4 rounded-xl bg-[#161b22] border border-[#30363d] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                      <Video className="w-4 h-4" /> Side-by-Side WebRTC Mesh Conferencing
                    </span>
                    <span className="text-[10px] font-mono text-zinc-500">Google STUN NAT Traversal</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                    <div className="p-3 rounded-lg bg-[#0d1117] border border-emerald-500/30 flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">A</div>
                      <div>
                        <div className="text-zinc-200">You (Host)</div>
                        <div className="text-[10px] text-emerald-400">Camera ON • Mic Active</div>
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-[#0d1117] border border-sky-500/30 flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold">B</div>
                      <div>
                        <div className="text-zinc-200">Sarah (Peer)</div>
                        <div className="text-[10px] text-sky-400">P2P Stream Connected</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeStep === 3 && (
                <div className="p-4 rounded-xl bg-[#161b22] border border-[#30363d] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-sky-400 flex items-center gap-1.5">
                      <MessageSquare className="w-4 h-4" /> Real-Time Chat & AI Bot Demo
                    </span>
                  </div>
                  <div className="space-y-2 text-xs font-mono">
                    <div className="p-2 rounded bg-sky-500/10 border border-sky-500/20 text-sky-300">
                      <strong>You:</strong> @ai explain scaled dot product attention math
                    </div>
                    <div className="p-2 rounded bg-[#0d1117] border border-[#30363d] text-zinc-300">
                      <strong>Gemini Copilot 🤖:</strong> Scaled dot-product attention computes Q * K^T / sqrt(d_k) to prevent gradients from vanishing in high dimensions...
                    </div>
                  </div>
                  <div className="pt-2 flex flex-wrap gap-2">
                    <button
                      onClick={() => onSendTestMessage('@ai explain self attention in 2 sentences')}
                      className="px-3 py-1.5 rounded-lg bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 text-xs font-medium cursor-pointer"
                    >
                      🚀 Send Test AI Message Now
                    </button>
                    <button
                      onClick={() => onSendTestMessage('👋 Hello from Tab 1! Chat is live and synchronizing!')}
                      className="px-3 py-1.5 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-zinc-200 border border-[#30363d] text-xs font-medium cursor-pointer"
                    >
                      💬 Send "Hello Team" Message
                    </button>
                  </div>
                </div>
              )}

              {activeStep === 4 && (
                <div className="p-4 rounded-xl bg-[#161b22] border border-[#30363d] space-y-3">
                  <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                    <Code2 className="w-4 h-4" /> Multi-User Remote Cursors & Selection Sync
                  </span>
                  <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d] text-xs font-mono text-zinc-300 space-y-1">
                    <div className="text-zinc-500">22:   public forward(Q, K, V, isCausalMask) &#123;</div>
                    <div className="text-zinc-500 flex items-center">
                      <span>23:     const scale = Math.sqrt(this.d_k);</span>
                      <span className="ml-3 px-1.5 py-0.2 rounded bg-emerald-500 text-black text-[9px] font-bold">Sarah (editing)</span>
                    </div>
                    <div className="text-zinc-500">24:     // Scaled dot-product attention computation</div>
                  </div>
                </div>
              )}

              {activeStep === 5 && (
                <div className="p-4 rounded-xl bg-[#161b22] border border-[#30363d] space-y-3">
                  <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                    <Terminal className="w-4 h-4" /> Run the file you have open
                  </span>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="rounded-lg border border-[#30363d] bg-[#0d1117] p-3 text-xs text-zinc-300">
                      <p className="mb-2 font-semibold text-sky-300">Quick steps</p>
                      <ol className="list-inside list-decimal space-y-1.5">
                        <li>Select a file tab, such as <code>main.ts</code> or <code>Main.java</code>.</li>
                        <li>Press <strong>Run</strong> at the top, or use <kbd>Ctrl+Enter</kbd>.</li>
                        <li>Read stdout/errors in the <strong>Terminal</strong> panel.</li>
                      </ol>
                    </div>
                    <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-3 text-xs text-zinc-300">
                      <p className="mb-2 font-semibold text-amber-300">Where code runs</p>
                      <p>JS, TS, and Python run in this browser. C, C++, Java, C#, Go, Rust, PHP, and Ruby are sent to the configured Piston service only after you approve the prompt. Don’t send code you need to keep private.</p>
                    </div>
                  </div>
                </div>
              )}

              {activeStep === 6 && (
                <div className="p-4 rounded-xl border border-[#30363d] bg-[#0d1117] space-y-3 text-xs text-zinc-300">
                  <div className="flex items-center gap-2 font-semibold text-sky-300"><Sparkles className="h-4 w-4" /> Gemini is optional</div>
                  <p>“Gemini is not configured” only affects AI chat and Copilot; running normal code does not require a key.</p>
                  <pre className="rounded border border-[#30363d] bg-[#161b22] p-3 font-mono text-[11px] text-emerald-300">Copy-Item .env.example .env{"\n"}# edit .env and set GEMINI_API_KEY="your-new-key"{"\n"}# stop the server with Ctrl+C, then restart:
{"\n"}npm run dev</pre>
                  <p>Keep the key in the server-side <code>.env</code> file. Never paste it into chat or share it in the ZIP.</p>
                </div>
              )}
            </div>

            {/* Explanation & Action footer */}
            <div className="mt-4 pt-3 border-t border-[#30363d]/60 flex items-center justify-between">
              <p className="text-xs text-zinc-300 font-sans">
                {currentStepData.desc}
              </p>
              <div className="flex items-center space-x-2">
                {activeStep > 1 && (
                  <button
                    onClick={() => setActiveStep(activeStep - 1)}
                    className="px-3 py-1.5 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-zinc-300 text-xs cursor-pointer"
                  >
                    Previous
                  </button>
                )}
                {activeStep < steps.length ? (
                  <button
                    onClick={() => setActiveStep(activeStep + 1)}
                    className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold cursor-pointer"
                  >
                    Next Step
                  </button>
                ) : (
                  <button
                    onClick={onClose}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold cursor-pointer"
                  >
                    Got It, Let's Code!
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Dev Server & Command Reference */}
          <div className="p-4 rounded-xl bg-[#0d1117] border border-[#30363d] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-sky-400" />
                <span>How the Full-Stack Server Runs</span>
              </span>
              <button
                onClick={() => handleCopyCmd('npm run dev')}
                className="flex items-center space-x-1 text-[11px] text-zinc-400 hover:text-white"
              >
                {copiedCmd ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedCmd ? 'Copied' : 'Copy Command'}</span>
              </button>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed font-sans">
              The project runs via <code className="text-sky-300 bg-black/40 px-1 py-0.5 rounded font-mono">tsx server.ts</code> on port 3000. It hosts both the Express HTTP server, the Vite React frontend middleware, and the real-time WebSocket signaling gateway for WebRTC conferencing.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#30363d] bg-[#0d1117]/80 flex items-center justify-between">
          <button
            onClick={onOpenPeerTab}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-md transition-colors cursor-pointer"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Open Peer Tab Now</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-white text-xs font-medium transition-colors cursor-pointer"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
