import React, { useState } from 'react';
import { 
  X, 
  ExternalLink, 
  CheckCircle, 
  Cpu, 
  Layers, 
  Zap, 
  ShieldCheck, 
  Activity, 
  Terminal, 
  Copy, 
  Share2, 
  Video, 
  Code2, 
  Network
} from 'lucide-react';
import { User, RoomState } from '../../types';
import { socketService } from '../../services/socket';
import { webrtcManager } from '../../services/webrtc';

interface InternshipDossierModalProps {
  isOpen: boolean;
  onClose: () => void;
  roomId: string;
  currentUser: User;
  users: User[];
  latencyMs: number;
  onOpenPeerTab: () => void;
}

export const InternshipDossierModal: React.FC<InternshipDossierModalProps> = ({
  isOpen,
  onClose,
  roomId,
  currentUser,
  users,
  latencyMs,
  onOpenPeerTab,
}) => {
  const [activeTab, setActiveTab] = useState<'architecture' | 'challenges' | 'telemetry' | 'interview'>('architecture');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#161b22] border border-[#30363d] rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-[#30363d] flex items-center justify-between bg-[#0d1117]/60">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 via-indigo-500 to-emerald-400 p-[1.5px] flex items-center justify-center shadow-lg shadow-sky-500/20">
              <div className="w-full h-full bg-[#0d1117] rounded-[10px] flex items-center justify-center">
                <Code2 className="w-5 h-5 text-sky-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-bold text-white tracking-tight">
                  SyncCode GenAI Studio
                </h2>
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full bg-gradient-to-r from-sky-500/20 to-indigo-500/20 text-sky-300 border border-sky-500/30">
                  MCA GENERATIVE AI & ML CAPSTONE
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Master of Computer Applications (MCA) Project: Collaborative Foundation Model Engineering & WebRTC Video Conferencing
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={onOpenPeerTab}
              className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-md transition-colors cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Launch Peer Tab</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-[#21262d] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 border-b border-[#30363d] flex items-center space-x-4 bg-[#161b22]">
          {[
            { id: 'architecture', label: 'GenAI Architecture', icon: Layers },
            { id: 'challenges', label: 'Transformer & ML Modules', icon: Zap },
            { id: 'telemetry', label: 'Live Telemetry & Diagnostics', icon: Activity },
            { id: 'interview', label: 'MCA Viva Defense & Resume', icon: ShieldCheck },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 flex items-center space-x-2 text-xs font-medium border-b-2 transition-colors cursor-pointer ${
                  isActive
                    ? 'border-sky-400 text-sky-400'
                    : 'border-transparent text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm text-zinc-300">
          {activeTab === 'architecture' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-white mb-2">High-Level System & Foundation Model Architecture</h3>
                <p className="text-xs text-zinc-400 leading-relaxed mb-4">
                  SyncCode GenAI Studio merges real-time collaborative state orchestration (WebSocket), direct peer-to-peer audio/video streaming (WebRTC mesh), and server-authoritative Generative AI reasoning via Google Gemini 3.8.
                </p>

                {/* Architecture Diagram Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
                  <div className="p-4 rounded-xl bg-[#0d1117] border border-[#30363d] space-y-2">
                    <div className="flex items-center space-x-2 text-sky-400 font-bold">
                      <Code2 className="w-4 h-4" />
                      <span>Frontend Client & Math</span>
                    </div>
                    <ul className="text-[11px] text-zinc-400 space-y-1 list-disc list-inside">
                      <li>React 19 + TypeScript IDE</li>
                      <li>Scaled Dot-Product Attention</li>
                      <li>Cosine Similarity Vector Search</li>
                      <li>WebRTC RTCPeerConnection</li>
                      <li>In-Memory Sandbox Runner</li>
                    </ul>
                  </div>

                  <div className="p-4 rounded-xl bg-[#0d1117] border border-[#30363d] space-y-2">
                    <div className="flex items-center space-x-2 text-emerald-400 font-bold">
                      <Network className="w-4 h-4" />
                      <span>Server & GenAI Gateway</span>
                    </div>
                    <ul className="text-[11px] text-zinc-400 space-y-1 list-disc list-inside">
                      <li>Express + WS (Port 3000)</li>
                      <li>@google/genai Gemini 3.8 SDK</li>
                      <li>Tensor Math & LoRA Analysis</li>
                      <li>State Serialization & Relay</li>
                      <li>Heartbeat RTT Telemetry</li>
                    </ul>
                  </div>

                  <div className="p-4 rounded-xl bg-[#0d1117] border border-[#30363d] space-y-2">
                    <div className="flex items-center space-x-2 text-purple-400 font-bold">
                      <Video className="w-4 h-4" />
                      <span>Media P2P Mesh</span>
                    </div>
                    <ul className="text-[11px] text-zinc-400 space-y-1 list-disc list-inside">
                      <li>WebRTC Mesh Architecture</li>
                      <li>Google Public STUN Traversal</li>
                      <li>Screen Share MediaStream</li>
                      <li>Voice Activity dB Detection</li>
                      <li>Synthetic Media Fallback</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-white mb-2">Data Flow Pipeline</h3>
                <div className="p-4 rounded-xl bg-[#0d1117] border border-[#30363d] text-xs font-mono text-zinc-400 space-y-2">
                  <div className="text-zinc-200">1. Client Keystroke / Selection</div>
                  <div className="text-sky-400 pl-4">↳ Optimistic UI Update + WebSocket delta broadcast (`code-change`)</div>
                  <div className="text-zinc-200">2. Signaling Hub</div>
                  <div className="text-emerald-400 pl-4">↳ In-memory room buffer updated → Dispatched to room peers</div>
                  <div className="text-zinc-200">3. Media Conference Call</div>
                  <div className="text-purple-400 pl-4">↳ SDP Offer / Answer negotiated over WS → Direct P2P Video/Audio stream established</div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'challenges' && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-white">Core Engineering Challenges Addressed</h3>
              
              <div className="space-y-3">
                <div className="p-4 rounded-xl bg-[#0d1117] border border-[#30363d]">
                  <h4 className="text-xs font-bold text-sky-400 mb-1">1. Low-Latency Real-Time Collaboration</h4>
                  <p className="text-xs text-zinc-400 leading-relaxed">
                    Prevented typing stutter by decoupling local input updates from remote round-trips (optimistic updates) combined with line/column cursor normalization to ensure multi-user cursor flags display accurately across diverse screen sizes.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#0d1117] border border-[#30363d]">
                  <h4 className="text-xs font-bold text-emerald-400 mb-1">2. WebRTC Mesh Signaling & Fallback Resilience</h4>
                  <p className="text-xs text-zinc-400 leading-relaxed">
                    Designed an SDP exchange mechanism using the unified WebSocket connection. Added an automatic fallback to virtual canvas media feeds when running in restricted browser sandboxes or when physical camera permissions are unavailable, ensuring the application always works seamlessly.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#0d1117] border border-[#30363d]">
                  <h4 className="text-xs font-bold text-purple-400 mb-1">3. In-Browser Sandboxed Execution & Console Capture</h4>
                  <p className="text-xs text-zinc-400 leading-relaxed">
                    Constructed a safe runtime environment that overrides and streams console logs (log, info, warn, error, table) with microsecond timing. Output results are synchronized via the WebSocket server so interviewers and candidates review code output collaboratively.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'telemetry' && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-white">Live Diagnostics & Network Stats</h3>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
                <div className="p-3 rounded-xl bg-[#0d1117] border border-[#30363d]">
                  <span className="text-[10px] text-zinc-500 uppercase">Latency RTT</span>
                  <div className="text-lg font-bold text-emerald-400">{latencyMs} ms</div>
                </div>

                <div className="p-3 rounded-xl bg-[#0d1117] border border-[#30363d]">
                  <span className="text-[10px] text-zinc-500 uppercase">Active Users</span>
                  <div className="text-lg font-bold text-sky-400">{users.length} Connected</div>
                </div>

                <div className="p-3 rounded-xl bg-[#0d1117] border border-[#30363d]">
                  <span className="text-[10px] text-zinc-500 uppercase">WS Packets In/Out</span>
                  <div className="text-lg font-bold text-zinc-200">{socketService.packetsReceived} / {socketService.packetsSent}</div>
                </div>

                <div className="p-3 rounded-xl bg-[#0d1117] border border-[#30363d]">
                  <span className="text-[10px] text-zinc-500 uppercase">WebRTC Mesh Links</span>
                  <div className="text-lg font-bold text-purple-400">{webrtcManager.peerConnections.size} Peers</div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#0d1117] border border-[#30363d] space-y-2">
                <span className="text-xs font-semibold text-zinc-300">Connected Peers in Room ({roomId})</span>
                <div className="space-y-1.5 pt-1">
                  {users.map((u) => (
                    <div key={u.id} className="flex items-center justify-between text-xs font-mono py-1 border-b border-zinc-800 last:border-none">
                      <div className="flex items-center space-x-2">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: u.color }} />
                        <span className="text-zinc-200">{u.name} {u.id === currentUser.id ? '(You)' : ''}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-[11px] text-zinc-400">
                        <span>Mic: {u.isAudioOn ? 'ON' : 'OFF'}</span>
                        <span>•</span>
                        <span>Cam: {u.isVideoOn ? 'ON' : 'OFF'}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'interview' && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-white">MCA Generative AI Resume Bullets & Viva Voce Defense</h3>
              
              <div className="p-4 rounded-xl bg-[#0d1117] border border-[#30363d] space-y-2">
                <span className="text-xs font-bold text-sky-400 uppercase font-mono">Bullet Point for MCA AI/ML Engineering Resume:</span>
                <p className="text-xs text-zinc-300 leading-relaxed bg-[#161b22] p-3 rounded-lg border border-[#30363d] font-mono">
                  "Engineered a real-time collaborative IDE and multi-modal conferencing platform for Generative AI research; implemented in-memory Scaled Dot-Product Attention, Cosine Similarity Vector RAG retrieval, and LoRA PEFT parameter decomposition, integrated with server-side Google Gemini 3.8 and WebRTC peer-to-peer video streaming."
                </p>
              </div>

              <div className="space-y-3">
                <h4 className="text-xs font-semibold text-zinc-300">MCA Viva Voce Defense Questions & Model Answers:</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-zinc-400">
                  <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d] space-y-1">
                    <strong className="text-sky-300 block">Q1: How does Scaled Dot-Product Attention scale?</strong>
                    <p className="text-zinc-400 leading-relaxed">
                      Attention computation scales quadratically O(N^2 * d) with sequence length N. Dividing by sqrt(d_k) stabilizes gradients by preventing the dot products from growing excessively large, where softmax would push gradients to near-zero.
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d] space-y-1">
                    <strong className="text-emerald-300 block">Q2: Why does LoRA achieve 99%+ parameter reduction?</strong>
                    <p className="text-zinc-400 leading-relaxed">
                      Rather than updating full-rank matrix W of dimension (d x k), LoRA decomposes the weight update into two low-rank matrices B (d x r) and A (r x k) where intrinsic rank r &lt;&lt; d. For a 4096 x 4096 matrix with r=16, parameters drop from 16.7M to 131K.
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d] space-y-1">
                    <strong className="text-amber-300 block">Q3: Why use Cosine Similarity over Euclidean Distance in RAG?</strong>
                    <p className="text-zinc-400 leading-relaxed">
                      High-dimensional text embeddings care primarily about semantic direction rather than vector magnitude (which may reflect document length). Cosine similarity normalizes vector lengths to focus purely on angular orientation.
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d] space-y-1">
                    <strong className="text-purple-300 block">Q4: How does WebRTC Mesh avoid server bottlenecks?</strong>
                    <p className="text-zinc-400 leading-relaxed">
                      By establishing direct peer-to-peer UDP/SRTP media pipes between client browsers via STUN NAT traversal, the signaling server only routes lightweight SDP/ICE JSON messages, reducing server CPU and bandwidth to near zero.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-[#30363d] bg-[#0d1117]/60 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs text-zinc-400 font-mono">
            <span>Room URL:</span>
            <button
              onClick={handleCopyLink}
              className="hover:text-white flex items-center space-x-1 text-sky-400"
            >
              <span>{copied ? 'Copied to Clipboard!' : 'Copy Invitation Link'}</span>
              <Copy className="w-3 h-3" />
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-white text-xs font-medium transition-colors cursor-pointer"
          >
            Close Dossier
          </button>
        </div>
      </div>
    </div>
  );
};
