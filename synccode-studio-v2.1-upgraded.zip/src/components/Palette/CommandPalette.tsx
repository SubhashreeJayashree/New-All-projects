import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Search, CornerDownLeft } from 'lucide-react';

export interface Command { id: string; title: string; group: string; hint?: string; run: () => void }

function score(q: string, t: string): number {
  if (!q) return 1;
  t = t.toLowerCase();
  let ti = 0, s = 0, streak = 0;
  for (const ch of q.toLowerCase()) {
    const at = t.indexOf(ch, ti);
    if (at < 0) return 0;
    streak = at === ti ? streak + 1 : 0;
    s += 1 + streak * 2 - Math.min(at - ti, 5) * 0.2;
    ti = at + 1;
  }
  return Math.max(s, 0.01);
}

export const CommandPalette: React.FC<{ open: boolean; onClose: () => void; commands: Command[] }> = ({ open, onClose, commands }) => {
  const [q, setQ] = useState('');
  const [idx, setIdx] = useState(0);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => { if (open) { setQ(''); setIdx(0); } }, [open]);

  const items = useMemo(() => commands
    .map((c) => ({ c, s: score(q, `${c.group} ${c.title}`) }))
    .filter((x) => x.s > 0)
    .sort((a, b) => b.s - a.s)
    .slice(0, 60)
    .map((x) => x.c), [q, commands]);

  useEffect(() => { setIdx(0); }, [q]);
  useEffect(() => { listRef.current?.querySelector('[data-active="true"]')?.scrollIntoView({ block: 'nearest' }); }, [idx]);

  if (!open) return null;
  const run = (c?: Command) => { if (!c) return; onClose(); setTimeout(c.run, 0); };

  return (
    <div className="fixed inset-0 z-[60] flex items-start justify-center pt-[12vh] bg-black/60 backdrop-blur-sm" onMouseDown={onClose}>
      <div role="dialog" aria-label="Command palette" className="w-full max-w-xl bg-[#161b22] border border-[#30363d] rounded-xl shadow-2xl overflow-hidden" onMouseDown={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2 px-3 border-b border-[#30363d]">
          <Search className="w-4 h-4 text-zinc-500" />
          <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Type a command or file name…"
            onKeyDown={(e) => {
              if (e.key === 'ArrowDown') { e.preventDefault(); setIdx((i) => Math.min(items.length - 1, i + 1)); }
              else if (e.key === 'ArrowUp') { e.preventDefault(); setIdx((i) => Math.max(0, i - 1)); }
              else if (e.key === 'Enter') { e.preventDefault(); run(items[idx]); }
              else if (e.key === 'Escape') { e.preventDefault(); onClose(); }
            }}
            className="flex-1 bg-transparent py-3 text-sm text-white placeholder-zinc-500 outline-none select-text" />
          <kbd className="text-[10px] text-zinc-500 border border-[#30363d] rounded px-1">esc</kbd>
        </div>
        <div ref={listRef} className="max-h-80 overflow-y-auto py-1">
          {items.length === 0 && <div className="px-4 py-6 text-center text-xs text-zinc-500">No matching commands</div>}
          {items.map((c, i) => (
            <button key={c.id} data-active={i === idx} onMouseEnter={() => setIdx(i)} onClick={() => run(c)}
              className={`w-full flex items-center justify-between px-3 py-2 text-left text-xs cursor-pointer ${i === idx ? 'bg-sky-500/15 text-white' : 'text-zinc-300'}`}>
              <span className="flex items-center gap-2 min-w-0">
                <span className="text-[10px] uppercase tracking-wider text-zinc-500 w-14 shrink-0">{c.group}</span>
                <span className="truncate">{c.title}</span>
              </span>
              <span className="flex items-center gap-2 shrink-0">
                {c.hint && <kbd className="text-[10px] text-zinc-500 border border-[#30363d] rounded px-1">{c.hint}</kbd>}
                {i === idx && <CornerDownLeft className="w-3 h-3 text-sky-400" />}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
