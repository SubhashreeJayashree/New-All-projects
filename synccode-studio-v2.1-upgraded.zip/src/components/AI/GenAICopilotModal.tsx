import React, { useEffect, useRef, useState } from 'react';
import { Sparkles, Send, X, BookOpen, Zap, ShieldAlert, FlaskConical, ClipboardCheck, Copy, Check, Share2, BrainCircuit, Bot, Square } from 'lucide-react';
import { CodeFile, User } from '../../types';
import { Markdown, CodeAction } from '../Common/Markdown';

type Action = 'explain' | 'optimize' | 'debug' | 'tests' | 'review' | 'chat';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  activeFile: CodeFile | null;
  files: CodeFile[];
  onShareToChat: (content: string) => void;
  codeActions: CodeAction[];
  currentUser: User;
}

const ACTIONS: { id: Action; label: string; icon: React.ReactNode; tone: string }[] = [
  { id: 'explain', label: 'Explain the maths', icon: <BookOpen className="w-3.5 h-3.5 text-sky-400" />, tone: 'sky' },
  { id: 'optimize', label: 'Optimise', icon: <Zap className="w-3.5 h-3.5 text-emerald-400" />, tone: 'emerald' },
  { id: 'debug', label: 'Audit & debug', icon: <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />, tone: 'amber' },
  { id: 'tests', label: 'Write tests', icon: <FlaskConical className="w-3.5 h-3.5 text-violet-400" />, tone: 'violet' },
  { id: 'review', label: 'Code review', icon: <ClipboardCheck className="w-3.5 h-3.5 text-pink-400" />, tone: 'pink' },
];

export const GenAICopilotModal: React.FC<Props> = ({ isOpen, onClose, activeFile, files, onShareToChat, codeActions, currentUser }) => {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [action, setAction] = useState<Action | null>(null);
  const [withProject, setWithProject] = useState(true);
  const [copied, setCopied] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { if (!isOpen) abortRef.current?.abort(); }, [isOpen]);
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (isOpen && e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [isOpen, onClose]);
  useEffect(() => { if (loading) scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight }); }, [response, loading]);

  if (!isOpen) return null;

  const run = async (a: Action, custom?: string) => {
    if (!activeFile || loading) return;
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setLoading(true); setAction(a); setResponse('');
    try {
      const res = await fetch('/api/ai/copilot', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal,
        body: JSON.stringify({
          action: a, stream: true, code: activeFile.content, activeFile: activeFile.name, prompt: custom ?? prompt,
          files: withProject ? files.map((f) => ({ name: f.name, content: f.content })) : undefined,
        }),
      });
      if (!res.ok || !res.body) {
        const data = await res.json().catch(() => ({}));
        setResponse(`⚠️ ${data.error || data.fallbackText || `Request failed (${res.status}).`}`);
        return;
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        setResponse((r) => r + dec.decode(value, { stream: true }));
      }
    } catch (e: any) {
      if (e?.name !== 'AbortError') setResponse(`⚠️ Could not reach the AI service: ${e?.message || e}`);
    } finally {
      setLoading(false);
    }
  };

  const stop = () => { abortRef.current?.abort(); setLoading(false); };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" role="dialog" aria-label="Gemini Copilot" onMouseDown={onClose}>
      <div className="bg-[#161b22] border border-[#30363d] rounded-2xl w-full max-w-3xl max-h-[88vh] flex flex-col shadow-2xl overflow-hidden" onMouseDown={(e) => e.stopPropagation()}>
        <div className="px-5 py-4 border-b border-[#30363d] flex items-center justify-between bg-[#0d1117]/80 shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 via-indigo-500 to-emerald-400 p-[1.5px]"><div className="w-full h-full bg-[#0d1117] rounded-[9px] flex items-center justify-center"><BrainCircuit className="w-5 h-5 text-sky-400" /></div></div>
            <div>
              <h3 className="text-sm font-bold text-white">Gemini Copilot</h3>
              <p className="text-xs text-zinc-400">Context: <span className="font-mono text-zinc-200">{activeFile?.name || '—'}</span></p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-[#21262d] cursor-pointer" aria-label="Close"><X className="w-5 h-5" /></button>
        </div>

        <div className="px-5 py-3 border-b border-[#30363d] flex flex-wrap items-center gap-2 shrink-0">
          {ACTIONS.map((a) => (
            <button key={a.id} onClick={() => run(a.id)} disabled={loading}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border disabled:opacity-50 cursor-pointer ${action === a.id ? 'bg-sky-500/20 text-sky-200 border-sky-500/40' : 'bg-[#21262d] text-zinc-300 border-[#30363d] hover:bg-[#30363d]'}`}>
              {a.icon}<span>{a.label}</span>
            </button>
          ))}
          <label className="ml-auto flex items-center gap-1.5 text-[11px] text-zinc-400 cursor-pointer select-none">
            <input type="checkbox" checked={withProject} onChange={(e) => setWithProject(e.target.checked)} className="accent-sky-400" />Include other files
          </label>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto p-5 text-xs text-zinc-200 min-h-[200px] select-text">
          {!response && !loading && (
            <div className="h-full min-h-[180px] flex flex-col items-center justify-center text-center text-zinc-500 space-y-2">
              <Bot className="w-8 h-8 text-sky-400/60" />
              <p className="text-sm font-semibold text-zinc-300">What would you like help with?</p>
              <p className="max-w-sm">Pick an action above or ask your own question below. Generated code blocks can be applied straight to your project.</p>
            </div>
          )}
          {(response || loading) && (
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-[#30363d] pb-2">
                <span className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5"><Bot className="w-4 h-4 text-sky-400" />{loading ? 'Gemini is writing…' : 'Gemini'}</span>
                {response && !loading && (
                  <div className="flex items-center space-x-2">
                    <button onClick={() => { navigator.clipboard.writeText(response); setCopied(true); setTimeout(() => setCopied(false), 1500); }} className="flex items-center space-x-1 text-zinc-400 hover:text-white px-2 py-1 rounded bg-[#21262d] border border-[#30363d] text-[10px] cursor-pointer">{copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}<span>{copied ? 'Copied' : 'Copy'}</span></button>
                    <button onClick={() => onShareToChat(`🤖 Copilot on ${activeFile?.name}:\n${response.slice(0, 600)}${response.length > 600 ? '…' : ''}`)} className="flex items-center space-x-1 text-sky-400 hover:text-white px-2 py-1 rounded bg-sky-500/10 border border-sky-500/30 text-[10px] cursor-pointer"><Share2 className="w-3 h-3" /><span>Share to chat</span></button>
                  </div>
                )}
              </div>
              <div className="p-4 rounded-xl bg-[#0d1117] border border-[#30363d] leading-relaxed"><Markdown text={response || '…'} codeActions={codeActions} /></div>
            </div>
          )}
        </div>

        <form onSubmit={(e) => { e.preventDefault(); if (prompt.trim()) { run('chat', prompt.trim()); setPrompt(''); } }} className="p-3 border-t border-[#30363d] bg-[#0d1117] flex items-center gap-2 shrink-0">
          <input value={prompt} onChange={(e) => setPrompt(e.target.value)} maxLength={2000} placeholder="Ask anything about this code…" aria-label="Ask Copilot"
            className="flex-1 bg-[#161b22] border border-[#30363d] focus:border-sky-500/50 rounded-lg px-3 py-2 text-xs text-white placeholder-zinc-500 outline-none" />
          {loading
            ? <button type="button" onClick={stop} className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs cursor-pointer"><Square className="w-3 h-3 fill-current" />Stop</button>
            : <button type="submit" disabled={!prompt.trim()} className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white text-xs cursor-pointer"><Send className="w-3.5 h-3.5" />Ask</button>}
        </form>
      </div>
    </div>
  );
};
