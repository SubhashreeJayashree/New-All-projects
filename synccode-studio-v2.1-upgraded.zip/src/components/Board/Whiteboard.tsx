import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Undo2, Trash2, Pen, Eraser } from 'lucide-react';
import { Stroke } from '../../types';

const W = 1600, H = 900;
const PALETTE = ['#38bdf8', '#10b981', '#f59e0b', '#ec4899', '#a78bfa', '#ffffff'];

interface Props {
  strokes: Stroke[];
  myId: string;
  onPoints: (strokeId: string, pts: number[], size: number, color: string) => void;
  onUndo: (strokeId: string) => void;
  onClear: () => void;
  disabled?: boolean;
}

export const Whiteboard: React.FC<Props> = ({ strokes, myId, onPoints, onUndo, onClear, disabled }) => {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [color, setColor] = useState(PALETTE[0]);
  const [size, setSize] = useState(4);
  const [eraser, setEraser] = useState(false);
  const drawing = useRef<{ id: string; buf: number[]; timer: any } | null>(null);
  const scale = useRef(1);

  const redraw = useCallback(() => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d')!;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.setTransform(scale.current, 0, 0, scale.current, 0, 0);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    for (const s of strokes) {
      if (s.pts.length < 2) continue;
      ctx.strokeStyle = s.color; ctx.fillStyle = s.color; ctx.lineWidth = s.size;
      if (s.pts.length === 2) { ctx.beginPath(); ctx.arc(s.pts[0], s.pts[1], s.size / 2, 0, Math.PI * 2); ctx.fill(); continue; }
      ctx.beginPath(); ctx.moveTo(s.pts[0], s.pts[1]);
      for (let i = 2; i < s.pts.length; i += 2) ctx.lineTo(s.pts[i], s.pts[i + 1]);
      ctx.stroke();
    }
  }, [strokes]);

  useEffect(() => {
    const wrap = wrapRef.current, c = canvasRef.current;
    if (!wrap || !c) return;
    const fit = () => {
      const r = wrap.getBoundingClientRect();
      const s = Math.min(r.width / W, r.height / H);
      const dpr = window.devicePixelRatio || 1;
      c.style.width = `${W * s}px`; c.style.height = `${H * s}px`;
      c.width = Math.round(W * s * dpr); c.height = Math.round(H * s * dpr);
      scale.current = s * dpr;
      redraw();
    };
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(wrap);
    return () => ro.disconnect();
  }, [redraw]);

  useEffect(redraw, [redraw]);

  const pos = (e: React.PointerEvent) => {
    const r = canvasRef.current!.getBoundingClientRect();
    return [Math.round(((e.clientX - r.left) / r.width) * W), Math.round(((e.clientY - r.top) / r.height) * H)];
  };
  const flush = () => {
    const d = drawing.current;
    if (!d || !d.buf.length) return;
    onPoints(d.id, d.buf, eraser ? 22 : size, eraser ? '#0d1117' : color);
    d.buf = [];
  };
  const down = (e: React.PointerEvent) => {
    if (disabled) return;
    (e.target as Element).setPointerCapture(e.pointerId);
    const id = `${myId.slice(0, 8)}-${Date.now().toString(36)}${Math.floor(Math.random() * 99)}`;
    drawing.current = { id, buf: pos(e), timer: setInterval(flush, 60) };
    flush();
  };
  const move = (e: React.PointerEvent) => {
    const d = drawing.current;
    if (!d) return;
    const [x, y] = pos(e);
    const n = d.buf.length;
    if (n >= 2 && Math.abs(d.buf[n - 2] - x) + Math.abs(d.buf[n - 1] - y) < 3) return;
    d.buf.push(x, y);
  };
  const up = () => {
    const d = drawing.current;
    if (!d) return;
    clearInterval(d.timer); flush();
    lastMine.current = d.id;
    drawing.current = null;
  };
  const lastMine = useRef<string | null>(null);
  const undo = () => {
    const mine = [...strokes].reverse().find((s) => s.userId === myId);
    if (mine) onUndo(mine.id);
  };

  return (
    <div className="h-full flex flex-col gap-2">
      <div className="flex items-center gap-2 text-xs select-none shrink-0">
        {PALETTE.map((c) => (
          <button key={c} onClick={() => { setColor(c); setEraser(false); }} aria-label={`Color ${c}`}
            className={`w-5 h-5 rounded-full border-2 cursor-pointer ${!eraser && color === c ? 'border-white' : 'border-transparent'}`} style={{ background: c }} />
        ))}
        <button onClick={() => setEraser(!eraser)} title="Eraser" className={`p-1 rounded cursor-pointer ${eraser ? 'bg-sky-500/20 text-sky-300' : 'text-zinc-400 hover:text-white'}`}>{eraser ? <Eraser className="w-4 h-4" /> : <Pen className="w-4 h-4" />}</button>
        <input type="range" min={2} max={16} value={size} onChange={(e) => setSize(+e.target.value)} className="w-20 accent-sky-400" aria-label="Brush size" />
        <div className="flex-1" />
        <button onClick={undo} className="flex items-center gap-1 px-2 py-1 rounded bg-[#21262d] border border-[#30363d] text-zinc-300 hover:text-white cursor-pointer"><Undo2 className="w-3 h-3" />Undo mine</button>
        <button onClick={onClear} disabled={disabled} className="flex items-center gap-1 px-2 py-1 rounded bg-rose-500/10 border border-rose-500/30 text-rose-300 hover:bg-rose-500/20 disabled:opacity-40 cursor-pointer"><Trash2 className="w-3 h-3" />Clear all</button>
      </div>
      <div ref={wrapRef} className="flex-1 min-h-0 flex items-center justify-center rounded-lg bg-[#0d1117] border border-[#30363d] overflow-hidden">
        <canvas ref={canvasRef} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}
          className={`touch-none ${disabled ? 'cursor-not-allowed' : 'cursor-crosshair'}`} style={{ background: '#0d1117' }} />
      </div>
    </div>
  );
};
