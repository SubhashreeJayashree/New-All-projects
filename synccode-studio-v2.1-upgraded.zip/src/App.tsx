/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Navbar, TimerView } from './components/Header/Navbar';
import { CodeEditor } from './components/Editor/CodeEditor';
import { VideoConferencing, FloatingReaction } from './components/Video/VideoConferencing';
import { CodeRunner, RunnerTab } from './components/Terminal/CodeRunner';
import { ChatPanel } from './components/Chat/ChatPanel';
import { InternshipDossierModal } from './components/Showcase/InternshipDossierModal';
import { GenAICopilotModal } from './components/AI/GenAICopilotModal';
import { HowToRunModal } from './components/Showcase/HowToRunModal';
import { Lobby, JoinInfo } from './components/Lobby/Lobby';
import { CommandPalette, Command } from './components/Palette/CommandPalette';
import { Whiteboard } from './components/Board/Whiteboard';
import { SessionReplay } from './components/Reviews/SessionReplay';
import { ReviewPanel } from './components/Reviews/ReviewPanel';
import { ToastHost, Toast } from './components/Common/Toasts';
import { CodeAction } from './components/Common/Markdown';
import { User, CodeFile, ChatMessage, RemoteCursor, ExecutionResult, ChallengePreset, RoomState, Stroke, ReplayEntry, ReviewComment } from './types';
import { socketService } from './services/socket';
import { webrtcManager } from './services/webrtc';
import { DocManager } from './services/docSync';
import { runProject, isTestFile } from './services/sandbox';
import { externalRunnerUrl, isExternalLanguage } from './services/externalRunner';
import { CHALLENGE_PRESETS } from './utils/challengePresets';
import { makeUser, loadSession } from './utils/identity';
import { makeZip, downloadBlob } from './utils/zip';
import { Op, diff, transformIndex } from './shared/ot';
import { WifiOff, AlertTriangle } from 'lucide-react';

const EXT_FOR: Record<string, string> = { typescript: 'ts', ts: 'ts', tsx: 'tsx', javascript: 'js', js: 'js', jsx: 'jsx', python: 'py', py: 'py', c: 'c', cpp: 'cpp', java: 'java', csharp: 'cs', go: 'go', rust: 'rs', php: 'php', ruby: 'rb', html: 'html', css: 'css', json: 'json', markdown: 'md', md: 'md' };

function starterContent(name: string): string {
  if (/\.(ts|js|tsx|jsx)$/.test(name)) return `// ${name}\nconsole.log("Hello from ${name}");\n`;
  if (/\.py$/.test(name)) return `# ${name}\nprint("Hello from ${name}")\n`;
  if (/\.c$|\.h$/i.test(name)) return `#include <stdio.h>\n\nint main(void) {\n    printf("Hello from ${name}!\\n");\n    return 0;\n}\n`;
  if (/\.(cc|cpp|cxx|hpp|hh|hxx)$/i.test(name)) return `#include <iostream>\n\nint main() {\n    std::cout << "Hello from ${name}!" << std::endl;\n    return 0;\n}\n`;
  if (/\.java$/i.test(name)) return `public class ${name.replace(/\.java$/i, '')} {\n    public static void main(String[] args) {\n        System.out.println("Hello from ${name}!");\n    }\n}\n`;
  if (/\.cs$/i.test(name)) return `using System;\n\nclass Program {\n    static void Main() {\n        Console.WriteLine("Hello from ${name}!");\n    }\n}\n`;
  if (/\.go$/i.test(name)) return `package main\n\nimport "fmt"\n\nfunc main() {\n    fmt.Println("Hello from ${name}!")\n}\n`;
  if (/\.rs$/i.test(name)) return `fn main() {\n    println!("Hello from ${name}!");\n}\n`;
  if (/\.php$/i.test(name)) return `<?php\n\necho "Hello from ${name}!\\n";\n`;
  if (/\.rb$/i.test(name)) return `puts "Hello from ${name}!"\n`;
  if (/\.html?$/.test(name)) return `<!DOCTYPE html>\n<html>\n<body>\n  <h1>${name}</h1>\n</body>\n</html>\n`;
  return '';
}

export default function App() {
  const q = useMemo(() => new URLSearchParams(window.location.search), []);
  const [join, setJoin] = useState<JoinInfo | null>(() => {
    if (q.get('peer') === 'true' && q.get('room')) return { name: q.get('name') || 'Peer', roomId: q.get('room')!, audio: true, video: true, account: null };
    return null;
  });
  if (!join) {
    return <Lobby initialRoom={q.get('room') || ''} onJoin={(j) => { history.replaceState(null, '', `?room=${encodeURIComponent(j.roomId)}`); setJoin(j); }} />;
  }
  return <Workspace join={join} />;
}

function Workspace({ join }: { join: JoinInfo }) {
  const roomId = join.roomId;
  const session = useMemo(loadSession, []);
  const currentUser = useMemo<User>(() => makeUser(session.id, join.name, join.audio, join.video), [session.id, join]);

  // ----- state -----
  const [users, setUsers] = useState<User[]>([currentUser]);
  const [files, setFiles] = useState<CodeFile[]>([]);
  const [activeFileId, setActiveFileId] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [remoteCursors, setRemoteCursors] = useState<RemoteCursor[]>([]);
  const [execution, setExecution] = useState<ExecutionResult | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [runStatus, setRunStatus] = useState('');
  const [runnerTab, setRunnerTab] = useState<RunnerTab>('console');
  const [challenge, setChallenge] = useState<ChallengePreset | null>(null);
  const [hostId, setHostId] = useState('');
  const [editLocked, setEditLocked] = useState(false);
  const [timer, setTimer] = useState<TimerView | null>(null);
  const [strokes, setStrokes] = useState<Stroke[]>([]);
  const [followUserId, setFollowUserId] = useState<string | null>(null);
  const [typingUsers, setTypingUsers] = useState<Record<string, string>>({});
  const [aiTyping, setAiTyping] = useState(false);
  const [reactions, setReactions] = useState<FloatingReaction[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [replayOpen, setReplayOpen] = useState(false);
  const [replayEntries, setReplayEntries] = useState<ReplayEntry[]>([]);
  const [replayLoading, setReplayLoading] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [reviewComments, setReviewComments] = useState<ReviewComment[]>([]);
  const [reviewAnchor, setReviewAnchor] = useState({ fileId: '', line: 1, selectedText: '' });

  const [latencyMs, setLatencyMs] = useState(0);
  const [isConnected, setIsConnected] = useState(false);
  const [hasJoined, setHasJoined] = useState(false);
  const [fatal, setFatal] = useState<string | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStreams, setRemoteStreams] = useState<Map<string, MediaStream>>(new Map());
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [audioVolume, setAudioVolume] = useState(0);

  const [dossierOpen, setDossierOpen] = useState(false);
  const [copilotOpen, setCopilotOpen] = useState(false);
  const [howToOpen, setHowToOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [findSignal, setFindSignal] = useState(0);

  // ----- refs -----
  const docs = useRef(new DocManager());
  const filesRef = useRef<CodeFile[]>([]);
  const activeRef = useRef('');
  const followRef = useRef<string | null>(null);
  const remoteOpListeners = useRef(new Set<(fileId: string, op: Op) => void>());
  const cursorTimer = useRef<any>(null);
  const externalRunConsent = useRef(false);
  const lastCursor = useRef<any>(null);
  const toastId = useRef(1);
  const hasJoinedRef = useRef(false);
  const speakRef = useRef({ speaking: false, vol: 0, t: 0 });
  filesRef.current = files;
  activeRef.current = activeFileId;
  followRef.current = followUserId;

  const isHost = hostId === currentUser.id;
  const readOnly = !isConnected || (editLocked && !isHost);
  const activeFile = files.find((f) => f.id === activeFileId) || files[0] || null;

  const notify = useCallback((text: string, kind: Toast['kind'] = 'info') => {
    const id = toastId.current++;
    setToasts((t) => [...t.slice(-3), { id, text, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3800);
  }, []);

  const subscribeRemoteOps = useCallback((cb: (fileId: string, op: Op) => void) => {
    remoteOpListeners.current.add(cb);
    return () => { remoteOpListeners.current.delete(cb); };
  }, []);

  const setContent = (fileId: string, content: string, version?: number) =>
    setFiles((prev) => prev.map((f) => (f.id === fileId ? { ...f, content, version: version ?? f.version, updatedAt: Date.now() } : f)));

  const mapCursors = (fileId: string, op: Op, exceptUser?: string) =>
    setRemoteCursors((prev) => prev.map((c) => (c.fileId !== fileId || c.userId === exceptUser ? c
      : { ...c, offset: transformIndex(c.offset, op), selStart: transformIndex(c.selStart, op), selEnd: transformIndex(c.selEnd, op) })));

  // ----- connection lifecycle -----
  useEffect(() => {
    webrtcManager.init(currentUser.id, (s) => setRemoteStreams(new Map(s)), (speaking, vol) => {
      const r = speakRef.current, now = performance.now();
      if (speaking !== r.speaking || (now - r.t > 120 && Math.abs(vol - r.vol) > 4)) {
        r.speaking = speaking; r.vol = vol; r.t = now;
        setIsSpeaking(speaking); setAudioVolume(vol);
      }
    }, currentUser.name);
    webrtcManager.startLocalMedia({ audio: join.audio, video: join.video }).then(setLocalStream);

    const off: (() => void)[] = [];
    const on = (ev: string, fn: (d: any) => void) => off.push(socketService.on(ev, fn));

    on('connection-status', (d) => setIsConnected(d.connected));
    on('latency-update', (d) => setLatencyMs(d.latencyMs));
    on('join-error', (d) => setFatal(d.reason || 'Could not join the room.'));
    on('notice', (d) => notify(d.text, 'error'));

    on('room-init', (d) => {
      const room: RoomState = d.roomState;
      const wasJoined = hasJoinedRef.current;
      hasJoinedRef.current = true;
      docs.current.init(room.files as CodeFile[]);
      setFiles(room.files);
      setActiveFileId((cur) => (room.files.some((f) => f.id === cur) ? cur : room.activeFileId || room.files[0]?.id || ''));
      setUsers(room.users);
      setMessages(room.messages || []);
      setChallenge(room.challenge || null);
      setExecution(room.lastExecution || null);
      setHostId(room.hostId || '');
      setEditLocked(!!room.editLocked);
      setStrokes(room.strokes || []);
      setReviewComments(room.reviewComments || []);
      if (room.timer) setTimer({ ...room.timer, receivedAt: Date.now() });
      setRemoteCursors([]);
      setHasJoined(true);
      if (wasJoined) notify('Reconnected — synced to the latest version.', 'success');
    });

    on('user-joined', (d) => {
      setUsers(d.users);
      if (d.user.id !== currentUser.id) { webrtcManager.callUser(d.user.id); notify(`${d.user.name} joined`); }
    });
    on('user-left', (d) => {
      setUsers(d.users);
      webrtcManager.removePeer(d.userId);
      setRemoteCursors((p) => p.filter((c) => c.userId !== d.userId));
      setFollowUserId((f) => (f === d.userId ? null : f));
      notify(`${d.userName} left`);
    });
    on('host-changed', (d) => { setHostId(d.hostId); setUsers(d.users); });
    on('user-media-state', (d) => setUsers((prev) => prev.map((u) => (u.id === d.userId ? { ...u, ...d } : u))));

    // ---- document sync (OT) ----
    on('doc-op', (d) => {
      const doc = docs.current.get(d.fileId);
      if (!doc) return;
      const applied = doc.remote(d.op, d.version);
      remoteOpListeners.current.forEach((cb) => cb(d.fileId, applied));
      setContent(d.fileId, doc.text, d.version);
      mapCursors(d.fileId, applied, d.senderId);
    });
    on('doc-ack', (d) => {
      const next = docs.current.get(d.fileId)?.ack(d.version);
      if (next) socketService.sendDocOp(d.fileId, next.baseVersion, next.op);
    });
    on('doc-resync', (d) => {
      docs.current.ensure(d.fileId).reset(d.content, d.version);
      setContent(d.fileId, d.content, d.version);
    });
    on('session-history', (d) => { setReplayEntries(Array.isArray(d.entries) ? d.entries : []); setReplayLoading(false); });
    on('review-comments', (d) => setReviewComments(Array.isArray(d.comments) ? d.comments : []));

    on('cursor-update', (d) => {
      const c: RemoteCursor = d.cursor;
      setRemoteCursors((prev) => [...prev.filter((x) => x.userId !== c.userId), c]);
      if (followRef.current === c.userId && c.fileId !== activeRef.current) setActiveFileId(c.fileId);
    });

    on('file-create', (d) => {
      docs.current.ensure(d.file.id, d.file.content, d.file.version ?? 0);
      setFiles((prev) => (prev.some((f) => f.id === d.file.id) ? prev : [...prev, d.file]));
      if (d.senderId === currentUser.id) setActiveFileId(d.file.id);
    });
    on('file-rename', (d) => setFiles((p) => p.map((f) => (f.id === d.fileId ? { ...f, name: d.newName, language: d.language ?? f.language } : f))));
    on('file-delete', (d) => {
      docs.current.remove(d.fileId);
      setFiles((p) => p.filter((f) => f.id !== d.fileId));
      setRemoteCursors((p) => p.filter((c) => c.fileId !== d.fileId));
      setActiveFileId((cur) => (cur === d.fileId ? d.activeFileId : cur));
    });
    on('file-select', (d) => { if (followRef.current === d.senderId) setActiveFileId(d.fileId); });

    on('chat-broadcast', (d) => setMessages((p) => (p.some((m) => m.id === d.message.id) ? p : [...p, d.message])));
    on('typing', (d) => setTypingUsers((p) => { const n = { ...p }; if (d.typing) n[d.userId] = d.userName; else delete n[d.userId]; return n; }));
    on('ai-typing', (d) => setAiTyping(!!d.typing));

    on('execute-broadcast', (d) => {
      setExecution(d.result);
      setIsRunning(false);
      setRunnerTab(d.result.kind === 'tests' ? 'tests' : 'console');
    });
    on('load-challenge', (d) => {
      setChallenge(d.challenge);
      docs.current.init(d.files);
      setFiles(d.files);
      setActiveFileId(d.activeFileId);
      setExecution(null);
      setRemoteCursors([]);
    });
    on('room-lock', (d) => setEditLocked(!!d.locked));
    on('timer-update', (d) => setTimer({ ...d.timer, receivedAt: Date.now() }));

    on('reaction', (d) => {
      const id = Date.now() + Math.random();
      setReactions((p) => [...p.slice(-12), { id, emoji: d.emoji, left: 8 + Math.random() * 78 }]);
      setTimeout(() => setReactions((p) => p.filter((r) => r.id !== id)), 2300);
    });

    on('board-points', (d) => setStrokes((prev) => {
      const i = prev.findIndex((s) => s.id === d.id);
      if (i < 0) return [...prev, { id: d.id, userId: d.userId, color: d.color, size: d.size, pts: d.pts }];
      const n = prev.slice(); n[i] = { ...n[i], pts: n[i].pts.concat(d.pts) }; return n;
    }));
    on('board-undo', (d) => setStrokes((p) => p.filter((s) => s.id !== d.id)));
    on('board-clear', () => setStrokes([]));

    socketService.connect(roomId, currentUser, session.token);
    return () => {
      off.forEach((f) => f());
      webrtcManager.cleanup();
      socketService.disconnect();
    };
  }, [roomId, currentUser.id]); // eslint-disable-line

  // global shortcuts
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const mod = e.metaKey || e.ctrlKey;
      if (mod && (e.key.toLowerCase() === 'k' || (e.shiftKey && e.key.toLowerCase() === 'p'))) { e.preventDefault(); setPaletteOpen((o) => !o); }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);

  // ----- editor callbacks -----
  const handleCodeChange = useCallback((fileId: string, content: string) => {
    const doc = docs.current.get(fileId);
    if (!doc) return;
    const prev = doc.text;
    const out = doc.local(content);
    setContent(fileId, content);
    const op = diff(prev, content);
    if (op.length) mapCursors(fileId, op);
    if (out) socketService.sendDocOp(fileId, out.baseVersion, out.op);
  }, []);

  const handleCursorChange = useCallback((fileId: string, offset: number, selStart: number, selEnd: number) => {
    lastCursor.current = { fileId, offset, selStart, selEnd };
    const file = filesRef.current.find((item) => item.id === fileId);
    if (file) {
      const start = Math.min(selStart, selEnd), end = Math.max(selStart, selEnd);
      setReviewAnchor({ fileId, line: file.content.slice(0, offset).split('\n').length, selectedText: file.content.slice(start, end).slice(0, 500) });
    }
    if (cursorTimer.current) return;
    cursorTimer.current = setTimeout(() => {
      cursorTimer.current = null;
      if (lastCursor.current) socketService.sendCursor(lastCursor.current);
    }, 50);
  }, []);

  const uniqueName = (name: string) => {
    const taken = new Set(filesRef.current.map((f) => f.name));
    if (!taken.has(name)) return name;
    const dot = name.lastIndexOf('.');
    const [base, ext] = dot > 0 ? [name.slice(0, dot), name.slice(dot)] : [name, ''];
    for (let i = 1; i < 100; i++) if (!taken.has(`${base}-${i}${ext}`)) return `${base}-${i}${ext}`;
    return `${base}-${Date.now()}${ext}`;
  };
  const createFile = (name: string, content?: string) => socketService.sendFileCreate(uniqueName(name), content ?? starterContent(name));
  const selectFile = (id: string) => { setActiveFileId(id); socketService.sendFileSelect(id); };

  const downloadZip = () => {
    if (!files.length) return;
    downloadBlob(makeZip(files.map((f) => ({ name: f.name, content: f.content }))), `${roomId}.zip`);
    notify('Project downloaded as .zip', 'success');
  };

  // ----- running code -----
  const run = async (mode: 'run' | 'tests') => {
    if (isRunning) return;
    const entry = filesRef.current.find((f) => f.id === activeRef.current) || filesRef.current[0];
    if (!entry) return;
    if (mode === 'run' && entry.language === 'html') { setRunnerTab('preview'); return; }
    if (mode === 'run' && isExternalLanguage(entry.language) && !externalRunConsent.current &&
      !confirm(`Run ${entry.name} using the optional external runner at ${externalRunnerUrl()}? This sends the active file's source code to that service for execution. Only run code you trust.`)) return;
    if (mode === 'run' && isExternalLanguage(entry.language)) externalRunConsent.current = true;
    if (mode === 'run' && !['javascript', 'typescript', 'python'].includes(entry.language) && !isExternalLanguage(entry.language)) { notify(`“${entry.name}” isn't runnable. See the How to Run guide for supported file types.`); return; }
    setIsRunning(true); setRunStatus(''); setRunnerTab(mode === 'tests' ? 'tests' : 'console');
    try {
      const result = await runProject(filesRef.current, entry, mode, { id: currentUser.id, name: currentUser.name }, setRunStatus);
      setExecution(result);
      setRunnerTab(mode === 'tests' ? 'tests' : 'console');
      socketService.broadcastExecution(result);
    } finally {
      setIsRunning(false); setRunStatus('');
    }
  };

  // ----- AI code actions -----
  const codeActions: CodeAction[] = [
    {
      label: 'Replace file',
      run: (code) => {
        if (!activeFile) return;
        if (readOnly) return notify('Editing is locked.', 'error');
        if (!confirm(`Replace the contents of ${activeFile.name} for everyone?`)) return;
        handleCodeChange(activeFile.id, code);
        notify(`Updated ${activeFile.name}`, 'success');
      },
    },
    {
      label: 'New file',
      run: (code, lang) => {
        if (readOnly) return notify('Editing is locked.', 'error');
        const ext = EXT_FOR[lang.toLowerCase()] || (activeFile?.name.split('.').pop() ?? 'ts');
        const isTest = /\b(expect|test|describe)\(/.test(code);
        createFile(isTest ? `generated.test.${ext === 'py' ? 'ts' : ext}` : `snippet.${ext}`, code);
        notify('Created new file from AI output', 'success');
      },
    },
  ];

  // ----- timer / board / social -----
  const timerAction = (action: string, durationMs?: number) => socketService.send('timer-action', { action, durationMs });
  const openReplay = () => {
    setReplayOpen(true);
    setReplayLoading(isConnected);
    if (isConnected) socketService.send('history-request');
  };
  const addReviewComment = (content: string) => {
    if (!activeFile) return;
    const anchor = reviewAnchor.fileId === activeFile.id ? reviewAnchor : { fileId: activeFile.id, line: 1, selectedText: '' };
    socketService.send('review-add', { comment: { ...anchor, fileId: activeFile.id, content } });
  };
  const signOut = async () => {
    try {
      const response = await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
      if (!response.ok) throw new Error('Could not sign out.');
      window.location.href = `/?room=${encodeURIComponent(roomId)}`;
    } catch (error) {
      notify(error instanceof Error ? error.message : 'Could not sign out.', 'error');
    }
  };
  const boardPoints = (id: string, pts: number[], size: number, color: string) => {
    setStrokes((prev) => {
      const i = prev.findIndex((s) => s.id === id);
      if (i < 0) return [...prev, { id, userId: currentUser.id, color, size, pts }];
      const n = prev.slice(); n[i] = { ...n[i], pts: n[i].pts.concat(pts) }; return n;
    });
    socketService.send('board-points', { id, pts, size, color });
  };
  const boardUndo = (id: string) => { setStrokes((p) => p.filter((s) => s.id !== id)); socketService.send('board-undo', { id }); };

  const openPeerTab = () => window.open(`${location.origin}/?room=${encodeURIComponent(roomId)}&peer=true&name=${encodeURIComponent('Guest')}`, '_blank', 'width=1280,height=800');

  // ----- command palette -----
  const commands = useMemo<Command[]>(() => {
    const c: Command[] = [
      { id: 'run', group: 'Run', title: 'Run current file', hint: '⌘↵', run: () => run('run') },
      { id: 'tests', group: 'Run', title: 'Run tests', run: () => run('tests') },
      { id: 'find', group: 'Edit', title: 'Find & replace in file', hint: '⌘F', run: () => setFindSignal((n) => n + 1) },
      { id: 'newfile', group: 'File', title: 'New file…', run: () => { const n = prompt('File name (e.g. utils.ts, solve.py)'); if (n?.trim()) createFile(n.trim()); } },
      { id: 'zip', group: 'File', title: 'Download project as .zip', run: downloadZip },
      { id: 'ai', group: 'AI', title: 'Open Gemini Copilot', run: () => setCopilotOpen(true) },
      { id: 'board', group: 'View', title: 'Show whiteboard', run: () => setRunnerTab('board') },
      { id: 'preview', group: 'View', title: 'Show live preview', run: () => setRunnerTab('preview') },
      { id: 'console', group: 'View', title: 'Show terminal', run: () => setRunnerTab('console') },
      { id: 'peer', group: 'Room', title: 'Open peer tab (test collaboration)', run: openPeerTab },
      { id: 'copy', group: 'Room', title: 'Copy invite link', run: () => { navigator.clipboard.writeText(`${location.origin}/?room=${encodeURIComponent(roomId)}`); notify('Invite link copied', 'success'); } },
      { id: 'dossier', group: 'Room', title: 'Open project dossier', run: () => setDossierOpen(true) },
      { id: 'howto', group: 'Room', title: 'How to run guide', run: () => setHowToOpen(true) },
    ];
    if (activeFile?.language === 'json') c.push({ id: 'fmt', group: 'Edit', title: 'Format JSON', run: () => { try { handleCodeChange(activeFile.id, JSON.stringify(JSON.parse(activeFile.content), null, 2) + '\n'); } catch { notify('Invalid JSON — cannot format.', 'error'); } } });
    if (isHost) {
      c.push({ id: 'lock', group: 'Host', title: editLocked ? 'Unlock editing for guests' : 'Lock editing for guests', run: () => socketService.send('room-lock', { locked: !editLocked }) });
      CHALLENGE_PRESETS.forEach((ch) => c.push({ id: `ch-${ch.id}`, group: 'Host', title: `Load challenge: ${ch.title}`, run: () => socketService.loadChallenge(ch.id) }));
    }
    files.forEach((f) => c.push({ id: `f-${f.id}`, group: 'Go to', title: f.name, run: () => selectFile(f.id) }));
    users.filter((u) => u.id !== currentUser.id).forEach((u) => c.push({ id: `fl-${u.id}`, group: 'Follow', title: followUserId === u.id ? `Stop following ${u.name}` : `Follow ${u.name}`, run: () => setFollowUserId(followUserId === u.id ? null : u.id) }));
    return c;
  }, [files, users, isHost, editLocked, followUserId, activeFile?.id, isRunning, roomId]); // eslint-disable-line

  const typingNames = Object.entries(typingUsers).filter(([id]) => id !== currentUser.id).map(([, n]) => n);

  if (fatal) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-[#0d1117] text-zinc-200 p-6">
        <div className="max-w-sm text-center space-y-3">
          <AlertTriangle className="w-10 h-10 text-amber-400 mx-auto" />
          <h2 className="text-lg font-semibold">Can’t join this room</h2>
          <p className="text-sm text-zinc-400">{fatal}</p>
          <button onClick={() => { sessionStorage.removeItem('synccode:session'); location.href = '/'; }} className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-sm cursor-pointer">Back to lobby</button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen flex flex-col bg-[#0d1117] text-[#e6edf3] overflow-hidden select-none">
      <Navbar
        roomId={roomId} currentUser={currentUser} users={users} hostId={hostId} isHost={isHost}
        latencyMs={latencyMs} isConnected={isConnected} isRunning={isRunning} hasTests={files.some((f) => isTestFile(f.name))}
        editLocked={editLocked} timer={timer} followUserId={followUserId} activeChallenge={challenge}
        accountEmail={join.account?.email} onSignOut={join.account ? signOut : undefined}
        onRunCode={() => run('run')} onRunTests={() => run('tests')} onOpenPalette={() => setPaletteOpen(true)}
        onOpenReplay={openReplay} onOpenReviews={() => setReviewOpen(true)}
        onOpenDossier={() => setDossierOpen(true)} onOpenPeerTab={openPeerTab} onOpenCopilot={() => setCopilotOpen(true)}
        onOpenHowToRun={() => setHowToOpen(true)} onSelectChallenge={(c) => socketService.loadChallenge(c.id)}
        onToggleLock={() => socketService.send('room-lock', { locked: !editLocked })} onTimerAction={timerAction}
        onToggleFollow={setFollowUserId} onTimerExpire={() => notify('⏰ Time is up!', 'error')}
      />

      {!isConnected && (
        <div className="bg-amber-500/15 border-b border-amber-500/30 text-amber-200 text-xs px-4 py-1.5 flex items-center gap-2 shrink-0" role="alert">
          <WifiOff className="w-3.5 h-3.5" />{hasJoined ? 'Connection lost — reconnecting. Editing is paused so nothing gets overwritten.' : 'Connecting to the room…'}
        </div>
      )}

      <div className="flex-1 flex overflow-hidden min-h-0">
        <ChatPanel
          messages={messages} onSendMessage={(c) => socketService.sendChat(c)} onTyping={(t) => socketService.sendTyping(t)}
          typingUsers={typingNames} aiTyping={aiTyping} currentUser={currentUser} codeActions={codeActions}
          onOpenPeerTab={openPeerTab} onOpenHowToRun={() => setHowToOpen(true)}
        />

        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <CodeEditor
            files={files} activeFileId={activeFileId} users={users} currentUser={currentUser} remoteCursors={remoteCursors}
            readOnly={readOnly} readOnlyReason={!isConnected ? 'Reconnecting — editing paused' : 'Locked by host'}
            followUserId={followUserId} findSignal={findSignal}
            onSelectFile={selectFile} onCodeChange={handleCodeChange} onCreateFile={(n) => createFile(n)}
            onRenameFile={(id, n) => n && socketService.sendFileRename(id, n)} onDeleteFile={(id) => socketService.sendFileDelete(id)}
            onCursorChange={handleCursorChange} onRunCode={() => run('run')}
            onSave={() => notify('Everything is saved automatically in the room ✓', 'success')}
            onImportFiles={(fs) => { fs.forEach((f) => createFile(f.name, f.content)); notify(`Added ${fs.length} file${fs.length > 1 ? 's' : ''}`, 'success'); }}
            onDownloadZip={downloadZip} onToggleFollow={setFollowUserId}
            subscribeRemoteOps={subscribeRemoteOps} notify={notify}
          />
          <CodeRunner
            executionResult={execution} onClearOutput={() => setExecution(null)} activeChallenge={challenge} files={files}
            isRunning={isRunning} runStatus={runStatus} tab={runnerTab} onTabChange={setRunnerTab}
            board={<Whiteboard strokes={strokes} myId={currentUser.id} onPoints={boardPoints} onUndo={boardUndo} onClear={() => { if (confirm('Clear the whiteboard for everyone?')) socketService.send('board-clear'); }} disabled={readOnly} />}
          />
        </div>

        <VideoConferencing
          currentUser={currentUser} users={users} localStream={localStream} remoteStreams={remoteStreams}
          isSpeaking={isSpeaking} audioVolume={audioVolume} reactions={reactions}
          onReact={(e) => socketService.send('reaction', { emoji: e })} onToggleHand={() => socketService.send('hand-toggle')}
          onMediaChange={() => setUsers((p) => p.map((u) => (u.id === currentUser.id ? { ...u, isAudioOn: webrtcManager.isAudioEnabled, isVideoOn: webrtcManager.isVideoEnabled } : u)))}
        />
      </div>

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} commands={commands} />
      <ToastHost toasts={toasts} dismiss={(id) => setToasts((t) => t.filter((x) => x.id !== id))} />

      <SessionReplay isOpen={replayOpen} entries={replayEntries} loading={replayLoading} onClose={() => setReplayOpen(false)} />
      <ReviewPanel
        isOpen={reviewOpen} comments={reviewComments} fileId={activeFile?.id || ''}
        fileName={activeFile?.name || ''} line={reviewAnchor.fileId === activeFile?.id ? reviewAnchor.line : 1}
        selectedText={reviewAnchor.fileId === activeFile?.id ? reviewAnchor.selectedText : ''}
        onClose={() => setReviewOpen(false)} onAdd={addReviewComment}
        onResolve={(id, resolved) => socketService.send('review-resolve', { commentId: id, resolved })}
        onDelete={(id) => socketService.send('review-delete', { commentId: id })}
      />
      <InternshipDossierModal isOpen={dossierOpen} onClose={() => setDossierOpen(false)} roomId={roomId} currentUser={currentUser} users={users} latencyMs={latencyMs} onOpenPeerTab={openPeerTab} />
      <GenAICopilotModal isOpen={copilotOpen} onClose={() => setCopilotOpen(false)} activeFile={activeFile} files={files} onShareToChat={(c) => socketService.sendChat(c)} codeActions={codeActions} currentUser={currentUser} />
      <HowToRunModal isOpen={howToOpen} onClose={() => setHowToOpen(false)} onOpenPeerTab={openPeerTab} onSendTestMessage={(t) => socketService.sendChat(t)} />
    </div>
  );
}
