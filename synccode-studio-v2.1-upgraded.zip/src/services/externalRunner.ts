import { CodeFile, CodeLanguage, ExecutionResult } from '../types';

const EXTERNAL_LANGUAGES: Partial<Record<CodeLanguage, string>> = {
  c: 'c',
  cpp: 'cpp',
  java: 'java',
  csharp: 'csharp',
  go: 'go',
  rust: 'rust',
  php: 'php',
  ruby: 'ruby',
};
const DEFAULT_API = 'https://emkc.org/api/v2/piston';
const MAX_SOURCE_CHARS = 100_000;
const MAX_OUTPUT_CHARS = 30_000;

interface Runtime {
  language: string;
  version: string;
  aliases?: string[];
}

interface RuntimeListCache {
  baseUrl: string;
  expiresAt: number;
  runtimes: Runtime[];
}

let runtimeCache: RuntimeListCache | null = null;

export const isExternalLanguage = (language: CodeLanguage) => !!EXTERNAL_LANGUAGES[language];
export const externalRunnerUrl = () => (import.meta.env.VITE_CODE_RUNNER_URL || DEFAULT_API).replace(/\/+$/, '');

function makeResult(
  who: { id: string; name: string },
  language: string,
  start: number,
  logs: ExecutionResult['logs'],
  error?: string,
): ExecutionResult {
  return {
    senderId: who.id,
    senderName: who.name,
    language,
    kind: 'run',
    durationMs: Math.max(0, Date.now() - start),
    logs: logs.length ? logs : [{ type: 'info', message: 'Program completed with no output.', timestamp: Date.now() }],
    error,
  };
}

function errorResult(message: string, who: { id: string; name: string }, language: string, start: number): ExecutionResult {
  return makeResult(who, language, start, [{ type: 'error', message, timestamp: Date.now() }], message);
}

async function requestRuntimes(baseUrl: string, request: typeof fetch): Promise<Runtime[]> {
  if (request === fetch && runtimeCache?.baseUrl === baseUrl && runtimeCache.expiresAt > Date.now()) return runtimeCache.runtimes;
  const response = await request(`${baseUrl}/runtimes`, { signal: AbortSignal.timeout(8000) });
  if (!response.ok) throw new Error(`The external runner could not list available languages (HTTP ${response.status}).`);
  const runtimes: unknown = await response.json();
  if (!Array.isArray(runtimes)) throw new Error('The external runner returned an invalid runtime list.');
  const valid = runtimes.filter((runtime): runtime is Runtime =>
    !!runtime && typeof runtime.language === 'string' && typeof runtime.version === 'string');
  if (request === fetch) runtimeCache = { baseUrl, expiresAt: Date.now() + 15 * 60_000, runtimes: valid };
  return valid;
}

function outputLog(logs: ExecutionResult['logs'], text: unknown, type: 'log' | 'error', prefix = '') {
  if (typeof text !== 'string' || !text) return;
  const clipped = text.slice(0, MAX_OUTPUT_CHARS);
  const lines = clipped.split(/\r?\n/).slice(0, 300);
  for (const line of lines) {
    if (line) logs.push({ type, message: `${prefix}${line}`.slice(0, 4000), timestamp: Date.now() });
  }
  if (text.length > MAX_OUTPUT_CHARS) logs.push({ type: 'warn', message: 'Output truncated at 30,000 characters.', timestamp: Date.now() });
}

export async function runExternalFile(
  entry: CodeFile,
  who: { id: string; name: string },
  onStatus?: (status: string) => void,
  request: typeof fetch = fetch,
  baseUrl = externalRunnerUrl(),
): Promise<ExecutionResult> {
  const start = Date.now();
  const alias = EXTERNAL_LANGUAGES[entry.language];
  if (!alias) return errorResult(`No external runtime is configured for ${entry.language}.`, who, entry.language, start);
  if (entry.content.length > MAX_SOURCE_CHARS) return errorResult('External runs are limited to 100,000 source characters per file.', who, entry.language, start);

  try {
    onStatus?.('Checking external runtime…');
    const runtimes = await requestRuntimes(baseUrl, request);
    const runtime = runtimes.find((item) =>
      [item.language, ...(item.aliases || [])].some((name) => name.toLowerCase() === alias.toLowerCase()));
    if (!runtime) return errorResult(`The external runner does not currently provide a ${entry.language} runtime.`, who, entry.language, start);

    onStatus?.(`Running ${entry.language} on the external runner…`);
    const response = await request(`${baseUrl}/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        language: runtime.language,
        version: runtime.version,
        files: [{ name: entry.name, content: entry.content }],
        stdin: '',
        args: [],
        run_timeout: 10_000,
        compile_timeout: 10_000,
      }),
      signal: AbortSignal.timeout(20_000),
    });
    const payload: any = await response.json().catch(() => null);
    if (!response.ok) {
      const reason = typeof payload?.message === 'string' ? payload.message : `HTTP ${response.status}`;
      return errorResult(`External runner request failed: ${reason}`, who, entry.language, start);
    }
    if (!payload || typeof payload !== 'object') return errorResult('The external runner returned an invalid response.', who, entry.language, start);

    const logs: ExecutionResult['logs'] = [];
    const compile = payload.compile;
    const run = payload.run;
    if (compile?.stdout) outputLog(logs, compile.stdout, 'log', '[compile] ');
    if (compile?.stderr) outputLog(logs, compile.stderr, 'error', '[compile] ');
    if (!compile?.stdout && !compile?.stderr && compile?.output) outputLog(logs, compile.output, compile.code === 0 ? 'log' : 'error', '[compile] ');
    if (compile && compile.code !== undefined && compile.code !== 0) {
      return makeResult(who, entry.language, start, logs.length ? logs : [{ type: 'error', message: 'Compilation failed.', timestamp: Date.now() }], 'Compilation failed.');
    }
    if (!run || typeof run !== 'object') return errorResult('The external runner did not return an execution result.', who, entry.language, start);
    if (run.stdout) outputLog(logs, run.stdout, 'log');
    if (run.stderr) outputLog(logs, run.stderr, 'error');
    if (!run.stdout && !run.stderr && run.output) outputLog(logs, run.output, run.code === 0 ? 'log' : 'error');
    const failure = (run.code !== undefined && run.code !== 0) || !!run.signal
      ? `Program exited with code ${String(run.code)}${run.signal ? ` (${String(run.signal)})` : ''}.`
      : undefined;
    if (failure && !logs.some((log) => log.type === 'error')) outputLog(logs, failure, 'error');
    return makeResult(who, entry.language, start, logs, failure);
  } catch (error) {
    const reason = error instanceof Error && ['AbortError', 'TimeoutError'].includes(error.name)
      ? 'The external runner timed out. Try again later.'
      : error instanceof Error
        ? `Could not reach the external runner: ${error.message}`
        : 'Could not reach the external runner.';
    return errorResult(reason, who, entry.language, start);
  }
}
