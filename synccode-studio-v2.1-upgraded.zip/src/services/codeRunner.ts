import { ExecutionLog, ExecutionResult } from '../types';

export function runSandboxedCode(
  code: string,
  language: string,
  senderId: string,
  senderName: string
): ExecutionResult {
  const startTime = performance.now();
  const logs: ExecutionLog[] = [];
  let returnValue: string | undefined = undefined;
  let errorMessage: string | undefined = undefined;

  // Stripping basic TypeScript types if language is typescript
  let executableCode = code;
  if (language === 'typescript') {
    // Basic regex cleaning for types to execute natively in JS engine:
    // Remove interface/type definitions, class visibility modifiers, simple type annotations
    executableCode = executableCode
      .replace(/:\s*(string|number|boolean|any|void|DLinkedNode|Map<[^>]+>|Array<[^>]+>|\[[^\]]+\]|null|undefined)(\s*\[\])?/g, '')
      .replace(/(public|private|protected|readonly)\s+/g, '')
      .replace(/as\s+[A-Za-z0-9_<>]+/g, '')
      .replace(/export\s+/g, '');
  }

  // Intercept console
  const originalLog = console.log;
  const originalInfo = console.info;
  const originalWarn = console.warn;
  const originalError = console.error;
  const originalTable = console.table;

  const pushLog = (type: ExecutionLog['type'], ...args: any[]) => {
    const formatted = args
      .map((arg) => {
        if (typeof arg === 'object' && arg !== null) {
          try {
            return JSON.stringify(arg, null, 2);
          } catch {
            return String(arg);
          }
        }
        return String(arg);
      })
      .join(' ');

    logs.push({
      type,
      message: formatted,
      timestamp: Date.now(),
    });
  };

  try {
    const sandboxConsole = {
      log: (...args: any[]) => pushLog('log', ...args),
      info: (...args: any[]) => pushLog('info', ...args),
      warn: (...args: any[]) => pushLog('warn', ...args),
      error: (...args: any[]) => pushLog('error', ...args),
      table: (arg: any) => {
        try {
          pushLog('table', JSON.stringify(arg, null, 2));
        } catch {
          pushLog('table', String(arg));
        }
      },
    };

    // Execute within Function scope with replaced console
    const executor = new Function('console', executableCode);
    const result = executor(sandboxConsole);

    if (result !== undefined) {
      try {
        returnValue = typeof result === 'object' ? JSON.stringify(result, null, 2) : String(result);
      } catch {
        returnValue = String(result);
      }
    }
  } catch (err: any) {
    const errorStr = (err && (err.stack || err.message)) ? String(err.stack || err.message) : String(err || 'Execution error');
    errorMessage = errorStr;
    logs.push({
      type: 'error',
      message: errorStr,
      timestamp: Date.now(),
    });
  }

  const durationMs = Math.round((performance.now() - startTime) * 100) / 100;

  return {
    senderId,
    senderName,
    logs,
    returnValue,
    error: errorMessage,
    durationMs,
  };
}
