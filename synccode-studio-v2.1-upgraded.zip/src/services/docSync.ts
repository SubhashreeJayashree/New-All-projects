import { Op, apply, diff, transform, transformIndex } from '../shared/ot';

export interface Outgoing {
  op: Op;
  baseVersion: number;
}

/**
 * Client side of the OT protocol for ONE file (Jupiter-style, one op in flight).
 * - text:       what the user sees (includes unsent edits)
 * - serverText: last known server state, excluding our in-flight op
 * - sentText:   serverText with our in-flight op applied
 * Unsent edits are never stored as ops: they are re-derived as diff(sentText -> text),
 * which keeps this state machine tiny and robust.
 */
export class ClientDoc {
  text: string;
  version: number;
  private serverText: string;
  private sentText: string;
  private inflight: Op | null = null;

  constructor(text: string, version: number) {
    this.text = text;
    this.serverText = text;
    this.sentText = text;
    this.version = version;
  }

  reset(text: string, version: number) {
    this.text = this.serverText = this.sentText = text;
    this.version = version;
    this.inflight = null;
  }

  get hasPending() {
    return this.inflight !== null || this.text !== this.serverText;
  }

  /** User changed the text. Returns an op to send now, or null if one is already in flight. */
  local(newText: string): Outgoing | null {
    this.text = newText;
    return this.flush();
  }

  private flush(): Outgoing | null {
    if (this.inflight) return null;
    const op = diff(this.serverText, this.text);
    if (op.length === 0) return null;
    this.inflight = op;
    this.sentText = this.text;
    return { op, baseVersion: this.version };
  }

  /** Server acknowledged our in-flight op at `version`. May return the next op to send. */
  ack(version: number): Outgoing | null {
    if (!this.inflight) return null;
    this.serverText = this.sentText;
    this.inflight = null;
    this.version = version;
    return this.flush();
  }

  /** A remote op (already transformed by the server up to version-1). Returns the op as applied to `text`. */
  remote(op: Op, version: number): Op {
    // pending unsent edits, relative to what the server will see after our in-flight op
    const pending = diff(this.inflight ? this.sentText : this.serverText, this.text);
    let rOverLocalBase = op;
    if (this.inflight) {
      const [i2, r2] = transform(this.inflight, op, false);
      this.inflight = i2;
      rOverLocalBase = r2;
      this.sentText = apply(this.sentText, r2);
    }
    this.serverText = apply(this.serverText, op);
    const [, rOverText] = transform(pending, rOverLocalBase, false);
    this.text = apply(this.text, rOverText);
    this.version = version;
    return rOverText;
  }

  mapIndex(idx: number, op: Op) {
    return transformIndex(idx, op);
  }
}

/** Holds one ClientDoc per file. */
export class DocManager {
  private docs = new Map<string, ClientDoc>();
  init(files: { id: string; content: string; version?: number }[]) {
    this.docs.clear();
    files.forEach((f) => this.docs.set(f.id, new ClientDoc(f.content, f.version ?? 0)));
  }
  get(id: string) { return this.docs.get(id); }
  ensure(id: string, content = '', version = 0) {
    let d = this.docs.get(id);
    if (!d) { d = new ClientDoc(content, version); this.docs.set(id, d); }
    return d;
  }
  remove(id: string) { this.docs.delete(id); }
}
