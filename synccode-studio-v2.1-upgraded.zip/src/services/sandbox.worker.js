/* Runs inside a Web Worker. Plain JS on purpose (loaded via Vite ?raw). */
(function () {
  var post = self.postMessage.bind(self);
  var MAX_LOGS = 1000, MAX_CHARS = 200000;

  function fmt(v, depth, seen) {
    depth = depth || 0; seen = seen || [];
    var t = typeof v;
    if (v === null) return 'null';
    if (t === 'undefined') return 'undefined';
    if (t === 'string') return depth ? JSON.stringify(v) : v;
    if (t === 'number' || t === 'boolean' || t === 'bigint') return String(v) + (t === 'bigint' ? 'n' : '');
    if (t === 'symbol') return v.toString();
    if (t === 'function') return '[Function' + (v.name ? ': ' + v.name : '') + ']';
    if (v instanceof Error) return depth ? '[' + v.name + ': ' + v.message + ']' : (v.stack || v.name + ': ' + v.message);
    if (seen.indexOf(v) >= 0) return '[Circular]';
    if (depth > 4) return Array.isArray(v) ? '[Array]' : '[Object]';
    seen = seen.concat([v]);
    if (Array.isArray(v) || ArrayBuffer.isView(v)) {
      var arr = Array.prototype.slice.call(v, 0, 100).map(function (x) { return fmt(x, depth + 1, seen); });
      if (v.length > 100) arr.push('… ' + (v.length - 100) + ' more');
      var flat = '[ ' + arr.join(', ') + ' ]';
      if (flat.length <= 80 && flat.indexOf('\n') < 0) return flat;
      return '[\n' + arr.map(function (s) { return '  ' + s.replace(/\n/g, '\n  '); }).join(',\n') + '\n]';
    }
    if (v instanceof Map) return 'Map(' + v.size + ') ' + fmt(Array.from(v.entries()), depth + 1, seen);
    if (v instanceof Set) return 'Set(' + v.size + ') ' + fmt(Array.from(v.values()), depth + 1, seen);
    if (v instanceof Date) return v.toISOString();
    var keys = Object.keys(v);
    var ctor = v.constructor && v.constructor.name && v.constructor.name !== 'Object' ? v.constructor.name + ' ' : '';
    if (!keys.length) return ctor + '{}';
    var parts = keys.slice(0, 50).map(function (k) { return k + ': ' + fmt(v[k], depth + 1, seen); });
    var one = ctor + '{ ' + parts.join(', ') + ' }';
    if (one.length <= 80 && one.indexOf('\n') < 0) return one;
    return ctor + '{\n' + parts.map(function (s) { return '  ' + s.replace(/\n/g, '\n  '); }).join(',\n') + '\n}';
  }

  function deepEqual(a, b) {
    if (Object.is(a, b)) return true;
    if (typeof a !== 'object' || typeof b !== 'object' || !a || !b) return false;
    if (Array.isArray(a) !== Array.isArray(b)) return false;
    if (a instanceof Map && b instanceof Map) return a.size === b.size && Array.from(a).every(function (e) { return b.has(e[0]) && deepEqual(e[1], b.get(e[0])); });
    if (a instanceof Set && b instanceof Set) return a.size === b.size && Array.from(a).every(function (x) { return b.has(x); });
    var ka = Object.keys(a), kb = Object.keys(b);
    if (ka.length !== kb.length) return false;
    return ka.every(function (k) { return Object.prototype.hasOwnProperty.call(b, k) && deepEqual(a[k], b[k]); });
  }

  self.onmessage = function (ev) {
    var d = ev.data;
    var started = performance.now();
    var logs = [], chars = 0, tests = [], queue = [], suite = [], timers = {};
    function push(type, args) {
      if (logs.length >= MAX_LOGS || chars > MAX_CHARS) return;
      var msg = Array.prototype.map.call(args, function (a) { return fmt(a); }).join(' ');
      chars += msg.length;
      logs.push({ type: type, message: msg, timestamp: Date.now() });
    }
    var con = {
      log: function () { push('log', arguments); }, info: function () { push('info', arguments); },
      debug: function () { push('log', arguments); }, warn: function () { push('warn', arguments); },
      error: function () { push('error', arguments); },
      table: function (x) { push('table', [x]); },
      assert: function (c) { if (!c) push('error', ['Assertion failed:'].concat(Array.prototype.slice.call(arguments, 1))); },
      time: function (l) { timers[l || 'default'] = performance.now(); },
      timeEnd: function (l) { l = l || 'default'; if (timers[l] != null) { push('log', [l + ': ' + (performance.now() - timers[l]).toFixed(2) + 'ms']); delete timers[l]; } },
      group: function () { push('log', arguments); }, groupEnd: function () {}
    };

    // ---- minimal jest-like harness ----
    function Fail(msg, exp, act) { this.message = msg; this.expected = exp; this.actual = act; }
    function expect(actual) {
      function build(neg) {
        function check(ok, msg, exp) {
          if (neg ? ok : !ok) throw new Fail((neg ? 'Expected NOT: ' : '') + msg, (neg ? 'not ' : '') + fmt(exp, 1), fmt(actual, 1));
        }
        return {
          toBe: function (e) { check(Object.is(actual, e), 'values are not identical (Object.is)', e); },
          toEqual: function (e) { check(deepEqual(actual, e), 'values are not deeply equal', e); },
          toStrictEqual: function (e) { check(deepEqual(actual, e), 'values are not deeply equal', e); },
          toBeCloseTo: function (e, digits) { digits = digits == null ? 2 : digits; check(Math.abs(actual - e) < Math.pow(10, -digits) / 2, 'not close to ' + e + ' (' + digits + ' digits)', e); },
          toBeTruthy: function () { check(!!actual, 'value is not truthy', 'truthy'); },
          toBeFalsy: function () { check(!actual, 'value is not falsy', 'falsy'); },
          toBeNull: function () { check(actual === null, 'value is not null', null); },
          toBeUndefined: function () { check(actual === undefined, 'value is not undefined', undefined); },
          toBeDefined: function () { check(actual !== undefined, 'value is undefined', 'defined'); },
          toBeNaN: function () { check(Number.isNaN(actual), 'value is not NaN', NaN); },
          toBeGreaterThan: function (e) { check(actual > e, 'not greater than ' + e, '> ' + e); },
          toBeGreaterThanOrEqual: function (e) { check(actual >= e, 'not >= ' + e, '>= ' + e); },
          toBeLessThan: function (e) { check(actual < e, 'not less than ' + e, '< ' + e); },
          toBeLessThanOrEqual: function (e) { check(actual <= e, 'not <= ' + e, '<= ' + e); },
          toContain: function (e) { check(actual != null && (typeof actual === 'string' ? actual.indexOf(e) >= 0 : Array.from(actual).some(function (x) { return deepEqual(x, e); })), 'does not contain value', e); },
          toHaveLength: function (e) { check(actual != null && actual.length === e, 'length differs', e); },
          toMatch: function (re) { check(typeof actual === 'string' && new RegExp(re).test(actual), 'does not match ' + re, String(re)); },
          toThrow: function (m) {
            var thrown = null; try { actual(); } catch (e) { thrown = e; }
            var ok = thrown !== null && (m == null || String(thrown && thrown.message || thrown).indexOf(typeof m === 'string' ? m : '') >= 0 || (m instanceof RegExp && m.test(String(thrown && thrown.message))));
            check(ok, thrown ? 'threw a different error' : 'did not throw', m == null ? 'an error' : String(m));
          }
        };
      }
      var m = build(false); m.not = build(true); return m;
    }
    function test(name, fn) { queue.push({ title: suite.concat([name]).join(' › '), fn: fn }); }
    function describe(name, fn) { suite.push(name); try { fn(); } finally { suite.pop(); } }

    // ---- tiny CommonJS loader over the project's files ----
    var mods = d.modules || {}, cache = {};
    function resolve(spec) {
      var base = spec.replace(/^(\.\.?\/)+/, '').replace(/^.*\//, '');
      var tries = [base, base + '.ts', base + '.tsx', base + '.js', base + '.jsx', base + '.json', base.replace(/\.(ts|tsx|jsx)$/, '.js')];
      for (var i = 0; i < tries.length; i++) if (Object.prototype.hasOwnProperty.call(mods, tries[i])) return tries[i];
      return null;
    }
    function load(name) {
      if (cache[name]) return cache[name].exports;
      var m = { exports: {} }; cache[name] = m;
      var src = mods[name];
      if (/\.json$/.test(name)) { m.exports = JSON.parse(src); return m.exports; }
      var req = function (spec) {
        if (spec.charAt(0) !== '.') throw new Error("Cannot find module '" + spec + "' – npm packages aren't available in the sandbox.");
        var r = resolve(spec); if (!r) throw new Error("Cannot find module '" + spec + "' in the project files.");
        return load(r);
      };
      var fn = new Function('exports', 'require', 'module', 'console', 'test', 'it', 'describe', 'expect', src);
      var ret = fn(m.exports, req, m, con, test, test, describe, expect);
      m._ret = ret;
      return m.exports;
    }

    // block network/side channels for user code
    ['fetch', 'XMLHttpRequest', 'WebSocket', 'EventSource', 'importScripts', 'indexedDB', 'caches'].forEach(function (k) { try { self[k] = undefined; } catch (e) {} });

    var returnValue, error;
    function finish() {
      var testResults = d.mode === 'tests' || tests.length ? tests : undefined;
      post({ type: 'done', logs: logs, testResults: testResults, returnValue: returnValue, error: error, durationMs: Math.round((performance.now() - started) * 100) / 100 });
    }
    function fail(e) {
      error = String(e && (e.stack || e.message) || e);
      logs.push({ type: 'error', message: error, timestamp: Date.now() });
    }
    var chain = Promise.resolve();
    try {
      (d.entries || []).forEach(function (n) {
        load(n);
        var r = cache[n] && cache[n]._ret;
        if (r !== undefined && d.mode !== 'tests') {
          chain = chain.then(function () { return r; }).then(function (v) {
            if (v !== undefined) { try { returnValue = typeof v === 'object' ? fmt(v) : String(v); } catch (e) { returnValue = String(v); } }
          });
        }
      });
    } catch (e) { fail(e); }

    chain.then(function () {
      var p = Promise.resolve();
      queue.forEach(function (t) {
        p = p.then(function () { return t.fn(); }).then(
          function () { tests.push({ passed: true, title: t.title, expected: '', actual: '' }); },
          function (e) {
            var f = e instanceof Fail;
            tests.push({ passed: false, title: t.title, expected: f ? e.expected : '', actual: f ? e.actual : '', error: f ? e.message : String(e && (e.stack || e.message) || e) });
          });
      });
      return p;
    }).catch(fail).then(finish);
  };
})();
