import { CodeFile, ExecutionResult } from '../types';
import jsWorkerSrc from './sandbox.worker.js?raw';
import pyWorkerSrc from './sandbox.python.worker.js?raw';
import { isExternalLanguage, runExternalFile } from './externalRunner';

const makeWorker = (src: string) => {
  const url = URL.createObjectURL(new Blob([src], { type: 'text/javascript' }));
  const w = new Worker(url);
  URL.revokeObjectURL(url);
  return w;
};

export const isTestFile = (name: string) => /\.(test|spec)\.(ts|tsx|js|jsx)$/.test(name);
export const isRunnable = (f: CodeFile) => f.language === 'javascript' || f.language === 'typescript' || f.language === 'python' || isExternalLanguage(f.language);

let pyWorker: Worker | null = null;
let pyReady = false;

function result(base: Partial<ExecutionResult> & { logs?: ExecutionResult['logs'] }, who: { id: string; name: string }, extra: Partial<ExecutionResult>): ExecutionResult {
  return { senderId: who.id, senderName: who.name, logs: base.logs || [], durationMs: 0, ...base, ...extra } as ExecutionResult;
}
const errorResult = (msg: string, who: { id: string; name: string }, extra: Partial<ExecutionResult> = {}) =>
  result({ logs: [{ type: 'error', message: msg, timestamp: Date.now() }], error: msg }, who, extra);

async function transpile(files: CodeFile[]): Promise<{ modules: Record<string, string>; error?: string }> {
  const modules: Record<string, string> = {};
  const toBuild: { name: string; code: string }[] = [];
  for (const f of files) {
    if (f.language === 'json') modules[f.name] = f.content;
    else if (f.language === 'javascript' || f.language === 'typescript') toBuild.push({ name: f.name, code: f.content });
  }
  let res: Response;
  try {
    res = await fetch('/api/transpile', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ files: toBuild }) });
  } catch {
    return { modules, error: 'Could not reach the transpile service. Is the server running?' };
  }
  if (!res.ok) return { modules, error: res.status === 429 ? 'Too many runs – slow down a little.' : 'Transpile service error.' };
  const data = await res.json();
  for (const f of data.files as { name: string; js?: string; error?: string }[]) {
    if (f.error) return { modules, error: f.error };
    modules[f.name] = f.js!;
  }
  return { modules };
}

function runInWorker(worker: Worker, message: any, timeoutMs: number, onStatus?: (s: string) => void): Promise<any> {
  return new Promise((resolve) => {
    let timer: any;
    const arm = (ms: number) => { clearTimeout(timer); timer = setTimeout(() => { worker.terminate(); resolve({ timeout: true }); }, ms); };
    arm(timeoutMs);
    worker.onmessage = (e) => {
      if (e.data?.type === 'status') { onStatus?.(e.data.text); if (/Running/.test(e.data.text)) arm(timeoutMs); return; }
      clearTimeout(timer);
      resolve(e.data);
    };
    worker.onerror = (e) => { clearTimeout(timer); resolve({ crashed: e.message || 'Worker crashed' }); };
    worker.postMessage(message);
  });
}

export async function runProject(
  files: CodeFile[],
  entry: CodeFile,
  mode: 'run' | 'tests',
  who: { id: string; name: string },
  onStatus?: (s: string) => void,
): Promise<ExecutionResult> {
  if (mode === 'run' && isExternalLanguage(entry.language)) return runExternalFile(entry, who, onStatus);

  // ---------- Python ----------
  if (mode === 'run' && entry.language === 'python') {
    if (!pyWorker) { pyWorker = makeWorker(pyWorkerSrc); pyReady = false; }
    const w = pyWorker;
    const out = await runInWorker(w, { code: entry.content }, pyReady ? 20_000 : 120_000, onStatus);
    if (out.timeout || out.crashed) { pyWorker = null; pyReady = false; }
    else pyReady = true;
    if (out.timeout) return errorResult('⏱ Python execution timed out. The runtime was restarted.', who, { language: 'python' });
    if (out.crashed) return errorResult(`Python runtime failed to start: ${out.crashed}. (It loads from cdn.jsdelivr.net – check your connection.)`, who, { language: 'python' });
    return result(out, who, { language: 'python', kind: 'run' });
  }

  // ---------- JS / TS ----------
  const { modules, error } = await transpile(files);
  if (error) return errorResult(error, who, { kind: mode, language: entry.language });

  let entries: string[];
  if (mode === 'tests') {
    entries = files.filter((f) => isTestFile(f.name)).map((f) => f.name);
    if (!entries.length) return errorResult('No test files found. Create a file named like `my_module.test.ts` that uses test() and expect().', who, { kind: 'tests' });
  } else {
    if (entry.language !== 'javascript' && entry.language !== 'typescript') {
      return errorResult(`“${entry.name}” can't be executed. Run a .js/.ts/.py file (HTML is shown in Live Preview).`, who);
    }
    entries = [entry.name];
  }
  const worker = makeWorker(jsWorkerSrc);
  const out = await runInWorker(worker, { modules, entries, mode }, mode === 'tests' ? 15_000 : 8_000);
  worker.terminate();
  if (out.timeout) return errorResult(`⏱ Execution stopped after ${mode === 'tests' ? 15 : 8}s – possible infinite loop.`, who, { kind: mode, language: entry.language });
  if (out.crashed) return errorResult(String(out.crashed), who, { kind: mode, language: entry.language });
  return result(out, who, { kind: mode, language: entry.language });
}
