/* Web Worker hosting Pyodide (Python in WebAssembly). Loaded via Vite ?raw. */
var PYODIDE_VERSION = 'v0.26.4';
var pyodide = null, loading = null, logs = [];

function ensure() {
  if (pyodide) return Promise.resolve(pyodide);
  if (loading) return loading;
  postMessage({ type: 'status', text: 'Downloading Python runtime (first run only, ~10 MB)…' });
  loading = new Promise(function (resolve, reject) {
    try {
      importScripts('https://cdn.jsdelivr.net/pyodide/' + PYODIDE_VERSION + '/full/pyodide.js');
      loadPyodide({ indexURL: 'https://cdn.jsdelivr.net/pyodide/' + PYODIDE_VERSION + '/full/' }).then(function (py) {
        py.setStdout({ batched: function (s) { logs.push({ type: 'log', message: s, timestamp: Date.now() }); } });
        py.setStderr({ batched: function (s) { logs.push({ type: 'error', message: s, timestamp: Date.now() }); } });
        pyodide = py; resolve(py);
      }, reject);
    } catch (e) { reject(e); }
  });
  return loading;
}

onmessage = function (ev) {
  var started = performance.now();
  logs = [];
  ensure().then(function (py) {
    postMessage({ type: 'status', text: 'Running…' });
    return py.loadPackagesFromImports(ev.data.code).then(function () {
      return py.runPythonAsync(ev.data.code);
    });
  }).then(function (result) {
    var rv;
    if (result !== undefined && result !== null) { try { rv = String(result); } catch (e) {} }
    postMessage({ type: 'done', logs: logs, returnValue: rv, durationMs: Math.round((performance.now() - started) * 100) / 100 });
  }).catch(function (e) {
    var msg = String(e && e.message || e);
    logs.push({ type: 'error', message: msg, timestamp: Date.now() });
    postMessage({ type: 'done', logs: logs, error: msg, durationMs: Math.round((performance.now() - started) * 100) / 100 });
  });
};
