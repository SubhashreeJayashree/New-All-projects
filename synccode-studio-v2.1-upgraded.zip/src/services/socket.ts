import { User, ExecutionResult, RemoteCursor } from '../types';
import { Op } from '../shared/ot';

type Handler = (data: any) => void;

class SocketService {
  private ws: WebSocket | null = null;
  private handlers = new Map<string, Set<Handler>>();
  private reconnectTimer: any = null;
  private pingTimer: any = null;
  private attempts = 0;
  private room = '';
  private user: User | null = null;
  private token = '';
  private closedByUs = false;

  public latencyMs = 0;
  public isConnected = false;
  public packetsSent = 0;
  public packetsReceived = 0;

  connect(roomId: string, user: User, token: string) {
    this.room = roomId; this.user = user; this.token = token;
    this.closedByUs = false;
    this.open();
  }

  private open() {
    clearTimeout(this.reconnectTimer);
    if (this.ws) { this.ws.onclose = null; this.ws.close(); }
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${proto}//${location.host}/ws`);
    this.ws = ws;
    ws.onopen = () => {
      this.attempts = 0;
      this.isConnected = true;
      this.emit('connection-status', { connected: true });
      this.send('join-room', { roomId: this.room, user: this.user, token: this.token });
      clearInterval(this.pingTimer);
      this.pingTimer = setInterval(() => this.send('ping', { timestamp: Date.now() }), 4000);
    };
    ws.onmessage = (e) => {
      try {
        const { type, payload } = JSON.parse(e.data);
        this.packetsReceived++;
        if (type === 'pong') {
          this.latencyMs = Math.max(0, Date.now() - (payload.clientTimestamp || Date.now()));
          this.emit('latency-update', { latencyMs: this.latencyMs });
          return;
        }
        this.emit(type, payload);
      } catch (err) { console.error('Bad WS message', err); }
    };
    ws.onclose = () => {
      this.isConnected = false;
      clearInterval(this.pingTimer);
      this.emit('connection-status', { connected: false });
      if (this.closedByUs) return;
      const delay = Math.min(10000, 500 * 2 ** this.attempts++) + Math.random() * 300;
      this.reconnectTimer = setTimeout(() => this.open(), delay);
    };
    ws.onerror = () => { /* onclose handles retry */ };
  }

  disconnect() {
    this.closedByUs = true;
    clearTimeout(this.reconnectTimer);
    clearInterval(this.pingTimer);
    if (this.ws) { this.ws.onclose = null; this.ws.close(); this.ws = null; }
    this.isConnected = false;
  }

  send(type: string, payload: any = {}) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) { this.ws.send(JSON.stringify({ type, payload })); this.packetsSent++; }
  }

  on(event: string, h: Handler) {
    if (!this.handlers.has(event)) this.handlers.set(event, new Set());
    this.handlers.get(event)!.add(h);
    return () => { this.handlers.get(event)?.delete(h); };
  }

  private emit(event: string, data: any) {
    this.handlers.get(event)?.forEach((h) => { try { h(data); } catch (e) { console.error(`handler ${event}`, e); } });
  }

  // ---- typed helpers ----
  sendDocOp(fileId: string, baseVersion: number, op: Op) { this.send('doc-op', { fileId, baseVersion, op }); }
  sendCursor(c: Omit<RemoteCursor, 'userId' | 'userName' | 'userColor'>) { this.send('cursor-move', { cursor: c }); }
  sendFileCreate(name: string, content: string) { this.send('file-create', { file: { name, content } }); }
  sendFileRename(fileId: string, newName: string) { this.send('file-rename', { fileId, newName }); }
  sendFileDelete(fileId: string) { this.send('file-delete', { fileId }); }
  sendFileSelect(fileId: string) { this.send('file-select', { fileId }); }
  sendChat(content: string) { this.send('chat-send', { content }); }
  sendTyping(typing: boolean) { this.send('typing', { typing }); }
  sendWebRTCSignal(targetUserId: string, signal: any) { this.send('webrtc-signal', { targetUserId, signal }); }
  sendWebRTCState(s: { isAudioOn: boolean; isVideoOn: boolean; isScreenSharing: boolean; isSpeaking?: boolean }) { this.send('webrtc-state', s); }
  broadcastExecution(result: ExecutionResult) { this.send('execute-broadcast', { result }); }
  loadChallenge(challengeId: string) { this.send('load-challenge', { challengeId }); }
}

export const socketService = new SocketService();
