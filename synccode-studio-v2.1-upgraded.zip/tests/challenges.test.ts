import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'fs';
import { Worker } from 'node:worker_threads';
import { transform } from 'esbuild';
import { CHALLENGE_PRESETS, STARTER_FILES } from '../src/utils/challengePresets';

const src = fs.readFileSync(new URL('../src/services/sandbox.worker.js', import.meta.url), 'utf8');
const shim = `const {parentPort}=require('worker_threads');globalThis.self=globalThis;globalThis.postMessage=m=>parentPort.postMessage(m);parentPort.on('message',d=>globalThis.onmessage({data:d}));`;

async function runTests(files: typeof STARTER_FILES) {
  const modules: Record<string, string> = {};
  for (const f of files) if (f.language === 'typescript') modules[f.name] = (await transform(f.content, { loader: 'ts', format: 'cjs', target: 'es2020' })).code;
  const entries = files.filter((f) => /\.test\.ts$/.test(f.name)).map((f) => f.name);
  return new Promise<any>((resolve) => {
    const w = new Worker(shim + src, { eval: true });
    w.on('message', (m) => { w.terminate(); resolve(m); });
    w.postMessage({ modules, entries, mode: 'tests' });
  });
}

for (const ch of CHALLENGE_PRESETS) {
  test(`challenge "${ch.title}": shipped starter code passes its own tests`, async () => {
    const out = await runTests(ch.files);
    assert.equal(out.error, undefined);
    assert.ok(out.testResults.length >= 3, 'has tests');
    const failed = out.testResults.filter((t: any) => !t.passed);
    assert.deepEqual(failed, [], JSON.stringify(failed));
  });
}
