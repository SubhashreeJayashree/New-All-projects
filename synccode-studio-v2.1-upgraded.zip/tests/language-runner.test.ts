import assert from 'node:assert/strict';
import { test } from 'node:test';
import { runExternalFile } from '../src/services/externalRunner';
import { CodeFile } from '../src/types';
import { langOf } from '../server/rooms';

const source: CodeFile = {
  id: 'cpp-file',
  name: 'main.cpp',
  language: 'cpp',
  content: '#include <iostream>\nint main() { std::cout << "hello"; }\n',
  updatedAt: Date.now(),
};

test('file extensions resolve to the supported programming languages', () => {
  const cases: Array<[string, string]> = [
    ['main.c', 'c'],
    ['main.h', 'c'],
    ['main.cpp', 'cpp'],
    ['main.cxx', 'cpp'],
    ['Main.java', 'java'],
    ['Program.cs', 'csharp'],
    ['main.go', 'go'],
    ['main.rs', 'rust'],
    ['index.php', 'php'],
    ['main.rb', 'ruby'],
  ];
  for (const [name, language] of cases) assert.equal(langOf(name), language, name);
});

test('external runner resolves a runtime and sends only the selected source file', async () => {
  const calls: Array<{ url: string; init?: RequestInit }> = [];
  const request: typeof fetch = async (input, init) => {
    const url = String(input);
    calls.push({ url, init });
    if (url.endsWith('/runtimes')) {
      return new Response(JSON.stringify([{ language: 'c++', version: '12.2.0', aliases: ['cpp', 'cxx'] }]), { status: 200 });
    }
    return new Response(JSON.stringify({ run: { stdout: 'hello\n', stderr: '', code: 0 } }), { status: 200 });
  };
  const result = await runExternalFile(source, { id: 'user', name: 'Tester' }, undefined, request, 'https://runner.example/api');

  assert.equal(calls.length, 2);
  assert.equal(calls[0].url, 'https://runner.example/api/runtimes');
  assert.equal(calls[1].url, 'https://runner.example/api/execute');
  const sent = JSON.parse(String(calls[1].init?.body));
  assert.deepEqual(sent.files, [{ name: source.name, content: source.content }]);
  assert.equal(sent.language, 'c++');
  assert.equal(result.error, undefined);
  assert.ok(result.logs.some((log) => log.message === 'hello'));
});

test('external runner rejects oversized source without making a network request', async () => {
  let called = false;
  const request: typeof fetch = async () => {
    called = true;
    throw new Error('unexpected request');
  };
  const result = await runExternalFile(
    { ...source, content: 'x'.repeat(100_001) },
    { id: 'user', name: 'Tester' },
    undefined,
    request,
    'https://runner.example/api',
  );

  assert.equal(called, false);
  assert.match(result.error || '', /100,000/);
});

test('external runner reports compilation and runtime failures', async () => {
  const request: typeof fetch = async (input) => String(input).endsWith('/runtimes')
    ? new Response(JSON.stringify([{ language: 'c++', version: '12.2.0', aliases: ['cpp'] }]), { status: 200 })
    : new Response(JSON.stringify({ compile: { stdout: '', stderr: 'missing main', code: 1 } }), { status: 200 });
  const result = await runExternalFile(source, { id: 'user', name: 'Tester' }, undefined, request, 'https://runner.example/api');

  assert.equal(result.error, 'Compilation failed.');
  assert.ok(result.logs.some((log) => log.message.includes('missing main')));
});
