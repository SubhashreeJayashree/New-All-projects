import { test } from 'node:test';
import assert from 'node:assert/strict';
import { apply, diff, transform, transformIndex, validateOp, Op } from '../src/shared/ot';
import { ClientDoc } from '../src/services/docSync';
import { RoomStore } from '../server/rooms';

// deterministic PRNG
function rng(seed: number) {
  return () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 2 ** 32);
}
const ALPHA = 'abcdef \n{}😀é';
function randomEdit(r: () => number, text: string): string {
  const chars = Array.from(text);
  const roll = r();
  const pos = Math.floor(r() * (chars.length + 1));
  if (roll < 0.5 || chars.length === 0) {
    const n = 1 + Math.floor(r() * 4);
    const ins = Array.from({ length: n }, () => Array.from(ALPHA)[Math.floor(r() * Array.from(ALPHA).length)]).join('');
    chars.splice(pos, 0, ...Array.from(ins));
  } else if (roll < 0.85) {
    chars.splice(Math.min(pos, chars.length - 1), 1 + Math.floor(r() * 5));
  } else { // replace
    const n = 1 + Math.floor(r() * 4);
    chars.splice(Math.min(pos, chars.length - 1), n, 'Z', 'Y');
  }
  return chars.join('');
}

test('diff/apply round-trip incl. surrogate pairs', () => {
  const r = rng(7);
  let t = 'hello 😀 world';
  for (let i = 0; i < 2000; i++) {
    const n = randomEdit(r, t);
    assert.equal(apply(t, diff(t, n)), n);
    for (const c of diff(t, n)) { /* no lone surrogates produced */ }
    t = n.length > 200 ? n.slice(0, 50) : n;
  }
});

test('TP1: transform converges for random concurrent ops', () => {
  const r = rng(42);
  for (let i = 0; i < 20000; i++) {
    let base = '';
    for (let k = 0; k < Math.floor(r() * 12); k++) base = randomEdit(r, base);
    const a = diff(base, randomEdit(r, randomEdit(r, base)));
    const b = diff(base, randomEdit(r, randomEdit(r, base)));
    const aFirst = r() < 0.5;
    const [a2, b2] = transform(a, b, aFirst);
    assert.equal(apply(apply(base, b), a2), apply(apply(base, a), b2), JSON.stringify({ base, a, b, aFirst }));
  }
});

test('transformIndex keeps carets sane', () => {
  assert.equal(transformIndex(5, [{ t: 'i', p: 2, s: 'xx' }]), 7);
  assert.equal(transformIndex(5, [{ t: 'i', p: 5, s: 'xx' }]), 5);
  assert.equal(transformIndex(5, [{ t: 'd', p: 2, n: 10 }]), 2);
});

test('validateOp rejects malformed/oob ops', () => {
  assert.ok(validateOp([{ t: 'i', p: 0, s: 'a' }], 0));
  assert.ok(!validateOp([{ t: 'i', p: 1, s: 'a' }], 0));
  assert.ok(!validateOp([{ t: 'd', p: 0, n: 3 }], 2));
  assert.ok(!validateOp([{ t: 'x' }], 2));
  assert.ok(!validateOp('nope', 2));
  assert.ok(!validateOp([{ t: 'i', p: 0, s: '' }], 2));
});

/** Full simulation: N clients + authoritative RoomStore with random per-client latency (FIFO per link). */
function simulate(seed: number, nClients: number, steps: number) {
  const r = rng(seed);
  const store = new RoomStore(null);
  const room = store.getOrCreate('sim');
  const fid = room.files[0].id;
  const init = room.files[0].content;
  const clients = Array.from({ length: nClients }, (_, i) => ({
    id: `u${i}`, doc: new ClientDoc(init, 0),
    toServer: [] as any[], toClient: [] as any[],
  }));
  clients.forEach((c) => store.join(room, { id: c.id, name: c.id, color: '#000000', avatar: 'x', isAudioOn: false, isVideoOn: false, isScreenSharing: false, isSpeaking: false }, 't' + c.id));
  const send = (c: typeof clients[0], out: any) => out && c.toServer.push(out);

  const deliverToServer = (c: typeof clients[0]) => {
    const m = c.toServer.shift();
    const res = store.applyOp(room, c.id, fid, m.baseVersion, m.op);
    assert.ok(res.ok, `server rejected: ${JSON.stringify(res)}`);
    if (!res.ok) return;
    c.toClient.push({ ack: res.version });
    clients.forEach((o) => o !== c && o.toClient.push({ op: res.op, version: res.version }));
  };
  const deliverToClient = (c: typeof clients[0]) => {
    const m = c.toClient.shift();
    if (m.ack !== undefined) send(c, c.doc.ack(m.ack));
    else c.doc.remote(m.op, m.version);
  };

  for (let s = 0; s < steps; s++) {
    const c = clients[Math.floor(r() * nClients)];
    const roll = r();
    if (roll < 0.45) send(c, c.doc.local(randomEdit(r, c.doc.text)));
    else if (roll < 0.72 && c.toServer.length) deliverToServer(c);
    else if (c.toClient.length) deliverToClient(c);
  }
  // drain
  let busy = true;
  while (busy) {
    busy = false;
    for (const c of clients) {
      if (c.toServer.length) { deliverToServer(c); busy = true; }
      if (c.toClient.length) { deliverToClient(c); busy = true; }
    }
  }
  const server = room.files[0].content;
  for (const c of clients) {
    assert.equal(c.doc.text, server, `client ${c.id} diverged (seed ${seed})`);
    assert.ok(!c.doc.hasPending);
  }
}

test('end-to-end convergence: 2-5 clients, random latency', () => {
  for (let seed = 1; seed <= 300; seed++) simulate(seed, 2 + (seed % 4), 120);
});

test('server resyncs clients with stale/future base versions and blocks viewers when locked', () => {
  const store = new RoomStore(null);
  const room = store.getOrCreate('x');
  const fid = room.files[0].id;
  const u = (id: string) => ({ id, name: id, color: '#111111', avatar: 'x', isAudioOn: false, isVideoOn: false, isScreenSharing: false, isSpeaking: false });
  store.join(room, u('host'), 'a');
  store.join(room, u('guest'), 'b');
  assert.equal(room.hostId, 'host');
  assert.equal(store.join(room, u('host'), 'WRONG'), false); // impersonation blocked
  const r1 = store.applyOp(room, 'guest', fid, 99, [{ t: 'i', p: 0, s: 'x' }]);
  assert.deepEqual(r1, { ok: false, reason: 'resync' });
  room.editLocked = true;
  assert.deepEqual(store.applyOp(room, 'guest', fid, 0, [{ t: 'i', p: 0, s: 'x' }]), { ok: false, reason: 'forbidden' });
  assert.ok(store.applyOp(room, 'host', fid, 0, [{ t: 'i', p: 0, s: 'x' }]).ok);
  store.leave(room, 'host');
  assert.equal(room.hostId, 'guest'); // host handover
});
