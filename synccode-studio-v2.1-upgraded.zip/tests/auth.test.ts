import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { test } from 'node:test';
import { AuthStore } from '../server/auth';

test('accounts persist; passwords are hashed and sessions can be revoked', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synccode-auth-'));
  try {
    const store = new AuthStore(dir);
    const account = store.register(' PERSON@example.com ', 'Person', 'correct-horse-battery');
    assert.ok(account);
    assert.notEqual(account.passwordHash, 'correct-horse-battery');
    assert.equal(store.register('person@example.com', 'Other', 'another-password'), null);
    assert.equal(store.login('person@example.com', 'wrong-password'), null);

    const login = store.login('person@example.com', 'correct-horse-battery');
    assert.ok(login);
    assert.equal(store.authenticate(login.token)?.id, account.id);
    assert.equal(store.publicAccount(account).email, 'person@example.com');

    const restarted = new AuthStore(dir);
    assert.equal(restarted.authenticate(login.token)?.id, account.id);
    restarted.revoke(login.token);
    assert.equal(restarted.authenticate(login.token), null);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
