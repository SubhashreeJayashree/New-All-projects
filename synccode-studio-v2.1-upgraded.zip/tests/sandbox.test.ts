import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'fs';
import { Worker } from 'node:worker_threads';
import { transform } from 'esbuild';

const src = fs.readFileSync(new URL('../src/services/sandbox.worker.js', import.meta.url), 'utf8');
const shim = `const {parentPort}=require('worker_threads');globalThis.self=globalThis;globalThis.postMessage=m=>parentPort.postMessage(m);parentPort.on('message',d=>globalThis.onmessage({data:d}));`;

function run(modules: Record<string, string>, entries: string[], mode = 'run', ms = 3000): Promise<any> {
  return new Promise((resolve) => {
    const w = new Worker(shim + src, { eval: true });
    const t = setTimeout(() => { w.terminate(); resolve({ timeout: true }); }, ms);
    w.on('message', (m) => { clearTimeout(t); w.terminate(); resolve(m); });
    w.postMessage({ modules, entries, mode });
  });
}
const cjs = async (code: string, loader: 'ts' | 'js' = 'ts') => (await transform(code, { loader, format: 'cjs', target: 'es2020' })).code;

test('console formatting, return value, errors', async () => {
  const out = await run({ 'a.js': `console.log('hi', {a:1,b:[1,2]}, new Map([[1,2]])); console.warn('w'); return 42;` }, ['a.js']);
  assert.equal(out.logs[0].message, 'hi { a: 1, b: [ 1, 2 ] } Map(1) [ [ 1, 2 ] ]');
  assert.equal(out.logs[1].type, 'warn');
  assert.equal(out.returnValue, '42');
  const bad = await run({ 'a.js': `throw new Error('boom')` }, ['a.js']);
  assert.match(bad.error, /boom/);
});

test('real TS handles the ternary-null case the old regex runner broke, and relative imports', async () => {
  const lib = await cjs(`export const pick = (x: number): number | null => (x > 0 ? x : null);`);
  const main = await cjs(`import { pick } from './lib'; console.log(pick(-1), pick(5));`);
  const out = await run({ 'lib.ts': lib, 'main.ts': main }, ['main.ts']);
  assert.equal(out.error, undefined);
  assert.equal(out.logs[0].message, 'null 5');
});

test('jest-like tests: pass, fail with expected/actual, async, toThrow, not', async () => {
  const code = await cjs(`
    describe('math', () => {
      test('adds', () => expect(1 + 1).toBe(2));
      test('close', () => expect(0.1 + 0.2).toBeCloseTo(0.3));
      test('wrong', () => expect([1, 2]).toEqual([1, 3]));
      test('async', async () => { await Promise.resolve(); expect('abc').toContain('b'); });
      test('throws', () => expect(() => { throw new Error('x'); }).toThrow('x'));
      test('not', () => expect(1).not.toBe(2));
    });`);
  const out = await run({ 't.test.ts': code }, ['t.test.ts'], 'tests');
  const byTitle = Object.fromEntries(out.testResults.map((t: any) => [t.title, t]));
  assert.equal(out.testResults.length, 6);
  assert.equal(byTitle['math › adds'].passed, true);
  assert.equal(byTitle['math › wrong'].passed, false);
  assert.equal(byTitle['math › wrong'].expected, '[ 1, 3 ]');
  assert.equal(byTitle['math › wrong'].actual, '[ 1, 2 ]');
  assert.ok(['math › close', 'math › async', 'math › throws', 'math › not'].every((k) => byTitle[k].passed));
});

test('infinite loop can be killed from outside', async () => {
  const t0 = Date.now();
  const out = await run({ 'a.js': `while(true){}` }, ['a.js'], 'run', 500);
  assert.equal(out.timeout, true);
  assert.ok(Date.now() - t0 < 2500);
});

test('network APIs are blocked in the sandbox', async () => {
  const out = await run({ 'a.js': `console.log(typeof fetch, typeof XMLHttpRequest, typeof WebSocket)` }, ['a.js']);
  assert.equal(out.logs[0].message, 'undefined undefined undefined');
});

test('missing module gives a helpful error', async () => {
  const out = await run({ 'a.js': `require('lodash')` }, ['a.js']);
  assert.match(out.error, /npm packages aren't available/);
});

test('REGRESSION: union types like `prev: Node | null = null` (the old "Unexpected token |" crash)', async () => {
  const code = await cjs(`
    class N { prev: N | null = null; next: N | null = null; v: number | string = 1; }
    const a: Array<N | null> = [new N(), null];
    const f = (x: number | undefined): string => (x ? 'yes' : 'no');
    console.log(a.length, f(1), f(undefined), new N().prev);`);
  const out = await run({ 'x.ts': code }, ['x.ts']);
  assert.equal(out.error, undefined);
  assert.equal(out.logs[0].message, '2 yes no null');
});
