import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { test } from 'node:test';
import { RoomStore } from '../server/rooms';
import { User } from '../src/types';

const user: User = {
  id: 'reviewer',
  name: 'Reviewer',
  color: '#38bdf8',
  avatar: 'R',
  isAudioOn: false,
  isVideoOn: false,
  isScreenSharing: false,
  isSpeaking: false,
};

test('room records replay snapshots for accepted edits', () => {
  const store = new RoomStore(null);
  const room = store.getOrCreate('replay-test');
  store.join(room, user, 'reviewer-token');
  const file = room.files[0];
  const result = store.applyOp(room, user.id, file.id, file.version ?? 0, [{ t: 'i', p: file.content.length, s: '\n// replayed edit' }]);

  assert.equal(result.ok, true);
  assert.equal(room.replayEntries.length, 1);
  assert.match(room.replayEntries[0].content, /replayed edit/);
  assert.equal(room.replayEntries[0].userName, user.name);
  assert.equal('replayEntries' in store.publicState(room), false);
});

test('room replay snapshots and review comments persist across server restarts', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synccode-room-history-'));
  try {
    const store = new RoomStore(dir);
    const room = store.getOrCreate('saved-room');
    store.join(room, user, 'reviewer-token');
    const file = room.files[0];
    store.applyOp(room, user.id, file.id, file.version ?? 0, [{ t: 'i', p: file.content.length, s: '\n// saved edit' }]);
    const comment = store.addReviewComment(room, user, { fileId: file.id, line: 1, content: 'Persist this comment.' });
    assert.ok(comment);
    store.flushAll();

    const restored = new RoomStore(dir).getOrCreate('saved-room');
    assert.equal(restored.replayEntries.length, 1);
    assert.match(restored.replayEntries[0].content, /saved edit/);
    assert.equal(restored.reviewComments[0].content, 'Persist this comment.');
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('review comments validate anchors and restrict resolve/delete to author or host', () => {
  const store = new RoomStore(null);
  const room = store.getOrCreate('review-test');
  store.join(room, user, 'reviewer-token');
  const file = room.files[0];
  const comment = store.addReviewComment(room, user, {
    fileId: file.id,
    line: 1,
    selectedText: 'code',
    content: 'Please clarify this.',
  });

  assert.ok(comment);
  assert.equal(store.addReviewComment(room, user, { fileId: file.id, line: 0, content: 'Invalid line' }), null);
  assert.equal(store.setReviewResolved(room, comment.id, 'another-user', false, true), false);
  assert.equal(store.setReviewResolved(room, comment.id, 'another-user', true, true), true);
  assert.equal(room.reviewComments[0].resolved, true);
  assert.equal(store.deleteReviewComment(room, comment.id, 'another-user', false), false);
  assert.equal(store.deleteReviewComment(room, comment.id, 'another-user', true), true);
  assert.equal(room.reviewComments.length, 0);
});
