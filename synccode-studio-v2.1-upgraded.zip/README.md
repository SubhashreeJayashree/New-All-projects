# SyncCode Studio 2.1 — real-time collaborative IDE + video workspace

Pair-program, interview, or teach in one browser tab: a multi-file editor with live cursors,
code execution (JS / TS / Python locally; additional languages through an opt-in external runner), a Jest-style test runner, P2P video, chat,
a shared whiteboard and a Gemini copilot.

## Quick start

```bash
npm install
cp .env.example .env      # add GEMINI_API_KEY (optional – everything else works without it)
npm run dev               # http://localhost:3000
npm test                  # OT fuzz tests, sandbox tests, challenge tests
```

On Windows, run these commands from PowerShell in the extracted project folder:

```powershell
npm install
npm run dev
```

Open `http://localhost:3000`. To enable Gemini AI, run `Copy-Item .env.example .env`, add your key to `.env`, and restart the server. The editor and code runner work without Gemini.

Open the app, pick a name and room code, and share the invite link (or use **⋯ → Open peer tab**).
The first person in a room is the **host**.

## What's new in 2.1

**Collaboration**
- **Conflict-free editing (Operational Transform).** Previously every keystroke replaced the whole file (last write wins), so simultaneous typing lost text. Edits are now sent as small ops, transformed on the server, and merged. Verified by randomized convergence tests (20,000 concurrent-edit cases + 300 simulated multi-client sessions).
- Your caret stays put when others edit above you; remote **cursors and selections** are scroll-accurate.
- **Follow mode** (click a teammate's avatar), **host controls** (lock editing for guests, host hand-over), **shared interview timer**, **shared whiteboard**.
- Rooms **persist to disk** and survive restarts; auto-reconnect with backoff (editing pauses while offline so nothing is overwritten).
- Lobby with name, room code and camera/mic preview; invite links.
- **Session replay** keeps a bounded timeline of code snapshots; open **⋯ → Session replay** to scrub through recent edits.
- **Inline code review** adds shared line-anchored comments, resolved threads, and author/host controls.
- Optional email/password accounts provide a persistent profile; guests can still enter rooms without signing in.

**Code execution**
- Runs in a **Web Worker** with a hard timeout (an infinite loop no longer freezes the page) and blocked network access.
- Real **TypeScript** via esbuild (the old regex stripper broke on things like `a ? b : null`), and **imports between project files** (`import { x } from './lib'`).
- **Python** via Pyodide (numpy etc. auto-load; first run downloads ~10 MB from jsDelivr).
- **C, C++, Java, C#, Go, Rust, PHP, and Ruby** via the optional Piston runner. Click Run and approve the privacy prompt; only the active file is sent.
- Built-in **`test` / `describe` / `expect`** and a **Run Tests** button; the 3 GenAI challenges now ship with tests.
- Create a file with its source extension (for example `main.c`, `Main.java`, `main.go`, or `script.rb`), then press **Run** or **Ctrl+Enter**. JavaScript, TypeScript, and Python run locally. C, C++, Java, C#, Go, Rust, PHP, and Ruby use the Piston API after an explicit privacy confirmation; only the active file is sent. Override its base URL with `VITE_CODE_RUNNER_URL`.

**Editor**
- Auto-close brackets/quotes, smart Enter, multi-line Tab/Shift+Tab, `Ctrl+/` comment, `Alt+↑/↓` move line, `Alt+Shift+↑/↓` duplicate, find & replace (`Ctrl+F`), font size, drag-and-drop file import, download file / whole project as `.zip`.
- **Command palette** (`Ctrl/⌘+K`): run, go to file, follow user, load challenge, …

**AI**
- Streaming responses, Markdown rendering, **Apply / New file** buttons on generated code, new *Write tests* and *Code review* actions, optional whole-project context. `@ai` in chat now sees your open file.

**Video & chat**
- Working spotlight/pin, reactions, raise hand, camera/mic picker, optional TURN server, typing indicators, unread badge, code blocks in chat.

**Security & robustness**
- Removed a hard-coded API key fallback from `server.ts` (**rotate any key that was in your old copy**).
- Server no longer trusts client identity: names/colors sanitized, chat sender set server-side (no spoofing `@ai`), per-user secret token prevents impersonation, host-only actions enforced.
- Payload limits, per-socket and per-IP rate limits, file-size/count caps, WebSocket on `/ws`.
- Fixed a WebRTC listener leak and a frozen placeholder video feed.

## Keyboard shortcuts
| Keys | Action |
|---|---|
| `Ctrl/⌘ + Enter` | Run current file |
| `Ctrl/⌘ + K` | Command palette |
| `Ctrl/⌘ + F` | Find / replace |
| `Ctrl/⌘ + /` | Toggle comment |
| `Alt + ↑/↓` | Move line(s) · add `Shift` to duplicate |
| `Tab / Shift+Tab` | Indent / outdent (multi-line aware) |

## Architecture
```
server.ts            Express + WebSocket (/ws), AI + transpile endpoints
server/auth.ts       Hashed-password accounts and HttpOnly login sessions
server/rooms.ts      Authoritative room state, OT apply/transform, persistence, permissions (unit-tested)
server/ai.ts         Gemini prompts, streaming, model fallback
src/shared/ot.ts     Text OT: apply / diff / transform (shared by server and browser)
src/services/docSync.ts   Client-side OT state machine (one op in flight per file)
src/services/sandbox*.js  Local worker runtimes; externalRunner.ts runs opt-in Piston jobs
src/components/Reviews/   Session replay and shared line-anchored review comments
tests/               node:test suites
```

## Configuration
See `.env.example`. Notes:
- Without `GEMINI_API_KEY` everything works except AI features (a clear message is shown).
- Behind strict NAT/firewalls, video needs a TURN relay (`VITE_TURN_*`).
- WebRTC uses a full mesh — great for ≤ 6 people; use an SFU for larger rooms.
- `GEMINI_MODELS` overrides the model fallback list.
- Account hashes and login sessions are saved under `data/auth` by default; use `AUTH_DATA_DIR` to move them. Use HTTPS when exposing sign-in beyond localhost.

## Known limitations
- Undo/redo is the browser's native textarea history; after a collaborator's edit the history may reset.
- Execution is client-side (each person runs their own copy; the result is broadcast). It's a convenience sandbox, not a hardened one — results shared to the room are self-reported.
- Top-level `await` works only in files without `import`/`export`.
- Rooms are held in one server process; scaling horizontally would need a shared store.
