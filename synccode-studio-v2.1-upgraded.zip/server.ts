import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import { transform as esbuildTransform } from 'esbuild';
import { ChatMessage, User } from './src/types';
import { CHALLENGE_PRESETS } from './src/utils/challengePresets';
import { RoomStore, ServerRoom, ROOM_ID_RE, sanitizeUser, sanitizeName } from './server/rooms';
import { Bucket, KeyedLimiter } from './server/security';
import { AuthStore } from './server/auth';
import { generate, generateStream, buildPrompt, SYSTEM, COPILOT_ROLE, aiConfigured, NOT_CONFIGURED } from './server/ai';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR === 'off' ? null : path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data', 'rooms'));
const AUTH_DATA_DIR = path.resolve(process.env.AUTH_DATA_DIR || path.join(__dirname, 'data', 'auth'));

const app = express();
app.disable('x-powered-by');
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 2 * 1024 * 1024 });
const store = new RoomStore(DATA_DIR);
const authStore = new AuthStore(AUTH_DATA_DIR);

interface Meta { roomId: string; userId: string; user: User; bucket: Bucket; chat: Bucket; ai: Bucket; ip: string }
const clients = new Map<WebSocket, Meta>();

const send = (ws: WebSocket, type: string, payload: any) => {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type, payload }));
};
function broadcast(roomId: string, type: string, payload: any, except?: WebSocket) {
  const data = JSON.stringify({ type, payload });
  for (const [ws, m] of clients) if (m.roomId === roomId && ws !== except && ws.readyState === WebSocket.OPEN) ws.send(data);
}
function sendToUser(roomId: string, userId: string, type: string, payload: any) {
  for (const [ws, m] of clients) if (m.roomId === roomId && m.userId === userId) { send(ws, type, payload); return; }
}
function systemMsg(room: ServerRoom, content: string, color = '#10b981') {
  const msg: ChatMessage = { id: `sys-${crypto.randomUUID()}`, userId: 'system', userName: 'System', userColor: color, content, timestamp: Date.now(), type: 'system' };
  store.addMessage(room, msg);
  broadcast(room.roomId, 'chat-broadcast', { message: msg });
}
const isInt = (n: any) => Number.isInteger(n) && Math.abs(n) < 1e9;

function aiChatReply(room: ServerRoom, meta: Meta, prompt: string) {
  const active = room.files.find((f) => f.id === room.activeFileId);
  const ctx = active ? `\n\nActive file "${active.name}":\n\`\`\`\n${active.content.slice(0, 15000)}\n\`\`\`` : '';
  broadcast(room.roomId, 'ai-typing', { typing: true });
  generate(`${prompt.slice(0, 2000)}${ctx}`, SYSTEM('You are Gemini Copilot in a collaborative coding chat. Be concise (a few sentences or a short snippet) and mathematically clear.'))
    .catch((e) => (e?.message === NOT_CONFIGURED || !aiConfigured ? NOT_CONFIGURED : 'Sorry, I could not reach Gemini right now.'))
    .then((text) => {
      const reply: ChatMessage = { id: `ai-${crypto.randomUUID()}`, userId: 'ai-copilot', userName: 'Gemini Copilot 🤖', userColor: '#38bdf8', content: text, timestamp: Date.now(), type: 'text' };
      store.addMessage(room, reply);
      broadcast(room.roomId, 'ai-typing', { typing: false });
      broadcast(room.roomId, 'chat-broadcast', { message: reply });
    });
}

wss.on('connection', (ws, req) => {
  const ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  const bucket = new Bucket(200, 120);

  ws.on('message', (raw) => {
    let msg: any;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    const { type, payload } = msg || {};
    if (typeof type !== 'string' || typeof payload !== 'object' || payload === null) return;
    if (!bucket.take()) return; // flood protection: silently drop

    if (type === 'ping') return send(ws, 'pong', { clientTimestamp: Number(payload.timestamp) || 0, serverTimestamp: Date.now() });

    if (type === 'join-room') {
      const roomId = String(payload.roomId || '');
      const uid = String(payload.user?.id || '');
      const token = String(payload.token || '');
      if (!ROOM_ID_RE.test(roomId) || !/^[\w-]{8,64}$/.test(uid) || token.length < 16) return send(ws, 'join-error', { reason: 'Invalid room or identity.' });
      const room = store.getOrCreate(roomId);
      const user = sanitizeUser(payload.user, uid);
      if (!store.join(room, user, token)) return send(ws, 'join-error', { reason: 'That identity is already in use in this room.' });
      // replace a stale socket of the same user (page reload / reconnect)
      for (const [other, m] of clients) if (m.roomId === roomId && m.userId === uid && other !== ws) { clients.delete(other); other.close(); }
      const stored = room.users.find((u) => u.id === uid)!;
      clients.set(ws, { roomId, userId: uid, user: stored, bucket, chat: new Bucket(5, 1), ai: new Bucket(4, 4 / 60), ip });
      send(ws, 'room-init', { roomState: store.publicState(room), yourId: uid });
      broadcast(roomId, 'user-joined', { user: stored, users: room.users }, ws);
      broadcast(roomId, 'host-changed', { hostId: room.hostId, users: room.users }, ws);
      systemMsg(room, `${stored.name} joined the session.`);
      return;
    }

    const meta = clients.get(ws);
    if (!meta) return;
    const room = store.rooms.get(meta.roomId);
    if (!room) return;
    const me = meta.userId;
    const isHost = room.hostId === me;
    const canEdit = store.canEdit(room, me);
    const notice = (text: string) => send(ws, 'notice', { text });

    switch (type) {
      case 'webrtc-signal': {
        if (typeof payload.targetUserId === 'string') sendToUser(meta.roomId, payload.targetUserId, 'webrtc-signal', { targetUserId: payload.targetUserId, senderId: me, signal: payload.signal });
        break;
      }
      case 'webrtc-state': {
        const u = room.users.find((x) => x.id === me);
        if (u) {
          u.isAudioOn = !!payload.isAudioOn; u.isVideoOn = !!payload.isVideoOn;
          u.isScreenSharing = !!payload.isScreenSharing; u.isSpeaking = !!payload.isSpeaking;
        }
        broadcast(meta.roomId, 'user-media-state', { userId: me, isAudioOn: !!payload.isAudioOn, isVideoOn: !!payload.isVideoOn, isScreenSharing: !!payload.isScreenSharing, isSpeaking: !!payload.isSpeaking }, ws);
        break;
      }
      case 'hand-toggle': {
        const u = room.users.find((x) => x.id === me);
        if (u) { u.isHandRaised = !u.isHandRaised; broadcast(meta.roomId, 'user-media-state', { userId: me, isHandRaised: u.isHandRaised }); }
        break;
      }
      case 'reaction': {
        const emoji = String(payload.emoji || '');
        if (['👍', '👏', '😂', '🎉', '❤️', '🤔'].includes(emoji)) broadcast(meta.roomId, 'reaction', { userId: me, emoji });
        break;
      }
      case 'doc-op': {
        const res = store.applyOp(room, me, String(payload.fileId), payload.baseVersion, payload.op);
        if (res.ok) {
          send(ws, 'doc-ack', { fileId: payload.fileId, version: res.version });
          broadcast(meta.roomId, 'doc-op', { fileId: payload.fileId, op: res.op, version: res.version, senderId: me }, ws);
        } else {
          const reason = (res as { reason?: string }).reason;
          if (reason === 'forbidden') notice('The host has locked editing.');
          if (reason === 'toolarge') notice('File is too large.');
          const f = room.files.find((x) => x.id === payload.fileId);
          if (f) send(ws, 'doc-resync', { fileId: f.id, content: f.content, version: f.version ?? 0 });
        }
        break;
      }
      case 'history-request': {
        const activeFile = room.files.find((file) => file.id === room.activeFileId);
        if (activeFile && store.recordSnapshot(room, activeFile, me)) store.scheduleSave(room);
        send(ws, 'session-history', { entries: room.replayEntries });
        break;
      }
      case 'review-add': {
        const comment = store.addReviewComment(room, meta.user, payload.comment);
        if (!comment) return notice('Could not add review comment. Check the file, line, and comment length.');
        broadcast(meta.roomId, 'review-comments', { comments: room.reviewComments });
        break;
      }
      case 'review-resolve': {
        if (!store.setReviewResolved(room, String(payload.commentId), me, isHost, !!payload.resolved)) return notice('You can only resolve your own comments unless you are the host.');
        broadcast(meta.roomId, 'review-comments', { comments: room.reviewComments });
        break;
      }
      case 'review-delete': {
        if (!store.deleteReviewComment(room, String(payload.commentId), me, isHost)) return notice('You can only delete your own comments unless you are the host.');
        broadcast(meta.roomId, 'review-comments', { comments: room.reviewComments });
        break;
      }
      case 'cursor-move': {
        const c = payload.cursor || {};
        if (typeof c.fileId === 'string' && isInt(c.offset) && isInt(c.selStart) && isInt(c.selEnd)) {
          broadcast(meta.roomId, 'cursor-update', { cursor: { userId: me, userName: meta.user.name, userColor: meta.user.color, fileId: c.fileId, offset: c.offset, selStart: c.selStart, selEnd: c.selEnd } }, ws);
        }
        break;
      }
      case 'file-create': {
        if (!canEdit) return notice('Editing is locked by the host.');
        const f = store.addFile(room, payload.file);
        if (!f) return notice('Could not create file (invalid or duplicate name, or file limit reached).');
        broadcast(meta.roomId, 'file-create', { file: f, senderId: me });
        break;
      }
      case 'file-rename': {
        if (!canEdit) return notice('Editing is locked by the host.');
        const f = store.renameFile(room, String(payload.fileId), payload.newName);
        if (!f) return notice('Could not rename file (invalid or duplicate name).');
        broadcast(meta.roomId, 'file-rename', { fileId: f.id, newName: f.name, language: f.language });
        break;
      }
      case 'file-delete': {
        if (!canEdit) return notice('Editing is locked by the host.');
        if (!store.deleteFile(room, String(payload.fileId))) return notice('Cannot delete that file.');
        broadcast(meta.roomId, 'file-delete', { fileId: payload.fileId, activeFileId: room.activeFileId });
        break;
      }
      case 'file-select': {
        if (room.files.some((f) => f.id === payload.fileId)) {
          room.activeFileId = payload.fileId;
          broadcast(meta.roomId, 'file-select', { fileId: payload.fileId, senderId: me }, ws);
        }
        break;
      }
      case 'chat-send': {
        if (!meta.chat.take()) return notice('Slow down a little.');
        const content = String(payload.content ?? payload.message?.content ?? '').slice(0, 4000).trim();
        if (!content) break;
        const m: ChatMessage = { id: `msg-${crypto.randomUUID()}`, userId: me, userName: meta.user.name, userColor: meta.user.color, content, timestamp: Date.now(), type: 'text' };
        store.addMessage(room, m);
        broadcast(meta.roomId, 'chat-broadcast', { message: m });
        const mention = content.match(/^@(ai|gemini)\b\s*([\s\S]*)$/i);
        if (mention) {
          if (!meta.ai.take()) return notice('AI limit reached (4 per minute). Try again shortly.');
          aiChatReply(room, meta, mention[2].trim() || 'Hello! How can you help with this workspace?');
        }
        break;
      }
      case 'typing':
        broadcast(meta.roomId, 'typing', { userId: me, userName: meta.user.name, typing: !!payload.typing }, ws);
        break;
      case 'execute-broadcast': {
        const r = payload.result;
        if (!r || !Array.isArray(r.logs)) break;
        const result = {
          senderId: me, senderName: meta.user.name,
          logs: r.logs.slice(0, 500).map((l: any) => ({ type: ['log', 'info', 'warn', 'error', 'table'].includes(l?.type) ? l.type : 'log', message: String(l?.message ?? '').slice(0, 5000), timestamp: Number(l?.timestamp) || Date.now() })),
          returnValue: r.returnValue === undefined ? undefined : String(r.returnValue).slice(0, 5000),
          error: r.error === undefined ? undefined : String(r.error).slice(0, 5000),
          durationMs: Number(r.durationMs) || 0,
          kind: r.kind === 'tests' ? 'tests' : 'run',
          language: typeof r.language === 'string' ? r.language.slice(0, 20) : undefined,
          testResults: Array.isArray(r.testResults) ? r.testResults.slice(0, 200).map((t: any) => ({ passed: !!t?.passed, title: String(t?.title ?? '').slice(0, 200), expected: String(t?.expected ?? '').slice(0, 500), actual: String(t?.actual ?? '').slice(0, 500), error: t?.error ? String(t.error).slice(0, 1000) : undefined })) : undefined,
        };
        room.lastExecution = result as any;
        broadcast(meta.roomId, 'execute-broadcast', { result }, ws);
        break;
      }
      case 'load-challenge': {
        if (!isHost) return notice('Only the host can load a challenge.');
        const ch = CHALLENGE_PRESETS.find((c) => c.id === payload.challengeId);
        if (!ch) break;
        room.challenge = ch;
        store.loadFiles(room, ch.files);
        broadcast(meta.roomId, 'load-challenge', { challenge: ch, files: room.files, activeFileId: room.activeFileId });
        systemMsg(room, `${meta.user.name} loaded challenge “${ch.title}”.`, '#f59e0b');
        break;
      }
      case 'room-lock': {
        if (!isHost) return notice('Only the host can lock editing.');
        room.editLocked = !!payload.locked;
        broadcast(meta.roomId, 'room-lock', { locked: room.editLocked });
        systemMsg(room, room.editLocked ? 'The host locked editing (read-only for guests).' : 'The host unlocked editing.', '#f59e0b');
        break;
      }
      case 'timer-action': {
        if (!isHost) return notice('Only the host controls the timer.');
        const t = store.timerAction(room, String(payload.action), Number(payload.durationMs));
        broadcast(meta.roomId, 'timer-update', { timer: { ...t, at: Date.now() } });
        break;
      }
      case 'board-points': {
        const s = store.addStrokePoints(room, me, meta.user.color, String(payload.id), Number(payload.size), payload.pts);
        if (s) broadcast(meta.roomId, 'board-points', { id: s.id, userId: me, color: s.color, size: s.size, pts: payload.pts.map(Math.round) }, ws);
        break;
      }
      case 'board-undo':
        if (store.undoStroke(room, me, String(payload.id))) broadcast(meta.roomId, 'board-undo', { id: payload.id });
        break;
      case 'board-clear':
        if (!canEdit) return notice('Whiteboard is locked by the host.');
        room.strokes = [];
        broadcast(meta.roomId, 'board-clear', {});
        break;
    }
  });

  ws.on('close', () => {
    const meta = clients.get(ws);
    if (!meta) return;
    clients.delete(ws);
    const room = store.rooms.get(meta.roomId);
    if (!room) return;
    const hostBefore = room.hostId;
    store.leave(room, meta.userId);
    broadcast(meta.roomId, 'user-left', { userId: meta.userId, userName: meta.user.name, users: room.users });
    if (room.hostId !== hostBefore && room.hostId) {
      broadcast(meta.roomId, 'host-changed', { hostId: room.hostId, users: room.users });
      systemMsg(room, `${room.users.find((u) => u.id === room.hostId)?.name} is now the host.`, '#f59e0b');
    }
    systemMsg(room, `${meta.user.name} left the room.`, '#f43f5e');
  });
});

// ---------------- HTTP ----------------
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  next();
});
app.use(express.json({ limit: '1mb' }));
app.use('/api/auth', (_req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
});

const httpLimiter = new KeyedLimiter(30, 0.5);
const authLimiter = new KeyedLimiter(8, 8 / 60);
const aiLimiter = new KeyedLimiter(8, 8 / 60);
const ipOf = (req: express.Request) => req.ip || req.socket.remoteAddress || 'x';
const AUTH_COOKIE = 'synccode_session';
const AUTH_SESSION_SECONDS = 30 * 24 * 60 * 60;
function requestAuthToken(req: express.Request): string | undefined {
  const cookie = req.headers.cookie?.split(';').map((part) => part.trim()).find((part) => part.startsWith(`${AUTH_COOKIE}=`));
  return cookie?.slice(AUTH_COOKIE.length + 1);
}
function setAuthCookie(req: express.Request, res: express.Response, token: string | null) {
  const forwardedProto = req.get('x-forwarded-proto')?.split(',')[0].trim();
  const secure = req.secure || forwardedProto === 'https' ? '; Secure' : '';
  const value = token ? `${AUTH_COOKIE}=${encodeURIComponent(token)}; Max-Age=${AUTH_SESSION_SECONDS}` : `${AUTH_COOKIE}=; Max-Age=0`;
  res.setHeader('Set-Cookie', `${value}; Path=/; HttpOnly; SameSite=Lax${secure}`);
}

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', roomsActive: store.rooms.size, clientsConnected: clients.size, aiConfigured, persistence: !!DATA_DIR, timestamp: Date.now() });
});

app.get('/api/auth/me', (req, res) => {
  const account = authStore.authenticate(requestAuthToken(req));
  res.json({ account: account ? authStore.publicAccount(account) : null });
});

app.post('/api/auth/register', (req, res) => {
  if (!authLimiter.allow(ipOf(req))) return res.status(429).json({ error: 'Too many account requests. Please wait a moment.' });
  const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  if (!/^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/.test(email) || !name || name.length > 32 || password.length < 10 || password.length > 128) {
    return res.status(400).json({ error: 'Enter a valid email, a display name (up to 32 characters), and a password from 10 to 128 characters.' });
  }
  const account = authStore.register(email, name, password);
  if (!account) return res.status(409).json({ error: 'An account with that email already exists.' });
  const login = authStore.login(email, password);
  if (!login) return res.status(500).json({ error: 'Could not create an account session.' });
  setAuthCookie(req, res, login.token);
  res.status(201).json({ account: authStore.publicAccount(account) });
});

app.post('/api/auth/login', (req, res) => {
  if (!authLimiter.allow(ipOf(req))) return res.status(429).json({ error: 'Too many account requests. Please wait a moment.' });
  const email = typeof req.body?.email === 'string' ? req.body.email : '';
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  if (email.length > 320 || password.length > 128) return res.status(400).json({ error: 'Email or password is invalid.' });
  const login = authStore.login(email, password);
  if (!login) return res.status(401).json({ error: 'Email or password is incorrect.' });
  setAuthCookie(req, res, login.token);
  res.json({ account: authStore.publicAccount(login.account) });
});

app.post('/api/auth/logout', (req, res) => {
  authStore.revoke(requestAuthToken(req));
  setAuthCookie(req, res, null);
  res.status(204).end();
});

/** TS/JS → CommonJS using esbuild (replaces the old regex type-stripping). */
app.post('/api/transpile', async (req, res) => {
  if (!httpLimiter.allow(ipOf(req))) return res.status(429).json({ error: 'Too many requests' });
  const files: { name: string; code: string }[] = Array.isArray(req.body?.files) ? req.body.files.slice(0, 40) : [];
  let total = 0;
  const out = await Promise.all(files.map(async (f) => {
    const name = String(f?.name || '');
    const code = String(f?.code ?? '');
    total += code.length;
    if (total > 2_000_000) return { name, error: 'Project too large' };
    const loader = /\.tsx$/.test(name) ? 'tsx' : /\.ts$/.test(name) ? 'ts' : /\.jsx$/.test(name) ? 'jsx' : 'js';
    const run = (src: string) => esbuildTransform(src, { loader, format: 'cjs', target: 'es2020', sourcefile: name, logLevel: 'silent' });
    try {
      return { name, js: (await run(code)).code };
    } catch (e: any) {
      // top-level await isn't allowed in CJS: retry wrapped in an async IIFE (works when there are no imports/exports)
      if (/top-level await/i.test(String(e?.message))) {
        try { return { name, js: (await run(`(async () => {\n${code}\n})();`)).code }; } catch (e2: any) { e = e2; }
      }
      const first = e?.errors?.[0];
      return { name, error: first ? `${name}:${first.location?.line ?? '?'}:${first.location?.column ?? '?'} ${first.text}` : String(e?.message || e) };
    }
  }));
  res.json({ files: out });
});

app.post('/api/ai/copilot', async (req, res) => {
  if (!aiLimiter.allow(ipOf(req))) return res.status(429).json({ error: 'AI rate limit reached. Please wait a moment.' });
  if (!aiConfigured) return res.status(503).json({ error: NOT_CONFIGURED, fallbackText: NOT_CONFIGURED });
  const prompt = buildPrompt(req.body || {});
  const sys = SYSTEM(COPILOT_ROLE);
  if (req.body?.stream) {
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('X-Accel-Buffering', 'no');
    try {
      for await (const chunk of generateStream(prompt, sys)) res.write(chunk);
    } catch (e: any) {
      console.warn('stream error', e?.message || e);
      res.write('\n\n⚠️ The AI request failed. Please try again.');
    }
    return res.end();
  }
  try {
    res.json({ text: await generate(prompt, sys), action: req.body?.action, timestamp: Date.now() });
  } catch (e: any) {
    console.warn('copilot error', e?.message || e);
    res.status(502).json({ error: 'The AI request failed.', fallbackText: 'Unable to reach Gemini right now. Please try again.' });
  }
});

async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: 'spa' });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => res.sendFile(path.resolve(__dirname, 'dist', 'index.html')));
  }
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`SyncCode Studio → http://localhost:${PORT}  (AI: ${aiConfigured ? 'on' : 'OFF – set GEMINI_API_KEY'}, persistence: ${DATA_DIR ?? 'off'})`);
  });
  (setInterval(() => store.sweep(), 10 * 60_000) as any).unref?.();
}
const shutdown = () => { store.flushAll(); process.exit(0); };
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
start();
