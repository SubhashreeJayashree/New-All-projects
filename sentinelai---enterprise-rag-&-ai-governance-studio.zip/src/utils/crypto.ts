import { AuditBlock } from '../types';

/**
 * Computes SHA-256 hash string for an arbitrary input string.
 * Uses native browser Web Crypto API.
 */
export async function sha256(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Creates a sealed hash-chained block.
 */
export async function createSealedBlock(
  index: number,
  actor: string,
  role: string,
  action: string,
  querySummary: string,
  clearanceLevel: number,
  guardrailStatus: 'PASSED' | 'BLOCKED' | 'FLAGGED',
  prevHash: string
): Promise<AuditBlock> {
  const timestamp = new Date().toISOString();
  const payloadString = `${index}|${timestamp}|${actor}|${role}|${action}|${querySummary}|${clearanceLevel}|${guardrailStatus}`;
  const payloadHash = await sha256(payloadString);
  const blockHash = await sha256(`${prevHash}:${payloadHash}:${index}`);

  return {
    index,
    timestamp,
    actor,
    role,
    action,
    querySummary,
    clearanceLevel,
    guardrailStatus,
    payloadHash,
    prevHash,
    blockHash
  };
}

/**
 * Verifies the integrity of a hash-chained ledger.
 * Returns { isValid, brokenIndex, details }.
 */
export async function verifyAuditChain(chain: AuditBlock[]): Promise<{
  isValid: boolean;
  brokenIndex?: number;
  details: string;
}> {
  if (!chain || chain.length === 0) {
    return { isValid: true, details: 'Chain is empty.' };
  }

  for (let i = 0; i < chain.length; i++) {
    const block = chain[i];

    // Check previous hash linkage (except genesis block)
    if (i > 0) {
      const prevBlock = chain[i - 1];
      if (block.prevHash !== prevBlock.blockHash) {
        return {
          isValid: false,
          brokenIndex: block.index,
          details: `Broken hash chain at block #${block.index}: prevHash (${block.prevHash.slice(0, 10)}...) does not match block #${prevBlock.index} hash (${prevBlock.blockHash.slice(0, 10)}...).`
        };
      }
    }

    // Recalculate payload hash
    const payloadString = `${block.index}|${block.timestamp}|${block.actor}|${block.role}|${block.action}|${block.querySummary}|${block.clearanceLevel}|${block.guardrailStatus}`;
    const calculatedPayloadHash = await sha256(payloadString);

    if (calculatedPayloadHash !== block.payloadHash) {
      return {
        isValid: false,
        brokenIndex: block.index,
        details: `Tampered payload detected at block #${block.index}! Payload hash mismatch.`
      };
    }

    // Recalculate block hash
    const calculatedBlockHash = await sha256(`${block.prevHash}:${calculatedPayloadHash}:${block.index}`);
    if (calculatedBlockHash !== block.blockHash) {
      return {
        isValid: false,
        brokenIndex: block.index,
        details: `Cryptographic fingerprint mismatch at block #${block.index}! Block was altered after sealing.`
      };
    }
  }

  return {
    isValid: true,
    details: `All ${chain.length} blocks verified against SHA-256 cryptographic root. Ledger is tamper-free and immutable.`
  };
}
