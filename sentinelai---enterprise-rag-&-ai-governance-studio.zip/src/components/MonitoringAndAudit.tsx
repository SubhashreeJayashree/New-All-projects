import React, { useState } from 'react';
import {
  Activity,
  ShieldCheck,
  ShieldAlert,
  Lock,
  Download,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Hash,
  RefreshCw,
  FileCheck2,
  Bug
} from 'lucide-react';
import { AuditBlock, UserRole } from '../types';
import { verifyAuditChain } from '../utils/crypto';

interface MonitoringAndAuditProps {
  activeRole: UserRole;
  auditChain: AuditBlock[];
  setAuditChain: React.Dispatch<React.SetStateAction<AuditBlock[]>>;
}

export const MonitoringAndAudit: React.FC<MonitoringAndAuditProps> = ({
  activeRole,
  auditChain,
  setAuditChain
}) => {
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<{
    isValid: boolean;
    brokenIndex?: number;
    details: string;
  } | null>(null);

  const [filterAction, setFilterAction] = useState<string>('all');

  const handleVerifyChain = async () => {
    setIsVerifying(true);
    setVerificationResult(null);

    // Simulate verification delay for visual feedback
    setTimeout(async () => {
      const result = await verifyAuditChain(auditChain);
      setVerificationResult(result);
      setIsVerifying(false);
    }, 600);
  };

  const handleSimulateTampering = () => {
    if (auditChain.length <= 1) return;
    setAuditChain(prev => {
      const cloned = [...prev];
      // Intentionally tamper payload summary of block #1
      cloned[1] = {
        ...cloned[1],
        querySummary: 'TAMPERED DATA: Unauthorized modification by insider threat',
        isTampered: true
      };
      return cloned;
    });
    setVerificationResult(null);
  };

  const handleRestoreChain = () => {
    setAuditChain(prev => {
      const cloned = [...prev];
      if (cloned.length > 1) {
        cloned[1] = {
          ...cloned[1],
          querySummary: 'Attempted access to Project Titan M&A Valuation ($420M)',
          isTampered: false
        };
      }
      return cloned;
    });
    setVerificationResult(null);
  };

  const handleExportAuditJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(auditChain, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `sentinel_audit_ledger_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleExportAuditCSV = () => {
    // Generate RFC 4180 compliant CSV format for compliance reporting
    const headers = [
      'Block Index',
      'Timestamp (UTC)',
      'Actor',
      'Role',
      'Clearance Level',
      'Action Taken',
      'Guardrail Status',
      'Query Summary',
      'Payload Hash (SHA-256)',
      'Previous Hash (SHA-256)',
      'Block Hash (SHA-256)',
      'Tampered Flag'
    ];

    const escapeCsvField = (field: string | number | boolean | undefined | null): string => {
      if (field === null || field === undefined) return '""';
      const str = String(field);
      // Escape double quotes by doubling them
      const escaped = str.replace(/"/g, '""');
      return `"${escaped}"`;
    };

    const rows = auditChain.map(block => [
      block.index,
      block.timestamp,
      escapeCsvField(block.actor),
      escapeCsvField(block.role),
      `Level ${block.clearanceLevel}`,
      escapeCsvField(block.action),
      escapeCsvField(block.guardrailStatus),
      escapeCsvField(block.querySummary),
      escapeCsvField(block.payloadHash),
      escapeCsvField(block.prevHash),
      escapeCsvField(block.blockHash),
      block.isTampered ? 'YES - TAMPERED' : 'NO - AUTHENTIC'
    ].join(','));

    const csvContent = [headers.join(','), ...rows].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', url);
    downloadAnchor.setAttribute('download', `sentinel_audit_compliance_report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    URL.revokeObjectURL(url);
  };

  const filteredLogs = auditChain.filter(log => {
    if (filterAction === 'all') return true;
    if (filterAction === 'blocked') return log.guardrailStatus === 'BLOCKED';
    if (filterAction === 'flagged') return log.guardrailStatus === 'FLAGGED';
    if (filterAction === 'passed') return log.guardrailStatus === 'PASSED';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Runtime Governance</span>
            <span aria-hidden="true">·</span>
            <span>Cryptographic Proof</span>
            <span aria-hidden="true">·</span>
            <span>Tamper-Evident Ledger</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Observability Metrics & Hash-Chained Audit Ledger
          </h1>
          <p className="text-sm text-slate-300 mt-1 max-w-3xl">
            Every retrieval decision, permission check, and guardrail interception is sealed into an immutable
            SHA-256 hash-chained block. Re-verify the mathematical chain at any time to guarantee audit integrity.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleExportAuditCSV}
            title="Export audit log ledger as standard CSV for compliance officers"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-700/80 hover:bg-emerald-600 text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download CSV</span>
          </button>

          <button
            onClick={handleExportAuditJSON}
            title="Export complete cryptographic JSON bundle for SOC 2 evidence"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export SOC 2 JSON</span>
          </button>
          
          <button
            onClick={handleVerifyChain}
            disabled={isVerifying}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            {isVerifying ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Verifying Proofs...</span>
              </>
            ) : (
              <>
                <FileCheck2 className="w-3.5 h-3.5" />
                <span>Verify Ledger Integrity</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-xs text-slate-400">Total Audit Blocks</div>
          <div className="text-xl font-bold text-white font-mono mt-1 tabular-nums">
            {auditChain.length}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Sealed SHA-256 payloads</div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-xs text-slate-400">P95 Verification Latency</div>
          <div className="text-xl font-bold text-emerald-400 font-mono mt-1 tabular-nums">
            1.2 ms
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Hardware WebCrypto digest</div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-xs text-slate-400">Blocked Attack Rate</div>
          <div className="text-xl font-bold text-rose-400 font-mono mt-1 tabular-nums">
            {auditChain.length > 0 ? `${Math.round((auditChain.filter(b => b.guardrailStatus === 'BLOCKED').length / auditChain.length) * 100)}%` : '0%'}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Adversarial injections intercepted</div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-xs text-slate-400">Token Cost Governance</div>
          <div className="text-xl font-bold text-indigo-400 font-mono mt-1 tabular-nums">
            $0.0142 USD
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Budget cap: $250.00 / month</div>
        </div>
      </div>

      {/* Verification Status Banner */}
      {verificationResult && (
        <div className={`p-4 rounded-xl border flex items-start gap-3 transition-all ${
          verificationResult.isValid
            ? 'bg-emerald-950/30 border-emerald-800/50 text-emerald-300'
            : 'bg-rose-950/30 border-rose-800/50 text-rose-300'
        }`}>
          {verificationResult.isValid ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          ) : (
            <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          )}
          <div className="flex-1 text-xs">
            <div className="font-semibold text-sm">
              {verificationResult.isValid
                ? 'Cryptographic Chain Validated: Zero Tampering Detected'
                : 'CRITICAL SECURITY ALERT: Cryptographic Mismatch Detected!'}
            </div>
            <div className="mt-1 font-mono text-[11px] opacity-90 leading-relaxed">
              {verificationResult.details}
            </div>
          </div>
        </div>
      )}

      {/* Hash-Chained Audit Ledger Explorer */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Hash className="w-4 h-4 text-indigo-400" />
            <h2 className="text-sm font-semibold text-slate-200">
              Immutable Hash-Chained Blocks
            </h2>
          </div>

          <div className="flex items-center gap-2">
            {/* Filter buttons */}
            <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-lg text-xs">
              <button
                onClick={() => setFilterAction('all')}
                className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                  filterAction === 'all' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                All ({auditChain.length})
              </button>
              <button
                onClick={() => setFilterAction('blocked')}
                className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                  filterAction === 'blocked' ? 'bg-slate-800 text-rose-400 font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Blocked
              </button>
              <button
                onClick={() => setFilterAction('passed')}
                className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                  filterAction === 'passed' ? 'bg-slate-800 text-emerald-400 font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Passed
              </button>
            </div>

            {/* Tampering simulator button for security demonstration */}
            <button
              onClick={auditChain.some(b => b.isTampered) ? handleRestoreChain : handleSimulateTampering}
              className={`text-xs px-2.5 py-1.5 rounded-lg border transition-colors cursor-pointer flex items-center gap-1.5 ${
                auditChain.some(b => b.isTampered)
                  ? 'bg-amber-950/30 border-amber-800 text-amber-300'
                  : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              <Bug className="w-3.5 h-3.5" />
              <span>{auditChain.some(b => b.isTampered) ? 'Restore Ledger' : 'Simulate Tampering'}</span>
            </button>
          </div>
        </div>

        {/* Ledger Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="text-[11px] text-slate-500 uppercase border-b border-slate-800">
              <tr>
                <th className="pb-2.5 pr-2">Block #</th>
                <th className="pb-2.5 pr-3">Timestamp</th>
                <th className="pb-2.5 pr-3">Actor / Role</th>
                <th className="pb-2.5 pr-3">Action</th>
                <th className="pb-2.5 pr-3">Summary</th>
                <th className="pb-2.5 pr-3">Status</th>
                <th className="pb-2.5 text-right">Block Hash (SHA-256)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-[11px]">
              {filteredLogs.map((block) => (
                <tr
                  key={block.index}
                  className={`hover:bg-slate-950/40 transition-colors ${
                    block.isTampered ? 'bg-rose-950/30 border-l-2 border-rose-500' : ''
                  }`}
                >
                  <td className="py-3 pr-2 text-indigo-400 font-bold">
                    #{block.index}
                  </td>
                  <td className="py-3 pr-3 text-slate-400 whitespace-nowrap">
                    {block.timestamp.split('T')[1]?.slice(0, 8) || block.timestamp}
                  </td>
                  <td className="py-3 pr-3 whitespace-nowrap">
                    <div className="text-slate-200 font-sans font-medium">{block.actor}</div>
                    <div className="text-slate-500 text-[10px]">L{block.clearanceLevel} Clearance</div>
                  </td>
                  <td className="py-3 pr-3 text-slate-300">
                    {block.action}
                  </td>
                  <td className="py-3 pr-3 font-sans text-slate-300 max-w-[200px] truncate">
                    {block.querySummary}
                  </td>
                  <td className="py-3 pr-3 whitespace-nowrap">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                      block.guardrailStatus === 'PASSED'
                        ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800/50'
                        : block.guardrailStatus === 'BLOCKED'
                        ? 'bg-rose-950/40 text-rose-300 border-rose-800/50'
                        : 'bg-amber-950/40 text-amber-300 border-amber-800/50'
                    }`}>
                      {block.guardrailStatus}
                    </span>
                  </td>
                  <td className="py-3 text-right text-slate-500 truncate max-w-[140px]">
                    {block.blockHash.slice(0, 16)}...
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
};
