import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Smile,
  Frown,
  AlertOctagon,
  KeyRound,
  ShieldCheck,
  Send,
  Sparkles,
  PhoneCall,
  PhoneOff
} from 'lucide-react';
import { VoiceMessage, VoiceMetric } from '../types';

export const VoiceAgentStudio: React.FC = () => {
  const [isCalling, setIsCalling] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [ttsEnabled, setTtsEnabled] = useState(true);
  const [inputText, setInputText] = useState('');

  // Voice metrics
  const [metrics, setMetrics] = useState<VoiceMetric>({
    frustrationIndex: 14,
    speechValence: 'Neutral',
    speakingRateWpm: 135,
    pitchVariabilityHz: 28,
    biometricConfidence: 94,
    mfaVerified: true
  });

  // Conversation transcript
  const [messages, setMessages] = useState<VoiceMessage[]>([
    {
      id: 'vm-1',
      sender: 'agent',
      text: 'Good day. You are connected to the Sentinel Enterprise Support line. Voice biometrics verified under Level 3 clearance. How may I assist your infrastructure today?',
      timestamp: '10:04:12 AM',
      emotionTag: '[Agent Persona: Calm Professional]',
      latencyMs: 140
    }
  ]);

  const transcriptBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    transcriptBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const speakText = (text: string) => {
    if (!ttsEnabled || typeof window === 'undefined' || !window.speechSynthesis) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('TTS speech synthesis unavailable:', e);
    }
  };

  const handleSendMessage = (userUtterance: string) => {
    if (!userUtterance.trim()) return;

    // Estimate emotion from acoustic lexical cues
    const isAngry = /(broken|cancel|angry|terrible|hate|refund|fraud|ridiculous|unacceptable)/i.test(userUtterance);
    const newFrustration = isAngry ? Math.min(88, metrics.frustrationIndex + 45) : Math.max(12, metrics.frustrationIndex - 10);
    const valence = newFrustration > 50 ? 'Frustrated' : 'Neutral';

    setMetrics(prev => ({
      ...prev,
      frustrationIndex: newFrustration,
      speechValence: valence
    }));

    const userMsg: VoiceMessage = {
      id: `vm-${Date.now()}`,
      sender: 'user',
      text: userUtterance,
      timestamp: new Date().toLocaleTimeString(),
      emotionTag: isAngry ? '[Acoustic: Frustrated/Elevated]' : '[Acoustic: Calm]'
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');

    // Agent response with adaptive persona
    setTimeout(() => {
      let agentReply = '';
      let personaTag = '';

      if (newFrustration > 50) {
        agentReply = "I completely understand how critical this issue is for your production services. I have escalated this immediately to our Level 4 on-call engineers and prioritized your ticket.";
        personaTag = '[Adaptive Persona: Empathetic De-escalation]';
      } else if (userUtterance.toLowerCase().includes('rate limit') || userUtterance.toLowerCase().includes('quota')) {
        agentReply = "Your current token rate limit is 5,000 requests per minute with Redis cluster replication. No throttling has been recorded in the past 24 hours.";
        personaTag = '[Grounding: Cleared Tech Doc L2]';
      } else {
        agentReply = "I have logged your request into our secure transaction ledger. The operation completed in 12ms and has been signed with SHA-256 provenance.";
        personaTag = '[Grounding: Enterprise KMS]';
      }

      const agentMsg: VoiceMessage = {
        id: `vm-${Date.now() + 1}`,
        sender: 'agent',
        text: agentReply,
        timestamp: new Date().toLocaleTimeString(),
        emotionTag: personaTag,
        latencyMs: 180,
        guardrailNotes: 'PII Redacted: Zero leakages'
      };

      setMessages(prev => [...prev, agentMsg]);
      speakText(agentReply);
    }, 600);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
          <span>Full-Duplex Audio</span>
          <span aria-hidden="true">·</span>
          <span>Acoustic Sentiment & Emotion</span>
          <span aria-hidden="true">·</span>
          <span>Voice Biometrics MFA</span>
        </div>
        <h1 className="text-xl font-bold text-white tracking-tight">
          Enterprise Full-Duplex Voice Agent Studio
        </h1>
        <p className="text-sm text-slate-300 mt-1 max-w-3xl">
          Simulates real-time voice conversations with sub-second latency, acoustic emotion analysis,
          dynamic empathetic persona adaptation, and multi-factor voice biometrics.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Live Call Controls & Emotion Telemetry (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Call Status Casing */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Active Telephony Channel
              </span>
              <span className={`text-[11px] font-mono px-2 py-0.5 rounded border ${
                isCalling
                  ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800/50'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}>
                {isCalling ? 'CALL ACTIVE (SIP / WebRTC)' : 'STANDBY READY'}
              </span>
            </div>

            {/* Primary Call Action */}
            <div className="flex items-center justify-center py-4">
              <button
                onClick={() => {
                  const nextCalling = !isCalling;
                  setIsCalling(nextCalling);
                  if (nextCalling) {
                    speakText("Connected to Sentinel Voice Agent. How can I assist you?");
                  } else {
                    if (window.speechSynthesis) window.speechSynthesis.cancel();
                  }
                }}
                className={`w-16 h-16 rounded-full flex items-center justify-center transition-transform hover:scale-105 cursor-pointer shadow-lg ${
                  isCalling
                    ? 'bg-rose-600 hover:bg-rose-500 text-white'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                }`}
              >
                {isCalling ? <PhoneOff className="w-7 h-7" /> : <PhoneCall className="w-7 h-7" />}
              </button>
            </div>

            {/* Secondary Controls (Mute, TTS) */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className={`py-2 px-3 rounded-lg border text-xs flex items-center justify-center gap-1.5 cursor-pointer ${
                  isMuted
                    ? 'bg-amber-950/30 border-amber-800/50 text-amber-300'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                {isMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                <span>{isMuted ? 'Muted' : 'Microphone Live'}</span>
              </button>

              <button
                onClick={() => setTtsEnabled(!ttsEnabled)}
                className={`py-2 px-3 rounded-lg border text-xs flex items-center justify-center gap-1.5 cursor-pointer ${
                  ttsEnabled
                    ? 'bg-indigo-950/30 border-indigo-800/50 text-indigo-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                {ttsEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                <span>{ttsEnabled ? 'Agent Audio On' : 'Audio Muted'}</span>
              </button>
            </div>
          </div>

          {/* Acoustic & Biometric Telemetry */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              Real-Time Acoustic & Biometric Telemetry
            </h2>

            {/* Frustration Meter */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1.5">
                  {metrics.frustrationIndex > 50 ? (
                    <Frown className="w-3.5 h-3.5 text-rose-400" />
                  ) : (
                    <Smile className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                  Caller Frustration Index
                </span>
                <span className={`font-mono font-semibold ${
                  metrics.frustrationIndex > 50 ? 'text-rose-400' : 'text-emerald-400'
                }`}>
                  {metrics.frustrationIndex}%
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${
                    metrics.frustrationIndex > 50 ? 'bg-rose-500' : 'bg-emerald-500'
                  }`}
                  style={{ width: `${metrics.frustrationIndex}%` }}
                />
              </div>
            </div>

            {/* Voice Biometrics */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-indigo-400" />
                  Voice Biometric Match
                </span>
                <span className="font-mono text-emerald-400 font-semibold">
                  {metrics.biometricConfidence}% Match
                </span>
              </div>
              <div className="text-[11px] text-slate-400">
                Acoustic vocal tract resonant frequencies matched against enrolled voiceprint. Zero-trust MFA verified.
              </div>
            </div>

            {/* Speaking Stats */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                <div className="text-slate-400 text-[11px]">Speaking Pace</div>
                <div className="font-mono text-slate-200 font-semibold mt-0.5">
                  {metrics.speakingRateWpm} WPM
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                <div className="text-slate-400 text-[11px]">Valence State</div>
                <div className="font-mono text-indigo-400 font-semibold mt-0.5">
                  {metrics.speechValence}
                </div>
              </div>
            </div>

          </div>

        </div>

        {/* Right Column: Real-Time Conversation Transcript (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col h-[520px]">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <span className="text-xs font-semibold text-slate-300">
                Live Conversation Stream & Grounding Tags
              </span>
              <span className="text-[11px] font-mono text-slate-500">
                Full-Duplex Sub-Second Pipeline
              </span>
            </div>

            {/* Scrollable Messages Area */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-2">
              {messages.map((m) => {
                const isAgent = m.sender === 'agent';
                return (
                  <div
                    key={m.id}
                    className={`flex flex-col ${isAgent ? 'items-start' : 'items-end'}`}
                  >
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mb-1 font-mono">
                      <span>{isAgent ? 'Voice Agent (Chord S2S)' : 'Caller (Microphone)'}</span>
                      <span>·</span>
                      <span>{m.timestamp}</span>
                      {m.latencyMs && (
                        <>
                          <span>·</span>
                          <span className="text-indigo-400">{m.latencyMs}ms</span>
                        </>
                      )}
                    </div>

                    <div
                      className={`max-w-[85%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                        isAgent
                          ? 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-sm'
                          : 'bg-indigo-600 text-white rounded-tr-sm'
                      }`}
                    >
                      {m.text}
                    </div>

                    {m.emotionTag && (
                      <div className="text-[10px] font-mono text-slate-400 mt-1">
                        {m.emotionTag}
                      </div>
                    )}
                  </div>
                );
              })}
              <div ref={transcriptBottomRef} />
            </div>

            {/* Utterance Input Bar */}
            <div className="pt-3 border-t border-slate-800 mt-3 flex gap-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSendMessage(inputText);
                }}
                placeholder="Say something or test a frustrated complaint..."
                className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-500 text-xs focus:outline-none focus:border-indigo-500"
              />
              <button
                onClick={() => handleSendMessage(inputText)}
                disabled={!inputText.trim()}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold cursor-pointer flex items-center gap-1.5 shrink-0"
              >
                <span>Speak</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Quick Speech Chips */}
            <div className="flex gap-2 mt-2 overflow-x-auto pb-1 text-[11px]">
              <button
                onClick={() => handleSendMessage("What are our current API rate limits?")}
                className="px-2.5 py-1 rounded-md bg-slate-950 border border-slate-800 text-slate-400 hover:text-white shrink-0 cursor-pointer"
              >
                "What are our rate limits?"
              </button>
              <button
                onClick={() => handleSendMessage("This outage is completely unacceptable! Fix my production database immediately!")}
                className="px-2.5 py-1 rounded-md bg-rose-950/30 border border-rose-900/40 text-rose-300 hover:bg-rose-900/40 shrink-0 cursor-pointer"
              >
                "This outage is unacceptable!" (Frustrated)
              </button>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
