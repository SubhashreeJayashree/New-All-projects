import React, { useState } from 'react';
import {
  Users,
  Code2,
  GitPullRequest,
  CheckCircle2,
  Clock,
  Play,
  ArrowRight,
  ShieldAlert,
  GitCommit
} from 'lucide-react';
import { AgentMessage } from '../types';

interface AgentCouncilViewProps {
  onAddAuditBlock: (block: any) => void;
}

const PRESET_TASKS = [
  {
    id: 'task-1',
    title: 'Distributed Token Bucket Rate Limiter with Keycloak RBAC',
    description: 'Implement a high-throughput Redis-backed rate limiter enforcing tiered QPS quotas by user role.'
  },
  {
    id: 'task-2',
    title: 'Hardware Security Module (HSM) Shard Rotation Hook',
    description: 'Create an automated Shamir Secret Sharing shard re-encryption routine for post-quantum key storage.'
  },
  {
    id: 'task-3',
    title: 'OAuth2 Proof Key for Code Exchange (PKCE) Token Validator',
    description: 'Build a zero-trust authorization middleware with SVID identity propagation.'
  }
];

export const AgentCouncilView: React.FC<AgentCouncilViewProps> = ({ onAddAuditBlock }) => {
  const [selectedTask, setSelectedTask] = useState(PRESET_TASKS[0]);
  const [isRunning, setIsRunning] = useState(false);
  const [messages, setMessages] = useState<AgentMessage[]>([]);
  const [currentStep, setCurrentStep] = useState(0);

  const startCouncilRun = () => {
    setIsRunning(true);
    setMessages([]);
    setCurrentStep(1);

    // Turn 1: Architect decomposes the problem
    setTimeout(() => {
      const msg1: AgentMessage = {
        id: 'msg-1',
        agentRole: 'Architect',
        agentName: 'Architect Agent (Opus-Plan)',
        avatarColor: 'text-indigo-400 bg-indigo-950/50 border-indigo-800/60',
        timestamp: new Date().toLocaleTimeString(),
        status: 'planning',
        thought: 'Analyzing system requirements, latency bounds, and Redis atomic script topology...',
        content: `I have decomposed the problem into 3 sequential deliverables:\n1. Atomic Redis Lua script for token replenishment (prevents race conditions).\n2. RBAC tier quota mapping (L1: 120 rpm, L2: 600 rpm, L3: 3000 rpm, L4: unlimited).\n3. Fail-closed fallback circuit breaker in case of cluster disconnection.`,
        diffSummary: 'Topology approved. Delegating to Lead Developer.'
      };
      setMessages([msg1]);
      setCurrentStep(2);
    }, 1000);

    // Turn 2: Lead Developer generates implementation
    setTimeout(() => {
      const msg2: AgentMessage = {
        id: 'msg-2',
        agentRole: 'Developer',
        agentName: 'Lead Developer (Codex-Build)',
        avatarColor: 'text-emerald-400 bg-emerald-950/50 border-emerald-800/60',
        timestamp: new Date().toLocaleTimeString(),
        status: 'coding',
        thought: 'Drafting high-performance TypeScript middleware using ioredis and atomic Redis EVAL...',
        content: `Here is the production implementation with sliding-window rate limiting:`,
        codeSnippet: `export async function enforceRateLimit(userId: string, roleLevel: number): Promise<boolean> {
  const quota = ROLE_QUOTAS[roleLevel] || 120;
  const key = \`rate_limit:\${userId}\`;
  
  // Atomic Lua token bucket evaluation
  const result = await redisClient.eval(LUA_TOKEN_BUCKET_SCRIPT, 1, key, quota, Date.now());
  if (result === 0) {
    throw new QuotaExceededException('Clearance quota depleted. Retry in 60s.');
  }
  return true;
}`,
        diffSummary: '+42 lines added, 0 deletions. Ready for independent cross-model review.'
      };
      setMessages(prev => [...prev, msg2]);
      setCurrentStep(3);
    }, 2400);

    // Turn 3: Security Auditor reviews diff (Independent review: different model)
    setTimeout(() => {
      const msg3: AgentMessage = {
        id: 'msg-3',
        agentRole: 'Security Auditor',
        agentName: 'Security Auditor (Grok-Review)',
        avatarColor: 'text-amber-400 bg-amber-950/50 border-amber-800/60',
        timestamp: new Date().toLocaleTimeString(),
        status: 'auditing',
        thought: 'Running static taint analysis, integer overflow checks, and denial-of-service simulations...',
        content: `Cross-model review findings:\n• Redis EVAL execution is atomic; zero race conditions detected.\n• Hardened TTL: Token bucket keys automatically expire after 120s of inactivity to prevent memory leak.\n• Edge case check: Level 4 bypass flag properly checked against verified cryptographic JWT claims, not raw request params.`,
        diffSummary: '0 vulnerabilities detected. High confidence approval.'
      };
      setMessages(prev => [...prev, msg3]);
      setCurrentStep(4);
    }, 3900);

    // Turn 4: Policy & Compliance Enforcer signs off and seals pull request
    setTimeout(() => {
      const msg4: AgentMessage = {
        id: 'msg-4',
        agentRole: 'Policy Enforcer',
        agentName: 'Policy Enforcer (Sentinel-Gate)',
        avatarColor: 'text-purple-400 bg-purple-950/50 border-purple-800/60',
        timestamp: new Date().toLocaleTimeString(),
        status: 'approved',
        thought: 'Verifying license compliance (Apache 2.0), SOC 2 audit telemetry, and git commit signature...',
        content: `All gates passed. Automated test suite passed with 100% branch coverage. Pull Request #1409 signed with Ed25519 commit signature and merged into staging.`,
        diffSummary: 'MERGED TO MAIN (Commit: 8f9b2a1)'
      };
      setMessages(prev => [...prev, msg4]);
      setCurrentStep(4);
      setIsRunning(false);
    }, 5200);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
          <span>Multi-Agent Swarm</span>
          <span aria-hidden="true">·</span>
          <span>Independent Cross-Model Review</span>
          <span aria-hidden="true">·</span>
          <span>Work Queues & Ledgers</span>
        </div>
        <h1 className="text-xl font-bold text-white tracking-tight">
          Multi-Agent Software Engineering Council
        </h1>
        <p className="text-sm text-slate-300 mt-1 max-w-3xl">
          Autonomous collaboration between specialized agents. The model that writes code is never the one
          that audits the git diff, ensuring strict verification and zero single-model bias.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Task Selection & Swarm Members (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <Code2 className="w-4 h-4 text-indigo-400" />
              Select Engineering Task
            </h2>

            <div className="space-y-2">
              {PRESET_TASKS.map(task => {
                const isSelected = selectedTask.id === task.id;
                return (
                  <button
                    key={task.id}
                    onClick={() => {
                      if (!isRunning) setSelectedTask(task);
                    }}
                    disabled={isRunning}
                    className={`w-full p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-600/15 border-indigo-500/50 text-white'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="text-xs font-semibold">{task.title}</div>
                    <div className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                      {task.description}
                    </div>
                  </button>
                );
              })}
            </div>

            <button
              onClick={startCouncilRun}
              disabled={isRunning}
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              {isRunning ? (
                <>
                  <Clock className="w-3.5 h-3.5 animate-spin" />
                  <span>Council Executing Turn {currentStep}/4...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5" />
                  <span>Dispatch Task to Council</span>
                </>
              )}
            </button>
          </div>

          {/* Council Roster */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2">
              <Users className="w-3.5 h-3.5" />
              Active Council Roster
            </h2>

            <div className="space-y-2.5 text-xs">
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-indigo-300">Lead Architect</div>
                  <div className="text-slate-400 text-[11px]">System planning & task graph</div>
                </div>
                <span className="font-mono text-[10px] text-slate-500">Claude-Opus</span>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-emerald-300">Lead Developer</div>
                  <div className="text-slate-400 text-[11px]">Implementation & pull requests</div>
                </div>
                <span className="font-mono text-[10px] text-slate-500">Codex-Pro</span>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-amber-300">Security Auditor</div>
                  <div className="text-slate-400 text-[11px]">Independent diff review (P2P)</div>
                </div>
                <span className="font-mono text-[10px] text-slate-500">Grok-3.0</span>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-purple-300">Policy Enforcer</div>
                  <div className="text-slate-400 text-[11px]">Compliance signoff & merge</div>
                </div>
                <span className="font-mono text-[10px] text-slate-500">Sentinel-Gate</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Council Swarm Timeline & Code Diffs (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <GitPullRequest className="w-4 h-4 text-emerald-400" />
              Swarm Execution Trace & Discussion Ledger
            </h2>
            <div className="text-xs text-slate-400 font-mono">
              {messages.length} / 4 Turns Recorded
            </div>
          </div>

          {messages.length > 0 ? (
            <div className="space-y-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span className={`text-xs font-semibold px-2.5 py-1 rounded-md border ${msg.avatarColor}`}>
                        {msg.agentName}
                      </span>
                      <span className="text-xs text-slate-500 font-mono">{msg.timestamp}</span>
                    </div>

                    <div className="flex items-center gap-1.5 text-[11px] font-mono">
                      {msg.status === 'approved' ? (
                        <span className="text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          VERIFIED
                        </span>
                      ) : (
                        <span className="text-indigo-400 flex items-center gap-1">
                          <GitCommit className="w-3.5 h-3.5" />
                          STAGE COMPLETED
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Internal Thought Stream */}
                  <div className="text-xs text-slate-400 italic bg-slate-950/40 p-2.5 rounded-lg border border-slate-800/60 font-mono">
                    <span className="text-slate-500 not-italic mr-1.5">Thought:</span>
                    {msg.thought}
                  </div>

                  {/* Response / Content */}
                  <div className="text-xs text-slate-200 whitespace-pre-wrap leading-relaxed">
                    {msg.content}
                  </div>

                  {/* Code snippet if present */}
                  {msg.codeSnippet && (
                    <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
                      <div className="px-3 py-1.5 bg-slate-900/80 border-b border-slate-800 text-[11px] font-mono text-slate-400 flex items-center justify-between">
                        <span>src/middleware/rateLimiter.ts</span>
                        <span className="text-emerald-400">TypeScript</span>
                      </div>
                      <pre className="p-3.5 text-xs font-mono text-emerald-300 overflow-x-auto">
                        <code>{msg.codeSnippet}</code>
                      </pre>
                    </div>
                  )}

                  {/* Diff / Audit Footer */}
                  {msg.diffSummary && (
                    <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                      <span>{msg.diffSummary}</span>
                      <span className="text-slate-500">Hash-Verified</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="p-12 rounded-2xl bg-slate-900/40 border border-slate-800/60 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-800/60 flex items-center justify-center mx-auto text-slate-400">
                <GitPullRequest className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-semibold text-slate-200">Council Idle</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Select an engineering task and click "Dispatch Task to Council" to watch independent agents collaborate, code, and review pull requests.
              </p>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
