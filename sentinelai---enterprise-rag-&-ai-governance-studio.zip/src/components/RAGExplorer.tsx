import React, { useState } from 'react';
import {
  Database,
  Search,
  Lock,
  Unlock,
  CheckCircle2,
  AlertTriangle,
  Plus,
  Hash,
  ArrowRight,
  RefreshCw,
  FileText
} from 'lucide-react';
import { UserRole, DocumentChunk } from '../types';
import { PRESET_QUERIES } from '../data/mockData';
import { evaluateInboundGuardrails, evaluateOutboundGuardrails } from '../utils/guardrailsEngine';
import { createSealedBlock } from '../utils/crypto';

interface RAGExplorerProps {
  activeRole: UserRole;
  documents: DocumentChunk[];
  setDocuments: React.Dispatch<React.SetStateAction<DocumentChunk[]>>;
  onAddAuditBlock: (block: any) => void;
}

export const RAGExplorer: React.FC<RAGExplorerProps> = ({
  activeRole,
  documents,
  setDocuments,
  onAddAuditBlock
}) => {
  const [queryInput, setQueryInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [retrievalResults, setRetrievalResults] = useState<{
    authorizedChunks: DocumentChunk[];
    deniedChunks: DocumentChunk[];
    generatedAnswer: string;
    guardrailOutcome: ReturnType<typeof evaluateInboundGuardrails>;
    outboundOutcome?: ReturnType<typeof evaluateOutboundGuardrails>;
    executionTimeMs: number;
    tokensConsumed: number;
  } | null>(null);

  // Ingestion Modal State
  const [showIngestModal, setShowIngestModal] = useState(false);
  const [newDocTitle, setNewDocTitle] = useState('');
  const [newDocCategory, setNewDocCategory] = useState('Security Architecture');
  const [newDocClearance, setNewDocClearance] = useState<number>(2);
  const [newDocContent, setNewDocContent] = useState('');

  const executeQuery = async (queryText: string) => {
    if (!queryText.trim()) return;
    setIsProcessing(true);
    const startTime = performance.now();

    // 1. Inbound Guardrail Gate
    const guardrailOutcome = evaluateInboundGuardrails(queryText);

    // If blocked by guardrails (e.g. prompt injection)
    if (!guardrailOutcome.allowed) {
      const elapsed = Math.round(performance.now() - startTime);
      setRetrievalResults({
        authorizedChunks: [],
        deniedChunks: [],
        generatedAnswer:
          '⛔ REQUEST BLOCKED BY INBOUND GUARDRAIL GATE: Query was flagged as an adversarial jailbreak or prompt injection attack. Clearance filter cannot be overridden.',
        guardrailOutcome,
        executionTimeMs: elapsed,
        tokensConsumed: 42
      });

      // Record in audit ledger
      const block = await createSealedBlock(
        Date.now(),
        activeRole.name,
        activeRole.title,
        'INBOUND_GUARDRAIL_BLOCK',
        `Blocked injection: "${queryText.slice(0, 60)}..."`,
        activeRole.clearanceLevel,
        'BLOCKED',
        '0000000000000000000000000000000000000000000000000000000000000000'
      );
      onAddAuditBlock(block);
      setIsProcessing(false);
      return;
    }

    // 2. Query-Time Identity & Lattice RBAC Scoping
    // Simulating semantic match + permission filter
    const lowerQuery = queryText.toLowerCase();
    const scoredDocs = documents.map(doc => {
      // Calculate simple semantic keyword match score
      const queryWords = lowerQuery.split(/\W+/).filter(w => w.length > 2);
      let matchCount = 0;
      for (const word of queryWords) {
        if (doc.content.toLowerCase().includes(word) || doc.docTitle.toLowerCase().includes(word)) {
          matchCount++;
        }
      }
      const score = queryWords.length > 0 ? matchCount / queryWords.length : 0.5;
      return { doc, score };
    });

    // Separate authorized vs unauthorized based on user's active clearance level
    const authorizedChunks: DocumentChunk[] = [];
    const deniedChunks: DocumentChunk[] = [];

    for (const item of scoredDocs) {
      if (item.doc.clearanceLevel <= activeRole.clearanceLevel) {
        if (item.score > 0.1 || scoredDocs.length <= 3) {
          authorizedChunks.push(item.doc);
        }
      } else {
        deniedChunks.push(item.doc);
      }
    }

    // 3. Grounded Answer Synthesis
    let answer = '';
    if (authorizedChunks.length === 0) {
      if (deniedChunks.length > 0) {
        answer = `Access Denied: The requested knowledge base documents require Clearance Level ${deniedChunks[0].clearanceLevel} (${deniedChunks[0].clearanceName}), but your current identity "${activeRole.title}" is cleared only up to Level ${activeRole.clearanceLevel} (${activeRole.clearanceName}). In accordance with Query-Time RBAC, these documents were excluded prior to retrieval.`;
      } else {
        answer = `No matching documents found in the authorized knowledge corpus for query "${queryText}".`;
      }
    } else {
      // Synthesize grounded answer
      const primeDoc = authorizedChunks[0];
      answer = `Based on authorized documentation [Doc: ${primeDoc.docTitle}]:\n\n${primeDoc.content.slice(0, 320)}...\n\n[Grounding Source: Clearance Level ${primeDoc.clearanceLevel} (${primeDoc.clearanceName}), SHA-256 Verified Chunk: ${primeDoc.hash.slice(0, 16)}...]`;
    }

    // 4. Outbound Guardrail Inspection
    const contextStr = authorizedChunks.map(c => c.content).join(' ');
    const outboundOutcome = evaluateOutboundGuardrails(answer, contextStr);

    const elapsed = Math.round(performance.now() - startTime);
    const tokens = Math.round(queryText.length / 4 + answer.length / 4 + 120);

    setRetrievalResults({
      authorizedChunks,
      deniedChunks,
      generatedAnswer: answer,
      guardrailOutcome,
      outboundOutcome,
      executionTimeMs: elapsed,
      tokensConsumed: tokens
    });

    // 5. Commit to cryptographic hash-chained audit ledger
    const actionType = authorizedChunks.length > 0 ? 'RAG_QUERY_SUCCESS' : 'RAG_QUERY_DENIED';
    const auditStatus = authorizedChunks.length > 0 ? 'PASSED' : 'FLAGGED';
    const auditBlock = await createSealedBlock(
      Date.now(),
      activeRole.name,
      activeRole.title,
      actionType,
      `Query: "${queryText.slice(0, 50)}..." [Cleared Docs: ${authorizedChunks.length}, Denied: ${deniedChunks.length}]`,
      activeRole.clearanceLevel,
      auditStatus,
      '0000000000000000000000000000000000000000000000000000000000000000'
    );
    onAddAuditBlock(auditBlock);

    setIsProcessing(false);
  };

  const handleIngestDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocTitle.trim() || !newDocContent.trim()) return;

    const clearanceNames: Record<number, DocumentChunk['clearanceName']> = {
      1: 'PUBLIC',
      2: 'INTERNAL',
      3: 'CONFIDENTIAL',
      4: 'TOP_SECRET'
    };

    const newChunk: DocumentChunk = {
      id: `chunk-${Date.now()}`,
      docId: `doc-${Date.now()}`,
      docTitle: newDocTitle,
      clearanceLevel: newDocClearance,
      clearanceName: clearanceNames[newDocClearance],
      category: newDocCategory,
      content: newDocContent,
      hash: 'e8b4c91a0f3d5e7b9c2a4f6d8e0b1c3a5e7f9a1b3c5d7e9f1a3b5c7d9e1f3a5b',
      metadata: {
        author: activeRole.name,
        department: activeRole.department,
        lastUpdated: new Date().toISOString().split('T')[0],
        version: '1.0.0-CUSTOM'
      }
    };

    setDocuments(prev => [newChunk, ...prev]);
    setShowIngestModal(false);
    setNewDocTitle('');
    setNewDocContent('');
  };

  return (
    <div className="space-y-6">
      {/* Header & Clearance Indicator */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Identity-Aware RAG</span>
            <span aria-hidden="true">·</span>
            <span>Query-Time Permission Lattice</span>
            <span aria-hidden="true">·</span>
            <span>Grounding Scoper</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Query-Time RBAC Retrieval & Knowledge Base
          </h1>
          <p className="text-sm text-slate-300 mt-1 max-w-2xl">
            Enforces document-level permissions inside the retrieval predicate before LLM synthesis.
            Unauthorized documents are geometrically excluded, preventing information leakage.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowIngestModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            Ingest Knowledge Doc
          </button>
        </div>
      </div>

      {/* Query Bar & Presets */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={queryInput}
              onChange={(e) => setQueryInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') executeQuery(queryInput);
              }}
              placeholder="Ask a question across the enterprise knowledge base..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-indigo-500"
            />
          </div>
          <button
            onClick={() => executeQuery(queryInput)}
            disabled={isProcessing || !queryInput.trim()}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-sm font-semibold transition-colors cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap"
          >
            {isProcessing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Querying...
              </>
            ) : (
              <>
                <span>Retrieve & Synthesize</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>

        {/* Preset Prompt Buttons */}
        <div>
          <div className="text-xs font-medium text-slate-400 mb-2">Preset Test Queries:</div>
          <div className="flex flex-wrap gap-2">
            {PRESET_QUERIES.map((preset, idx) => {
              const isAllowed = preset.expectedLevel <= activeRole.clearanceLevel;
              return (
                <button
                  key={idx}
                  onClick={() => {
                    setQueryInput(preset.query);
                    executeQuery(preset.query);
                  }}
                  className={`text-xs px-3 py-1.5 rounded-lg border transition-all cursor-pointer text-left ${
                    preset.label.includes('⚠️')
                      ? 'border-amber-500/40 bg-amber-500/10 text-amber-200 hover:bg-amber-500/20'
                      : isAllowed
                      ? 'border-slate-800 bg-slate-950 text-slate-300 hover:border-indigo-500/40 hover:text-white'
                      : 'border-rose-900/40 bg-rose-950/20 text-rose-300 hover:border-rose-800'
                  }`}
                >
                  <div className="font-medium flex items-center gap-1.5">
                    {preset.label.includes('⚠️') ? (
                      <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0" />
                    ) : isAllowed ? (
                      <Unlock className="w-3 h-3 text-emerald-400 shrink-0" />
                    ) : (
                      <Lock className="w-3 h-3 text-rose-400 shrink-0" />
                    )}
                    <span>{preset.label}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Grid: Active Knowledge Base Corpus vs Query Outcome */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Knowledge Base Corpus (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <Database className="w-4 h-4 text-indigo-400" />
              Indexed Documents & Access Clearance
            </h2>
            <span className="text-xs text-slate-400 font-mono">
              {documents.length} Chunks Indexed
            </span>
          </div>

          <div className="space-y-3">
            {documents.map((doc) => {
              const hasAccess = doc.clearanceLevel <= activeRole.clearanceLevel;
              return (
                <div
                  key={doc.id}
                  className={`p-4 rounded-xl border transition-all ${
                    hasAccess
                      ? 'bg-slate-900/90 border-slate-800'
                      : 'bg-rose-950/10 border-rose-900/30 opacity-75'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 text-xs mb-1">
                        <span className={`font-mono text-[11px] font-semibold px-2 py-0.5 rounded ${
                          doc.clearanceLevel === 4
                            ? 'bg-purple-950/60 text-purple-300 border border-purple-800/50'
                            : doc.clearanceLevel === 3
                            ? 'bg-rose-950/60 text-rose-300 border border-rose-800/50'
                            : doc.clearanceLevel === 2
                            ? 'bg-blue-950/60 text-blue-300 border border-blue-800/50'
                            : 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/50'
                        }`}>
                          L{doc.clearanceLevel} {doc.clearanceName}
                        </span>
                        <span className="text-slate-500 font-mono text-[11px]">{doc.category}</span>
                      </div>
                      <h3 className="text-sm font-medium text-slate-100 leading-snug">
                        {doc.docTitle}
                      </h3>
                    </div>

                    <div className="shrink-0">
                      {hasAccess ? (
                        <div className="flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-950/30 px-2 py-0.5 rounded border border-emerald-900/40">
                          <Unlock className="w-3 h-3" />
                          <span>Cleared</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1 text-[11px] text-rose-400 bg-rose-950/30 px-2 py-0.5 rounded border border-rose-900/40">
                          <Lock className="w-3 h-3" />
                          <span>Denied</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 mt-2 line-clamp-2">
                    {hasAccess ? doc.content : '•••• Content encrypted & shielded under Query-Time RBAC lattice policy ••••'}
                  </p>

                  <div className="mt-3 pt-2.5 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                    <span className="truncate max-w-[160px]">Hash: {doc.hash.slice(0, 14)}...</span>
                    <span>Updated: {doc.metadata.lastUpdated}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Grounded Answer & Scoping Trace (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-400" />
              Retrieval & Grounded Synthesis
            </h2>
            {retrievalResults && (
              <div className="text-xs font-mono text-slate-400 flex items-center gap-2">
                <span>{retrievalResults.executionTimeMs}ms</span>
                <span aria-hidden="true">·</span>
                <span>{retrievalResults.tokensConsumed} tokens</span>
              </div>
            )}
          </div>

          {retrievalResults ? (
            <div className="space-y-4">
              {/* Grounded Synthesis Card */}
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    Synthesized Model Response
                  </span>
                  {retrieatedTag(retrievalResults)}
                </div>

                <div className="text-sm text-slate-200 leading-relaxed whitespace-pre-wrap bg-slate-950/60 p-4 rounded-xl border border-slate-800/80 font-mono text-xs">
                  {retrievalResults.generatedAnswer}
                </div>

                {/* Grounding Confidence & Metrics */}
                {retrievalResults.outboundOutcome && (
                  <div className="grid grid-cols-3 gap-3 pt-2">
                    <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                      <div className="text-[11px] text-slate-400">Faithfulness</div>
                      <div className="text-sm font-bold text-emerald-400 font-mono mt-0.5">
                        {(retrievalResults.outboundOutcome.faithfulnessScore * 100).toFixed(0)}%
                      </div>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                      <div className="text-[11px] text-slate-400">Grounding</div>
                      <div className="text-sm font-bold text-indigo-400 capitalize font-mono mt-0.5">
                        {retrievalResults.outboundOutcome.groundingConfidence}
                      </div>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                      <div className="text-[11px] text-slate-400">Hallucination Risk</div>
                      <div className="text-sm font-bold text-slate-200 capitalize font-mono mt-0.5">
                        {retrievalResults.outboundOutcome.hallucinationRisk}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Retrieval Authorization Scoping Table */}
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  Query-Time Permission Scoping Decisions
                </div>

                <div className="space-y-2">
                  {retrievalResults.authorizedChunks.map(chunk => (
                    <div
                      key={chunk.id}
                      className="p-3 rounded-lg bg-emerald-950/20 border border-emerald-800/30 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <div>
                          <div className="font-medium text-emerald-200">{chunk.docTitle}</div>
                          <div className="text-emerald-400/80 text-[11px] font-mono">
                            Cleared for Level {chunk.clearanceLevel} ({chunk.clearanceName})
                          </div>
                        </div>
                      </div>
                      <span className="font-mono text-emerald-400 text-[11px] font-semibold">
                        AUTHORIZED
                      </span>
                    </div>
                  ))}

                  {retrievalResults.deniedChunks.map(chunk => (
                    <div
                      key={chunk.id}
                      className="p-3 rounded-lg bg-rose-950/20 border border-rose-900/40 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <Lock className="w-4 h-4 text-rose-400 shrink-0" />
                        <div>
                          <div className="font-medium text-rose-200">{chunk.docTitle}</div>
                          <div className="text-rose-400/80 text-[11px] font-mono">
                            Requires Level {chunk.clearanceLevel} · Caller holds Level {activeRole.clearanceLevel}
                          </div>
                        </div>
                      </div>
                      <span className="font-mono text-rose-400 text-[11px] font-semibold">
                        DENIED PRE-RETRIEVAL
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-12 rounded-2xl bg-slate-900/40 border border-slate-800/60 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-800/60 flex items-center justify-center mx-auto text-slate-400">
                <Search className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-semibold text-slate-200">
                No active RAG query executed yet
              </h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Type a query in the search bar above or choose a preset query to experience real-time query-time RBAC scoping.
              </p>
            </div>
          )}

        </div>
      </div>

      {/* Ingest Document Modal */}
      {showIngestModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Ingest New Enterprise Document</h3>
              <button
                onClick={() => setShowIngestModal(false)}
                className="text-slate-400 hover:text-white text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleIngestDocument} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Document Title</label>
                <input
                  type="text"
                  required
                  value={newDocTitle}
                  onChange={(e) => setNewDocTitle(e.target.value)}
                  placeholder="e.g. Zero-Trust Gateway Deployment Specification"
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Category</label>
                  <input
                    type="text"
                    required
                    value={newDocCategory}
                    onChange={(e) => setNewDocCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Clearance Level</label>
                  <select
                    value={newDocClearance}
                    onChange={(e) => setNewDocClearance(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                  >
                    <option value={1}>Level 1: Public</option>
                    <option value={2}>Level 2: Internal</option>
                    <option value={3}>Level 3: Confidential</option>
                    <option value={4}>Level 4: Top Secret</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Document Body / Content</label>
                <textarea
                  required
                  rows={4}
                  value={newDocContent}
                  onChange={(e) => setNewDocContent(e.target.value)}
                  placeholder="Paste document text..."
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowIngestModal(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold cursor-pointer"
                >
                  Index & Hash Document
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

function retrieatedTag(results: any) {
  if (results.deniedChunks.length > 0 && results.authorizedChunks.length === 0) {
    return (
      <span className="text-[11px] font-mono text-rose-400 font-semibold bg-rose-950/40 px-2 py-0.5 rounded border border-rose-900/50">
        PERMISSION DENIED
      </span>
    );
  }
  return (
    <span className="text-[11px] font-mono text-emerald-400 font-semibold bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-900/50">
      AUTHENTICATED & GROUNDED
    </span>
  );
}
