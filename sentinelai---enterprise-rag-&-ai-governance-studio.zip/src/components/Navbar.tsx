import React, { useState } from 'react';
import { Shield, ChevronDown, Check } from 'lucide-react';
import { UserRole } from '../types';
import { USER_ROLES } from '../data/mockData';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  activeRole: UserRole;
  setActiveRole: (role: UserRole) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  activeRole,
  setActiveRole
}) => {
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);

  const navLinks = [
    { id: 'rag', label: 'RAG Knowledge' },
    { id: 'guardrails', label: 'Guardrails Gate' },
    { id: 'agents', label: 'Agent Council' },
    { id: 'voice', label: 'Voice Studio' },
    { id: 'classifier', label: 'Text Classifier' },
    { id: 'monitoring', label: 'Audit & Metrics' }
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-slate-800/80 bg-slate-950/85 backdrop-blur-md px-6 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
        
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
            <Shield className="w-4 h-4" />
          </div>
          <a
            href="#"
            onClick={(e) => { e.preventDefault(); setActiveTab('rag'); }}
            className="text-base font-bold tracking-tight text-white whitespace-nowrap"
          >
            SentinelAI Studio
          </a>
        </div>

        {/* Zone 2: Navigation Links (Single line, text with hover states) */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-400">
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => setActiveTab(link.id)}
                className={`transition-colors whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'text-white font-semibold border-b-2 border-indigo-500 pb-0.5'
                    : 'hover:text-slate-200'
                }`}
              >
                {link.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Active User Role Switcher */}
        <div className="relative shrink-0">
          <button
            onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
            className="flex items-center gap-3 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 transition-colors cursor-pointer text-left"
          >
            <img
              src="/src/assets/images/avatar_security_officer_1792075760296.jpg"
              alt={activeRole.name}
              className="w-7 h-7 rounded-full object-cover border border-slate-700"
              referrerPolicy="no-referrer"
            />
            <div className="hidden sm:block text-xs">
              <div className="font-semibold text-slate-200 leading-tight whitespace-nowrap">
                {activeRole.name}
              </div>
              <div className="text-slate-400 flex items-center gap-1.5">
                <span>{activeRole.title}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono text-indigo-400 font-medium">L{activeRole.clearanceLevel}</span>
              </div>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-1" />
          </button>

          {/* Role selection dropdown */}
          {roleDropdownOpen && (
            <div className="absolute right-0 mt-2 w-72 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl p-2 z-50">
              <div className="px-3 py-2 text-xs font-semibold text-slate-400 border-b border-slate-800/80">
                Switch Security Clearance & Role
              </div>
              <div className="mt-1 space-y-1">
                {USER_ROLES.map((role) => {
                  const isSelected = role.id === activeRole.id;
                  return (
                    <button
                      key={role.id}
                      onClick={() => {
                        setActiveRole(role);
                        setRoleDropdownOpen(false);
                      }}
                      className={`w-full text-left p-2.5 rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'bg-indigo-600/20 text-white border border-indigo-500/30'
                          : 'text-slate-300 hover:bg-slate-800/70'
                      }`}
                    >
                      <div>
                        <div className="font-medium text-slate-100 flex items-center gap-2">
                          <span>{role.name}</span>
                          <span className="font-mono text-xs px-1.5 py-0.2 rounded bg-slate-800 text-indigo-300">
                            L{role.clearanceLevel}
                          </span>
                        </div>
                        <div className="text-slate-400 mt-0.5">{role.title}</div>
                        <div className="text-slate-500 text-[11px] mt-0.5">
                          Clearance: <span className="font-mono text-slate-300">{role.clearanceName}</span>
                        </div>
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-indigo-400 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

      </div>
    </header>
  );
};
