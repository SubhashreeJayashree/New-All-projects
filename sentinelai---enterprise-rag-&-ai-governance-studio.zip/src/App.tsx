import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { RAGExplorer } from './components/RAGExplorer';
import { GuardrailsPlayground } from './components/GuardrailsPlayground';
import { AgentCouncilView } from './components/AgentCouncilView';
import { VoiceAgentStudio } from './components/VoiceAgentStudio';
import { TextClassifierLab } from './components/TextClassifierLab';
import { MonitoringAndAudit } from './components/MonitoringAndAudit';
import { USER_ROLES, INITIAL_KNOWLEDGE_BASE, INITIAL_AUDIT_LOGS } from './data/mockData';
import { UserRole, DocumentChunk, AuditBlock } from './types';
import { Shield, Database, Lock, Users, Mic, Cpu, Activity } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('rag');
  const [activeRole, setActiveRole] = useState<UserRole>(USER_ROLES[0]);
  const [documents, setDocuments] = useState<DocumentChunk[]>(INITIAL_KNOWLEDGE_BASE);
  const [auditChain, setAuditChain] = useState<AuditBlock[]>(INITIAL_AUDIT_LOGS);

  const handleAddAuditBlock = (newBlock: AuditBlock) => {
    setAuditChain(prev => {
      // Connect to latest block hash
      const prevHash = prev.length > 0 ? prev[prev.length - 1].blockHash : '0'.repeat(64);
      const updatedBlock = {
        ...newBlock,
        index: prev.length,
        prevHash
      };
      return [...prev, updatedBlock];
    });
  };

  const tabs = [
    { id: 'rag', label: 'RAG Knowledge', icon: Database, badge: `${documents.length} docs` },
    { id: 'guardrails', label: 'Guardrails Gate', icon: Shield, badge: 'Inbound/Outbound' },
    { id: 'agents', label: 'Agent Council', icon: Users, badge: 'Cross-Model' },
    { id: 'voice', label: 'Voice Studio', icon: Mic, badge: 'Full-Duplex' },
    { id: 'classifier', label: 'Text Classifier', icon: Cpu, badge: '<1ms Hybrid' },
    { id: 'monitoring', label: 'Audit & Metrics', icon: Activity, badge: 'SHA-256' },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Navbar Contract */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeRole={activeRole}
        setActiveRole={setActiveRole}
      />

      {/* Secondary Quick Navigation Bar for Mobile / Tablet / Fast Switching */}
      <div className="border-b border-slate-800/80 bg-slate-900/50 backdrop-blur px-6 py-2">
        <div className="max-w-7xl mx-auto flex items-center justify-between overflow-x-auto gap-2">
          <div className="flex items-center gap-1.5 min-w-max">
            {tabs.map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs transition-colors cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0" />
                  <span>{tab.label}</span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                    isActive ? 'bg-indigo-700/60 text-indigo-100' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {tab.badge}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="hidden md:flex items-center gap-3 text-xs text-slate-400 shrink-0 font-mono">
            <span>Clearance: <strong className="text-indigo-400">{activeRole.clearanceName} (L{activeRole.clearanceLevel})</strong></span>
            <span>·</span>
            <span>Immutable Blocks: <strong className="text-slate-200">{auditChain.length}</strong></span>
          </div>
        </div>
      </div>

      {/* Main Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 md:p-8">
        {activeTab === 'rag' && (
          <RAGExplorer
            activeRole={activeRole}
            documents={documents}
            setDocuments={setDocuments}
            onAddAuditBlock={handleAddAuditBlock}
          />
        )}

        {activeTab === 'guardrails' && (
          <GuardrailsPlayground
            activeRole={activeRole}
            onAddAuditBlock={handleAddAuditBlock}
          />
        )}

        {activeTab === 'agents' && (
          <AgentCouncilView
            onAddAuditBlock={handleAddAuditBlock}
          />
        )}

        {activeTab === 'voice' && (
          <VoiceAgentStudio />
        )}

        {activeTab === 'classifier' && (
          <TextClassifierLab />
        )}

        {activeTab === 'monitoring' && (
          <MonitoringAndAudit
            activeRole={activeRole}
            auditChain={auditChain}
            setAuditChain={setAuditChain}
          />
        )}
      </main>

      {/* Quiet Corporate Footer adhering to section 1.B */}
      <footer className="border-t border-slate-900 bg-slate-950 px-6 py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            SentinelAI Enterprise RAG, RBAC & AI Governance Platform · ISO 27001 & SOC 2 Type II Architecture
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Query-Time Lattice Enforced</span>
            <span>·</span>
            <span>Cryptographic WebCrypto Proofs</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
