export type RoleClearance = 'PUBLIC' | 'INTERNAL' | 'CONFIDENTIAL' | 'TOP_SECRET';

export interface UserRole {
  id: string;
  name: string;
  title: string;
  clearanceLevel: number; // 1: Public, 2: Internal, 3: Confidential, 4: Top Secret
  clearanceName: RoleClearance;
  department: string;
  allowedActions: string[];
}

export interface DocumentChunk {
  id: string;
  docId: string;
  docTitle: string;
  clearanceLevel: number;
  clearanceName: RoleClearance;
  category: string;
  content: string;
  hash: string;
  metadata: {
    author: string;
    department: string;
    lastUpdated: string;
    version: string;
  };
}

export interface GuardrailCheck {
  name: string;
  passed: boolean;
  score: number;
  latencyMs: number;
  details: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export interface GuardrailResult {
  allowed: boolean;
  riskScore: number; // 0 - 100
  promptInjectionDetected: boolean;
  piiDetected: boolean;
  redactedText: string;
  originalText: string;
  detectedPII: Array<{ type: string; value: string; masked: string }>;
  checks: GuardrailCheck[];
  outboundCheck?: {
    faithfulnessScore: number;
    hallucinationRisk: 'low' | 'medium' | 'high';
    groundingConfidence: 'well-grounded' | 'moderate' | 'low';
    toxicityScore: number;
    retriedWithExpandedK: boolean;
  };
}

export interface AuditBlock {
  index: number;
  timestamp: string;
  actor: string;
  role: string;
  action: string;
  querySummary: string;
  clearanceLevel: number;
  guardrailStatus: 'PASSED' | 'BLOCKED' | 'FLAGGED';
  payloadHash: string;
  prevHash: string;
  blockHash: string;
  isTampered?: boolean;
}

export interface AgentMessage {
  id: string;
  agentRole: 'Architect' | 'Developer' | 'Security Auditor' | 'Policy Enforcer';
  agentName: string;
  avatarColor: string;
  timestamp: string;
  status: 'planning' | 'coding' | 'auditing' | 'approved' | 'rejected';
  thought: string;
  content: string;
  codeSnippet?: string;
  diffSummary?: string;
}

export interface AgentTask {
  id: string;
  title: string;
  description: string;
  status: 'idle' | 'running' | 'completed' | 'failed';
  currentStep: number;
  totalSteps: number;
  workQueue: string[];
  messages: AgentMessage[];
}

export interface VoiceMetric {
  frustrationIndex: number; // 0 - 100
  speechValence: 'Positive' | 'Neutral' | 'Frustrated' | 'Urgent';
  speakingRateWpm: number;
  pitchVariabilityHz: number;
  biometricConfidence: number; // 0 - 100
  mfaVerified: boolean;
}

export interface VoiceMessage {
  id: string;
  sender: 'user' | 'agent';
  text: string;
  timestamp: string;
  emotionTag?: string;
  latencyMs?: number;
  guardrailNotes?: string;
}

export interface TextClassificationResult {
  id: string;
  inputText: string;
  category: 'Spam' | 'Account Issue' | 'Security Threat' | 'General Query' | 'High Risk PII';
  resolvedTier: 'Tier 1 (Regex Rule)' | 'Tier 2 (TF-IDF Statistical ML)' | 'Tier 3 (LLM Fallback)';
  confidence: number; // 0 - 100%
  latencyMs: number;
  costIncurredUsd: number;
  ruleMatched?: string;
}
