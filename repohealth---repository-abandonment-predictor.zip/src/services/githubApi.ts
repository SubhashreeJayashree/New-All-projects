export interface GitHubRepoDetails {
  fullName: string;
  owner: string;
  name: string;
  description: string;
  stars: number;
  forks: number;
  openIssuesCount: number;
  pushedAt: string;
  createdAt: string;
  htmlUrl: string;
  extractedFeatures: [number, number, number, number, number, number];
  rateLimitRemaining?: number;
}

export async function fetchGitHubRepoMetrics(ownerAndRepo: string): Promise<GitHubRepoDetails> {
  const cleanInput = ownerAndRepo
    .trim()
    .replace(/^https?:\/\/github\.com\//i, '')
    .replace(/\/$/, '');

  const parts = cleanInput.split('/');
  if (parts.length !== 2 || !parts[0] || !parts[1]) {
    throw new Error('Please enter a valid format, such as "facebook/react" or "expressjs/express".');
  }

  const [owner, repo] = parts;
  const baseUrl = `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`;

  // 1. Fetch main repo metadata
  const repoRes = await fetch(baseUrl, {
    headers: {
      Accept: 'application/vnd.github.v3+json',
    },
  });

  if (repoRes.status === 404) {
    throw new Error(`Repository "${owner}/${repo}" was not found on GitHub. Check the spelling or ensure it is public.`);
  }

  if (repoRes.status === 403 || repoRes.status === 429) {
    throw new Error('GitHub API rate limit reached for unauthenticated requests. You can adjust the metric sliders manually or use one of the curated presets below.');
  }

  if (!repoRes.ok) {
    throw new Error(`GitHub API error (${repoRes.status}): ${repoRes.statusText}`);
  }

  const repoData = await repoRes.json();
  const rateLimitRemaining = Number(repoRes.headers.get('x-ratelimit-remaining')) || undefined;

  // 2. Calculate days since last commit / push
  const pushedDate = new Date(repoData.pushed_at || repoData.updated_at);
  const now = new Date();
  const diffDays = Math.max(0, Math.round((now.getTime() - pushedDate.getTime()) / (1000 * 60 * 60 * 24)));
  const daysSinceCommit = Math.min(500, diffDays);

  // 3. Fetch recent commits to compute 90-day velocity
  let commits90 = 15; // default fallback if commit list restricted
  try {
    const ninetyDaysAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000).toISOString();
    const commitsRes = await fetch(`${baseUrl}/commits?since=${ninetyDaysAgo}&per_page=100`, {
      headers: { Accept: 'application/vnd.github.v3+json' },
    });
    if (commitsRes.ok) {
      const commitList = await commitsRes.json();
      if (Array.isArray(commitList)) {
        commits90 = commitList.length;
      }
    }
  } catch {
    // Keep reasonable estimate
  }

  // 4. Fetch releases to compute releases last year
  let releaseCount = 0;
  try {
    const releasesRes = await fetch(`${baseUrl}/releases?per_page=30`, {
      headers: { Accept: 'application/vnd.github.v3+json' },
    });
    if (releasesRes.ok) {
      const releaseList = await releasesRes.json();
      if (Array.isArray(releaseList)) {
        const oneYearAgo = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
        releaseCount = releaseList.filter((r: { published_at?: string }) => {
          if (!r.published_at) return false;
          return new Date(r.published_at) >= oneYearAgo;
        }).length;
      }
    }
  } catch {
    releaseCount = 0;
  }

  // 5. Contributors count estimate
  let contributorCount = 5;
  try {
    const contribRes = await fetch(`${baseUrl}/contributors?per_page=30&anon=true`, {
      headers: { Accept: 'application/vnd.github.v3+json' },
    });
    if (contribRes.ok) {
      const contribList = await contribRes.json();
      if (Array.isArray(contribList)) {
        contributorCount = Math.min(100, Math.max(1, contribList.length));
      }
    }
  } catch {
    contributorCount = 5;
  }

  // 6. Open issues ratio approximation
  // GitHub returns `open_issues_count` (which includes open pull requests).
  // Repositories typically have lifetime closed issues ~ 2x to 5x open issues.
  const openIssues = repoData.open_issues_count || 0;
  const estimatedTotalIssues = Math.max(openIssues * 2.5, 50);
  const openIssuesRatio = Number(Math.min(0.99, Math.max(0.05, openIssues / estimatedTotalIssues)).toFixed(2));

  // 7. Avg response time proxy (based on recent activity & open backlog)
  let avgResponseDays = 3;
  if (daysSinceCommit > 180) {
    avgResponseDays = 90;
  } else if (daysSinceCommit > 45) {
    avgResponseDays = 25;
  } else if (openIssues > 500) {
    avgResponseDays = 8;
  } else {
    avgResponseDays = 2;
  }

  const extractedFeatures: [number, number, number, number, number, number] = [
    daysSinceCommit,
    openIssuesRatio,
    contributorCount,
    commits90,
    avgResponseDays,
    releaseCount,
  ];

  return {
    fullName: repoData.full_name || `${owner}/${repo}`,
    owner: repoData.owner?.login || owner,
    name: repoData.name || repo,
    description: repoData.description || 'Public software repository',
    stars: repoData.stargazers_count || 0,
    forks: repoData.forks_count || 0,
    openIssuesCount: openIssues,
    pushedAt: repoData.pushed_at || new Date().toISOString(),
    createdAt: repoData.created_at || new Date().toISOString(),
    htmlUrl: repoData.html_url || `https://github.com/${owner}/${repo}`,
    extractedFeatures,
    rateLimitRemaining,
  };
}
