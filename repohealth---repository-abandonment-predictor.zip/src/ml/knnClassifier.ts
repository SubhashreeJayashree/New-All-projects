import { FEATURE_DEFINITIONS, LABEL_INFO, RepoSample } from '../data/benchmarkDataset';

export type DistanceMetric = 'euclidean' | 'manhattan' | 'chebyshev' | 'cosine';

export interface NearestNeighborResult {
  sample: RepoSample;
  distance: number;
  normalizedDistance: number;
  weight: number;
}

export interface FeatureImpact {
  featureId: string;
  featureName: string;
  rawValue: number;
  unit: string;
  normalizedValue: number;
  impactScore: number; // positive = pushes towards healthy, negative = pushes towards abandoned
  riskContributionPercent: number;
  status: 'safe' | 'warning' | 'danger';
  insight: string;
}

export interface PredictionResult {
  predictedLabel: 0 | 1 | 2;
  labelName: string;
  confidence: number;
  classProbabilities: [number, number, number];
  nearestNeighbors: NearestNeighborResult[];
  featureImpacts: FeatureImpact[];
  primaryRiskFactor: string;
  maintainerRecommendation: string;
  healthIndexScore: number; // 0 to 100
}

export interface ModelMetrics {
  totalSamples: number;
  accuracy: number;
  macroPrecision: number;
  macroRecall: number;
  macroF1: number;
  confusionMatrix: number[][]; // [actual][predicted]
  classMetrics: {
    label: string;
    precision: number;
    recall: number;
    f1: number;
    support: number;
  }[];
}

export const MAX_VALUES = [500, 1.0, 60, 120, 90, 12];
export const MIN_VALUES = [0, 0, 1, 0, 0, 0];

export function normalizeFeatures(features: [number, number, number, number, number, number]): number[] {
  return features.map((val, idx) => {
    const min = MIN_VALUES[idx];
    const max = MAX_VALUES[idx];
    const clamped = Math.max(min, Math.min(max, val));
    return (clamped - min) / (max - min);
  });
}

export function computeDistance(a: number[], b: number[], metric: DistanceMetric = 'euclidean'): number {
  switch (metric) {
    case 'manhattan':
      return a.reduce((sum, val, idx) => sum + Math.abs(val - b[idx]), 0);
    case 'chebyshev':
      return Math.max(...a.map((val, idx) => Math.abs(val - b[idx])));
    case 'cosine': {
      let dot = 0;
      let normA = 0;
      let normB = 0;
      for (let i = 0; i < a.length; i++) {
        dot += a[i] * b[i];
        normA += a[i] * a[i];
        normB += b[i] * b[i];
      }
      if (normA === 0 || normB === 0) return 1;
      const sim = dot / (Math.sqrt(normA) * Math.sqrt(normB));
      return 1 - Math.max(-1, Math.min(1, sim));
    }
    case 'euclidean':
    default:
      return Math.sqrt(a.reduce((sum, val, idx) => sum + Math.pow(val - b[idx], 2), 0));
  }
}

export function runKnnPredict(
  inputFeatures: [number, number, number, number, number, number],
  dataset: RepoSample[],
  k: number = 3,
  metric: DistanceMetric = 'euclidean',
  weighted: boolean = true
): PredictionResult {
  const normInput = normalizeFeatures(inputFeatures);

  const neighborDistances: { sample: RepoSample; distance: number; weight: number }[] = dataset.map((item) => {
    const normItem = normalizeFeatures(item.features);
    const dist = computeDistance(normInput, normItem, metric);
    // Weight inversely proportional to distance (add epsilon to avoid div by zero)
    const weight = weighted ? 1 / (dist + 0.001) : 1;
    return {
      sample: item,
      distance: dist,
      weight,
    };
  });

  neighborDistances.sort((a, b) => a.distance - b.distance);
  const topK = neighborDistances.slice(0, Math.min(k, dataset.length));

  // Compute votes
  const labelWeights = [0, 0, 0];
  let totalWeight = 0;

  topK.forEach((n) => {
    labelWeights[n.sample.label] += n.weight;
    totalWeight += n.weight;
  });

  const probabilities: [number, number, number] = [
    totalWeight > 0 ? labelWeights[0] / totalWeight : 0.33,
    totalWeight > 0 ? labelWeights[1] / totalWeight : 0.33,
    totalWeight > 0 ? labelWeights[2] / totalWeight : 0.34,
  ];

  // Pick winner
  let bestLabel: 0 | 1 | 2 = 0;
  let maxWeight = -1;
  labelWeights.forEach((w, idx) => {
    if (w > maxWeight) {
      maxWeight = w;
      bestLabel = idx as 0 | 1 | 2;
    }
  });

  const maxDist = Math.max(...topK.map((n) => n.distance), 1);
  const formattedNeighbors: NearestNeighborResult[] = topK.map((n) => ({
    sample: n.sample,
    distance: Number(n.distance.toFixed(4)),
    normalizedDistance: Number((n.distance / maxDist).toFixed(3)),
    weight: Number(n.weight.toFixed(3)),
  }));

  // Feature impact analysis
  const featureImpacts = analyzeFeatureImpacts(inputFeatures, normInput);

  // Health index score calculation (0 to 100)
  // 100 = perfectly vibrant active project, 0 = completely dead
  const healthyWeight = probabilities[0] * 100;
  const atRiskWeight = probabilities[1] * 45;
  const abandonedWeight = probabilities[2] * 0;
  const healthIndexScore = Math.round(healthyWeight + atRiskWeight + abandonedWeight);

  // Recommendations and bottleneck identification
  const primaryRisk = featureImpacts.sort((a, b) => a.impactScore - b.impactScore)[0];
  const primaryRiskFactor =
    bestLabel === 0
      ? 'Repository demonstrates active maintainer cadence and minimal operational backlog.'
      : `${primaryRisk.featureName} (${primaryRisk.rawValue} ${primaryRisk.unit}) is the critical bottleneck.`;

  const maintainerRecommendation = generateRecommendation(bestLabel, inputFeatures);

  return {
    predictedLabel: bestLabel,
    labelName: LABEL_INFO[bestLabel].name,
    confidence: Number((probabilities[bestLabel] * 100).toFixed(1)),
    classProbabilities: [
      Number(probabilities[0].toFixed(3)),
      Number(probabilities[1].toFixed(3)),
      Number(probabilities[2].toFixed(3)),
    ],
    nearestNeighbors: formattedNeighbors,
    featureImpacts,
    primaryRiskFactor,
    maintainerRecommendation,
    healthIndexScore,
  };
}

function analyzeFeatureImpacts(
  raw: [number, number, number, number, number, number],
  norm: number[]
): FeatureImpact[] {
  // Ideal healthy benchmarks in normalized space:
  // daysSinceCommit: ~0.02 (7 days), openIssuesRatio: ~0.15, contributorCount: ~0.7 (40+),
  // commits90: ~0.8 (100+), avgResponseDays: ~0.05 (4 days), releaseCount: ~0.6 (7+)
  const idealNorm = [0.02, 0.15, 0.7, 0.8, 0.05, 0.6];

  return FEATURE_DEFINITIONS.map((def, idx) => {
    const rawVal = raw[idx];
    const normVal = norm[idx];
    const isHigherBetter = def.healthierDirection === 'higher';

    // delta: positive = favorable/healthy, negative = alarming/risk
    const delta = isHigherBetter ? normVal - idealNorm[idx] : idealNorm[idx] - normVal;

    let status: 'safe' | 'warning' | 'danger' = 'safe';
    let insight = '';

    if (idx === 0) {
      // Days since commit
      if (rawVal <= 14) {
        status = 'safe';
        insight = 'High commit cadence; active commits within past two weeks.';
      } else if (rawVal <= 60) {
        status = 'warning';
        insight = 'Commit lag observed; maintainer activity slowing down.';
      } else {
        status = 'danger';
        insight = 'Critical commit hiatus (>60 days without code pushes).';
      }
    } else if (idx === 1) {
      // Open issues ratio
      if (rawVal <= 0.3) {
        status = 'safe';
        insight = 'Low backlog; majority of submitted issues successfully resolved.';
      } else if (rawVal <= 0.65) {
        status = 'warning';
        insight = 'Moderate issue debt; unresolved bug reports accumulating.';
      } else {
        status = 'danger';
        insight = 'Severe issue backlog; community reports remain unanswered.';
      }
    } else if (idx === 2) {
      // Contributor count
      if (rawVal >= 15) {
        status = 'safe';
        insight = 'Strong distributed bus factor across multiple contributors.';
      } else if (rawVal >= 3) {
        status = 'warning';
        insight = 'Limited maintainer pool; vulnerable to single-contributor burnout.';
      } else {
        status = 'danger';
        insight = 'Solo maintainer bottleneck with zero backup committers.';
      }
    } else if (idx === 3) {
      // Commits last 90 days
      if (rawVal >= 40) {
        status = 'safe';
        insight = 'High development velocity with continuous code integration.';
      } else if (rawVal >= 10) {
        status = 'warning';
        insight = 'Sparse quarterly activity; maintenance pacing is low.';
      } else {
        status = 'danger';
        insight = 'Near-zero code changes in trailing 90-day window.';
      }
    } else if (idx === 4) {
      // Avg issue response days
      if (rawVal <= 3) {
        status = 'safe';
        insight = 'Rapid first-response SLA; maintainers engage community quickly.';
      } else if (rawVal <= 15) {
        status = 'warning';
        insight = 'Triage latency; users wait weeks for feedback.';
      } else {
        status = 'danger';
        insight = 'Prolonged triage paralysis; issues go unacknowledged for months.';
      }
    } else {
      // Releases last year
      if (rawVal >= 4) {
        status = 'safe';
        insight = 'Predictable release schedule and regular version bumps.';
      } else if (rawVal >= 1) {
        status = 'warning';
        insight = 'Infrequent deployment; users rely on stale tags.';
      } else {
        status = 'danger';
        insight = 'No releases published in over 12 months.';
      }
    }

    // Impact score roughly between -1.0 and +1.0
    const impactScore = Math.max(-1, Math.min(1, delta * 1.5));
    // Risk contribution percentage (larger if negative delta)
    const riskFactor = delta < 0 ? Math.abs(delta) : 0.05;

    return {
      featureId: def.id,
      featureName: def.name,
      rawValue: rawVal,
      unit: def.unit,
      normalizedValue: Number(normVal.toFixed(3)),
      impactScore: Number(impactScore.toFixed(3)),
      riskContributionPercent: 0, // will normalize below
      status,
      insight,
    };
  });
}

function generateRecommendation(
  label: 0 | 1 | 2,
  raw: [number, number, number, number, number, number]
): string {
  if (label === 0) {
    return 'Repository is structurally sound. Continue automated CI/CD gating and keep grooming community pull requests to expand the maintainer bench.';
  }
  if (label === 1) {
    const suggestions: string[] = [];
    if (raw[0] > 30) suggestions.push('merge pending maintenance PRs or publish a patch branch to restore commit cadence');
    if (raw[1] > 0.5) suggestions.push('triage and close stale discussions or obsolete issues');
    if (raw[2] < 5) suggestions.push('onboard at least one co-maintainer to mitigate bus factor risk');
    if (raw[5] === 0) suggestions.push('cut a formal semantic release tag to reassure downstream consumers');
    return `To prevent total repository abandonment: ${suggestions.join('; ')}.`;
  }
  return 'Repository exhibits strong signatures of permanent abandonment. Downstream enterprise users should consider forking the codebase, pinning legacy versions, or migrating to active alternatives.';
}

export function evaluateModelPerformance(
  dataset: RepoSample[],
  k: number = 3,
  metric: DistanceMetric = 'euclidean'
): ModelMetrics {
  const n = dataset.length;
  const confusion = [
    [0, 0, 0],
    [0, 0, 0],
    [0, 0, 0],
  ];

  // Leave-one-out cross validation
  let correct = 0;
  for (let i = 0; i < n; i++) {
    const testSample = dataset[i];
    const trainSubset = dataset.filter((_, idx) => idx !== i);
    const pred = runKnnPredict(testSample.features, trainSubset, k, metric, true);
    confusion[testSample.label][pred.predictedLabel]++;
    if (pred.predictedLabel === testSample.label) {
      correct++;
    }
  }

  const accuracy = n > 0 ? correct / n : 0;

  // Per-class metrics
  const classMetrics = [0, 1, 2].map((classIdx) => {
    const label = LABEL_INFO[classIdx].name;
    const tp = confusion[classIdx][classIdx];
    const fp = confusion.reduce((sum, row, rIdx) => (rIdx !== classIdx ? sum + row[classIdx] : sum), 0);
    const fn = confusion[classIdx].reduce((sum, val, cIdx) => (cIdx !== classIdx ? sum + val : sum), 0);
    const support = confusion[classIdx].reduce((sum, val) => sum + val, 0);

    const precision = tp + fp > 0 ? tp / (tp + fp) : 0;
    const recall = tp + fn > 0 ? tp / (tp + fn) : 0;
    const f1 = precision + recall > 0 ? (2 * precision * recall) / (precision + recall) : 0;

    return {
      label,
      precision: Number(precision.toFixed(3)),
      recall: Number(recall.toFixed(3)),
      f1: Number(f1.toFixed(3)),
      support,
    };
  });

  const macroPrecision = classMetrics.reduce((s, c) => s + c.precision, 0) / 3;
  const macroRecall = classMetrics.reduce((s, c) => s + c.recall, 0) / 3;
  const macroF1 = classMetrics.reduce((s, c) => s + c.f1, 0) / 3;

  return {
    totalSamples: n,
    accuracy: Number(accuracy.toFixed(3)),
    macroPrecision: Number(macroPrecision.toFixed(3)),
    macroRecall: Number(macroRecall.toFixed(3)),
    macroF1: Number(macroF1.toFixed(3)),
    confusionMatrix: confusion,
    classMetrics,
  };
}
