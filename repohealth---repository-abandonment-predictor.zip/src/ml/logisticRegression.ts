import { RepoSample } from '../data/benchmarkDataset';
import { normalizeFeatures } from './knnClassifier';

export interface LogisticRegressionModel {
  // weights: 3 classes x 6 features
  weights: number[][];
  // biases: 3 classes
  biases: number[];
  lossHistory: number[];
  epochsTrained: number;
}

// Initial empirically calibrated weights from software repository survival analysis
export const DEFAULT_LOGISTIC_MODEL: LogisticRegressionModel = {
  // Classes: [0: Healthy, 1: At Risk, 2: Abandoned]
  // Features: [daysSinceCommit, openIssuesRatio, contributorCount, commits90, avgResponseDays, releaseCount]
  weights: [
    [-3.8, -2.4, 2.9, 3.5, -2.8, 2.7], // Class 0 (Healthy: high commits, low lag, low issues, more releases)
    [0.8, 1.2, -0.6, -1.1, 0.9, -0.8],  // Class 1 (At Risk: moderate lag, rising issue ratio, falling velocity)
    [3.9, 3.1, -2.8, -3.2, 2.6, -2.5],  // Class 2 (Abandoned: extreme commit lag, 100% backlog, zero commits)
  ],
  biases: [1.2, 0.1, -1.8],
  lossHistory: [0.65, 0.42, 0.28, 0.19, 0.14],
  epochsTrained: 50,
};

export function softmax(logits: number[]): [number, number, number] {
  const maxLogit = Math.max(...logits);
  const exps = logits.map((l) => Math.exp(l - maxLogit));
  const sum = exps.reduce((a, b) => a + b, 0);
  return [exps[0] / sum, exps[1] / sum, exps[2] / sum];
}

export function predictLogisticRegression(
  features: [number, number, number, number, number, number],
  model: LogisticRegressionModel = DEFAULT_LOGISTIC_MODEL
): {
  predictedLabel: 0 | 1 | 2;
  probabilities: [number, number, number];
  logits: number[];
} {
  const norm = normalizeFeatures(features);
  const logits = model.weights.map((wRow, cIdx) => {
    let dot = model.biases[cIdx];
    for (let f = 0; f < norm.length; f++) {
      dot += wRow[f] * norm[f];
    }
    return dot;
  });

  const probs = softmax(logits);
  let bestIdx: 0 | 1 | 2 = 0;
  let maxP = -1;
  probs.forEach((p, idx) => {
    if (p > maxP) {
      maxP = p;
      bestIdx = idx as 0 | 1 | 2;
    }
  });

  return {
    predictedLabel: bestIdx,
    probabilities: [
      Number(probs[0].toFixed(3)),
      Number(probs[1].toFixed(3)),
      Number(probs[2].toFixed(3)),
    ],
    logits: logits.map((l) => Number(l.toFixed(3))),
  };
}

export function trainLogisticRegressionStep(
  dataset: RepoSample[],
  currentModel: LogisticRegressionModel,
  learningRate: number = 0.08,
  epochs: number = 10
): LogisticRegressionModel {
  const newWeights = currentModel.weights.map((row) => [...row]);
  const newBiases = [...currentModel.biases];
  const newLossHistory = [...currentModel.lossHistory];

  const n = dataset.length;
  if (n === 0) return currentModel;

  for (let ep = 0; ep < epochs; ep++) {
    // Gradients
    const dW = [
      [0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0],
    ];
    const dB = [0, 0, 0];
    let totalLoss = 0;

    dataset.forEach((sample) => {
      const norm = normalizeFeatures(sample.features);
      const logits = newWeights.map((wRow, cIdx) => {
        let dot = newBiases[cIdx];
        for (let f = 0; f < norm.length; f++) {
          dot += wRow[f] * norm[f];
        }
        return dot;
      });
      const probs = softmax(logits);

      // Cross entropy loss: -log(p_true)
      const trueClass = sample.label;
      totalLoss += -Math.log(Math.max(1e-12, probs[trueClass]));

      // Gradient of cross-entropy with softmax: (probs[c] - y_onehot[c])
      for (let c = 0; c < 3; c++) {
        const error = probs[c] - (c === trueClass ? 1 : 0);
        dB[c] += error;
        for (let f = 0; f < 6; f++) {
          dW[c][f] += error * norm[f];
        }
      }
    });

    const avgLoss = totalLoss / n;
    newLossHistory.push(Number(avgLoss.toFixed(4)));

    // Update weights with L2 regularization
    const reg = 0.001;
    for (let c = 0; c < 3; c++) {
      newBiases[c] -= (learningRate * dB[c]) / n;
      for (let f = 0; f < 6; f++) {
        newWeights[c][f] -= (learningRate * (dW[c][f] / n + reg * newWeights[c][f]));
      }
    }
  }

  return {
    weights: newWeights,
    biases: newBiases,
    lossHistory: newLossHistory.slice(-20),
    epochsTrained: currentModel.epochsTrained + epochs,
  };
}
