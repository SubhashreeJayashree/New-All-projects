import React, { useState } from 'react';
import { TopBar, ActiveTab } from './components/TopBar';
import { PredictorStudio } from './components/PredictorStudio';
import { DatasetMatrix } from './components/DatasetMatrix';
import { StandaloneExportView } from './components/StandaloneExportView';
import { InternshipGuide } from './components/InternshipGuide';
import { INITIAL_BENCHMARK_DATASET, RepoSample } from './data/benchmarkDataset';
import {
  LogisticRegressionModel,
  DEFAULT_LOGISTIC_MODEL,
} from './ml/logisticRegression';
import {
  STANDALONE_HTML,
  STANDALONE_CSS,
  STANDALONE_JS,
  downloadFile,
} from './utils/standaloneBundleGenerator';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('predictor');
  const [dataset, setDataset] = useState<RepoSample[]>(INITIAL_BENCHMARK_DATASET);
  const [logisticModel, setLogisticModel] = useState<LogisticRegressionModel>(DEFAULT_LOGISTIC_MODEL);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  const handleAddSample = (sample: RepoSample) => {
    setDataset((prev) => [sample, ...prev]);
    showToast(`Added ${sample.name} to the empirical dataset!`);
  };

  const handleDownloadAll = () => {
    downloadFile('index.html', STANDALONE_HTML, 'text/html');
    setTimeout(() => {
      downloadFile('style.css', STANDALONE_CSS, 'text/css');
    }, 250);
    setTimeout(() => {
      downloadFile('script.js', STANDALONE_JS, 'text/javascript');
    }, 500);
    showToast('Downloaded index.html, style.css, and script.js!');
  };

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-100 flex flex-col font-sans selection:bg-sky-500/20 selection:text-sky-300">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 rounded-lg bg-sky-950 border border-sky-800/80 px-4 py-3 text-xs font-semibold text-sky-200 shadow-xl flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-sky-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Bar following 3-zone contract */}
      <TopBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onDownloadAll={handleDownloadAll}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTab === 'predictor' && (
          <PredictorStudio
            dataset={dataset}
            logisticModel={logisticModel}
            onOpenBundle={() => setActiveTab('bundle')}
          />
        )}

        {activeTab === 'dataset' && (
          <DatasetMatrix
            dataset={dataset}
            onAddSample={handleAddSample}
            logisticModel={logisticModel}
            onUpdateLogisticModel={(m) => {
              setLogisticModel(m);
              showToast('Updated Softmax Logistic Regression model parameters!');
            }}
          />
        )}

        {activeTab === 'bundle' && <StandaloneExportView />}

        {activeTab === 'guide' && <InternshipGuide />}
      </main>

      {/* Clean quiet footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-8 px-4 text-center text-xs text-slate-500">
        <div className="mx-auto max-w-7xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">RepoHealth</span>
            <span aria-hidden="true">·</span>
            <span>Empirical Software Engineering & Browser Machine Learning</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <button
              onClick={() => setActiveTab('predictor')}
              className="hover:text-slate-200 transition-colors"
            >
              Predictor
            </button>
            <button
              onClick={() => setActiveTab('dataset')}
              className="hover:text-slate-200 transition-colors"
            >
              Dataset Matrix
            </button>
            <button
              onClick={() => setActiveTab('bundle')}
              className="hover:text-slate-200 transition-colors"
            >
              Standalone Files
            </button>
            <button
              onClick={() => setActiveTab('guide')}
              className="hover:text-slate-200 transition-colors"
            >
              Research Guide
            </button>
          </div>
          <p>© 2026. Zero external backends. Pure client-side machine learning.</p>
        </div>
      </footer>
    </div>
  );
}
