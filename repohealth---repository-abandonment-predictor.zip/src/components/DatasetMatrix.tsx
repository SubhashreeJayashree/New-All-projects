import React, { useState } from 'react';
import {
  Database,
  PlusCircle,
  Play,
  RotateCcw,
  CheckCircle2,
  Table,
} from 'lucide-react';
import { LABEL_INFO, RepoSample } from '../data/benchmarkDataset';
import { evaluateModelPerformance } from '../ml/knnClassifier';
import {
  LogisticRegressionModel,
  trainLogisticRegressionStep,
  DEFAULT_LOGISTIC_MODEL,
} from '../ml/logisticRegression';

interface DatasetMatrixProps {
  dataset: RepoSample[];
  onAddSample: (sample: RepoSample) => void;
  logisticModel: LogisticRegressionModel;
  onUpdateLogisticModel: (model: LogisticRegressionModel) => void;
}

export const DatasetMatrix: React.FC<DatasetMatrixProps> = ({
  dataset,
  onAddSample,
  logisticModel,
  onUpdateLogisticModel,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLabelFilter, setSelectedLabelFilter] = useState<'all' | '0' | '1' | '2'>('all');
  const [showAddForm, setShowAddForm] = useState(false);

  // New sample form state
  const [newRepoName, setNewRepoName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newStars, setNewStars] = useState(1200);
  const [newDays, setNewDays] = useState(25);
  const [newRatio, setNewRatio] = useState(0.35);
  const [newContribs, setNewContribs] = useState(8);
  const [newCommits90, setNewCommits90] = useState(25);
  const [newResponse, setNewResponse] = useState(6.0);
  const [newReleases, setNewReleases] = useState(2);
  const [newLabel, setNewLabel] = useState<0 | 1 | 2>(0);

  // Cross validation evaluation
  const metrics = evaluateModelPerformance(dataset, 3, 'euclidean');

  // Filtered dataset
  const filteredDataset = dataset.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLabel =
      selectedLabelFilter === 'all' || item.label.toString() === selectedLabelFilter;
    return matchesSearch && matchesLabel;
  });

  const handleTrainEpochs = () => {
    const updated = trainLogisticRegressionStep(dataset, logisticModel, 0.1, 10);
    onUpdateLogisticModel(updated);
  };

  const handleResetWeights = () => {
    onUpdateLogisticModel({
      ...DEFAULT_LOGISTIC_MODEL,
      weights: DEFAULT_LOGISTIC_MODEL.weights.map((row) => [...row]),
      biases: [...DEFAULT_LOGISTIC_MODEL.biases],
      lossHistory: [...DEFAULT_LOGISTIC_MODEL.lossHistory],
    });
  };

  const handleSubmitNewSample = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRepoName.trim()) return;

    const [owner, name] = newRepoName.includes('/')
      ? newRepoName.split('/')
      : ['custom', newRepoName];

    const sample: RepoSample = {
      id: `custom-${Date.now()}`,
      name: newRepoName.trim(),
      owner: owner || 'custom',
      description: newDesc.trim() || 'Custom training repository',
      stars: Number(newStars) || 0,
      features: [
        Number(newDays),
        Number(newRatio),
        Number(newContribs),
        Number(newCommits90),
        Number(newResponse),
        Number(newReleases),
      ],
      label: newLabel,
      lastUpdatedYear: 2026,
    };

    onAddSample(sample);
    setShowAddForm(false);
    setNewRepoName('');
    setNewDesc('');
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Title */}
      <div>
        <div className="flex items-center gap-2 text-xs text-slate-400 font-medium tracking-wider uppercase mb-1">
          <span>Empirical Evaluation Suite</span>
          <span aria-hidden="true">·</span>
          <span>Cross-Validation & Ground Truth</span>
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
          Model Evaluation Matrix & Dataset
        </h1>
        <p className="mt-2 text-sm text-slate-400 max-w-3xl">
          Evaluated against {dataset.length} empirical software repositories using leave-one-out cross validation.
          Review the confusion matrix, class-specific precision/recall, and interactive dataset records.
        </p>
      </div>

      {/* KPI Metric Summary Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/60">
          <span className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Overall Accuracy
          </span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black font-mono text-emerald-400 tabular-nums">
              {(metrics.accuracy * 100).toFixed(1)}%
            </span>
            <span className="text-xs text-slate-500">Leave-one-out</span>
          </div>
        </div>

        <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/60">
          <span className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Macro F1-Score
          </span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black font-mono text-sky-400 tabular-nums">
              {metrics.macroF1.toFixed(3)}
            </span>
            <span className="text-xs text-slate-500">Harmonic mean</span>
          </div>
        </div>

        <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/60">
          <span className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Macro Precision
          </span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black font-mono text-white tabular-nums">
              {metrics.macroPrecision.toFixed(3)}
            </span>
            <span className="text-xs text-slate-500">Avg across 3 classes</span>
          </div>
        </div>

        <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/60">
          <span className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Benchmark Repositories
          </span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black font-mono text-white tabular-nums">
              {dataset.length}
            </span>
            <span className="text-xs text-slate-500">Empirical samples</span>
          </div>
        </div>
      </div>

      {/* Confusion Matrix & Class-wise Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Confusion Matrix (6 cols) */}
        <div className="lg:col-span-6 rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white">
              Leave-One-Out Confusion Matrix (k = 3)
            </h2>
            <span className="text-xs text-slate-500 font-mono">Actual vs Predicted</span>
          </div>

          <div className="overflow-x-auto pt-2">
            <table className="w-full text-center text-xs border-collapse">
              <thead>
                <tr>
                  <th className="py-2 px-3 text-left text-slate-500 font-normal">Actual \ Pred</th>
                  {LABEL_INFO.map((lbl) => (
                    <th key={lbl.id} className="py-2 px-3 font-semibold text-slate-300">
                      {lbl.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {LABEL_INFO.map((rowLbl, rIdx) => (
                  <tr key={rowLbl.id}>
                    <td className="py-3 px-3 text-left font-semibold text-slate-300">
                      {rowLbl.name}
                    </td>
                    {LABEL_INFO.map((colLbl, cIdx) => {
                      const count = metrics.confusionMatrix[rIdx][cIdx];
                      const isDiagonal = rIdx === cIdx;
                      return (
                        <td key={colLbl.id} className="py-3 px-3">
                          <span
                            className={`inline-block w-10 py-1.5 rounded font-mono font-bold tabular-nums text-sm ${
                              isDiagonal
                                ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/50'
                                : count > 0
                                ? 'bg-rose-950/60 text-rose-400 border border-rose-800/50'
                                : 'text-slate-600'
                            }`}
                          >
                            {count}
                          </span>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed pt-2 border-t border-slate-800">
            Green diagonal cells indicate correct classifications. Off-diagonal numbers show prediction errors
            occurring during leave-one-out validation.
          </p>
        </div>

        {/* Per-Class Detailed Performance (6 cols) */}
        <div className="lg:col-span-6 rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-4">
          <h2 className="text-base font-bold text-white">Class-Specific Performance Metrics</h2>
          <div className="overflow-x-auto pt-2">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-semibold">
                  <th className="py-2 px-3">Class Label</th>
                  <th className="py-2 px-3 text-right">Precision</th>
                  <th className="py-2 px-3 text-right">Recall</th>
                  <th className="py-2 px-3 text-right">F1 Score</th>
                  <th className="py-2 px-3 text-right">Support</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 text-slate-300">
                {metrics.classMetrics.map((cm) => (
                  <tr key={cm.label} className="hover:bg-slate-800/20">
                    <td className="py-3 px-3 font-semibold text-white">{cm.label}</td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-300">
                      {cm.precision.toFixed(3)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-300">
                      {cm.recall.toFixed(3)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-sky-400 font-bold">
                      {cm.f1.toFixed(3)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-500">
                      {cm.support}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* In-Browser Gradient Descent Trainer Card */}
          <div className="mt-4 p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-sky-400 flex items-center gap-1.5">
                <Play className="h-3.5 w-3.5" />
                <span>Softmax Logistic Regression In-Browser Trainer</span>
              </span>
              <span className="text-[11px] text-slate-400 font-mono">
                {logisticModel.epochsTrained} epochs
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleTrainEpochs}
                className="px-3.5 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs rounded-md transition-colors flex items-center gap-1.5"
              >
                <Play className="h-3 w-3" />
                <span>Train +10 Epochs (Gradient Descent)</span>
              </button>
              <button
                onClick={handleResetWeights}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700 text-xs rounded-md transition-colors flex items-center gap-1"
                title="Reset weights"
              >
                <RotateCcw className="h-3 w-3" />
                <span>Reset</span>
              </button>
            </div>

            <div className="text-[11px] text-slate-400">
              Loss curve (last 5 steps):{' '}
              <span className="font-mono text-slate-200">
                {logisticModel.lossHistory.slice(-5).join(' → ')}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Benchmark Dataset Table */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Table className="h-4 w-4 text-sky-400" />
              <span>Benchmark Repository Dataset</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Showing {filteredDataset.length} of {dataset.length} empirical records
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Search */}
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search repository name..."
              className="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            />

            {/* Label Filter */}
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
              <button
                onClick={() => setSelectedLabelFilter('all')}
                className={`px-2.5 py-1 rounded font-medium transition-colors ${
                  selectedLabelFilter === 'all' ? 'bg-slate-800 text-white' : 'text-slate-400'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setSelectedLabelFilter('0')}
                className={`px-2.5 py-1 rounded font-medium transition-colors ${
                  selectedLabelFilter === '0' ? 'bg-emerald-950 text-emerald-400' : 'text-slate-400'
                }`}
              >
                Healthy
              </button>
              <button
                onClick={() => setSelectedLabelFilter('1')}
                className={`px-2.5 py-1 rounded font-medium transition-colors ${
                  selectedLabelFilter === '1' ? 'bg-amber-950 text-amber-400' : 'text-slate-400'
                }`}
              >
                At Risk
              </button>
              <button
                onClick={() => setSelectedLabelFilter('2')}
                className={`px-2.5 py-1 rounded font-medium transition-colors ${
                  selectedLabelFilter === '2' ? 'bg-rose-950 text-rose-400' : 'text-slate-400'
                }`}
              >
                Abandoned
              </button>
            </div>

            {/* Add Sample Toggle */}
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-3.5 py-1.5 bg-sky-500/10 text-sky-400 border border-sky-500/30 hover:bg-sky-500/20 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <PlusCircle className="h-3.5 w-3.5" />
              <span>Add Sample</span>
            </button>
          </div>
        </div>

        {/* Add Sample Modal / Form */}
        {showAddForm && (
          <form
            onSubmit={handleSubmitNewSample}
            className="p-5 rounded-xl border border-sky-800/40 bg-slate-950 space-y-4"
          >
            <h3 className="text-sm font-bold text-sky-400">Add New Labeled Repository to Dataset</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Repository Name (owner/repo):</label>
                <input
                  type="text"
                  required
                  value={newRepoName}
                  onChange={(e) => setNewRepoName(e.target.value)}
                  placeholder="e.g. torvalds/linux"
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Description:</label>
                <input
                  type="text"
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="e.g. Linux kernel source tree"
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Ground Truth Label:</label>
                <select
                  value={newLabel}
                  onChange={(e) => setNewLabel(parseInt(e.target.value, 10) as 0 | 1 | 2)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                >
                  <option value={0}>0 - Healthy</option>
                  <option value={1}>1 - At Risk</option>
                  <option value={2}>2 - Abandoned</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-6 gap-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Days Commit Lag:</label>
                <input
                  type="number"
                  value={newDays}
                  onChange={(e) => setNewDays(parseFloat(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Open Issues Ratio:</label>
                <input
                  type="number"
                  step="0.01"
                  value={newRatio}
                  onChange={(e) => setNewRatio(parseFloat(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Contributors:</label>
                <input
                  type="number"
                  value={newContribs}
                  onChange={(e) => setNewContribs(parseFloat(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Commits 90d:</label>
                <input
                  type="number"
                  value={newCommits90}
                  onChange={(e) => setNewCommits90(parseFloat(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Avg Response (d):</label>
                <input
                  type="number"
                  step="0.5"
                  value={newResponse}
                  onChange={(e) => setNewResponse(parseFloat(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Releases (1yr):</label>
                <input
                  type="number"
                  value={newReleases}
                  onChange={(e) => setNewReleases(parseFloat(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs rounded transition-colors"
              >
                Save to Dataset
              </button>
            </div>
          </form>
        )}

        {/* Dataset Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-semibold bg-slate-950/40">
                <th className="py-2.5 px-3">Repository</th>
                <th className="py-2.5 px-3">Status Label</th>
                <th className="py-2.5 px-3 text-right">Commit Lag</th>
                <th className="py-2.5 px-3 text-right">Open Issues Ratio</th>
                <th className="py-2.5 px-3 text-right">Contributors</th>
                <th className="py-2.5 px-3 text-right">Commits (90d)</th>
                <th className="py-2.5 px-3 text-right">Response Time</th>
                <th className="py-2.5 px-3 text-right">Releases</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredDataset.map((sample) => {
                const lbl = LABEL_INFO[sample.label];
                return (
                  <tr key={sample.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-white">{sample.name}</div>
                      <div className="text-[11px] text-slate-500 line-clamp-1">{sample.description}</div>
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`font-semibold ${
                          sample.label === 0
                            ? 'text-emerald-400'
                            : sample.label === 1
                            ? 'text-amber-400'
                            : 'text-rose-400'
                        }`}
                      >
                        {lbl.name}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                      {sample.features[0]}d
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                      {(sample.features[1] * 100).toFixed(0)}%
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                      {sample.features[2]}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                      {sample.features[3]}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                      {sample.features[4]}d
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                      {sample.features[5]}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
