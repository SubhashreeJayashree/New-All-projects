import React, { useState } from 'react';
import {
  BookOpen,
  CheckCircle,
  HelpCircle,
  FileText,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

export const InternshipGuide: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const toggleFaq = (idx: number) => {
    setOpenFaq(openFaq === idx ? null : idx);
  };

  const vivaQuestions = [
    {
      q: 'Why did you choose traditional Machine Learning (k-NN) instead of an LLM or RAG pipeline?',
      a: 'Software repository sustainability requires deterministic, mathematically reproducible classification based on quantitative activity metrics (commit frequency, issue ratio, bus factor). LLMs are probabilistic text generators prone to hallucination, require expensive cloud GPUs or API keys, and cannot guarantee consistent distance metrics in numerical vector spaces. k-NN provides transparent decision boundaries, zero inference latency, 100% offline edge execution, and direct explainability via nearest empirical examples.',
    },
    {
      q: 'How does the feature normalization prevent large-scale metrics from dominating distance calculations?',
      a: 'Raw metrics vary across different units: days since commit can reach 500, whereas open issues ratio is bounded between 0 and 1. If unnormalized, Euclidean distance would be almost entirely determined by the days since commit. We apply Min-Max domain normalization: x_norm = (x - min) / (max - min), scaling every metric strictly into [0, 1] so each dimension contributes proportionately to the distance geometry.',
    },
    {
      q: 'What is the decision boundary rule used in your k-NN model?',
      a: 'Given a test feature vector x*, the model computes the Euclidean distance d(x*, x_i) to all N training vectors. It selects the top k neighbors with minimal distance. To prevent ties and reward closer analogs, we use inverse-distance weighting w_i = 1 / (d(x*, x_i) + ε). The final predicted class is argmax_c Σ_{i ∈ Top-K, y_i = c} w_i.',
    },
    {
      q: 'Why does this project qualify as a Computer Science & AI/ML project?',
      a: 'It combines empirical software engineering (mining software repositories, turnover analysis, maintainer bus factor) with core machine learning classification. The model extracts a 6-dimensional feature vector, evaluates nearest-neighbor manifolds, computes cross-validation performance matrices (Accuracy, Precision, Recall, Macro F1), and provides automated maintainer diagnostics.',
    },
    {
      q: 'How does this project differ from ready-made GitHub tools?',
      a: 'Most existing open-source metrics dashboards (like GitHub Insights) simply plot raw commit charts without predictive intelligence. RepoHealth trains a supervised classification model on labeled historical repositories to forecast future abandonment before complete project failure occurs, packaged in a zero-dependency client-side architecture.',
    },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Title */}
      <div>
        <div className="flex items-center gap-2 text-xs text-slate-400 font-medium tracking-wider uppercase mb-1">
          <span>MCA Generative AI & Machine Learning Internship</span>
          <span aria-hidden="true">·</span>
          <span>Project Defense & Thesis Guide</span>
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
          Internship Project Report & Viva Guide
        </h1>
        <p className="mt-2 text-sm text-slate-400 max-w-3xl">
          Everything you need for your MCA project presentation, seminar synopsis, and external examiner viva voce.
        </p>
      </div>

      {/* Synopsis Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Project Details */}
        <div className="p-6 rounded-xl border border-slate-800 bg-slate-900/60 space-y-4">
          <div className="flex items-center gap-2 text-sky-400">
            <FileText className="h-5 w-5" />
            <h2 className="text-base font-bold text-white">Project Identity & Specification</h2>
          </div>
          <dl className="space-y-3 text-xs">
            <div>
              <dt className="text-slate-400 font-semibold">Recommended Project Title:</dt>
              <dd className="text-white font-medium text-sm mt-0.5">
                RepoHealth: A Machine Learning Framework for Predicting Open-Source Software Repository Abandonment
              </dd>
            </div>
            <div>
              <dt className="text-slate-400 font-semibold">Academic Domain:</dt>
              <dd className="text-slate-200 mt-0.5">
                Artificial Intelligence & Machine Learning · Empirical Software Engineering
              </dd>
            </div>
            <div>
              <dt className="text-slate-400 font-semibold">Target Problem:</dt>
              <dd className="text-slate-300 leading-relaxed mt-0.5">
                Over 80% of open-source libraries eventually suffer from maintainer abandonment or developer burnout.
                Downstream applications frequently depend on unmaintained dependencies that introduce critical unpatched vulnerabilities.
                RepoHealth detects early warning signals before abandonment occurs.
              </dd>
            </div>
          </dl>
        </div>

        {/* Mathematical Formulations */}
        <div className="p-6 rounded-xl border border-slate-800 bg-slate-900/60 space-y-4">
          <div className="flex items-center gap-2 text-sky-400">
            <BookOpen className="h-5 w-5" />
            <h2 className="text-base font-bold text-white">Mathematical Formulations</h2>
          </div>
          <div className="space-y-3 text-xs font-mono">
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80">
              <span className="text-slate-400 block text-[11px] font-sans">1. Min-Max Normalization:</span>
              <span className="text-sky-300">x_norm[i] = (x[i] - min[i]) / (max[i] - min[i])</span>
            </div>
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80">
              <span className="text-slate-400 block text-[11px] font-sans">2. Euclidean Metric (L2 Distance):</span>
              <span className="text-sky-300">{"d(a, b) = √ [ Σ_{i=1}^6 (a_norm[i] - b_norm[i])² ]"}</span>
            </div>
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80">
              <span className="text-slate-400 block text-[11px] font-sans">3. Inverse Distance Weighting:</span>
              <span className="text-sky-300">w_i = 1 / (d(x, x_i) + 0.001)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Rationale Table */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-4">
        <h2 className="text-base font-bold text-white">Feature Selection & Empirical Literature Justification</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-semibold bg-slate-950/40">
                <th className="py-2.5 px-3">Metric</th>
                <th className="py-2.5 px-3">Dimension</th>
                <th className="py-2.5 px-3">Software Engineering Justification</th>
                <th className="py-2.5 px-3">Impact Direction</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-2.5 px-3 font-semibold text-white">Days Since Last Commit</td>
                <td className="py-2.5 px-3 font-mono text-slate-400">Temporal</td>
                <td className="py-2.5 px-3">Direct indicator of maintainer cadence; &gt;90 days indicates high risk.</td>
                <td className="py-2.5 px-3 text-rose-400">Higher = Worse</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-white">Open Issues Ratio</td>
                <td className="py-2.5 px-3 font-mono text-slate-400">Quality / Debt</td>
                <td className="py-2.5 px-3">Unresolved bugs relative to lifetime volume indicate triage backlog collapse.</td>
                <td className="py-2.5 px-3 text-rose-400">Higher = Worse</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-white">Active Contributors</td>
                <td className="py-2.5 px-3 font-mono text-slate-400">Social / Bus Factor</td>
                <td className="py-2.5 px-3">Reduces single-point-of-failure risk (bus factor = 1).</td>
                <td className="py-2.5 px-3 text-emerald-400">Higher = Healthier</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-white">Commits (Last 90d)</td>
                <td className="py-2.5 px-3 font-mono text-slate-400">Velocity</td>
                <td className="py-2.5 px-3">Measures quarterly code throughput and community momentum.</td>
                <td className="py-2.5 px-3 text-emerald-400">Higher = Healthier</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-white">Avg Issue Response Time</td>
                <td className="py-2.5 px-3 font-mono text-slate-400">Responsiveness</td>
                <td className="py-2.5 px-3">Turnaround time to first maintainer reply; prolonged silence discourages contributors.</td>
                <td className="py-2.5 px-3 text-rose-400">Higher = Worse</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-white">Releases (Last Year)</td>
                <td className="py-2.5 px-3 font-mono text-slate-400">Delivery</td>
                <td className="py-2.5 px-3">Demonstrates formal semantic versioning and deployment discipline.</td>
                <td className="py-2.5 px-3 text-emerald-400">Higher = Healthier</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Viva Voce FAQ Accordion */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-4">
        <div className="flex items-center gap-2 text-sky-400">
          <HelpCircle className="h-5 w-5" />
          <h2 className="text-base font-bold text-white">Viva Voce Preparation (Examiner Q&A)</h2>
        </div>
        <p className="text-xs text-slate-400">
          Click any question below to view the recommended defense answer for your MCA presentation.
        </p>

        <div className="space-y-3 pt-2">
          {vivaQuestions.map((item, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                className="rounded-lg border border-slate-800 bg-slate-950 overflow-hidden transition-colors"
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(idx)}
                  className="w-full p-4 text-left flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white"
                >
                  <span className="pr-4">{item.q}</span>
                  {isOpen ? (
                    <ChevronUp className="h-4 w-4 text-sky-400 shrink-0" />
                  ) : (
                    <ChevronDown className="h-4 w-4 text-slate-500 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <div className="p-4 pt-0 text-xs text-slate-300 leading-relaxed border-t border-slate-800/60">
                    <p className="pt-2">{item.a}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Report Structure Checklist */}
      <div className="p-6 rounded-xl border border-slate-800 bg-slate-900/60 space-y-4">
        <div className="flex items-center gap-2 text-emerald-400">
          <CheckCircle className="h-5 w-5" />
          <h2 className="text-base font-bold text-white">Internship Report Chapter Outline</h2>
        </div>
        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300">
          <li className="flex items-start gap-2 p-2.5 rounded bg-slate-950 border border-slate-800">
            <span className="font-mono font-bold text-sky-400">Ch 1:</span>
            <span>Introduction, Background, and Open Source Sustainability Problem</span>
          </li>
          <li className="flex items-start gap-2 p-2.5 rounded bg-slate-950 border border-slate-800">
            <span className="font-mono font-bold text-sky-400">Ch 2:</span>
            <span>Literature Survey on Repository Turnover & Metric Mining</span>
          </li>
          <li className="flex items-start gap-2 p-2.5 rounded bg-slate-950 border border-slate-800">
            <span className="font-mono font-bold text-sky-400">Ch 3:</span>
            <span>Feature Engineering & Domain Normalization Mathematics</span>
          </li>
          <li className="flex items-start gap-2 p-2.5 rounded bg-slate-950 border border-slate-800">
            <span className="font-mono font-bold text-sky-400">Ch 4:</span>
            <span>Machine Learning Architecture (k-NN & Softmax Logistic Regression)</span>
          </li>
          <li className="flex items-start gap-2 p-2.5 rounded bg-slate-950 border border-slate-800">
            <span className="font-mono font-bold text-sky-400">Ch 5:</span>
            <span>Experimental Results, Confusion Matrix, and Performance Evaluation</span>
          </li>
          <li className="flex items-start gap-2 p-2.5 rounded bg-slate-950 border border-slate-800">
            <span className="font-mono font-bold text-sky-400">Ch 6:</span>
            <span>Conclusion, Future Work (CI/CD Bot Integration), and References</span>
          </li>
        </ul>
      </div>
    </div>
  );
};
