import React from 'react';
import { Download, Code2, Database, Activity, BookOpen } from 'lucide-react';

export type ActiveTab = 'predictor' | 'dataset' | 'bundle' | 'guide';

interface TopBarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onDownloadAll: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ activeTab, onSelectTab, onDownloadAll }) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single text wordmark in display face */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-sky-500/10 border border-sky-500/20 text-sky-400">
            <Activity className="h-5 w-5" />
          </div>
          <span className="text-xl font-bold tracking-tight text-white whitespace-nowrap">
            RepoHealth
          </span>
        </div>

        {/* Zone 2: 4 clean single-line nav tabs */}
        <nav className="hidden md:flex items-center gap-1 text-sm font-medium">
          <button
            onClick={() => onSelectTab('predictor')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold tracking-wide transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'predictor'
                ? 'bg-slate-800 text-sky-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Activity className="h-3.5 w-3.5" />
            Predictor Studio
          </button>

          <button
            onClick={() => onSelectTab('dataset')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold tracking-wide transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'dataset'
                ? 'bg-slate-800 text-sky-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Database className="h-3.5 w-3.5" />
            Model Matrix & Data
          </button>

          <button
            onClick={() => onSelectTab('bundle')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold tracking-wide transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'bundle'
                ? 'bg-slate-800 text-sky-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Code2 className="h-3.5 w-3.5" />
            HTML / CSS / JS Bundle
          </button>

          <button
            onClick={() => onSelectTab('guide')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold tracking-wide transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'guide'
                ? 'bg-slate-800 text-sky-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <BookOpen className="h-3.5 w-3.5" />
            Internship Research Guide
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onDownloadAll}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-sky-400 hover:bg-sky-300 rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Download HTML/CSS/JS</span>
          </button>
        </div>
      </div>

      {/* Mobile nav row */}
      <div className="flex md:hidden border-t border-slate-800/60 px-4 py-2 overflow-x-auto gap-1 text-xs">
        <button
          onClick={() => onSelectTab('predictor')}
          className={`px-3 py-1.5 rounded-md whitespace-nowrap ${
            activeTab === 'predictor' ? 'bg-slate-800 text-sky-400' : 'text-slate-400'
          }`}
        >
          Predictor
        </button>
        <button
          onClick={() => onSelectTab('dataset')}
          className={`px-3 py-1.5 rounded-md whitespace-nowrap ${
            activeTab === 'dataset' ? 'bg-slate-800 text-sky-400' : 'text-slate-400'
          }`}
        >
          Model Matrix
        </button>
        <button
          onClick={() => onSelectTab('bundle')}
          className={`px-3 py-1.5 rounded-md whitespace-nowrap ${
            activeTab === 'bundle' ? 'bg-slate-800 text-sky-400' : 'text-slate-400'
          }`}
        >
          HTML/CSS/JS
        </button>
        <button
          onClick={() => onSelectTab('guide')}
          className={`px-3 py-1.5 rounded-md whitespace-nowrap ${
            activeTab === 'guide' ? 'bg-slate-800 text-sky-400' : 'text-slate-400'
          }`}
        >
          Research Guide
        </button>
      </div>
    </header>
  );
};
