import React, { useState } from 'react';
import {
  Code2,
  Copy,
  Check,
  Download,
  FileCode,
  Layers,
  Terminal,
  Play,
  Monitor,
} from 'lucide-react';
import {
  STANDALONE_HTML,
  STANDALONE_CSS,
  STANDALONE_JS,
  downloadFile,
} from '../utils/standaloneBundleGenerator';

export const StandaloneExportView: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<'html' | 'css' | 'js' | 'preview'>('html');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const getActiveCode = () => {
    switch (selectedFile) {
      case 'html':
        return STANDALONE_HTML;
      case 'css':
        return STANDALONE_CSS;
      case 'js':
        return STANDALONE_JS;
      default:
        return '';
    }
  };

  const handleCopy = (key: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleDownloadSingle = (fileType: 'html' | 'css' | 'js') => {
    switch (fileType) {
      case 'html':
        downloadFile('index.html', STANDALONE_HTML, 'text/html');
        break;
      case 'css':
        downloadFile('style.css', STANDALONE_CSS, 'text/css');
        break;
      case 'js':
        downloadFile('script.js', STANDALONE_JS, 'text/javascript');
        break;
    }
  };

  const handleDownloadAll = () => {
    downloadFile('index.html', STANDALONE_HTML, 'text/html');
    setTimeout(() => {
      downloadFile('style.css', STANDALONE_CSS, 'text/css');
    }, 250);
    setTimeout(() => {
      downloadFile('script.js', STANDALONE_JS, 'text/javascript');
    }, 500);
  };

  // Assembled standalone page for in-browser live iframe sandbox
  const assembledSrcDoc = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8" />
        <style>${STANDALONE_CSS}</style>
      </head>
      <body>
        ${STANDALONE_HTML.replace(/<!DOCTYPE html>[\s\S]*?<body>/i, '').replace(/<script src="script.js"><\/script>[\s\S]*?<\/html>/i, '')}
        <script>${STANDALONE_JS}</script>
      </body>
    </html>
  `;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 font-medium tracking-wider uppercase mb-1">
            <span>Vanilla Web Delivery</span>
            <span aria-hidden="true">·</span>
            <span>Zero Dependencies · Pure Browser ML</span>
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            Pure HTML / CSS / JS Standalone Package
          </h1>
          <p className="mt-2 text-sm text-slate-400 max-w-3xl">
            You requested standalone files with no Streamlit, no RAG, and no external backends.
            Here is the complete production bundle containing <strong>index.html</strong>, <strong>style.css</strong>, and <strong>script.js</strong>.
            You can preview it live, copy each file, or download all files for local submission.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownloadAll}
            className="px-4 py-2 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-2 transition-colors shadow-sm whitespace-nowrap"
          >
            <Download className="h-4 w-4" />
            <span>Download All 3 Files</span>
          </button>
        </div>
      </div>

      {/* Package Structure & Quick Instructions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-orange-500/10 text-orange-400 border border-orange-500/20">
            <FileCode className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">index.html</span>
              <button
                onClick={() => handleDownloadSingle('html')}
                className="text-[11px] text-sky-400 hover:text-sky-300 font-semibold"
              >
                Download
              </button>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Semantic markup, input forms, metric sliders, presets, and result tables.
            </p>
          </div>
        </div>

        <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400 border border-sky-500/20">
            <Layers className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">style.css</span>
              <button
                onClick={() => handleDownloadSingle('css')}
                className="text-[11px] text-sky-400 hover:text-sky-300 font-semibold"
              >
                Download
              </button>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              High-contrast dark mode styling, responsive CSS grid, zero external fonts required.
            </p>
          </div>
        </div>

        <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Terminal className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">script.js</span>
              <button
                onClick={() => handleDownloadSingle('js')}
                className="text-[11px] text-sky-400 hover:text-sky-300 font-semibold"
              >
                Download
              </button>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Full k-NN machine learning classifier with 30-sample benchmark dataset embedded.
            </p>
          </div>
        </div>
      </div>

      {/* Code Viewer / Live Preview Container */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden">
        {/* Tabs */}
        <div className="flex flex-wrap items-center justify-between border-b border-slate-800 bg-slate-950 px-4 py-2.5">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setSelectedFile('html')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                selectedFile === 'html'
                  ? 'bg-slate-800 text-sky-400'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              index.html
            </button>
            <button
              onClick={() => setSelectedFile('css')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                selectedFile === 'css'
                  ? 'bg-slate-800 text-sky-400'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              style.css
            </button>
            <button
              onClick={() => setSelectedFile('js')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                selectedFile === 'js'
                  ? 'bg-slate-800 text-sky-400'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              script.js
            </button>
            <button
              onClick={() => setSelectedFile('preview')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 ${
                selectedFile === 'preview'
                  ? 'bg-sky-500 text-slate-950'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Monitor className="h-3 w-3" />
              <span>Live Sandbox Preview</span>
            </button>
          </div>

          {selectedFile !== 'preview' && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleCopy(selectedFile, getActiveCode())}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded flex items-center gap-1.5 transition-colors"
              >
                {copiedKey === selectedFile ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5 text-slate-400" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
              <button
                onClick={() => handleDownloadSingle(selectedFile as 'html' | 'css' | 'js')}
                className="px-3 py-1.5 bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/30 text-sky-400 text-xs font-semibold rounded flex items-center gap-1.5 transition-colors"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download</span>
              </button>
            </div>
          )}
        </div>

        {/* Content View */}
        {selectedFile === 'preview' ? (
          <div className="p-4 bg-slate-950">
            <div className="mb-3 flex items-center justify-between text-xs text-slate-400">
              <span>Running in sandboxed iframe (Zero React, Zero external CDN dependencies)</span>
              <span className="font-mono text-emerald-400">● Live Standalone Instance</span>
            </div>
            <div className="rounded-lg border border-slate-800 overflow-hidden bg-[#0b0f19] h-[750px]">
              <iframe
                title="RepoHealth Standalone Sandbox"
                srcDoc={assembledSrcDoc}
                className="w-full h-full border-0"
                sandbox="allow-scripts"
              />
            </div>
          </div>
        ) : (
          <div className="relative">
            <pre className="p-6 text-xs font-mono text-slate-300 overflow-x-auto max-h-[650px] leading-relaxed bg-[#0b0f19]">
              <code>{getActiveCode()}</code>
            </pre>
          </div>
        )}
      </div>

      {/* Execution Instructions */}
      <div className="p-6 rounded-xl border border-slate-800 bg-slate-900/60 space-y-4">
        <h3 className="text-base font-bold text-white">How to Run on Any Computer</h3>
        <ol className="list-decimal list-inside space-y-2 text-xs text-slate-300">
          <li>Create a new directory named <code className="text-sky-300 font-mono">repohealth</code> on your computer.</li>
          <li>Save the three files inside it: <code className="text-sky-300 font-mono">index.html</code>, <code className="text-sky-300 font-mono">style.css</code>, and <code className="text-sky-300 font-mono">script.js</code>.</li>
          <li>Double click <code className="text-sky-300 font-mono">index.html</code> to open it in Chrome, Firefox, Edge, or Safari.</li>
          <li>The machine learning classification runs 100% locally in your browser memory — no Node.js, Python, or local server required!</li>
        </ol>
      </div>
    </div>
  );
};
