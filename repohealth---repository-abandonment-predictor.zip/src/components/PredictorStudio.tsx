import React, { useState } from 'react';
import {
  Search,
  RotateCcw,
  GitBranch,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Sliders,
  ExternalLink,
  ChevronRight,
  TrendingDown,
  TrendingUp,
  Layers,
  Sparkles,
} from 'lucide-react';
import { FEATURE_DEFINITIONS, LABEL_INFO, RepoSample } from '../data/benchmarkDataset';
import {
  DistanceMetric,
  PredictionResult,
  runKnnPredict,
} from '../ml/knnClassifier';
import {
  predictLogisticRegression,
  LogisticRegressionModel,
  DEFAULT_LOGISTIC_MODEL,
} from '../ml/logisticRegression';
import { fetchGitHubRepoMetrics, GitHubRepoDetails } from '../services/githubApi';

interface PredictorStudioProps {
  dataset: RepoSample[];
  logisticModel: LogisticRegressionModel;
  onOpenBundle: () => void;
}

export const PredictorStudio: React.FC<PredictorStudioProps> = ({
  dataset,
  logisticModel,
  onOpenBundle,
}) => {
  // Feature states: [daysSinceCommit, openIssuesRatio, contributorCount, commits90, avgResponseDays, releaseCount]
  const [features, setFeatures] = useState<[number, number, number, number, number, number]>([
    4, 0.15, 28, 75, 2.5, 6,
  ]);

  // Model parameters
  const [modelType, setModelType] = useState<'knn' | 'logistic'>('knn');
  const [kParam, setKParam] = useState<number>(3);
  const [distanceMetric, setDistanceMetric] = useState<DistanceMetric>('euclidean');
  const [distanceWeighted, setDistanceWeighted] = useState<boolean>(true);

  // GitHub Search state
  const [githubQuery, setGithubQuery] = useState<string>('facebook/react');
  const [isFetchingGithub, setIsFetchingGithub] = useState<boolean>(false);
  const [githubError, setGithubError] = useState<string | null>(null);
  const [fetchedRepo, setFetchedRepo] = useState<GitHubRepoDetails | null>(null);

  // Run predictions
  const knnResult: PredictionResult = runKnnPredict(
    features,
    dataset,
    kParam,
    distanceMetric,
    distanceWeighted
  );

  const logisticResult = predictLogisticRegression(features, logisticModel);

  // Active prediction based on chosen model
  const activeLabel = modelType === 'knn' ? knnResult.predictedLabel : logisticResult.predictedLabel;
  const activeProbs = modelType === 'knn' ? knnResult.classProbabilities : logisticResult.probabilities;
  const activeConfidence =
    modelType === 'knn'
      ? knnResult.confidence
      : Number((activeProbs[activeLabel] * 100).toFixed(1));

  const labelConfig = LABEL_INFO[activeLabel];

  const handleFeatureChange = (index: number, val: number) => {
    const updated = [...features] as [number, number, number, number, number, number];
    updated[index] = val;
    setFeatures(updated);
  };

  const handleApplyPreset = (type: 'healthy' | 'atRisk' | 'abandoned' | 'solo') => {
    switch (type) {
      case 'healthy':
        setFeatures([2, 0.12, 45, 130, 1.2, 9]);
        break;
      case 'atRisk':
        setFeatures([55, 0.58, 4, 14, 18, 1]);
        break;
      case 'abandoned':
        setFeatures([360, 0.94, 0, 0, 95, 0]);
        break;
      case 'solo':
        setFeatures([14, 0.72, 1, 38, 22, 2]);
        break;
    }
    setFetchedRepo(null);
    setGithubError(null);
  };

  const handleFetchGitHub = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!githubQuery.trim()) return;

    setIsFetchingGithub(true);
    setGithubError(null);

    try {
      const details = await fetchGitHubRepoMetrics(githubQuery);
      setFetchedRepo(details);
      setFeatures(details.extractedFeatures);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to query GitHub API';
      setGithubError(msg);
    } finally {
      setIsFetchingGithub(false);
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      {/* Intro Header */}
      <div className="mb-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-400 font-medium tracking-wider uppercase mb-1">
              <span>Computer Science & Empirical Software Engineering</span>
              <span aria-hidden="true">·</span>
              <span>In-Browser Machine Learning</span>
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
              Repository Abandonment Predictor
            </h1>
            <p className="mt-2 text-sm text-slate-400 max-w-3xl">
              Predict open-source software sustainability using multidimensional activity vectors.
              Evaluates commit lag, maintainer turnover, issue resolution latency, and release cadence through
              client-side k-NN and Softmax Logistic Regression.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenBundle}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-sky-400 bg-sky-950/40 border border-sky-800/60 rounded-lg hover:bg-sky-900/40 transition-colors whitespace-nowrap"
            >
              <span>View Pure HTML/CSS/JS Source</span>
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {/* Live GitHub Auto-Fetcher */}
        <div className="mt-6 p-4 rounded-xl border border-slate-800 bg-slate-900/70">
          <form onSubmit={handleFetchGitHub} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="relative flex-1">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                <Search className="h-4 w-4" />
              </div>
              <input
                type="text"
                value={githubQuery}
                onChange={(e) => setGithubQuery(e.target.value)}
                placeholder="Enter public GitHub repo, e.g. facebook/react or expressjs/express"
                className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-700/80 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent"
              />
            </div>
            <button
              type="submit"
              disabled={isFetchingGithub}
              className="px-5 py-2.5 bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-slate-950 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-2 whitespace-nowrap shadow-sm"
            >
              {isFetchingGithub ? (
                <div className="h-4 w-4 animate-spin rounded-full border-2 border-slate-950 border-t-transparent" />
              ) : (
                <GitBranch className="h-4 w-4" />
              )}
              <span>Fetch Live Metrics</span>
            </button>
          </form>

          {githubError && (
            <div className="mt-3 p-3 rounded-lg bg-rose-950/40 border border-rose-800/50 text-xs text-rose-300 flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
              <span>{githubError}</span>
            </div>
          )}

          {fetchedRepo && (
            <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-300">
              <div className="flex items-center gap-3">
                <span className="font-semibold text-white">{fetchedRepo.fullName}</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span>{fetchedRepo.stars.toLocaleString()} stars</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span>{fetchedRepo.openIssuesCount.toLocaleString()} open issues</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span>Last pushed: {new Date(fetchedRepo.pushedAt).toLocaleDateString()}</span>
              </div>
              <a
                href={fetchedRepo.htmlUrl}
                target="_blank"
                rel="noreferrer"
                className="text-sky-400 hover:text-sky-300 flex items-center gap-1 font-medium"
              >
                <span>View on GitHub</span>
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          )}
        </div>

        {/* Quick Presets Bar */}
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <span className="text-xs font-medium text-slate-400 mr-1">Empirical Presets:</span>
          <button
            onClick={() => handleApplyPreset('healthy')}
            className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 border border-slate-800 text-emerald-400 hover:bg-slate-800 transition-colors"
          >
            Active Framework (React/Vite)
          </button>
          <button
            onClick={() => handleApplyPreset('atRisk')}
            className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 border border-slate-800 text-amber-400 hover:bg-slate-800 transition-colors"
          >
            Maintenance Mode (Moment.js)
          </button>
          <button
            onClick={() => handleApplyPreset('abandoned')}
            className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 border border-slate-800 text-rose-400 hover:bg-slate-800 transition-colors"
          >
            Abandoned Legacy (Page.js)
          </button>
          <button
            onClick={() => handleApplyPreset('solo')}
            className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800 transition-colors"
          >
            Solo Maintainer Risk
          </button>
        </div>
      </div>

      {/* Main 2-Column Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Feature Controls (5 cols) */}
        <div className="lg:col-span-6 space-y-6">
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sliders className="h-4 w-4 text-sky-400" />
                <h2 className="text-base font-bold text-white">Repository Feature Vector (X)</h2>
              </div>
              <button
                onClick={() => setFeatures([4, 0.15, 28, 75, 2.5, 6])}
                className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
                title="Reset to default"
              >
                <RotateCcw className="h-3 w-3" />
                <span>Reset</span>
              </button>
            </div>

            <div className="mt-6 space-y-5">
              {FEATURE_DEFINITIONS.map((def, idx) => {
                const currentVal = features[idx];
                const impact = knnResult.featureImpacts[idx];

                return (
                  <div key={def.id} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-200">{def.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-white text-sm font-bold tabular-nums">
                          {currentVal}
                        </span>
                        <span className="text-slate-500 font-normal">{def.unit}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <input
                        type="range"
                        min={def.min}
                        max={def.max}
                        step={def.step}
                        value={currentVal}
                        onChange={(e) => handleFeatureChange(idx, parseFloat(e.target.value))}
                        className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400 focus:outline-none"
                      />
                      <input
                        type="number"
                        min={def.min}
                        max={def.max}
                        step={def.step}
                        value={currentVal}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          if (!isNaN(val)) handleFeatureChange(idx, val);
                        }}
                        className="w-20 px-2 py-1 text-right bg-slate-950 border border-slate-700 rounded text-xs font-mono text-white tabular-nums"
                      />
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-0.5">
                      <span>{def.description}</span>
                      <span
                        className={`font-semibold ${
                          impact.status === 'safe'
                            ? 'text-emerald-400'
                            : impact.status === 'warning'
                            ? 'text-amber-400'
                            : 'text-rose-400'
                        }`}
                      >
                        {impact.status === 'safe' ? 'Healthy' : impact.status === 'warning' ? 'Warning' : 'Critical'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Model Hyperparameters Card */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Layers className="h-4 w-4 text-sky-400" />
                <h3 className="text-sm font-bold text-white">Machine Learning Hyperparameters</h3>
              </div>
              <div className="flex items-center gap-1 p-0.5 bg-slate-950 rounded-lg border border-slate-800">
                <button
                  onClick={() => setModelType('knn')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                    modelType === 'knn' ? 'bg-sky-500 text-slate-950' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  k-NN
                </button>
                <button
                  onClick={() => setModelType('logistic')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                    modelType === 'logistic' ? 'bg-sky-500 text-slate-950' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Softmax Logistic
                </button>
              </div>
            </div>

            {modelType === 'knn' ? (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-2">
                <div>
                  <label className="block text-slate-400 mb-1">Neighbors (k):</label>
                  <select
                    value={kParam}
                    onChange={(e) => setKParam(parseInt(e.target.value, 10))}
                    className="w-full bg-slate-950 border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-white"
                  >
                    <option value={1}>k = 1</option>
                    <option value={3}>k = 3 (Default)</option>
                    <option value={5}>k = 5</option>
                    <option value={7}>k = 7</option>
                    <option value={9}>k = 9</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Distance Metric:</label>
                  <select
                    value={distanceMetric}
                    onChange={(e) => setDistanceMetric(e.target.value as DistanceMetric)}
                    className="w-full bg-slate-950 border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-white"
                  >
                    <option value="euclidean">Euclidean (L2)</option>
                    <option value="manhattan">Manhattan (L1)</option>
                    <option value="chebyshev">Chebyshev (L-inf)</option>
                    <option value="cosine">Cosine Distance</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Weighting Scheme:</label>
                  <select
                    value={distanceWeighted ? 'weighted' : 'uniform'}
                    onChange={(e) => setDistanceWeighted(e.target.value === 'weighted')}
                    className="w-full bg-slate-950 border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-white"
                  >
                    <option value="weighted">Inverse Distance (1/d)</option>
                    <option value="uniform">Uniform Voting</option>
                  </select>
                </div>
              </div>
            ) : (
              <div className="text-xs text-slate-400 pt-2 space-y-2">
                <p>
                  Multinomial Logistic Regression calculates class posterior probabilities via the Softmax activation:
                  <code className="ml-1 text-sky-300 font-mono">P(y=c|x) = exp(w_c·x + b_c) / Σ exp(w_j·x + b_j)</code>.
                </p>
                <div className="flex items-center gap-4 text-slate-300 font-mono text-[11px] pt-1">
                  <span>Epochs trained: {logisticModel.epochsTrained}</span>
                  <span aria-hidden="true">·</span>
                  <span>Latest loss: {logisticModel.lossHistory[logisticModel.lossHistory.length - 1]}</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Prediction Results & Explanations (7 cols) */}
        <div className="lg:col-span-6 space-y-6">
          {/* Main Prediction Card */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
              <div>
                <span className="text-xs uppercase tracking-wider text-slate-400 font-semibold">
                  Model Prediction Output
                </span>
                <div className="flex items-center gap-3 mt-1">
                  {activeLabel === 0 && <ShieldCheck className="h-7 w-7 text-emerald-400" />}
                  {activeLabel === 1 && <AlertTriangle className="h-7 w-7 text-amber-400" />}
                  {activeLabel === 2 && <ShieldAlert className="h-7 w-7 text-rose-400" />}
                  <span className={`text-2xl font-black tracking-tight ${
                    activeLabel === 0 ? 'text-emerald-400' : activeLabel === 1 ? 'text-amber-400' : 'text-rose-400'
                  }`}>
                    {labelConfig.name}
                  </span>
                </div>
              </div>

              {/* Health Index Score */}
              <div className="flex items-center gap-4 bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div className="text-right">
                  <span className="block text-[11px] text-slate-400 font-medium">Health Index</span>
                  <span className="text-xl font-mono font-black text-white tabular-nums">
                    {knnResult.healthIndexScore}
                    <span className="text-xs font-normal text-slate-500">/100</span>
                  </span>
                </div>
                <div className="h-9 w-px bg-slate-800" />
                <div className="text-right">
                  <span className="block text-[11px] text-slate-400 font-medium">Confidence</span>
                  <span className="text-xl font-mono font-black text-white tabular-nums">
                    {activeConfidence}%
                  </span>
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              {labelConfig.description}
            </p>

            {/* Probability Breakdown Bars */}
            <div className="space-y-2.5">
              <span className="text-xs font-semibold text-slate-400">Class Probability Distribution:</span>
              <div className="space-y-2">
                {LABEL_INFO.map((lbl, idx) => {
                  const prob = activeProbs[idx];
                  const percent = (prob * 100).toFixed(1);
                  return (
                    <div key={lbl.id} className="flex items-center gap-3 text-xs">
                      <span className="w-20 font-medium text-slate-300">{lbl.name}</span>
                      <div className="flex-1 h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                        <div
                          className="h-full rounded-full transition-all duration-300"
                          style={{
                            width: `${percent}%`,
                            backgroundColor: lbl.color,
                          }}
                        />
                      </div>
                      <span className="w-12 text-right font-mono font-semibold text-slate-300 tabular-nums">
                        {percent}%
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Maintainer Diagnostic & Recommendation */}
            <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-sky-400">
                <Sparkles className="h-3.5 w-3.5" />
                <span>Maintainer Diagnostic Report</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-normal">
                {knnResult.primaryRiskFactor}
              </p>
              <p className="text-xs text-slate-400 leading-relaxed pt-1 border-t border-slate-900">
                <strong className="text-slate-200">Recommendation:</strong> {knnResult.maintainerRecommendation}
              </p>
            </div>
          </div>

          {/* Factor Explainability Breakdown */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <span>Feature Explainability Decomposition</span>
              <span className="text-xs font-normal text-slate-400">(Domain Significance)</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {knnResult.featureImpacts.map((imp) => {
                const isHealthy = imp.status === 'safe';
                const isWarn = imp.status === 'warning';

                return (
                  <div
                    key={imp.featureId}
                    className="p-3 rounded-lg bg-slate-950 border border-slate-800/80 space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-200">{imp.featureName}</span>
                      <span
                        className={`font-mono text-xs font-bold tabular-nums ${
                          isHealthy ? 'text-emerald-400' : isWarn ? 'text-amber-400' : 'text-rose-400'
                        }`}
                      >
                        {imp.rawValue} {imp.unit.split(' ')[0]}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                      {isHealthy ? (
                        <TrendingUp className="h-3 w-3 text-emerald-400 shrink-0" />
                      ) : (
                        <TrendingDown className="h-3 w-3 text-rose-400 shrink-0" />
                      )}
                      <span className="line-clamp-2">{imp.insight}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Nearest Empirical Benchmark Repositories Table */}
          {modelType === 'knn' && (
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white">
                  Nearest Empirical Benchmark Neighbors (Top {kParam})
                </h3>
                <span className="text-xs text-slate-400 font-mono">
                  Metric: {distanceMetric}
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-semibold">
                      <th className="py-2.5 px-3">Repository</th>
                      <th className="py-2.5 px-3">True Label</th>
                      <th className="py-2.5 px-3 text-right">Distance</th>
                      <th className="py-2.5 px-3 text-right">Weight</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-300">
                    {knnResult.nearestNeighbors.map((n) => {
                      const lbl = LABEL_INFO[n.sample.label];
                      return (
                        <tr key={n.sample.id} className="hover:bg-slate-800/30">
                          <td className="py-2.5 px-3">
                            <div className="font-semibold text-white">{n.sample.name}</div>
                            <div className="text-[11px] text-slate-500 line-clamp-1">{n.sample.description}</div>
                          </td>
                          <td className="py-2.5 px-3">
                            <span
                              className={`font-semibold ${
                                n.sample.label === 0
                                  ? 'text-emerald-400'
                                  : n.sample.label === 1
                                  ? 'text-amber-400'
                                  : 'text-rose-400'
                              }`}
                            >
                              {lbl.name}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-400">
                            {n.distance}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-sky-400 font-semibold">
                            {n.weight}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
