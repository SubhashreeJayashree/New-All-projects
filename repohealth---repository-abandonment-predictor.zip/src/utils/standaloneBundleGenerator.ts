export const STANDALONE_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>RepoHealth — Machine Learning Repository Abandonment Predictor</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <div class="container">
    <div class="header">
      <span class="badge">AI / ML Computer Science Project</span>
      <h1>RepoHealth</h1>
      <p class="subtitle">Predict if an open-source GitHub repository will be abandoned using an in-browser k-Nearest Neighbors (k-NN) machine learning model.</p>
    </div>

    <!-- Quick Presets -->
    <div class="presets-section">
      <span class="section-label">Quick Test Presets:</span>
      <div class="preset-buttons">
        <button type="button" class="preset-btn" onclick="applyPreset('active')">Healthy (e.g. React/Vite)</button>
        <button type="button" class="preset-btn" onclick="applyPreset('atRisk')">At Risk (Maintenance)</button>
        <button type="button" class="preset-btn" onclick="applyPreset('abandoned')">Abandoned (Dormant)</button>
      </div>
    </div>

    <!-- Feature Input Grid -->
    <div class="card form-card">
      <h2 class="card-title">Repository Feature Vector</h2>
      <div class="form-grid">
        <div class="input-group">
          <label for="daysSinceCommit">
            <span>Days Since Last Commit</span>
            <span class="helper-text">(0 - 500 days)</span>
          </label>
          <input type="number" id="daysSinceCommit" value="4" min="0" max="500" />
        </div>

        <div class="input-group">
          <label for="openIssuesRatio">
            <span>Open Issues Ratio</span>
            <span class="helper-text">(0.0 to 1.0)</span>
          </label>
          <input type="number" id="openIssuesRatio" value="0.15" step="0.01" min="0" max="1" />
        </div>

        <div class="input-group">
          <label for="contributorCount">
            <span>Active Contributors</span>
            <span class="helper-text">(People with merged PRs)</span>
          </label>
          <input type="number" id="contributorCount" value="28" min="0" max="200" />
        </div>

        <div class="input-group">
          <label for="commits90">
            <span>Commits in Last 90 Days</span>
            <span class="helper-text">(Quarterly velocity)</span>
          </label>
          <input type="number" id="commits90" value="75" min="0" max="500" />
        </div>

        <div class="input-group">
          <label for="avgResponseDays">
            <span>Avg Issue Response Time</span>
            <span class="helper-text">(Days to first triage)</span>
          </label>
          <input type="number" id="avgResponseDays" value="2.5" step="0.5" min="0" max="365" />
        </div>

        <div class="input-group">
          <label for="releaseCount">
            <span>Releases in Last Year</span>
            <span class="helper-text">(Tags or releases)</span>
          </label>
          <input type="number" id="releaseCount" value="6" min="0" max="50" />
        </div>
      </div>

      <!-- Model Parameters -->
      <div class="params-row">
        <label for="kValue">Hyperparameter k:
          <select id="kValue">
            <option value="1">k = 1</option>
            <option value="3" selected>k = 3 (Recommended)</option>
            <option value="5">k = 5</option>
            <option value="7">k = 7</option>
          </select>
        </label>
        <label for="distanceMetric">Distance Metric:
          <select id="distanceMetric">
            <option value="euclidean" selected>Euclidean (L2)</option>
            <option value="manhattan">Manhattan (L1)</option>
          </select>
        </label>
      </div>

      <button id="predictBtn" type="button" class="primary-btn">Compute ML Prediction</button>
    </div>

    <!-- Output Section -->
    <div id="resultCard" class="card result-card hidden">
      <div class="result-header">
        <div>
          <span class="result-kicker">Predicted Sustainability Status</span>
          <h2 id="predictionText" class="result-status">Analyzing...</h2>
        </div>
        <div class="confidence-box">
          <span class="confidence-label">Model Confidence</span>
          <span id="confidenceText" class="confidence-value">0%</span>
        </div>
      </div>

      <div class="probability-bars">
        <div class="prob-row">
          <span class="prob-name">Healthy</span>
          <div class="prob-track"><div id="probHealthy" class="prob-fill fill-healthy" style="width: 0%"></div></div>
          <span id="probHealthyVal" class="prob-val">0%</span>
        </div>
        <div class="prob-row">
          <span class="prob-name">At Risk</span>
          <div class="prob-track"><div id="probAtRisk" class="prob-fill fill-at-risk" style="width: 0%"></div></div>
          <span id="probAtRiskVal" class="prob-val">0%</span>
        </div>
        <div class="prob-row">
          <span class="prob-name">Abandoned</span>
          <div class="prob-track"><div id="probAbandoned" class="prob-fill fill-abandoned" style="width: 0%"></div></div>
          <span id="probAbandonedVal" class="prob-val">0%</span>
        </div>
      </div>

      <!-- Nearest Neighbors Table -->
      <div class="neighbors-section">
        <h3 class="subheading">Nearest Empirical Benchmark Repositories (Top k)</h3>
        <table class="neighbors-table">
          <thead>
            <tr>
              <th>Repository</th>
              <th>True Label</th>
              <th>Distance</th>
              <th>Weight</th>
            </tr>
          </thead>
          <tbody id="neighborsTableBody">
            <!-- Populated via script.js -->
          </tbody>
        </table>
      </div>

      <div class="diagnosis-box">
        <h3 class="subheading">Automated Maintainer Diagnostic</h3>
        <p id="diagnosticText" class="diagnostic-copy"></p>
      </div>
    </div>

    <!-- Project Information for MCA Presentation -->
    <div class="card info-card">
      <h3 class="subheading">Academic Project Specification</h3>
      <ul class="info-list">
        <li><strong>Field:</strong> Machine Learning & Empirical Software Engineering (CS / MCA)</li>
        <li><strong>Algorithm:</strong> Normalized k-Nearest Neighbors (k-NN) classification</li>
        <li><strong>Feature Space:</strong> 6-dimensional activity vector normalized over empirical bounds</li>
        <li><strong>Architecture:</strong> 100% Client-side JavaScript. No backend server or external API required.</li>
      </ul>
    </div>

    <footer class="footer">
      <p>RepoHealth &copy; 2026. Built with Pure HTML, CSS, and Vanilla JavaScript.</p>
    </footer>
  </div>

  <script src="script.js"></script>
</body>
</html>`;

export const STANDALONE_CSS = `/* RepoHealth — Modern Clean Dark Theme (Zero Dependencies) */
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  background-color: #0b0f19;
  color: #e2e8f0;
  min-height: 100vh;
  padding: 32px 16px;
  line-height: 1.5;
}

.container {
  max-width: 860px;
  margin: 0 auto;
}

.header {
  margin-bottom: 24px;
}

.badge {
  display: inline-block;
  font-size: 0.75rem;
  font-weight: 600;
  color: #38bdf8;
  background: rgba(56, 189, 248, 0.1);
  border: 1px solid rgba(56, 189, 248, 0.25);
  padding: 4px 10px;
  border-radius: 9999px;
  margin-bottom: 12px;
  letter-spacing: 0.04em;
}

h1 {
  font-size: 2.25rem;
  font-weight: 800;
  color: #ffffff;
  letter-spacing: -0.02em;
  margin-bottom: 8px;
}

.subtitle {
  font-size: 1rem;
  color: #94a3b8;
  max-width: 680px;
}

/* Presets */
.presets-section {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 20px;
  flex-wrap: wrap;
}

.section-label {
  font-size: 0.85rem;
  color: #94a3b8;
}

.preset-buttons {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.preset-btn {
  background: #1e293b;
  border: 1px solid #334155;
  color: #cbd5e1;
  padding: 6px 14px;
  border-radius: 6px;
  font-size: 0.825rem;
  cursor: pointer;
  transition: all 0.2s ease;
}

.preset-btn:hover {
  background: #334155;
  color: #ffffff;
  border-color: #475569;
}

/* Card */
.card {
  background: #131c2e;
  border: 1px solid #22324d;
  border-radius: 12px;
  padding: 24px;
  margin-bottom: 24px;
}

.card-title {
  font-size: 1.15rem;
  font-weight: 700;
  color: #f1f5f9;
  margin-bottom: 20px;
}

/* Form Grid */
.form-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
  margin-bottom: 20px;
}

@media (max-width: 640px) {
  .form-grid {
    grid-template-columns: 1fr;
  }
}

.input-group label {
  display: flex;
  justify-content: space-between;
  font-size: 0.85rem;
  font-weight: 500;
  color: #cbd5e1;
  margin-bottom: 6px;
}

.helper-text {
  font-size: 0.75rem;
  color: #64748b;
  font-weight: 400;
}

input[type="number"], select {
  width: 100%;
  padding: 10px 12px;
  background: #0b0f19;
  border: 1px solid #334155;
  border-radius: 8px;
  color: #ffffff;
  font-size: 0.95rem;
  font-family: inherit;
  transition: border-color 0.2s;
}

input[type="number"]:focus, select:focus {
  outline: none;
  border-color: #38bdf8;
  box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
}

.params-row {
  display: flex;
  gap: 20px;
  margin-bottom: 20px;
  padding-top: 14px;
  border-top: 1px solid #22324d;
  flex-wrap: wrap;
}

.params-row label {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 0.85rem;
  color: #94a3b8;
}

.params-row select {
  width: auto;
  padding: 6px 10px;
}

/* Button */
.primary-btn {
  width: 100%;
  padding: 14px 20px;
  background: #38bdf8;
  color: #0b0f19;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 700;
  cursor: pointer;
  transition: background 0.2s, transform 0.1s;
}

.primary-btn:hover {
  background: #7dd3fc;
}

.primary-btn:active {
  transform: translateY(1px);
}

/* Result Card */
.result-card.hidden {
  display: none;
}

.result-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-bottom: 20px;
  border-bottom: 1px solid #22324d;
  margin-bottom: 20px;
  flex-wrap: wrap;
  gap: 16px;
}

.result-kicker {
  font-size: 0.8rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: #94a3b8;
}

.result-status {
  font-size: 2rem;
  font-weight: 800;
  margin-top: 4px;
}

.status-healthy { color: #10b981; }
.status-at-risk { color: #f59e0b; }
.status-abandoned { color: #f43f5e; }

.confidence-box {
  background: #0b0f19;
  padding: 12px 18px;
  border-radius: 8px;
  border: 1px solid #22324d;
  text-align: right;
}

.confidence-label {
  display: block;
  font-size: 0.75rem;
  color: #94a3b8;
}

.confidence-value {
  font-size: 1.5rem;
  font-weight: 800;
  color: #ffffff;
  font-variant-numeric: tabular-nums;
}

/* Probability Bars */
.probability-bars {
  margin-bottom: 24px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.prob-row {
  display: flex;
  align-items: center;
  gap: 12px;
}

.prob-name {
  width: 80px;
  font-size: 0.85rem;
  font-weight: 600;
  color: #cbd5e1;
}

.prob-track {
  flex: 1;
  height: 10px;
  background: #0b0f19;
  border-radius: 9999px;
  overflow: hidden;
}

.prob-fill {
  height: 100%;
  border-radius: 9999px;
  transition: width 0.4s ease;
}

.fill-healthy { background: #10b981; }
.fill-at-risk { background: #f59e0b; }
.fill-abandoned { background: #f43f5e; }

.prob-val {
  width: 45px;
  text-align: right;
  font-size: 0.85rem;
  font-weight: 600;
  color: #94a3b8;
  font-variant-numeric: tabular-nums;
}

/* Neighbors Table */
.neighbors-section {
  margin-bottom: 24px;
}

.subheading {
  font-size: 0.95rem;
  font-weight: 700;
  color: #f1f5f9;
  margin-bottom: 12px;
}

.neighbors-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.85rem;
}

.neighbors-table th {
  text-align: left;
  padding: 10px 12px;
  color: #94a3b8;
  font-weight: 600;
  border-bottom: 1px solid #334155;
  background: #0f172a;
}

.neighbors-table td {
  padding: 10px 12px;
  border-bottom: 1px solid #1e293b;
  color: #e2e8f0;
}

.neighbors-table tr:hover {
  background: rgba(255, 255, 255, 0.03);
}

.diagnosis-box {
  background: #0b0f19;
  border-left: 4px solid #38bdf8;
  padding: 16px;
  border-radius: 0 8px 8px 0;
}

.diagnostic-copy {
  font-size: 0.9rem;
  color: #cbd5e1;
}

/* Info Card */
.info-card {
  background: #0f172a;
}

.info-list {
  list-style: none;
  font-size: 0.85rem;
  color: #94a3b8;
}

.info-list li {
  margin-bottom: 8px;
}

.info-list strong {
  color: #f1f5f9;
}

.footer {
  text-align: center;
  font-size: 0.8rem;
  color: #64748b;
  margin-top: 32px;
}
`;

export const STANDALONE_JS = `/**
 * RepoHealth — Browser-Based Machine Learning Predictor
 * Algorithm: Normalized k-Nearest Neighbors (k-NN) Classification
 * Field: Empirical Software Engineering / AI & ML
 */

// 1. Embedded Benchmark Dataset (30 empirical open-source repositories)
// Features: [daysSinceCommit, openIssuesRatio, contributorCount, commits90, avgResponseDays, releaseCount]
// Labels: 0 = Healthy, 1 = At Risk, 2 = Abandoned
const benchmarkDataset = [
  // Class 0: Healthy
  { name: "facebook/react", x: [2, 0.12, 58, 142, 1.2, 9], y: 0 },
  { name: "vitejs/vite", x: [1, 0.09, 44, 180, 0.8, 14], y: 0 },
  { name: "expressjs/express", x: [4, 0.18, 28, 65, 2.5, 5], y: 0 },
  { name: "tiangolo/fastapi", x: [3, 0.15, 32, 95, 1.9, 7], y: 0 },
  { name: "rust-lang/rust", x: [1, 0.14, 85, 210, 0.6, 12], y: 0 },
  { name: "tailwindlabs/tailwindcss", x: [2, 0.11, 24, 88, 1.4, 8], y: 0 },
  { name: "pallets/flask", x: [6, 0.16, 20, 52, 2.8, 4], y: 0 },
  { name: "godotengine/godot", x: [1, 0.22, 60, 160, 1.5, 10], y: 0 },
  { name: "denoland/deno", x: [1, 0.17, 36, 130, 1.1, 16], y: 0 },
  { name: "vuejs/core", x: [3, 0.13, 26, 75, 2.1, 8], y: 0 },

  // Class 1: At Risk
  { name: "moment/moment", x: [45, 0.62, 5, 8, 18, 0], y: 1 },
  { name: "bower/bower", x: [95, 0.74, 2, 4, 35, 0], y: 1 },
  { name: "request/request", x: [80, 0.82, 1, 1, 40, 0], y: 1 },
  { name: "enzymejs/enzyme", x: [65, 0.68, 4, 6, 28, 0], y: 1 },
  { name: "tj/co", x: [75, 0.70, 2, 2, 30, 0], y: 1 },
  { name: "caolan/async", x: [50, 0.55, 6, 12, 15, 1], y: 1 },
  { name: "gulpjs/gulp", x: [40, 0.48, 8, 16, 12, 1], y: 1 },
  { name: "jashkenas/backbone", x: [85, 0.65, 3, 3, 24, 0], y: 1 },
  { name: "gruntjs/grunt", x: [60, 0.58, 4, 8, 20, 0], y: 1 },
  { name: "restify/node-restify", x: [35, 0.42, 9, 22, 11, 2], y: 1 },

  // Class 2: Abandoned
  { name: "visionmedia/page.js", x: [380, 0.94, 0, 0, 110, 0], y: 2 },
  { name: "lynndylanhurley/devise_token_auth", x: [290, 0.91, 1, 0, 85, 0], y: 2 },
  { name: "krisk/Fuse-legacy", x: [210, 0.88, 1, 1, 70, 0], y: 2 },
  { name: "lapwing/cheerio-tableparser", x: [450, 0.98, 0, 0, 160, 0], y: 2 },
  { name: "indutny/elliptic-legacy", x: [320, 0.89, 0, 0, 95, 0], y: 2 },
  { name: "ganlanyuan/tiny-slider", x: [260, 0.86, 1, 0, 75, 0], y: 2 },
  { name: "slackapi/hubot-slack-classic", x: [480, 0.99, 0, 0, 180, 0], y: 2 },
  { name: "Dogfalo/materialize", x: [350, 0.92, 1, 0, 90, 0], y: 2 },
  { name: "substack/node-optimist", x: [500, 1.00, 0, 0, 200, 0], y: 2 },
  { name: "facebookarchive/flux", x: [490, 0.97, 0, 0, 150, 0], y: 2 }
];

const labelNames = ["Healthy", "At Risk", "Abandoned"];
const labelClasses = ["status-healthy", "status-at-risk", "status-abandoned"];

// Normalization ceiling constants (domain boundaries)
const maxBounds = [500, 1.0, 60, 120, 90, 12];

function normalize(features) {
  return features.map((val, idx) => {
    const clamped = Math.max(0, Math.min(maxBounds[idx], val));
    return clamped / maxBounds[idx];
  });
}

// Distance Calculation Functions
function computeDistance(a, b, metric) {
  if (metric === "manhattan") {
    return a.reduce((sum, val, i) => sum + Math.abs(val - b[i]), 0);
  }
  // Euclidean (L2) by default
  return Math.sqrt(a.reduce((sum, val, i) => sum + Math.pow(val - b[i], 2), 0));
}

// k-NN Prediction Core
function predictKNN(inputFeatures, k = 3, metric = "euclidean") {
  const normInput = normalize(inputFeatures);

  const neighborDistances = benchmarkDataset.map((item, index) => {
    const normItem = normalize(item.x);
    const dist = computeDistance(normInput, normItem, metric);
    const weight = 1 / (dist + 0.001); // inverse-distance weighting
    return {
      index,
      name: item.name,
      dist,
      label: item.y,
      weight
    };
  });

  // Sort ascending by distance
  neighborDistances.sort((a, b) => a.dist - b.dist);
  const topK = neighborDistances.slice(0, k);

  // Compute weighted class votes
  const votes = [0, 0, 0];
  let totalWeight = 0;
  topK.forEach((neighbor) => {
    votes[neighbor.label] += neighbor.weight;
    totalWeight += neighbor.weight;
  });

  // Probabilities
  const probabilities = votes.map((v) => (totalWeight > 0 ? v / totalWeight : 0.33));
  const maxVote = Math.max(...votes);
  const predictedLabel = votes.indexOf(maxVote);
  const confidence = probabilities[predictedLabel];

  return {
    predictedLabel,
    confidence,
    probabilities,
    topK
  };
}

// DOM Interaction
document.addEventListener("DOMContentLoaded", () => {
  const predictBtn = document.getElementById("predictBtn");
  const resultCard = document.getElementById("resultCard");
  const predictionText = document.getElementById("predictionText");
  const confidenceText = document.getElementById("confidenceText");
  const diagnosticText = document.getElementById("diagnosticText");
  const neighborsTableBody = document.getElementById("neighborsTableBody");

  const probHealthy = document.getElementById("probHealthy");
  const probAtRisk = document.getElementById("probAtRisk");
  const probAbandoned = document.getElementById("probAbandoned");
  const probHealthyVal = document.getElementById("probHealthyVal");
  const probAtRiskVal = document.getElementById("probAtRiskVal");
  const probAbandonedVal = document.getElementById("probAbandonedVal");

  predictBtn.addEventListener("click", () => {
    const daysSinceCommit = parseFloat(document.getElementById("daysSinceCommit").value);
    const openIssuesRatio = parseFloat(document.getElementById("openIssuesRatio").value);
    const contributorCount = parseFloat(document.getElementById("contributorCount").value);
    const commits90 = parseFloat(document.getElementById("commits90").value);
    const avgResponseDays = parseFloat(document.getElementById("avgResponseDays").value);
    const releaseCount = parseFloat(document.getElementById("releaseCount").value);

    const k = parseInt(document.getElementById("kValue").value, 10);
    const metric = document.getElementById("distanceMetric").value;

    const inputFeatures = [daysSinceCommit, openIssuesRatio, contributorCount, commits90, avgResponseDays, releaseCount];

    if (inputFeatures.some(isNaN)) {
      alert("Please ensure all numeric inputs have valid numbers.");
      return;
    }

    const result = predictKNN(inputFeatures, k, metric);

    // Update Result UI
    predictionText.textContent = labelNames[result.predictedLabel];
    predictionText.className = "result-status " + labelClasses[result.predictedLabel];
    confidenceText.textContent = (result.confidence * 100).toFixed(1) + "%";

    // Update Probability Bars
    const p0 = (result.probabilities[0] * 100).toFixed(0);
    const p1 = (result.probabilities[1] * 100).toFixed(0);
    const p2 = (result.probabilities[2] * 100).toFixed(0);

    probHealthy.style.width = p0 + "%";
    probHealthyVal.textContent = p0 + "%";

    probAtRisk.style.width = p1 + "%";
    probAtRiskVal.textContent = p1 + "%";

    probAbandoned.style.width = p2 + "%";
    probAbandonedVal.textContent = p2 + "%";

    // Update Neighbors Table
    neighborsTableBody.innerHTML = "";
    result.topK.forEach((n) => {
      const row = document.createElement("tr");
      row.innerHTML = \`
        <td><strong>\${n.name}</strong></td>
        <td><span class="\${labelClasses[n.label]}">\${labelNames[n.label]}</span></td>
        <td>\${n.dist.toFixed(4)}</td>
        <td>\${n.weight.toFixed(2)}</td>
      \`;
      neighborsTableBody.appendChild(row);
    });

    // Diagnostic Feedback
    if (result.predictedLabel === 0) {
      diagnosticText.textContent = "Repository shows robust activity metrics with regular commits, manageable issue volume, and strong maintainer engagement.";
    } else if (result.predictedLabel === 1) {
      diagnosticText.textContent = "Warning: Moderate signs of maintenance fatigue detected. Key risks include declining commit cadence, delayed issue triage, or low release frequency.";
    } else {
      diagnosticText.textContent = "Critical: Strong markers of abandonment. With elongated commit gaps (>180 days) and unanswered issues, the repository is largely dormant.";
    }

    resultCard.classList.remove("hidden");
    resultCard.scrollIntoView({ behavior: "smooth", block: "nearest" });
  });

  // Run initial prediction on page load
  predictBtn.click();
});

// Preset loader
window.applyPreset = function(presetKey) {
  const presets = {
    active: { days: 3, issues: 0.12, contribs: 35, commits: 120, response: 1.5, releases: 8 },
    atRisk: { days: 55, issues: 0.58, contribs: 4, commits: 14, response: 18, releases: 1 },
    abandoned: { days: 340, issues: 0.92, contribs: 1, commits: 0, response: 90, releases: 0 }
  };

  const p = presets[presetKey];
  if (!p) return;

  document.getElementById("daysSinceCommit").value = p.days;
  document.getElementById("openIssuesRatio").value = p.issues;
  document.getElementById("contributorCount").value = p.contribs;
  document.getElementById("commits90").value = p.commits;
  document.getElementById("avgResponseDays").value = p.response;
  document.getElementById("releaseCount").value = p.releases;

  document.getElementById("predictBtn").click();
};
`;

export function downloadFile(filename: string, content: string, contentType: string = 'text/plain') {
  const blob = new Blob([content], { type: contentType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
